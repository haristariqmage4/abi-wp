<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly
}

class EM_Attendees_Booking_Admin {

	public function __construct() {
		add_action('admin_enqueue_scripts', array($this,'enqueue'));
    add_action('event_magic_menus', array($this, 'menus'));
		$this->current_page = isset($_GET['page']) ? $_GET['page'] : '';
	}

  public function menus(){
    add_submenu_page("", __('Add New Attendees Booking', 'eventprime-event-attendees-booking'), __('Add New Attendees Booking', 'eventprime-event-attendees-booking'), "manage_options", "em_add_new_attendee", array($this, 'attendee'));
    add_submenu_page("", __('Attendee Event', 'eventprime-event-attendees-booking'), __('Attendee Event', 'eventprime-event-attendees-booking'), "manage_options", "em_attendee_event", array($this, 'attendee'));
    add_submenu_page("", __('New Attendees Booking', 'eventprime-event-attendees-booking'), __('New Attendees Booking', 'eventprime-event-attendees-booking'), "manage_options", "em_new_attendee_booking", array($this, 'attendee'));
    add_submenu_page("", __('Attendees Booking', 'eventprime-event-attendees-booking'), __('Attendees Booking', 'eventprime-event-attendees-booking'), "manage_options", "em_attendee_booking", array($this, 'attendee'));
  }

  public function attendee() {
		wp_enqueue_style('em_admin_attendee_booking_css', plugin_dir_url(__DIR__) . 'admin/template/css/em_admin_attendee_booking_css.css', false, EVENTPRIME_VERSION);
    wp_enqueue_script('em-attendees-booking-controller');
    if($this->current_page == 'em_add_new_attendee'){
      wp_register_script('em-public', EM_BASE_URL . 'includes/templates/js/em-public.js', array('jquery', 'jquery-ui-datepicker'), EVENTPRIME_VERSION);

      wp_enqueue_script('em-full-calendar');
      wp_enqueue_script('em-full-interaction-calendar');
      wp_enqueue_script('em-full-daygrid-calendar');
      wp_enqueue_script('em-full-list-calendar');
      wp_enqueue_script('em-full-calendar-locales');
      wp_enqueue_script('em-full-calendar-moment');

      include_once('template/attendee_add.php' );
    }
    if($this->current_page == 'em_attendee_event'){
      include_once('template/attendee_event.php' );
    }
    if($this->current_page == 'em_new_attendee_booking'){
      include_once('template/new_attendee_booking.php' );
    }
    if($this->current_page == 'em_attendee_booking'){
    	if(isset($_GET['booking_id']) && !empty($_GET['booking_id'])){
    		wp_register_script('em-google-map', EM_BASE_URL . 'includes/js/em-map.js', array('jquery'), EVENTPRIME_VERSION);
      	include_once('template/attendee_booking.php' );
    	}
    }
  }

	public function enqueue(){
		wp_register_script('em-attendees-booking-controller', EMAB_BASE_URL.'includes/admin/template/js/em-attendees-booking-controller.js',array('em-angular-module'));
    wp_register_script('em-public', EM_BASE_URL . 'includes/templates/js/em-public.js', array('jquery', 'jquery-ui-datepicker'), EVENTPRIME_VERSION);
    wp_register_script('moment', EM_BASE_URL . 'includes/templates/js/moment.min.js', array(), EVENTPRIME_VERSION);


    /*wp_register_script('em-full-calendar', EM_BASE_URL . 'includes/templates/js/calendar-3.9.0.js', array('jquery', 'moment'), EVENTPRIME_VERSION);
    wp_register_script('em-full-calendar-locales', EM_BASE_URL . 'includes/templates/js/calendar-locales-3.9.0.js', array('em-full-calendar'), EVENTPRIME_VERSION);*/

    wp_register_script('em-full-calendar', EM_BASE_URL.'includes/templates/js/calendar-4.4.2/core/main.min.js', array(), EVENTPRIME_VERSION);
    wp_register_script('em-full-interaction-calendar', EM_BASE_URL.'includes/templates/js/calendar-4.4.2/interaction/main.min.js', array('em-full-calendar'), EVENTPRIME_VERSION);
    wp_register_script('em-full-daygrid-calendar', EM_BASE_URL.'includes/templates/js/calendar-4.4.2/daygrid/main.min.js', array('em-full-calendar'), EVENTPRIME_VERSION);
    wp_register_script('em-full-list-calendar', EM_BASE_URL.'includes/templates/js/calendar-4.4.2/list/main.min.js', array('em-full-calendar'), EVENTPRIME_VERSION);
    wp_register_script('em-full-calendar-locales', EM_BASE_URL.'includes/templates/js/calendar-4.4.2/core/locales-all.min.js', array('em-full-calendar'), EVENTPRIME_VERSION);
    wp_register_script('em-full-calendar-moment', EM_BASE_URL.'includes/templates/js/calendar-4.4.2/moment/main.js', array('em-full-calendar', 'moment'), EVENTPRIME_VERSION);

    wp_register_script('em-calendar-util', EM_BASE_URL . 'includes/templates/js/em-calendar-util.js', array('em-full-calendar', 'em-full-interaction-calendar', 'em-full-daygrid-calendar', 'em-full-list-calendar', 'em-public', 'em-full-calendar-locales', 'moment', 'em-full-calendar-moment'), EVENTPRIME_VERSION);

    wp_register_style('jquery-ui-css', EM_BASE_URL . 'includes/templates/css/jquery-ui.css', array(), EVENTPRIME_VERSION);
    wp_register_style('em-public-css', plugin_dir_url(__DIR__) . '/includes/templates/css/em_public.css', array('jquery-ui-css'), EVENTPRIME_VERSION);

    //wp_register_style('em-full-calendar-css', EM_BASE_URL . 'includes/templates/css/calendar.min.css', array(), EVENTPRIME_VERSION);

    wp_register_style('em-full-calendar-css', EM_BASE_URL . 'includes/templates/js/calendar-4.4.2/core/main.min.css', array('em-public-css'), EVENTPRIME_VERSION);
    wp_register_style('em-full-calendar-daygrid-css', EM_BASE_URL . 'includes/templates/js/calendar-4.4.2/daygrid/main.min.css', array(), EVENTPRIME_VERSION);
    wp_register_style('em-full-calendar-list-css', EM_BASE_URL . 'includes/templates/js/calendar-4.4.2/list/main.min.css', array(), EVENTPRIME_VERSION);

    wp_localize_script('em-public', 'em_js_vars', em_global_js_strings());
	}
}
new EM_Attendees_Booking_Admin;