<?php
wp_enqueue_script('em-public');
$gs_service = EventM_Factory::get_service('EventM_Setting_Service');
$global_settings = $gs_service->load_model_from_db();
$atts = [];$tag = '';$posts_per_page = 10;
$events_atts = shortcode_atts([
  'view' => 'month',
  'types' => array(),
  'sites' => array()
], $atts, $tag);

$event_service = EventM_Factory::get_service('EventM_Service');
$attendee_service = EventM_Factory::get_service('EventM_Attendees_Booking_Service');
if (event_m_get_param('em_types')) {
  $type_id = event_m_get_param('em_types');
  $type_service = EventM_Factory::get_service('EventTypeM_Service');
  $type_model = $type_service->load_model_from_db($type_id);
  if (!empty($type_model->id) && !empty($type_model->description)) {
    ?>    
    <div class="em_event_type_note">
      <?php echo $type_model->name; ?>
      <?php echo do_shortcode(wpautop($type_model->description)); ?>
    </div>
    <?php
  }
}
$currency_symbol = em_currency_symbol();
$request_data = $_REQUEST;
if(isset($request_data['events_view']) && !empty($request_data['events_view'])){
  $events_atts['view'] = sanitize_text_field($request_data['events_view']);
}
if(isset($request_data['em_types']) && !empty($request_data['em_types'])){
  $events_atts['types'] = $request_data['em_types'];
}
if(isset($request_data['em_venue']) && !empty($request_data['em_venue'])){
  $events_atts['sites'] = array($request_data['em_venue']);
}
$view = $events_atts['view'];
$form_action = !empty($events_page_id) ? get_permalink($events_page_id) : "";
$form_action = add_query_arg('events_view', $view, $form_action);
?>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<div class="kikfyre kf-container ep-attendee-container" ng-app="eventMagicApp" ng-controller="attendeeBookingCtrl" ng-cloak="">
  <!-----Operations bar Starts-->
  <div class="kf-operationsbar dbfl">
    <div class="kf-title difl"><?php _e('Attendees Booking','eventprime-event-attendees-booking'); ?></div>
    <div class="difr ep-support-links"><a target="__blank" href="https://eventprime.net/contact/"><?php _e('Submit Support Ticket', 'eventprime-event-attendees-booking'); ?></a></div>
    <div class="kf-nav dbfl">
      <ul>
        <li><a href="<?php echo admin_url().'admin.php?page=em_bookings'; ?>">Back</a></li>
        <li><a target="_blank" href="https://eventprime.net/how-manage-attendees-wordpress-events/"><?php _e('Attendee Manager Guide','eventprime-event-attendees-booking'); ?> <span class="dashicons dashicons-book-alt"></span></a></li>
        <!-- attendees booking section -->
        <li class="kf-toggle difr"></li>
      </ul>
    </div>
  </div>
  <!--  Operations bar Ends----->
  <div class="emagic">
    <?php if ((isset($global_settings->disable_filter_options) && $global_settings->disable_filter_options == 0) || !isset($global_settings->disable_filter_options)) { ?>
      <form id="em_event_search_form" class="ep-event_search_form dbfl" name="em_event_search_form" action="<?php echo $form_action; ?>">
        <input type="hidden" name="events_view" value="<?php echo $view;?>">
        <input type="hidden" name="page" value="em_add_new_attendee">
        <div class="em_event_views_wrap dbfl" >
          <div class="em_event-filter-reset difl"><a href="<?php echo admin_url('admin.php?page=em_add_new_attendee');?>"><?php _e('Reset Filters', 'eventprime-event-attendees-booking'); ?></a></div>
          <div class="em_event_views difr">
            <div class="ep-event-view-sort difl"><?php _e('View as', 'eventprime-event-attendees-booking'); ?></div>
            <?php //Profile Grid group ID  
            $gid = isset($_REQUEST['gid']) ? '&gid='.absint($_REQUEST['gid']) : '';  
            ?>
            <div class="ep-event-view-sort difl <?php echo $view == 'list' ? 'ep-active-view' : ''; ?>"><a href="<?php echo admin_url('admin.php?page=em_add_new_attendee&events_view=list');?>"><span class="difl"><i class="material-icons">view_list</i></span><?php _e('List', 'eventprime-event-attendees-booking'); ?></a></div>
            <div class="ep-event-view-sort difl <?php echo $view == 'card' ? 'ep-active-view' : ''; ?>"><a href="<?php echo admin_url('admin.php?page=em_add_new_attendee&events_view=card');?>"><span class="difl"><i class="material-icons">view_module</i></span><?php _e('Card', 'eventprime-event-attendees-booking'); ?></a></div>
            <div class="ep-event-view-sort difl <?php echo $view == 'day' ? 'ep-active-view' : ''; ?>"><a href="<?php echo admin_url('admin.php?page=em_add_new_attendee&events_view=day');?>"><span class="difl"><i class="material-icons">today</i></span><?php _e('Day', 'eventprime-event-attendees-booking'); ?></a></div>
            <div class="ep-event-view-sort difl <?php echo $view == 'week' ? 'ep-active-view' : ''; ?>"><a href="<?php echo admin_url('admin.php?page=em_add_new_attendee&events_view=week');?>"><span class="difl"><i class="material-icons">date_range</i></span><?php _e('Week', 'eventprime-event-attendees-booking'); ?></a></div>
            <div class="ep-event-view-sort difl <?php echo $view == 'month' ? 'ep-active-view' : ''; ?>"><a href="<?php echo admin_url('admin.php?page=em_add_new_attendee&events_view=month');?>"><span class="difl"><i class="material-icons">date_range</i></span><?php _e('Month', 'eventprime-event-attendees-booking'); ?></a></div>
          </div>
        </div>
        <!-- Filter -->
        <button id="ep-filter-bar-collapse-toggle"  type="button">
          <span class="ep-filters-toggle-text-show"><?php _e('Show Event Search', 'eventprime-event-attendees-booking'); ?></span>
          <span class="ep-filters-toggle-text-hide"><?php _e('Hide Event Search', 'eventprime-event-attendees-booking'); ?></span>
          <span class="tribe-bar-toggle-arrow"></span>
        </button>

        <div id="ep-event-filterbar" class="ep-event-filters dbfl">
          <div class="ep-event-filter-block difl">
            <div class="ep-event-filter-search">
              <div class='ep-filter-label dbfl'><?php _e('Search by keyword', 'eventprime-event-attendees-booking'); ?></div>
              <input type="hidden" name="em_s" value="1" />
              <input placeholder="<?php _e('Keyword', 'eventprime-event-attendees-booking'); ?>" class="em_input" type="text" name="em_search" id="em_search" value="<?php $data = event_m_get_param('em_search'); echo $data; ?>" />
            </div>
          </div>
          <!-- <a class="em_hide_filter" ><?php _e('View and Hide Filter', 'eventprime-event-attendees-booking'); ?></a>-->

          <div class="ep-event-filter-block difl">
            <div class="ep-event-types">
              <div class="ep-filter-label"><?php echo __('Search by Event Type', 'eventprime-event-attendees-booking'); ?></div>
              <div class="ep-event-title ep_menu_item_visible"><?php _e('Event Type','eventprime-event-attendees-booking'); ?></div>
              <div class="ep-event-types-wrap ep_menu_item_hide">
                <?php
                $eventType_service = EventM_Factory::get_service('EventTypeM_Service');
                if(isset($events_atts['types']) && !empty($events_atts['types']))
                  $types= $eventType_service->get_types(array('include'=>$events_atts['types']));
                else
                  $types = $eventType_service->get_types();
                $em_types = (array) event_m_get_param('em_types');
                if (count($types) > 0):
                  foreach ($types as $type):?>
                    <div class="ep-event-type-block">
                      <div class="em_radio">
                        <input type="checkbox" <?php echo !empty($events_atts['types']) ? in_array($type->id, $events_atts['types']) ? 'checked' : '' :'' ?> class="em_type_option" name="em_types[]" value="<?php echo $type->id; ?>" <?php if (in_array($type->id, $em_types)) echo 'checked'; ?> id="<?php echo $type->id; ?>"style="background-color: <?php echo '#' . $type->color; ?>" />
                        <label for="<?php echo $type->id; ?>"><?php echo $type->name; ?></label>
                      </div>
                    </div>
                    <?php
                  endforeach;
                endif;
                ?> 
              </div>
            </div>
          </div>
          <div class="ep-event-filter-block difl">
            <div class='start-end-date'>
              <div class="ep-filter-label"> <?php echo __('Search by Date', 'eventprime-event-attendees-booking'); ?></div>
              <div class="ep-event-date"> 
                <input type="text" placeholder="<?php echo __('Select Date', 'eventprime-event-attendees-booking'); ?>" readonly class="em_date" name="em_sd" value="<?php echo isset($_REQUEST['em_sd']) ? $_REQUEST['em_sd'] : ' '; ?>"/>
              </div>
            </div>
          </div>

          <div class="ep-event-filter-block difl">
            <div class='ep-event-venue-filter'>
              <div class="ep-filter-label"><?php echo __('Search by Event Site', 'eventprime-event-attendees-booking'); ?></div>
              <div class="ep-event-serach-venue">
                <?php
                $venue_service = EventM_Factory::get_service('EventM_Venue_Service');
                $all_venues = $venue_service->get_venues();
                if (count($all_venues) > 0): ?>
                  <select name="em_venue">
                    <option value=""><?php _e('Event Site', 'eventprime-event-attendees-booking'); ?></option>
                    <?php foreach ($all_venues as $venue): ?>
                      <option <?php echo in_array($venue->id, $events_atts['sites']) ? 'selected' : ''; ?>  value='<?php echo $venue->id; ?>'><?php echo $venue->name; ?></option>
                      <?php
                    endforeach;
                    ?>
                  </select>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <?php do_action('em_event_filter_form'); ?>
          <div class="ep-event-filter-block difl">
            <div class="ep-event-filter-search_buttons">    
              <input class="" type="submit" value="<?php _e('Search', 'eventprime-event-attendees-booking'); ?>"/>
            </div>
          </div>
        </div>
      </form> 
    <?php } ?>
  </div>
  <?php
  switch ($view) {
    case 'list':
    case 'day':
    case 'week':
    case 'month': include_once('event_views/calendar.php');
    break;
    default: include_once('event_views/card.php'); // Loading card view
  }
  ?>
</div>