<?php
wp_enqueue_script('em-public');
em_localize_map_info('em-google-map');
$event_service = EventM_Factory::get_service('EventM_Service');
$setting_service = EventM_Factory::get_service('EventM_Setting_Service');
$global_settings = $setting_service->load_model_from_db();
$user = wp_get_current_user();
// Get booking details
$booking_service = EventM_Factory::get_service('EventM_Booking_Service');
$bookings = $booking_service->get_bookings_by_user($user->ID);
$venue_service = EventM_Factory::get_service('EventM_Venue_Service');
$booking_service = EventM_Factory::get_service('EventM_Booking_Service');
// Add thickbox library for details pop up
add_thickbox();
$i = 0;
$booking_ids = event_m_get_param('booking_id');
$booking_ids = empty($booking_ids) ? '' : explode(',', $booking_ids);
if(!empty($booking_ids)){ ?>
  <div class="emagic ep-booking-confirmation-wrap">
    <?php
    foreach ($booking_ids as $b_id):
      $booking = $booking_service->load_model_from_db($b_id);
      if (empty($booking->id)) {
        printf(__('No such booking exists for Booking ID #%d', 'eventprime-event-attendees-booking'),$b_id);
        continue;
      }?>
      <?php if ($booking->user != $user->ID) continue; ?>  
      <div class="kf-booking-confirmation dbfl">
        <div class="kf-booking-confirmation-notice">
          <?php
          if ($booking->status == 'pending') {
            _e('Booking is Pending', 'eventprime-event-attendees-booking');
          } elseif ($booking->status == 'completed') {
            _e('Congratulations, your booking has been confirmed!', 'eventprime-event-attendees-booking');
          } elseif ($booking->status == 'cancelled') {
            _e('Your booking has been cancelled!', 'eventprime-event-attendees-booking');
          }
          ?>
        </div>
        <div class="kf-booked-event-details em_block dbfl">
          <div class="kf-booked-event-cover difl">
            <?php
            $event = $event_service->load_model_from_db($booking->event);
            if (!empty($event->cover_image_id)) {
              echo get_the_post_thumbnail($event->id, 'full');
            } else {?>
              <img height="150" width="150" src="<?php echo esc_url(plugins_url('/images/dummy_image_thumbnail.png', __FILE__)) ?>" alt="<?php _e('Dummy Image', 'eventprime-event-attendees-booking'); ?>" >
            <?php } ?>
            <div class="kf-booked-event-print em_bg dbfl em_block">
              <a href="<?php echo site_url(); ?>/wp-admin/admin-ajax.php?action=em_show_booking_details&id=<?php echo $booking->id; ?>" class="thickbox details bg_gradient bg_grad_button"><?php _e('View Details', 'eventprime-event-attendees-booking'); ?></a>
            </div>
            <div class="kf-booked-event-new-booking em_bg dbfl">
              <a href="<?php echo esc_url(admin_url().'admin.php?page=em_add_new_attendee');?>" class="details bg_gradient bg_grad_button"><?php _e('Add New Booking', 'eventprime-event-attendees-booking'); ?></a>
            </div>
          </div>
          <div class="kf-booked-event-details-wrap difl">
            <div class="kf-booked-event-name"> <?php echo $event->name; ?></div>
            <div class="kf-booked-event-date em_color"> <?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $event->start_date); ?></div>
            <!--   Add to Calendar-->
            <?php if (!empty($global_settings->gcal_sharing)): ?>
              <div id="add-to-google-calendar">
                <span><label><input type="text" id="event_<?php echo $event->id; ?>"  style="display: none" value="<?php echo $event->name; ?>"></label></span>
                <span>
                  <label><input type="text" id="s_date_<?php echo $event->id; ?>"  style="display: none"value="<?php echo em_showDateTime($event->start_date, true); ?>" ></label>
                </span>
                <span>
                  <label><input type="text" id="e_date_<?php echo $event->id; ?>"  style="display: none" value="<?php echo em_showDateTime($event->end_date, true); ?>" ></label>
                </span>
                <div onclick="em_gcal_handle_auth_click()" id="authorize-button" class="kf-event-add-calendar em_color dbfl" style="display: none;">
                  <img class="kf-google-calendar-add" src="<?php echo esc_url(plugins_url('/images/gcal.png', __FILE__)); ?>"/>
                  <a class="kf-add-calendar"><?php _e('Add To Calendar', 'eventprime-event-attendees-booking'); ?></a>
                </div>
                <?php if(em_current_time_by_timezone() < $event->start_date): ?>
                  <div class="pm-edit-user pm-difl">
                    <div onclick="em_add_to_calendar('<?php echo $event->id; ?>')" id="addToCalendar" style="display: none;" class="kf-event-add-calendar em_color dbfl">
                      <img class="kf-google-calendar-add" src="<?php echo esc_url(plugins_url('/images/gcal.png', __FILE__)); ?>">
                      <a class="kf-add-calendar"><?php _e('Add To Calendar', 'eventprime-event-attendees-booking'); ?></a>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="pm-popup-mask"></div>    
                <div id="pm-change-password-dialog" style="display:none">
                  <div class="pm-popup-container">
                    <div class="pm-popup-title pm-dbfl pm-bg-lt pm-pad10 pm-border-bt">
                      <div class="title"><?php _e('Event Added', 'eventprime-event-attendees-booking'); ?>
                        <div class="pm-popup-close pm-difr">
                          <img src="<?php echo esc_url(plugins_url('/images/popup-close.png', __FILE__)); ?>"  height="24px" width="24px">
                        </div>
                      </div>
                      <div class="pm-popup-action pm-dbfl pm-pad10 pm-bg">
                        <div class="pm-login-box GCal-confirm-message">
                          <div class="pm-login-box-error pm-pad10" style="" id="pm_reset_passerror"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            <?php endif; ?>
            <div class="kf-booked-event-description">
              <?php echo wpautop(do_shortcode($event->description)); ?>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    <?php
    $gmap_api_key = em_global_settings('gmap_api_key');
    if (!empty($event->venue)):
      $venue = $venue_service->load_model_from_db($event->venue);
      if (!empty($venue->id) && !empty($gmap_api_key) && !empty($venue->address)):?>
        <div class="kf-event-venue-info difr">
          <div class="kf-booked-event-venue-name"><?php echo $venue->name ?></div>
          <div class="kf-booked-event-venue-address"><?php echo $venue->address; ?></div>
          <?php $direction_links = '<a target="blank" href="https://www.google.com/maps?saddr=My+Location&daddr=' . $venue->address . '">' . $venue->name . '</a> '; ?>
          <div class="em_venue_dir"><?php _e('Directions', 'eventprime-event-attendees-booking'); ?> : <?php echo $direction_links; ?></div>
          <div data-venue-id="<?php echo $venue->id; ?>" id="em_booking_map_canvas" style="height: 400px;"></div>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    <script type="text/javascript">
      document.addEventListener("DOMContentLoaded", function (event) {
        jQuery(function () {
          em_load_map('booking', 'em_booking_map_canvas');
        });
      });
    </script>
  </div><?php
}?>