<?php
global $paged;
$gs_service = EventM_Factory::get_service('EventM_Setting_Service');
$attendee_service = EventM_Factory::get_service('EventM_Attendees_Booking_Service');
$event_service = EventM_Factory::get_service('EventM_Service');
$global_settings = $gs_service->load_model_from_db();
$currency_symbol = em_currency_symbol();
//$events_atts = array("view" => 'card', "types" => array(), "sites" => array());
if(isset($_GET['paged']) && !empty($_GET['paged'])){
  $paged = sanitize_text_field($_GET['paged']);
  set_query_var('paged', $paged);
}
$the_query = $attendee_service->attendee_events_get_events_the_query(array(),$events_atts);
$posts = $the_query->posts;
$atts = array();
$posts = apply_filters('ep_filter_front_events',$posts,$atts);
$posts = array_filter($posts, function($post){ return $post->post_status !== 'draft'; });
$timestamp = current_time('timestamp');
$i = 0;
?>    
<div class="emagic">
  <?php 
  if (!empty($posts)) : ?>
    <div class="em_cards">
      <!-- the loop -->
      <?php foreach ($posts as $post) :  
        $event = $event_service->load_model_from_db($post->ID);
        //if($event->end_date < time()) continue;
        // check for booking allowed
        $booking_allowed = 1;
        if((isset($event->parent) && !empty($event->parent)) && (isset($event->enable_recurrence_automatic_booking) && !empty($event->enable_recurrence_automatic_booking))){
          // if event is recurring and parent has automatic booking enable than not allowed
          $booking_allowed = 0;
        }
        $event->url = admin_url('admin.php?page=em_attendee_event&event='.$event->id) ?>
        <div class="em_card difl <?php if (em_is_event_expired($event->id)) echo 'emcard-expired'; ?> <?php echo empty($event->enable_booking) ? 'em_event_disabled' : ''; ?>">
          <!-- <div class="em_event_cover dbfl">
            <?php if (!empty($event->cover_image_id)): ?>                            
              <a href="<?php echo $event->url; ?>"><?php echo get_the_post_thumbnail($event->id,'large'); ?></a>
            <?php else: ?>
              <a href="<?php echo $event->url; ?>"><img src="<?php echo esc_url(EM_BASE_FRONT_IMG_URL.'dummy_image.png'); ?>" alt="<?php _e('Dummy Image','eventprime-event-attendees-booking'); ?>" ></a>
            <?php endif; ?>
          </div> -->
          <div class="em_event_cover dbfl">
            <?php 
            $thumbImage = esc_url(EM_BASE_FRONT_IMG_URL.'dummy_image.png');
            if (!empty($event->cover_image_id)): ?>
                <?php 
                $thumbImage = wp_get_attachment_image_src($event->cover_image_id, 'large')[0];
                if(empty($thumbImage)){
                    $thumbImage = get_the_post_thumbnail($event->id,'large');
                    if(isset($event->parent) && !empty($event->parent) && empty($thumbImage)){
                        $thumbImage = get_the_post_thumbnail($event->parent,'large');
                    }
                }?>
                <a href="<?php echo $event->url; ?>">
                    <?php //echo $thumbImage; ?>
                    <img src="<?php echo $thumbImage; ?>" alt="<?php _e('Event Cover Image', 'eventprime-event-calendar-management');?>">
                </a>
            <?php else: ?>
                <a href="<?php echo $event->url; ?>"><img src="<?php echo esc_url(EM_BASE_FRONT_IMG_URL.'dummy_image.png'); ?>" alt="<?php _e('Dummy Image','eventprime-event-calendar-management'); ?>" class="em-no-image" ></a>
            <?php endif; ?>
        </div>
          <div class="dbfl em-card-description">
            <div class="em_event_title em_block dbfl em_wrap"  title="<?php  echo $event->name; ?>"><a href="<?php echo $event->url; ?>"><?php echo $event->name; ?></a></div>
            <?php   $start_date = null; $end_date = null; $start_time = null; $end_time = null; $day = null;
            if (em_compare_event_dates($event->id)){
              $day = date_i18n(get_option('date_format'),$event->start_date);
              $start_time = date_i18n(get_option('time_format'),$event->start_date);
              $end_time = date_i18n(get_option('time_format'),$event->end_date);
            }
            else
            {
              $start_date = date_i18n(get_option('date_format').' '.get_option('time_format'),$event->start_date);
              $end_date = date_i18n(get_option('date_format').' '.get_option('time_format'),$event->end_date);
            }?>
            <?php if(!empty($day)): ?>
              <div class="em_event_start difl em_color em_wrap">
                <?php echo $day; ?>
              </div>
              <div class="em_event_start difl em_color em_wrap"><?php echo $start_time.'  to  '.$end_time; ?></div>
            <?php else: ?>
              <div class="em_event_start difl em_color em_wrap">
                <?php echo $start_date; ?> -    
              </div>
              <div class="em_event_start difl em_color em_wrap">
                <?php echo $end_date; ?>  
              </div>
            <?php endif; ?> 
            <?php 
            if(!empty($event->venue)){  
              $venue_service = EventM_Factory::get_service('EventM_Venue_Service');
              $venue = $venue_service->load_model_from_db($event->venue);
              if(!empty($venue->id)){  ?>
                <div class="em_event_address dbfl" title="<?php echo $venue->address; ?>"><?php echo $venue->address; ?></div>
                <?php 
              }
            }?>
            <?php if(!empty($event->description)) { ?>
              <div class="em_event_description dbfl"><?php echo $event->description; ?></div>
            <?php } ?>
            <?php if(!empty($event->enable_booking) && !empty($event->hide_booking_status)):
              $sum = $event_service->booked_seats($event->id);
              $capacity = em_event_seating_capcity($event->id);
              ?>  
              <div class="dbfl">
                <div class="kf-event-attr-value dbfl">  
                  <?php if ($capacity > 0): ?>
                    <div class="dbfl">
                      <?php echo $sum; ?> / <?php echo $capacity; ?> 
                    </div>
                    <?php $width = ($sum / $capacity) * 100; ?>
                    <div class="dbfl">
                      <div id="progressbar" class="em_progressbar dbfl">
                        <div style="width:<?php echo $width . '%'; ?>" class="em_progressbar_fill em_bg" ></div>
                      </div>
                    </div>
                    <?php
                  else:
                    echo '<div class="dbfl">' . $sum . ' '.__('Sold','eventprime-event-attendees-booking').'</div>';
                    ?>
                  <?php endif; ?>
                </div>
              </div>  
              <?php
            endif;?>
          </div>
          <div class="em-cards-footer dbfl">
            <!-- <div class="em_event_price  difl">
              <?php 
              /* echo !empty($event->ticket_price) ? $currency_symbol.$event->ticket_price : ''; */ 
              ?>
            </div> -->
            <div class="em_event_price  difl">
                <?php 
                $ticket_price = $event->ticket_price;
                $ticket_price = apply_filters('event_magic_load_calender_ticket_price', $ticket_price, $event);
                // check if show one time event fees at front enable
                if($event->show_fixed_event_price){
                    if($event->fixed_event_price > 0){
                        $ticket_price = $event->fixed_event_price;
                    }
                }
                if(!is_numeric($ticket_price)){
                    echo $ticket_price;
                }
                else{
                    echo !empty($ticket_price) ? em_price_with_position($ticket_price) : '';
                } ?>
            </div>
            <?php do_action('event_magic_card_view_after_price',$event); ?>                        
            <div class="kf-tickets-button difr">
              <div class="em_event_attr_box em_eventpage_register difl">
                <?php if($event_service->is_bookable($event) && absint($event->custom_link_enabled) != 1): $current_ts = em_current_time_by_timezone();?>
                  <?php if($event->status == 'expired'):?>
                    <div class="em_header_button em_event_expired kf-tickets"><?php echo em_global_settings_button_title("Bookings Expired",'eventprime-event-attendees-booking'); ?></div>
                  <?php elseif($current_ts>$event->last_booking_date): ?>
                    <div class="em_header_button em_booking-closed kf-tickets"><?php echo em_global_settings_button_title("Bookings Closed",'eventprime-event-attendees-booking'); ?></div>
                  <?php elseif($current_ts<$event->start_booking_date): ?>  
                    <div class="em_header_button em_not_started kf-tickets"><?php echo em_global_settings_button_title("Bookings not started yet",'eventprime-event-attendees-booking'); ?></div>
                  <?php else: ?>
                    <?php 
                    if(!empty($booking_allowed)): ?>
                      <form action="<?php echo admin_url('admin.php?page=em_new_attendee_booking'); ?>" method="post" name="em_attendee_booking<?php echo $event->id ?>">
                        <button type="button" class="em_header_button em_event-booking kf-tickets" name="tickets" ng-click="em_event_attendee_booking(<?php echo $event->id ?>)" id="em_attendee_booking"><?php echo em_global_settings_button_title('Book Now','eventprime-event-attendees-booking'); ?></button>
                        <input type="hidden" name="event_id" value="<?php echo $event->id; ?>" />
                        <input type="hidden" name="venue_id" value="<?php echo $event->venue; ?>" />
                      </form>
                    <?php endif; ?>
                  <?php endif; ?>
                <?php elseif($event->status == 'publish'): ?>
                  <div class="em_event_attr_box em_eventpage_register difl">
                    <div class="em_header_button em_not_bookable kf-tickets"><?php echo em_global_settings_button_title("Bookings Closed",'eventprime-event-attendees-booking'); ?></div>
                  </div>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
        <?php
        $i++;?>
      <?php endforeach; ?>
    </div>     
    <!-- <?php if($the_query->max_num_pages > 1): ?>
      <nav class="prev-next-posts">
        <div class="prev-posts-link">
          <?php echo get_next_posts_link('Older Entries', $the_query->max_num_pages); // display older posts link  ?>
        </div>
        <div class="next-posts-link">
          <?php echo get_previous_posts_link('Newer Entries'); // display newer posts link  ?>
        </div>
      </nav>
    <?php endif; ?> -->
    <?php if($the_query->max_num_pages > 1):?>
      <?php $curr_page = $the_query->query_vars['paged'];?>
      <div class="ep-view-load-more ep-view-load-more-wrap dbfl" onclick="em_view_load_more_events('.ep-view-load-more','.ep-loading-view-btn','.em_cards')" data-curr_page="<?php echo $curr_page?>" data-loading="<?php _e('Loading...');?>" data-loaded="<?php _e('Load More');?>" data-max_page="<?php echo $the_query->max_num_pages;?>" data-sites="<?php echo implode(',', $events_atts['sites']);?>" data-types="<?php echo implode(',', $events_atts['types']);?>" data-show="<?php echo $posts_per_page;?>" >
          <div class="ep-loading-view-btn em_color"><?php _e('Load More');?></div>
      </div>
    <?php endif;?>
  <?php else: ?>
    <?php if($_POST): ?>
      <article class="em-no-attendee-event">
        <p><?php _e('No events match your criterion.','eventprime-event-attendees-booking'); ?></p>
      </article>
    <?php else: ?>
      <article class="em-no-attendee-event">
        <p><?php _e('There are no Events available right now.','eventprime-event-attendees-booking'); ?></p>
      </article>
    <?php endif; ?>
  <?php endif; ?>
  <?php
  if(empty($i)):?>
    <article class="em-no-attendee-event">
      <p><?php _e('There are no active Events available right now.','eventprime-event-attendees-booking'); ?></p>
    </article>
    <?php
  endif;?>
</div>