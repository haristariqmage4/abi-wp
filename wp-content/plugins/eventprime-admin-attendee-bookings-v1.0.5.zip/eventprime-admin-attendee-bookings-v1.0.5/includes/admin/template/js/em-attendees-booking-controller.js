eventMagicApp.controller('attendeeBookingCtrl', function($scope, $http, EMRequest, Seat, $compile, $filter){
  $scope.data = {};
  $scope.requestInProgress = false;
  $scope.formErrors = [];
  $scope.selections = [];
  $scope.paged = 1;

  $scope.data = {};
  $scope.event = {};
  $scope.price = 0;
  $scope.order = {};
  $scope.selectedSeats = [];
  $scope.requestInProgress = false;
  $scope.orders = [];
  $scope.order_ids = [];
  $scope.order_id_arr = [];
  $scope.currency_symbol;
  $scope.venue_id;
  $scope.event_id;
  $scope.bookable = true;   
  $scope.booking_notice;
  $scope.is_timer_on = false;
  $scope.minute = 0;
  $scope.second = 0;
  $scope.errorMsg = '';
  $scope.booking_quantity = 0;
  $scope.attendee_names = [];
  $scope.is_custom_booking_field = 0;
  $scope.event_multi_price_option = {val: 0};
  $scope.setFocus = 0;
  $scope.em_selected_seat_price = 0;
  $scope.seatAttendeeInfo = [];
  $scope.standingAttendeeInfo = [];
  $scope.em_all_variation_name = [];
  $scope.applyWoocommerce = 0;
  $scope.fixed_event_price = 0;

  $ = jQuery;
  $scope.progressStart = function()
  {
    $scope.requestInProgress = true;
  }

  $scope.progressStop = function()
  {
    $scope.requestInProgress = false;
  }

  $scope.em_event_attendee_booking = function(id){
    if (id > 0){ 
      var formName = 'em_attendee_booking' + id;
      jQuery('form[name=' + formName + ']').submit();
    }
  }

  // Called at initialization
  $scope.initialize = function (venue_id, event_id) {
    $scope.venue_id = venue_id;
    $scope.event_id = event_id;
    $scope.load_payment_configuration($scope.event_id);
  }

  // Loading Global payment configuration
  $scope.load_payment_configuration = function(event_id){   
    $scope.request = {};
    $scope.request.event_id = event_id || $scope.event_id;
    $scope.event_id = event_id || $scope.event_id;
    EMRequest.send('em_load_payment_configuration', $scope.request).then(function (response) {
      $scope.progressStop();
      if(!response.data.is_payment_configured && response.data.ticket_price>0){
        $scope.errorMsg= 'Payment system is not configured.';
        return;
      }
      $scope.payment_processors= response.data.payment_prcoessor;
      $scope.currency_symbol= response.data.currency_symbol; 
      // As payment system is confiured loading Event's data for booking
      $scope.loadEventForBooking(event_id);
    });
  }
  
  $scope.loadEventForBooking = function(event_id){
    $scope.request = {};
    $scope.request.event_id = event_id || $scope.event_id;
    $scope.event_id = event_id || $scope.event_id;

    // Loading Seats and other payment options related to Event
    $scope.progressStart();
    EMRequest.send('em_load_event_for_booking', $scope.request).then(function (response) {
      $scope.progressStop();
      $scope.event = response.data;
      /* $scope.event.ticket_price = 0; */
      $scope.setSeatContainerWidth(); 

      if(response.data.venue.type == "seats")
        $scope.allowSeatSelectionUpdate();
      else
        $scope.allowSeatQuantityUpdate();

      $scope.display_cart(false);

      // add multi price default option
      if($scope.event.price_option_data && $scope.event.price_option_data.length > 0){
        angular.forEach($scope.event.price_option_data, function(value, key){
          if(value.is_default == 1){
            $scope.event_multi_price_option.val = value;
          }
          $scope.em_all_variation_name[value.id] = value.name;
        });
      }
    });
  }

  $scope.setSeatContainerWidth = function(){
    if( $scope.event.seats.length > 0 ){
      var seat_container_width = ($scope.event.seats[0].length*35) + 40 + "px";
      $scope.seat_container_width = { "width" : seat_container_width };
    }
  }

  $scope.allowSeatQuantityUpdate= function(){
    $scope.selectedSeats = [];
    var order_exist = false;
    if($scope.orders.length > 0){  
      for(var i = 0;i < $scope.orders.length;i++){   
        if($scope.orders[i].event_id == $scope.event_id){
          document.getElementById("standing_order_quantity").value = $scope.orders[i].quantity;
          $scope.update_cart = true;
          order_exist = true;
          break;
        }
      }
    } 
    if(!order_exist){
      $scope.update_cart = false;
      $scope.booking_quantity = 1;
    }
  }

  // Allows selection and deselection of seats after order creation.
  $scope.allowSeatSelectionUpdate = function(){
    $scope.selectedSeats = [];
    if($scope.orders.length > 0)
    {  
      for(var i = 0;i < $scope.orders.length;i++)
      {   
        if($scope.orders[i].event_id == $scope.event_id)
        {
          var seatPositions = $scope.orders[i].seat_pos;
          for(var j = 0;j < seatPositions.length;j++)
          {   
            var seatIndexes = seatPositions[j].split("-");
            var row = $scope.event.seats[seatIndexes[0]];
            var seat = row[seatIndexes[1]];
            seat.type = 'selected';
            seat.seatColor = '#'+$scope.event.venue.selected_seat_color;
            seat.seatBorderColor = '3px solid #'+$scope.event.venue.selected_seat_color;
            $scope.update_cart = true;
            $scope.selectedSeats.push(seat);
          }
        }
      }
    } 

    if($scope.selectedSeats.length == 0)
      $scope.update_cart = false;
  }

  $scope.display_cart = function(show){
    if(show){
      $scope.show_cart = true; 
    }  
    else{
      $scope.show_cart = false;
    } 
  }

  $scope.calculate_price = function(){
    $scope.price = 0;
    $scope.item_numbers = 0
    for(var i = 0;i < $scope.orders.length;i++){
      //$scope.price += $scope.orders[i].quantity * $scope.orders[i].single_price;
      $scope.item_numbers += $scope.orders[i].quantity;
    }
  }

  $scope.update_order_ids = function(){
    var order_ids = [];
    for(var i = 0;i < $scope.orders.length;i++)
      order_ids.push($scope.orders[i].order_id);

    $scope.order_ids = order_ids.join(',');    
  }

  $scope.orderStandings = function(){
    $scope.progressStart();
    $scope.order = {};
    $scope.request = {
      'event_id': $scope.event_id
    };
    var noBooking = 0;
    // Order quantity related checks
    var quantity = document.getElementById("standing_order_quantity").value;
    if(!(quantity > 0)){
      alert('Please enter at least 1 booking to proceed ahead');
      $scope.progressStop();
      return;
    } else {
      if($scope.attendee_names.length > 0) {
        if($scope.event.custom_booking_field_data && $scope.event.custom_booking_field_data.length > 0){
          $scope.is_custom_booking_field = 1;
          var cbfd = {};
          $scope.event.custom_booking_field_data.forEach(function(data, dk){
            if(data){
              cbfd[data.type] = data.required;
            }
          });

          $(".em-booking-standing-data").html('');
          $scope.attendee_names.forEach(function(item, index) {
            if(noBooking == 0){
              angular.forEach(item, function(type, type_key){
                if(isNaN(type_key)){
                  delete item[type_key];
                } else{
                  angular.forEach(type, function(indx, indx_key){
                    angular.forEach(indx, function(label, label_key){
                      if((!label.value || label.value == null || label.value == undefined || label.value == '') && cbfd[indx_key] == 1){
                        jQuery("#em-attendee-name-standing-"+index+"-"+indx_key).html('This is required field');
                        jQuery("#ep-standings-input-"+index+"-"+indx_key).focus();
                        $scope.progressStop();
                        noBooking = 1;
                        return;
                      }
                      if(indx_key == 'email'){
                        if(label.value){
                          var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                          if(!regex.test(label.value)) {
                            jQuery("#em-attendee-name-standing-"+index+"-"+indx_key).html('Please enter valid email');
                            jQuery("#ep-standings-input-"+index+"-"+indx_key).focus();
                            $scope.progressStop();
                            noBooking = 1;
                            return;
                          }
                        }
                      }
                      if(indx_key == 'tel'){
                        if(label.value){
                          if(!$.isNumeric(label.value)|| label.value.length < 10){
                            jQuery("#em-attendee-name-standing-"+index+"-"+indx_key).html('Please enter valid phone');
                            jQuery("#ep-standings-input-"+index+"-"+indx_key).focus();
                            $scope.progressStop();
                            noBooking = 1;
                            return;
                          }
                        }
                      }
                      if(label.value == null || label.value == undefined || label.value.trim() == '') {
                        $scope.attendee_names[index][type_key][indx_key][label_key].value = 'N/A';
                      }
                    });
                  });
                }
              });
            }
          });
        }
        else{
          $scope.attendee_names.forEach(function(item, index) {
            $scope.is_custom_booking_field = 0;
            if(noBooking == 0){
              $(".em-booking-standing-data").html('');
              if(item == null || item == undefined || item.trim() == '') {
                if($scope.event.required_booking_attendee_name == 1 && $scope.event.enable_attendees == 1){
                  $("#em-attendee-name-standing-"+index).html('This is required field');
                  $("#em-attendee-name-input-standing-"+index).focus();
                  $scope.progressStop();
                  noBooking = 1;
                  return;
                }
                else{
                  $scope.attendee_names[index] = 'N/A';
                }
              }
            }
          });
        }
        if(noBooking == 1) return;
      }
    }

    if($scope.event.max_tickets_per_person>0 && quantity>$scope.event.max_tickets_per_person){
      alert("Maximum tickets allowed per booking - " + $scope.event.max_tickets_per_person);
      $scope.progressStop();
      return;
    }

    // Check if event is bookable
    EMRequest.send('em_check_bookable', $scope.request).then(function (response) {
      $scope.progressStop();
      if ($scope.check_errors(response))
        return true;
      else{
        $scope.order.item_number = $scope.get_item_number($scope.event_id);
        $scope.order.quantity = quantity;
        $scope.no_seats = true;
        $scope.order.ticket_limit = $scope.event.max_tickets_per_person;
        $scope.order.seats = $scope.event.seats;
        $scope.order.allow_discount = $scope.event.allow_discount;
        $scope.order.discount_per = $scope.event.discount_per;
        $scope.order.discount_no_tickets = $scope.event.discount_no_tickets;           
        /* $scope.order.single_price = $scope.event.ticket_price; */
        $scope.order.order_ticket_price = 0;
        $scope.order.single_price = 0;
        // add fixed event price to order
        $scope.order.fixed_event_price = $scope.event.fixed_event_price;
        $scope.order.multi_price_option_data = [];
        if($scope.event_multi_price_option.val != 0){
          $scope.order.multi_price_option_data.push($scope.event_multi_price_option.val);
        }
        $scope.order.payment_gateway = "none";
        $scope.order.event_id = $scope.event_id;
        $scope.order.name = $scope.event.name;
        $scope.order.start_date = $scope.event.start_date;
        $scope.order.attendee_names = $scope.attendee_names;
        $scope.order.is_custom_booking_field = $scope.is_custom_booking_field;
        // sub total
        var subTotal = 0;
        var order_item_data = [];
        if($scope.event_multi_price_option.val != 0){
          var price_option_data = [];
          if($scope.event.price_option_data.length > 0){
            angular.forEach($scope.event.price_option_data, function(pvalue, pkey){
              price_option_data[pvalue.id] = pvalue;
            });
          }

          var eventPriceOption = $scope.event_multi_price_option.val;
          var seatPrice = eventPriceOption.price;
          if(eventPriceOption.special_price != ''){
            seatPrice = eventPriceOption.special_price;
          }
          var event_variation_id = eventPriceOption.id;
          order_item_data[event_variation_id] = [];
          var oid = {};
          var var_name = '';
          if(price_option_data[event_variation_id]){
            var_name = price_option_data[event_variation_id].name
          }
          oid.variation_name = var_name;
          oid.quantity = $scope.order.quantity;
          oid.price = seatPrice;
          oid.sub_total = parseFloat(seatPrice) * $scope.order.quantity;
          oid.variation_id = event_variation_id;
          oid.event_id = $scope.event_id;
          order_item_data[event_variation_id] = oid;
          /* subTotal = oid.sub_total; */
          subTotal = 0;
        }
        $scope.order.order_item_data = order_item_data;
        $scope.order.order_ticket_price = subTotal;
        $scope.order.subtotal = subTotal;

        // check for woocommerce products
        $scope.order.cart_selected_product = [];
        $scope.order.cart_selected_product_variation_id = [];
        $scope.order.cart_selected_product_variation_price = [];
        $scope.order.woocommerce_products = [];
        $scope.order.billing_address = {};
        $scope.order.shipping_address = {};
        if($scope.ep_product_quantity){
          angular.forEach($scope.ep_product_quantity, function (item, index) {
            if(item > 0){
              var pdata = {'id' : index, 'qty' : item};
              $scope.order.cart_selected_product.push(pdata);
            }
          });
          if($scope.ep_product_variation_id){                        
            angular.forEach($scope.ep_product_variation_id, function(item, index){
              var pdata = {'id' : index, 'variation' : item};
              $scope.order.cart_selected_product_variation_id.push(pdata);
            })
          }
          // variation price
          if($scope.ep_product_variation_price){
            angular.forEach($scope.ep_product_variation_price, function(item, index){
              var pdata = {'id' : index, 'variation_price' : item};
              $scope.order.cart_selected_product_variation_price.push(pdata);
            })
          }
          EMRequest.send('em_get_woocommerce_event_cart_product', $scope.order).then(function (response) {
            $scope.order.woocommerce_products = response.data.products;
            $scope.order.billing_address = response.data.billing_address;
            $scope.order.shipping_address = response.data.shipping_address;
            $scope.applyWoocommerce = 1;
            angular.forEach(response.data.products, function(item, index){
              var psubtotal = item.sub_total;
              /* $scope.order.subtotal += parseFloat(psubtotal); */
              /* $scope.price += parseFloat(psubtotal); */
              $scope.order.subtotal = 0;
              $scope.price = 0;
            });
            $scope.order.shipping_address.address_option = 'same';
          });
        }
        $scope.order.is_order_from_admin_attendee_booking = 1;
        EMRequest.send('em_book_seat', $scope.order).then(function (response) {
          if ($scope.check_errors(response)){
            return true;
          }
          // Payment countdown timer
          var timeInMinutes = 60*4 ,
          display = document.querySelector('#em_payment_timer');
          //$scope.startTimer(timeInMinutes, display); 
          $scope.order.order_id = response.data.order_id;
          $scope.orders.push($scope.order);
          //$scope.calculate_discount();
          $scope.calculate_price();
          $scope.update_order_ids();
          $scope.display_cart(true);
        });
      }
    });
  }

  /*
   * Setting Order object for seats
   */
  $scope.orderSeats = function () {
    $scope.progressStart();
    // Temporarily storing seating position and seat sequences
    var tmpSequences = [];
    var seatPos = [];
    $scope.order = {};
    $scope.request = {
      'event_id': $scope.event_id
    };
    var noBooking = 0;
    // Check if any seats are selected
    if(!($scope.selectedSeats.length > 0)){
      /* alert("No seats are selected"); */
      var no_seat_msg = $("#kf_seat_update").data('no_seat');
      alert(no_seat_msg);  
      $scope.progressStop();
      return;
    } else {
      if($scope.attendee_names.length > 0) {
        if($scope.event.custom_booking_field_data && $scope.event.custom_booking_field_data.length > 0){
          $scope.is_custom_booking_field = 1;
          var cbfd = {};
          $scope.event.custom_booking_field_data.forEach(function(data, dk){
            if(data){
              cbfd[data.type] = data.required;
            }
          });

          $(".em-booking-seating-data").html('');
          $scope.attendee_names.forEach(function(item, index) {
            if(noBooking == 0){
              angular.forEach(item, function(type, type_key){
                if(isNaN(type_key)){
                  delete item[type_key];
                } else{
                  angular.forEach(type, function(indx, indx_key){
                    angular.forEach(indx, function(label, label_key){
                      if((!label.value || label.value == null || label.value == undefined || label.value == '') && cbfd[indx_key] == 1){
                        jQuery("#em-attendee-name-standing-"+index+"-"+indx_key).html('This is required field');
                        jQuery("#ep-standings-input-"+index+"-"+indx_key).focus();
                        $scope.progressStop();
                        noBooking = 1;
                        return;
                      }
                      if(indx_key == 'email'){
                        if(label.value){
                          var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                          if(!regex.test(label.value)) {
                            jQuery("#em-attendee-name-standing-"+index+"-"+indx_key).html('Please enter valid email');
                            jQuery("#ep-standings-input-"+index+"-"+indx_key).focus();
                            $scope.progressStop();
                            noBooking = 1;
                            return;
                          }
                        }
                      }
                      if(indx_key == 'tel'){
                        if(label.value){
                          if(!$.isNumeric(label.value)|| label.value.length < 10){
                            jQuery("#em-attendee-name-standing-"+index+"-"+indx_key).html('Please enter valid phone');
                            jQuery("#ep-standings-input-"+index+"-"+indx_key).focus();
                            $scope.progressStop();
                            noBooking = 1;
                            return;
                          }
                        }
                      }
                      if(label.value == null || label.value == undefined || label.value.trim() == '') {
                        $scope.attendee_names[index][type_key][indx_key][label_key].value = 'N/A';
                      }
                    });
                  });
                }
              });
            }
          });
        }
        else{
          $scope.attendee_names.forEach(function(item, index) {
            if(noBooking == 0){
              $(".em-booking-seat-data").html('');
              if(item == null || item == undefined || item.trim() == '') {
                if($scope.event.required_booking_attendee_name == 1 && $scope.event.enable_attendees == 1){
                  $("#em-attendee-name-"+index).html('This is required field');
                  $("#em-attendee-name-input-"+index).focus();
                  $scope.progressStop();
                  noBooking = 1;
                  return;
                }
                else{
                  $scope.attendee_names[index] = 'N/A';
                }
              }
            }
          });
        }
        if(noBooking == 1) return;
      }
    }

    // Check if event is bookable
    EMRequest.send('em_check_bookable', $scope.request).then(function (response) {
      $scope.progressStop();
      if ($scope.check_errors(response))
        return true;
      else{
        // If seats are selected for booking
        if ($scope.selectedSeats.length > 0) {
          angular.forEach($scope.selectedSeats, function (seat, key) {
            tmpSequences.push(seat.seatSequence);
            seatPos.push(seat.row + "-" + seat.col);
            // Updating seat type to temporarily block the seat from other users
            seat.type = "tmp";
          });

          $scope.order.item_number = tmpSequences.join(', ');
          $scope.order.seat_sequences = tmpSequences;
          $scope.order.seat_pos = seatPos;
          $scope.order.quantity = tmpSequences.length;
        } 
        else if ($scope.event.seats.length == 0){
          $scope.order.item_number = $scope.get_item_number($scope.event_id);
          $scope.order.quantity = 1;
          $scope.no_seats = true;
        } 
        // Show final checkout section
        $scope.order.ticket_limit = $scope.event.max_tickets_per_person;
        $scope.order.seats = $scope.event.seats;
        $scope.order.allow_discount = $scope.event.allow_discount;
        $scope.order.discount_per = $scope.event.discount_per;
        $scope.order.discount_no_tickets = $scope.event.discount_no_tickets;           
        /* $scope.order.single_price = $scope.event.ticket_price; */
        $scope.order.single_price = 0;
        $scope.order.order_ticket_price = 0;
        $scope.order.multi_price_option_data = [];
        // add fixed event price to order
        $scope.order.fixed_event_price = $scope.event.fixed_event_price;
        if($scope.event_multi_price_option.val != 0){
          $scope.order.multi_price_option_data.push($scope.event_multi_price_option.val);
        }
        $scope.order.payment_gateway = "none";
        $scope.order.event_id = $scope.event_id;
        $scope.order.name = $scope.event.name;
        $scope.order.attendee_names = $scope.attendee_names;
        $scope.order.start_date = $scope.event.start_date;
        $scope.order.is_custom_booking_field = $scope.is_custom_booking_field;
        // sub total
        var subTotal = 0;
        var order_item_data = [];
        if($scope.selectedSeats.length > 0){
          var price_option_data = [];
          if($scope.event.price_option_data.length > 0){
            angular.forEach($scope.event.price_option_data, function(pvalue, pkey){
              price_option_data[pvalue.id] = pvalue;
            });
          }
          angular.forEach($scope.selectedSeats, function(svalue, skey){
            var seatPrice = svalue.price;
            if(isNaN(seatPrice) && seatPrice.indexOf('-') > -1) {
              var spl = seatPrice.split('-');
              seatPrice = spl[1];
            }
            if(svalue.variation_id){
              if(order_item_data[svalue.variation_id]){
                var oid = order_item_data[svalue.variation_id];
                oid.seatNo += ',' + svalue.seatSequence;
                oid.quantity++;
                oid.sub_total = parseFloat(oid.sub_total) + parseFloat(seatPrice);
                order_item_data[svalue.variation_id] = oid;
              }
              else{
                order_item_data[svalue.variation_id] = [];
                var oid = {};
                var var_name = '';
                if(price_option_data[svalue.variation_id]){
                  var_name = price_option_data[svalue.variation_id].name
                }
                oid.variation_name = var_name;
                oid.seatNo = svalue.seatSequence;
                oid.quantity = 1;
                oid.price = seatPrice;
                oid.sub_total = seatPrice;
                oid.variation_id = svalue.variation_id;
                oid.event_id = $scope.event_id;
                order_item_data[svalue.variation_id] = oid;
              }
            }
            else{
              if(order_item_data[0]){
                var oid = order_item_data[0];
                oid.seatNo += ',' + svalue.seatSequence;
                oid.quantity++;
                oid.sub_total = parseFloat(oid.sub_total) + parseFloat(seatPrice);
                order_item_data[0] = oid;
              }
              else{
                order_item_data[0] = [];
                var oid = {};
                oid.variation_name = '';
                oid.seatNo = svalue.seatSequence;
                oid.quantity = 1;
                oid.price = seatPrice;
                oid.sub_total = seatPrice;
                oid.variation_id = '';
                oid.event_id = $scope.event_id;
                order_item_data[0] = oid;
              }
            }
            subTotal = 0;
          });
        }
        $scope.order.order_item_data = order_item_data;
        $scope.order.order_ticket_price = subTotal;
        $scope.order.subtotal = subTotal;

        // check for woocommerce products
        $scope.order.cart_selected_product = [];
        $scope.order.cart_selected_product_variation_id = [];
        $scope.order.cart_selected_product_variation_price = [];
        $scope.order.woocommerce_products = [];
        $scope.order.billing_address = {};
        $scope.order.shipping_address = {};
        if($scope.ep_product_quantity){
          angular.forEach($scope.ep_product_quantity, function (item, index) {
            if(item > 0){
              var pdata = {'id' : index, 'qty' : item};
              $scope.order.cart_selected_product.push(pdata);
            }
          });
          if($scope.ep_product_variation_id){                        
            angular.forEach($scope.ep_product_variation_id, function(item, index){
              var pdata = {'id' : index, 'variation' : item};
              $scope.order.cart_selected_product_variation_id.push(pdata);
            })
          }
          // variation price
          if($scope.ep_product_variation_price){                        
            angular.forEach($scope.ep_product_variation_price, function(item, index){
              var pdata = {'id' : index, 'variation_price' : item};
              $scope.order.cart_selected_product_variation_price.push(pdata);
            })
          }
          EMRequest.send('em_get_woocommerce_event_cart_product', $scope.order).then(function (response) {
            $scope.order.woocommerce_products = response.data.products;
            $scope.order.billing_address = response.data.billing_address;
            $scope.order.shipping_address = response.data.shipping_address;
            $scope.applyWoocommerce = 1;
            angular.forEach(response.data.products, function(item, index){
              var psubtotal = item.sub_total;
              $scope.order.subtotal = 0;
              $scope.price = 0;
            });
            $scope.order.shipping_address.address_option = 'same';
          });
        }
        $scope.order.is_order_from_admin_attendee_booking = 1;
        $scope.progressStart();
        EMRequest.send('em_book_seat', $scope.order).then(function (response) {
          $scope.progressStop();

          if ($scope.check_errors(response)){
            return true;
          }
          // Payment countdown timer
          var timeInMinutes = 60*4 ,
          display = document.querySelector('#em_payment_timer');

          $scope.order.order_id = response.data.order_id;
          $scope.orders.push($scope.order);
          $scope.selectedSeats= [];
          //$scope.calculate_discount();
          $scope.calculate_price();
          $scope.update_order_ids();
          $scope.display_cart(true);
        });
      }
    });
  }

  // Delete current event's order and create new 
  $scope.updateOrder = function(){
    $scope.progressStart();
    // Deleting previous order
    if($scope.orders.length>0){
      for(var i = 0;i < $scope.orders.length;i++){
        if($scope.orders[i].event_id == $scope.event_id){
          $scope.request = {
            "order_id": $scope.orders[i].order_id
          }
          //$scope.progressStart();
          EMRequest.send('em_delete_order', $scope.request).then(function (response) {
            $scope.progressStop();
            // Removing old order
            $scope.orders.splice(i,1);
            // Check if any seats are selected
            if($scope.event.venue.type == "seats" && $scope.selectedSeats.length > 0)
              $scope.orderSeats();
            else if($scope.event.venue.type == "standings")
              $scope.orderStandings();
            else
              $scope.update_cart= false;
          });
          break;
        }
      }
    }
  }

  $scope.add_update_quantity= function(){
    newVal= $scope.order.quantity;
    if ($scope.order.seat_post == undefined) {
      $scope.bookable = false;
      if ($scope.order.ticket_limit != 0 && newVal >= $scope.order.ticket_limit) {
        $scope.order.quantity = $scope.order.ticket_limit;
      }
      if ($scope.order.quantity > 0){
        $scope.progressStart();
        EMRequest.send('em_update_booking', $scope.order).then(function (response) {
          $scope.progressStop();
          $scope.check_errors(response);
        });
      }
    }
  }

  $scope.get_item_number = function(event_id){  
    return $scope.event.name; 
  }

  $scope.check_errors = function (response){
    if (response.data.errors){
      if (response.data.errors.error_capacity) {
        $scope.errorMsg = response.data.errors.error_capacity[0];
        return true;
      }
      if (response.data.errors.booking_expired) {
        $scope.bookable = false;
        return true;
      }
      if (response.data.errors.booking_finished) {
        $scope.errorMsg = response.data.errors.booking_finished[0];
        return true;
      }
      if (response.data.errors.seat_conflict) {
        $scope.errorMsg = response.data.errors.seat_conflict[0];
        return true;
      } 
    }
    $scope.bookable = true;
    return false;
  }

  /**************************** Seating selection code *************/
 /*  $scope.selectSeat = function (seat, row, col) {
    // Preventing reserver,blocked and sold seats from selection
    if (seat.type == "reserve" || seat.type == "tmp" || seat.type == "sold") {
      return;
    }

    if (seat.type == 'selected' && seat.type != 'general'){
      // If seat already selected then deselect it.
      var index = $scope.selectedSeats.indexOf(seat);
      if (index >= 0) {
        $scope.selectedSeats.splice(index, 1);
        $scope.attendee_names.splice($scope.attendee_names.length-1,1);
      }
      seat.type = 'general';
    } 
    else{   
      // If number of tickets are  more than configured limit
      if (($scope.event.max_tickets_per_person != 0 && $scope.selectedSeats.length == $scope.event.max_tickets_per_person) || ($scope.selectedSeats.length==$scope.event.available_seats)) {
        angular.forEach($scope.selectedSeats, function (seat, key) {
          seat.type = "general";
        });
        $scope.selectedSeats = [];
      }
      seat.type = 'selected';
      $scope.selectedSeats.push(seat);
      $scope.attendee_names.push('');
    }
  } */
   /**************************** Seating selection code *************/
   $scope.selectSeat = function (seat, row, col, scolor, sel_color) {
    // Preventing reserver,blocked and sold seats from selection
    if (seat.type == "reserve" || seat.type == "tmp" || seat.type == "sold") {
        return;
    }

    if (seat.type == 'selected' && seat.type != 'general'){
        // If seat already selected then deselect it.
        var index = $scope.selectedSeats.indexOf(seat);
        if (index >= 0) {
            $scope.selectedSeats.splice(index, 1);
            $scope.attendee_names.splice($scope.attendee_names.length-1,1);
        }
        seat.type = 'general';
        if(seat.mainSeatColor && seat.mainSeatColor !== '#null'){
            seat.seatColor = seat.mainSeatColor
            seat.seatBorderColor = seat.mainSeatBorderColor
        }else{
            seat.seatColor = '#'+scolor;
            seat.seatBorderColor = '3px solid #'+scolor;
        }
        // remove seat price from booking
        var selectedSeatPrice = seat.price;
        if(isNaN(selectedSeatPrice) && selectedSeatPrice.indexOf('-') > -1) {
            var spl = seat.price.split('-');
            selectedSeatPrice = spl[1];
        }
        $scope.em_selected_seat_price -= selectedSeatPrice;
    } else {
        // If number of tickets are  more than configured limit
        if (($scope.event.max_tickets_per_person != 0 && $scope.selectedSeats.length == $scope.event.max_tickets_per_person) || ($scope.selectedSeats.length==$scope.event.available_seats)) {
            angular.forEach($scope.selectedSeats, function (seat, key) {
                seat.type = "general";
                if(seat.mainSeatColor && seat.mainSeatColor !== '#null'){
                    seat.seatColor = seat.mainSeatColor
                    seat.seatBorderColor = seat.mainSeatBorderColor
                }else{
                    seat.seatColor = '#'+scolor;
                    seat.seatBorderColor = '3px solid #'+scolor;
                }
            });
            $scope.selectedSeats = [];
            $scope.attendee_names = [];
        }
        seat.type = 'selected';
        /*seat.mainSeatColor = seat.seatColor;
        seat.mainSeatBorderColor = seat.seatBorderColor;*/
        seat.seatColor = '#'+sel_color;
        seat.seatBorderColor = '3px solid #'+sel_color;
        $scope.selectedSeats.push(seat);
        if($scope.event.custom_booking_field_data && $scope.event.custom_booking_field_data.length > 0){
            var nkey = $scope.attendee_names.length;
            $scope.attendee_names[nkey] = {};
            $scope.event.custom_booking_field_data.forEach(function(item, key){
                if(item){
                    $scope.attendee_names[nkey][item.type] = {};
                    $scope.attendee_names[nkey][item.type][item.label] = {};
                    $scope.attendee_names[nkey][item.type][item.label].value = '';
                    setTimeout(function(){
                        jQuery(".em-cbf-datepicker").datepicker({
                            changeMonth: true,
                            changeYear: true
                        });
                    }, 500);
                }
            });
        }
        else{
            $scope.attendee_names.push('');
        }
        // update attendee info title
        var infoId = $scope.attendee_names.length;
        var infoHtml = 'Attendee ' + infoId + '.';
        if(seat.seatSequence){
            infoHtml += ' (Seat No. ' + seat.seatSequence + ')';
        }
        $scope.seatAttendeeInfo[infoId] = infoHtml;
        // add seat price
        var selectedSeatPrice = seat.price;
        if(isNaN(selectedSeatPrice) && selectedSeatPrice.indexOf('-') > -1) {
            var spl = seat.price.split('-');
            selectedSeatPrice = spl[1];
        }
        $scope.em_selected_seat_price = parseFloat($scope.em_selected_seat_price) + parseFloat(selectedSeatPrice);
    }
  }

  /********************** Generate Alphabet seat sequence ****************/

  $scope.getRowAlphabet = function (rowIndex) {
    var indexNumber = "";
    if (rowIndex > 25) {
      indexNumber = parseInt(rowIndex / 26);
      rowIndex = rowIndex % 26;
    }
    return String.fromCharCode(65 + parseInt(rowIndex)) + indexNumber;
  }

  $scope.adjustContainerWidth = function(columnMargin,index){
    var width = parseInt($scope.seat_container_width.width);
    if(index == 0 && columnMargin > 0){
      width += columnMargin;
      $scope.seat_container_width.width = width + "px";
    }
  }

  $scope.$watch('booking_quantity',function(newVal,oldVal){
    if(newVal > $scope.attendee_names.length) {
      while($scope.attendee_names.length < newVal) {
        $scope.attendee_names.push('');
      }
    } else if(newVal < $scope.attendee_names.length) {
      while($scope.attendee_names.length > newVal) {
        $scope.attendee_names.splice($scope.attendee_names.length-1,1);
      }
    }
  });

  $scope.proceedWithoutPayment = function(){   
    var booking = {};
    var order_ids = [];
    var id = [];
    if($scope.applyWoocommerce == 1){
      if($scope.validateOrderBillingShipping() == false)
      {
        $scope.progressStop();
        return false;
      }
    }
    for(var i = 0;i < $scope.orders.length;i++)
      order_ids.push($scope.orders[i].order_id);

    booking.booking_id = order_ids;
    booking.all_order_data = $scope.orders;
    $scope.progressStart();
    EMRequest.send('em_confirm_booking_without_payment', booking).then(function (res){
      $scope.progressStop();                
      if ($scope.check_errors(res)){
        return true;
      }
      var orderId = order_ids[0];
      var path = '?page=em_attendee_booking&booking_id='+orderId;
      url = admin_vars.admin_url + "admin.php" + path;
      location.href = url;
    });
  }

  $scope.showAttendeeInfoBlock = function(index){
    if(jQuery("#attendee-info-block-"+index).css('display') == 'none'){
      jQuery("#attendee-info-block-"+index).css('display', 'block');
    }
    else{
      jQuery("#attendee-info-block-"+index).css('display', 'none');
    }
  }

   // functions for woocommerce
   $scope.removeBookingProduct = function(pid){
    angular.forEach($scope.ep_product_quantity, function(item, index){
        if(index == pid) {
           $scope.ep_product_quantity[index] = 0;
        }
    });
    $('[name="ep_product_quantity['+pid+']"]').closest('tr').remove();
  }
  // get woocommerce state by country code
  $scope.getWoocommerceCountryState = function(address, item, target){
    $scope.progressStart();
    var addval = $scope.order[address][item];
    if(addval){
        $scope.data.country_code = addval;
        EMRequest.send('em_get_woocommerce_state_by_country_code', $scope.data).then(function (response) {
            if(response.data){
                var statelist = response.data;
                jQuery("#"+target).empty();
                jQuery("#"+target).append(new Option("Select an option…", ""));
                angular.forEach(statelist, function(item, idx){
                  jQuery("#"+target).append(new Option(item, idx));
                });
            }
            $scope.progressStop();
        });
    }
  }

  // reset products on booking page
  $scope.reset_woo_products_on_booking_page = function(){
    $scope.progressStart();
    $scope.request = {};
    $scope.request.event_id = $scope.event_id;
    EMRequest.send('em_reset_woo_products_booking_page', $scope.request).then(function (response) {
        jQuery(".ep-product-info-block").html(response.data.data);
        $scope.is_reset_woo_product = true;
        $scope.progressStop();
    });
  }

  $scope.$watch('is_reset_woo_product',function(val){
    if(val){
        $compile($('.ep-product-info-block'))($scope);
    }
  });

  $scope.validateOrderBillingShipping = function(){
    $scope.billingErrors = [];
    $scope.shippingErrors = [];
    $scope.setFocus = 0;
    angular.forEach($scope.order.billing_address, function(item, index){
        if(!item){
            var itemElem = angular.element("#"+index);
            if(itemElem){
                var itemReq = itemElem.data('field_required');
                if(itemReq){
                    $scope.billingErrors.push(itemReq);
                    if($scope.setFocus == 0){
                        itemElem.focus();
                        $scope.setFocus = 1;
                    }
                    return false;
                }
            }
        }
    });
    if($scope.order.shipping_address.address_option == 'same'){
        var shiAdd = {};
        angular.forEach($scope.order.shipping_address, function(item, index){
            if(index && index !== 'address_option'){
                shiAdd[index] = '';
                var sapItem = index.replace('shipping_', '');
                shiAdd[index] = $scope.order.billing_address['billing_'+sapItem];
            }
        });
        $scope.order.shipping_address = shiAdd;
    }
    angular.forEach($scope.order.shipping_address, function(item, index){
        if(!item){
            var itemElem = angular.element("#"+index);
            if(itemElem){
                var itemReq = itemElem.data('field_required');
                if(itemReq){
                    $scope.shippingErrors.push(itemReq);
                    if($scope.setFocus == 0){
                        itemElem.focus();
                        $scope.setFocus = 1;
                    }
                    return false;
                }
            }
        }
    });
    if($scope.setFocus == 1){
        return false;
    }
}

});

eventMagicApp.filter('unsafe', function($sce) {
  return function(val) {
    return $sce.trustAsHtml(val);
  };
});

eventMagicApp.filter('currencyPosition', function($sce) {
  return function(val, position, symbol) {
      if(isNaN(parseInt(val)) === true){
          return $sce.trustAsHtml(val);
      }
      if(position == 'before'){
          return symbol + val;
      }
      if(position == 'before_space'){
          return symbol + ' ' + val;
      }
      if(position == 'after'){
          return val + symbol;
      }
      if(position == 'after_space'){
          return val + ' ' + symbol;
      }
  };
});
eventMagicApp.filter('currencyPositionWithHtml', function($sce) {
  return function(val, position, symbol) {
      var currhtml = '';
      if(position == 'before'){
          currhtml = symbol + '<span class="em-booking-ticket-price">' + val + '</span>';
      }
      if(position == 'before_space'){
          currhtml = symbol + ' ' + '<span class="em-booking-ticket-price">' + val + '</span>';
      }
      if(position == 'after'){
          currhtml = '<span class="em-booking-ticket-price">' + val + '</span>' + symbol;
      }
      if(position == 'after_space'){
          currhtml = '<span class="em-booking-ticket-price">' + val + '</span>' + ' ' + symbol;
      }

      return $sce.trustAsHtml(currhtml);
  };
});