<?php
if (!defined( 'ABSPATH')){
    exit;
}

class EventM_Attendees_Booking_Service {
    
    private static $instance = null;
    
    private function __construct() {
        $this->actions();
    }
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }
    
    public function actions(){
        add_action( 'event_magic_add_attendees_booking_button', array($this, 'add_attendees_booking_button'), 10, 1 );
    }

    public function add_attendees_booking_button(){
        $extensions = event_magic_instance()->extensions;
        if(!in_array('attendees_booking', $extensions)){
            return;
        }
        if (!is_admin()) return;

        if(!is_user_logged_in()) return;
        ?>
        <li><a ng-href="<?php echo admin_url('admin.php?page=em_add_new_attendee'); ?>"><?php _e('Add New Attendees Booking', 'eventprime-event-attendees-booking'); ?></a></li>
        <?php
    }

    public function get_attendee_events_for_calendar_view($params) {
        $event_service = EventM_Factory::get_service('EventM_Service');
        $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
        $global_settings = $setting_service->load_model_from_db();
        $currency_symbol = "";
        $em = event_magic_instance();
        // datepicker format from global settings
        $datepicker_format_arr = explode('&', em_global_settings('datepicker_format'));
        $date_format = (!empty($datepicker_format_arr) && isset($datepicker_format_arr[1])) ? $datepicker_format_arr[1] : get_option('date_format');
        $time_format = get_option('time_format');
        $date_time_format = $date_format . ' ' . $time_format;
        if ($global_settings->currency) {
            $all_currency_symbols = EventM_Constants::get_currency_symbol();
            $currency_symbol = $all_currency_symbols[$global_settings->currency];
        } else {
            $currency_symbol = EM_DEFAULT_CURRENCY;
        }

        $the_query = $this->attendee_events_get_events_the_query(array('nopaging'=>true),$params);
        $posts = $the_query->posts;
        $events = array();
        $performer_service = EventM_Factory::get_service('EventM_Performer_Service');
        $type_service = EventM_Factory::get_service('EventTypeM_Service');
        if (empty($posts))
            return $events;
        
        $posts = apply_filters('ep_filter_front_events',$posts,$params);
        $posts = array_filter($posts, function($post){ return $post->post_status !== 'draft'; });
        foreach ($posts as $post) {
            $event = $event_service->load_model_from_db($post->ID);
            $time_str = '';
            $start_date = ( !empty( $event->start_date ) ? date( 'c',$event->start_date ) : '' );
            $end_date = ( !empty( $event->end_date ) ? date( 'c',$event->end_date ) : '' );
            if (em_compare_event_dates($post->ID)) {
                //$day = date('D, M d, Y',$event->start_date);
                $day = date_i18n($date_format,$event->start_date);
                $start_time = date_i18n($time_format,$event->start_date);
                $end_time = date_i18n($time_format,$event->end_date);                
                $time_str .= $day . ' ' . $start_time . ' ' .__("to", 'eventprime-event-calendar-management') . ' ' . $end_time;
            } 
            else {
                $time_str .= date_i18n($date_time_format,$event->start_date) . ' - ' . date_i18n($date_time_format,$event->end_date);
            }
            if($event->all_day){
                $time_str = date_i18n($date_format,$event->start_date) . ' - ' . __("ALL DAY",'eventprime-event-calendar-management');
            }
            $link_href = add_query_arg("event", $event->id, get_permalink($global_settings->events_page));
            $event_arr = array('title' => $event->name, 'start' => $start_date, 'end' => $end_date, 'id' => $post->ID, 'time_str' => $time_str);
            if (!empty($event->event_type)) {
                $type_model = $type_service->load_model_from_db($event->event_type);
                $event_arr['bg_color'] = '#' . $type_model->color;
                $event_arr['type_text_color'] = '#' . $type_model->type_text_color;
            }
            if(!empty($event->event_text_color)){
                $event_arr['event_text_color'] = '#' . $event->event_text_color;
            }

            $venue_address = em_get_term_meta($event->venue, 'address', true);
            $event_arr['address'] = !empty($venue_address) ? $venue_address : '';
            /* $event_arr['ticket_price'] = (abs(floatval($event->ticket_price)) <= 0) ? '' : em_price_with_position($event->ticket_price); */
            $event_arr['ticket_price'] = (abs(floatval($event->ticket_price)) <= 0) ? '' : $event->ticket_price;
            // check if show one time event fees at front enable
            if($event->show_fixed_event_price){
                if($event->fixed_event_price > 0){
                   /*  $event_arr['ticket_price'] = em_price_with_position($event->fixed_event_price); */
                   $event_arr['ticket_price'] = $event->fixed_event_price;
                }
            }
            $bookable= $event_service->is_bookable($event);
            if($bookable){
                $showBookNowForGuestUsers = em_show_book_now_for_guest_users();
                $current_ts = em_current_time_by_timezone();
                if($event->status == 'expired'){
                    $event_arr['link']='<div class="em_header_button em_event_expired kf-tickets">'.em_global_settings_button_title("Bookings Expired", 'eventprime-event-attendees-booking').'</div>';
                }
                elseif($current_ts > $event->last_booking_date){
                    $event_arr['link'] = '<div class="em_header_button em_booking-closed kf-tickets">'.em_global_settings_button_title("Bookings Closed",'eventprime-event-attendees-booking').'</div>';
                }
                elseif($current_ts < $event->start_booking_date){
                    $event_arr['link'] = '<div class="em_header_button em_not_started kf-tickets">'.em_global_settings_button_title("Bookings not started yet",'eventprime-event-attendees-booking').'</div>';
                }
                else {
                    $event_arr['link'] = '<form action="'.admin_url('admin.php?page=em_new_attendee_booking').'" method="post" name="em_attendee_booking'.$event->id.'"><input type="hidden" name="event_id" value="'.$event->id.'" /><input type="hidden" name="venue_id" value="'.$event->venue.'" /><button name="tickets" ng-click="em_event_attendee_booking('.$event->id.')" id="em_attendee_booking" class="em_color">'.em_global_settings_button_title('Book Now','eventprime-event-attendees-booking').'</button>';
                }
            }
            else {
                if((isset($event->parent) && !empty($event->parent)) && (isset($event->enable_recurrence_automatic_booking) && !empty($event->enable_recurrence_automatic_booking))){
                    $event_arr['link']='<div class="em_header_button em_booking-closed kf-tickets">'.em_global_settings_button_title("Bookings not allowed",'eventprime-event-attendees-booking').'</div>';
                }
                elseif(isset($event->standing_capacity) && !empty($event->standing_capacity)){
                    $event_arr['link']='<div class="em_header_button em_booking-closed kf-tickets">'.em_global_settings_button_title("All Seats Booked",'eventprime-event-attendees-booking').'</div>';
                }
                else{
                    $event_arr['link']='<div class="em_header_button em_booking-closed kf-tickets">'.em_global_settings_button_title("Bookings Closed",'eventprime-event-attendees-booking').'</div>';
                }
            }
            
            $capacity = em_event_seating_capcity($event->id);
            if(!empty($event->enable_booking) && empty($event->hide_booking_status) && !empty($capacity)){
               $sum = $event_service->booked_seats($event->id);
               $width= ($sum / $capacity) * 100;
               $event_arr['booking_status']= array('stats'=>$sum.' / '.$capacity,'width'=>$width);
            }
            
            if (!empty($event->enable_performer) && !empty($event->performer)) {
                $performers = array();
                foreach ($event->performer as $p_id) {
                    $performer = $performer_service->load_model_from_db($p_id);
                    $cover_image = $performer_service->get_image($performer->id);
                    if (!empty($cover_image)) {
                        array_push($performers, $cover_image);
                    }
                }
                if (!empty($performers)) {
                    $event_arr['performers'] = '<ul>';
                    foreach ($performers as $img_url) {
                        $event_arr['performers'] .= "<li><img src='$img_url' /></li>";
                    }
                    $event_arr['performers'] .= '</ul>';
                }
            }
            $event_arr['url']= 'javascript:void(0);';
            /* $event_arr['ticket_price'] = apply_filters('event_magic_load_calender_ticket_price', $event_arr['ticket_price'], $event); */
            $event_arr['ticket_price'] = apply_filters('event_magic_load_calender_ticket_price', $event_arr['ticket_price'], $event);
            if ( is_numeric( $event_arr['ticket_price'] ) ) {
                $event_arr['ticket_price'] = em_price_with_position( $event_arr['ticket_price'] );
            }
            $popup_html = 
            '<div class="em_event_detail_popup" style="display:none">
                <a href="'.admin_url('admin.php?page=em_attendee_event&event='.$event->id).'">
                    <div class="ep_event_detail_popup_head em_bg dbfl">
                        <div class="ep_event_title difl">'.$event_arr['title'].'</div>
                        <div class="ep_event_price difr">'.$event_arr['ticket_price'].'</div>
                    </div>
                </a>
                <div class="ep-event-detail-wrap">
                    <div class="ep-event-detail-row dbfl">
                        <i class="material-icons">access_time</i>
                        <span class="ep_event_time">'.$event_arr['time_str'].'</span>
                    </div>';
                    if(!empty($event_arr['address'])){
                        $popup_html .= '<div class="ep-event-location ep-event-detail-row dbfl"><i class="material-icons">location_on</i><span class="ep_event_venue">'.$event_arr['address'].'</span></div>';
                    }
                    
                    if(!empty($event_arr['performers'])){
                        $popup_html .= '<div class="ep-event-performers ep-event-detail-row dbfl"><span class="ep-event-performers-title">'.__('Performers','eventprime-event-attendees-booking').'</span><div class="ep_event_performers">'.$event_arr['performers'].'</div></div>';
                    }

                    $popup_html .= '<div class="event_booking_details ep-event-detail-row">';
                        if(!empty($event->enable_booking)){
                            if(!empty($event_arr['booking_status']) && absint($event->custom_link_enabled) != 1){
                                $popup_html .= __("Booking Status", 'eventprime-event-attendees-booking') .'<div class="status">'.$event_arr['booking_status']['stats'].'</div>
                                <div class="dbfl">
                                    <div id="progressbar" class="em_progressbar dbfl">
                                        <div class="em_progressbar_fill em_bg" style="width:'.$event_arr['booking_status']['width'].'%"></div>
                                    </div>
                                </div>'; 
                            }
                            if(!empty($event->enable_booking) && absint($event->custom_link_enabled) != 1){
                                $popup_html .= '<div class="ep-book-now dbfl">'.$event_arr['link'].'</div>';
                            }
                        }
                    $popup_html .= '</div>';
            $popup_html .= '</div></div>';
            $event_arr['popup_html']=  $popup_html;
            array_push($events, $event_arr);
        }
        return $events;
    }

    public function attendee_events_get_events_the_query($custom_args=array(),$shortcode_params=array()) {
        $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
        $gs = $setting_service->load_model_from_db();
        $hide_past_events = $gs->hide_past_events;
        $type_ids = $shortcode_params['types'];
        $venue_ids = $shortcode_params['sites'];
        $paged = (get_query_var('paged') ) ? get_query_var('paged') : 1;
        $meta_query= array(
            'relation' => 'AND',
            array(
                'key' => em_append_meta_key('hide_event_from_events'),
                'value' => '1',
                'compare' => '!='
            )
        );
        $search = event_m_get_param('em_s');
        $args = array(
            'meta_key' => em_append_meta_key('start_date'),
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'posts_per_page' => 10,
            'paged' => $paged,
            'meta_query' => $meta_query,
            'post_type' => EM_EVENT_POST_TYPE
        );
        $args['post_status'] = !empty($hide_past_events) == 1 ? 'publish' : 'any';
        
        if ($search == "1"){
            $sd = event_m_get_param('em_sd');
            $start_date= DateTime::createFromFormat('!Y-m-d',$sd);
            if(!empty($start_date)){
                $start_date->setTime(23,59,59);
                $start_ts= $start_date->getTimestamp();
                $start_date->setTime(0,0);
                $end_ts=$start_date->getTimestamp();
                array_push($meta_query,array(
                    'key' => em_append_meta_key('start_date'),
                    'value' => $start_ts,
                    'compare' => '<=',
                    'type'=>'NUMERIC'
                ),
                array(
                    'key' => em_append_meta_key('end_date'),
                    'value' => $end_ts,
                    'compare' => '>=',
                    'type'=>'NUMERIC'
                ));
            }
            
            $keyword = event_m_get_param('em_search');
            if (!empty($keyword)){
                $args['s']= $keyword;
            }
            
            $types = event_m_get_param('em_types');
            if (!empty($types)) {
                $types = is_array($types) ? $types : array($types);
                if(!empty($type_ids))
                    $type_ids = array_intersect($types,$type_ids);
                else
                    $type_ids = $types;
            }
            
            $venue = event_m_get_param('em_venue');
            if (!empty($venue)) {
                $venue = is_array($venue) ? $venue : array($venue);
                if(!empty($venue_ids))
                    $venue_ids = array_intersect($venue,$venue_ids);
                else
                    $venue_ids = $venue;
            }
        }
        
        if (!empty($type_ids)) {
            array_push($meta_query,array(
                'key' => em_append_meta_key('event_type'),
                'value' => $type_ids,
                'compare' => 'IN',
                'type'=>'NUMERIC'
            ));
        }
        
        if (!empty($venue_ids)) {
            array_push($meta_query,array(
                'key' => em_append_meta_key('venue'),
                'value' => $venue_ids,
                'compare' => 'IN',
                'type'=>'NUMERIC'
            ));
        }
        
        if(!empty($meta_query)){
            $args['meta_query']= $meta_query;
        }
        $args = wp_parse_args($custom_args, $args);
        add_filter('posts_orderby', 'em_posts_order_by');
        $wp_query = new WP_Query($args);
        remove_filter('posts_orderby', 'em_posts_order_by');
        return $wp_query;
    }
}
EventM_Attendees_Booking_Service::get_instance();