<?php
/**
 * Plugin Name:       EventPrime Attendees List
 * Plugin URI:        http://eventprime.net
 * Description:       Display names of attendess for an event in a widget or on the event page
 * Version:           1.0.4
 * Author:            EventPrime
 * Author URI:        http://eventprime.net
 * Text Domain:       eventprime-attendees-list
 * Domain Path:       /languages
 * Requires at least: 4.8
 * Tested up to:      6.0.3
 * Requires PHP:      5.6
 */
// Exit if accessed directly
if (!defined('ABSPATH'))
    exit;

// Check if plugin is active and class not already loaded
if (!class_exists('EM_Attendees_List')) {

    final class EM_Attendees_List {

        public $version = '1.0.4';
        private static $instance = null;

        public static function instance() {
            if (is_null(self::$instance)) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        private function __construct() {
            $this->load_plugin_textdomain();
            $this->define_constants();
            $this->global_actions();
            $this->includes();
            $em = event_magic_instance();
            array_push($em->extensions, 'attendees-list');
        }

        public function global_actions() {
            add_action('event_magic_attendees_list',array($this,'display_attendees_list'));
            add_action('event_magic_attendees_list_setting',array($this,'display_attendees_list_setting'));
            add_action('event_magic_gs_settings',array($this,'event_attendees_list_gs_settings'));
        }
        
        public function define_constants() {
            if (!defined('EM_ATTENDEES_LIST_BASE_URL')) {
                define('EM_ATTENDEES_LIST_BASE_URL', plugin_dir_url(__FILE__));
            }
            if (!defined('EM_ATTENDEES_LIST_PLUGIN_DIR')) {
                define('EM_ATTENDEES_LIST_PLUGIN_DIR', plugin_dir_path(__FILE__));
            }
        }

        private function includes() {
            include_once('includes/public/eventprime-attendees-list-public.php');
            include_once('includes/widgets/eventprime-attendees-list-widget.php');
        }

        public function load_plugin_textdomain() {
            load_plugin_textdomain('eventprime-attendees-list', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }
        
        public function display_attendees_list($event) {
            if(!empty($event->enable_booking) && !empty($event->show_attendees)) { ?>
                <div class="ep-attendees-container dbfl">
                    <div class="ep-attendees-wrap dbfl">
                        <div class="ep-attendees-title dbfl"> 
                            <div class="kf-row-heading">
                                <span class="kf-row-title em_color" ><i class="fa fa-users" aria-hidden="true"></i> <?php echo __("Attendees",'eventprime-attendees-list'); ?></span>
                            </div> 
                        </div>
                        <div class="ep-attendees-list-container kf-event-attendees">
                        <?php $booking_service = EventM_Factory::get_service('EventM_Booking_Service');
                            if (empty($event->id)) {
                                _e("Invalid event","eventprime-attendees-list");
                            } else {
                                $booking_args = array(
                                    'numberposts' => -1,
                                    'post_status'=> 'completed',
                                    'post_type'=> 'em_booking',
                                    'meta_key' => 'em_event',
                                    'meta_value' => $event->id
                                );
                                $booking_posts = get_posts($booking_args);
                                if (!empty($booking_posts)) {
                                    echo '<ol>';
                                    foreach ($booking_posts as $post) {
                                        $attendee_names = get_post_meta($post->ID, 'em_attendee_names');
                                        $order_info = get_post_meta($post->ID, 'em_order_info');
                                        if(!isset($order_info[0]['is_custom_booking_field']) || $order_info[0]['is_custom_booking_field'] == 0){
                                            if (!empty($attendee_names)) {
                                                foreach($attendee_names[0] as $key => $val) {
                                                    echo "<li>".$val."</li>";
                                                }
                                            }
                                        }
                                        else{
                                            foreach($attendee_names as $attendee_data){
                                                foreach ($attendee_data as $alabel => $avalue) {
                                                    if(!empty($avalue)){
                                                        $name = 0;
                                                        foreach($avalue as $label => $value){
                                                            if(strpos(strtolower($label), 'name') !== false){
                                                                echo "<li>".$value."</li>";
                                                                $name = 1;
                                                            }
                                                        }
                                                        // if empty the name fields then show first field value
                                                        if( empty( $name ) ) {
                                                            $ni = 1;
                                                            foreach($avalue as $label => $value){
                                                                if( $ni == 1 ){
                                                                    if( $value != 'N/A' ) {
                                                                        echo "<li>".$value."</li>";
                                                                    }
                                                                }
                                                                $ni++;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    echo '</ol>';
                                } else {
                                    _e("No confirmed bookings for this event yet","eventprime-attendees-list");
                                }
                            } ?>
                        </div>
                    </div>
                    <!-- <div class="ep-loadMore-wrap dbfl">
                        <a href="#" id="ep-loadMore"><?php //_e("Show More",'eventprime-attendees-list'); ?></a>
                    </div> -->
                </div>
                <script>
                    jQuery(document).ready(function(){
                        $= jQuery;
                        $(".emagic #em_primary .ep-attendees-wrap .kf-event-attendees li").append("<span></span>");
                        var epDomColor = $(".emagic").find("a").css('color');
                        bgcolor = epDomColor.replace(')', ',0.02)');
                        $(".emagic #em_primary .ep-attendees-wrap .kf-event-attendees li").css('background-color', bgcolor);
                        $(".emagic #em_primary .ep-attendees-wrap .kf-event-attendees li span").css('background-color', epDomColor);

                        $(".emagic #em_primary .ep-attendees-wrap .kf-event-attendees li").slice(0, 9).show();
                        if($(".emagic #em_primary .ep-attendees-wrap .kf-event-attendees li:hidden").length === 0) {
                          $("#ep-loadMore").addClass("ep-noattendees");
                        }
                        $("#ep-loadMore").on("click", function(e){
                            e.preventDefault();
                            $(".emagic #em_primary .ep-attendees-wrap .kf-event-attendees li:hidden").slice(0, 9).slideDown();
                            if($(".emagic #em_primary .ep-attendees-wrap .kf-event-attendees li:hidden").length === 0) {
                                $("#ep-loadMore").text("Showing All").addClass("ep-all-attendees-loaded");
                            }
                        });
                    });
                </script>
            <?php }
        }
        
        public function display_attendees_list_setting() { ?>
            <div class="emrow">
                <div class="emfield"><?php _e('Show Attendee Names','eventprime-attendees-list'); ?></div>
                <div class="eminput">
                    <input type="checkbox" name="show_attendees"  ng-model="data.post.show_attendees"  ng-true-value="1" ng-false-value="0">
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Enable this option to display names of attendees on the event page.','eventprime-attendees-list'); ?>
                </div>
            </div>
        <?php }
        
        public function event_attendees_list_gs_settings(){?>
            <a href='javascript:void(0)'>
                <div class="em-settings-box ep-active-extension ep-no-global-settings-model" data-popup="ep-attendees-lists-ext" onclick="CallEPExtensionModal(this)">
                    <img class="em-settings-icon" ng-src="<?php echo EM_BASE_URL; ?>includes/admin/template/images/ep-attendees-list-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Attendees List', 'eventprime-attendees-list'); ?></div>
                    <span><?php _e('Publish frontend attendee lists.', 'eventprime-attendees-list'); ?></span>
                </div>
            </a>
            <?php
        }
        
    }
    
}

function em_attendees_list_checks() { ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e("EventPrime Attendees List Extension won't work as EventPrime plugin is not installed or activated.", 'eventprime-attendees-list'); ?></p>
    </div>
<?php }

function em_attendees_list_init() {
    return EM_Attendees_List::instance();
}

add_action('plugins_loaded', function() {
    if (!class_exists('Event_Magic')) {
        add_action('admin_notices', 'em_attendees_list_checks');
    }
});
add_action('event_magic_loaded', 'em_attendees_list_init');
require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_attendees_list_metadata.json',
    __FILE__,
    'eventprime-event-attendees-list'
);