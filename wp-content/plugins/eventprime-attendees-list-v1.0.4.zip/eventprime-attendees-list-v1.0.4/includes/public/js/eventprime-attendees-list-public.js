jQuery(document).ready(function(){
    $= jQuery;

    $(".widget_eventm_attendees_list .em_widget_container li").append("<span></span>");
    var epDomColor = $("body").find("a").css('color');
    bgcolor = epDomColor.replace(')', ',0.02)');
    $(".widget_eventm_attendees_list .em_widget_container li").css('background-color', bgcolor);
    $(".widget_eventm_attendees_list .em_widget_container li span").css('background-color', epDomColor);
    jQuery(".widget_eventm_attendees_list .em_widget_container li").slice(0, 5).show();
    if($(".widget_eventm_attendees_list .em_widget_container li:hidden").length === 0) {
        $("#ep-load-More").addClass("ep-noattendees");
    }
    jQuery("#ep-load-More").on("click", function(e) {
        e.preventDefault();
        jQuery(".widget_eventm_attendees_list .em_widget_container li:hidden").slice(0, 5).slideDown();
        if(jQuery(".widget_eventm_attendees_list .em_widget_container li:hidden").length === 0) {
            jQuery("#ep-load-More").text("Showing All").addClass("ep-all-attendees-loaded");
        }
    });
});