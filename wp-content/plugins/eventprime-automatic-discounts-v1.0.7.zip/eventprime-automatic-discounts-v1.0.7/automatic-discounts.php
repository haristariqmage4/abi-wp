<?php
/**
 * Plugin Name: EventPrime Automatic Discounts
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that allow you to set date-time, bookings, user role, seat base discount.
 * Version: 1.0.7
 * Author: EventPrime
 * Text Domain: eventprime-automatic-discount
 * Domain Path: /languages
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 6.0.1
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_Automatic_Discounts')) {

    final class EM_Automatic_Discounts {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.0.7';

        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;

        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }
        /**
         * Event_Magic Constructor.
         */
        private function __construct() {
            $this->define_constants();
            $this->load_textdomain();
            $this->includes(); 
            $this->define_hooks();
            $em = event_magic_instance();
            array_push($em->extensions,'em_automatic_discounts');
        }
        
        public function define_constants(){
            $em = event_magic_instance();
            $em->define('EM_EBD_POST_TYPE','em_ebd');
            $em->define('EMEBD_BASE_URL', plugin_dir_url(__FILE__));
            define('EMEBD_VERSION', $this->version);
            if (!defined('EVENTPRIME_EBD_RULE_TYPE')) {
                define('EVENTPRIME_EBD_RULE_TYPE', array(
                    'datetime' => __('Date / Time based rule', 'eventprime-event-automatic-discounts'),
                    'booking' => __('Booking based rule', 'eventprime-event-automatic-discounts'),
                    'user_role' => __('User Role based rule', 'eventprime-event-automatic-discounts'),
                    'seat' => __('Seat based rule', 'eventprime-event-automatic-discounts'),
                ));
            }
            if (!defined('EVENTPRIME_EBD_DISCOUNT_TYPE')) {
                define('EVENTPRIME_EBD_DISCOUNT_TYPE', array(
                    'percentage' => __('Percentage', 'eventprime-event-automatic-discounts'),
                    'fixed' => __('Fixed', 'eventprime-event-automatic-discounts'),
                ));
            }
        }

        public function load_textdomain(){
            load_plugin_textdomain('eventprime-event-automatic-discounts', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }
        
        public function includes(){
            include_once('includes/models/class-emebd-global-settings.php');
            include_once('includes/dao/class-emebd-global-settings.php');
            include_once('includes/models/class-early-bird-discounts.php');
            include_once('includes/dao/class-early-bird-discounts.php');
            include_once('includes/services/class-early-bird-discount.php');
            if(is_admin()){
                include('includes/admin/class-admin.php');
            }
        }
        
        public function define_hooks(){
            add_action('init', array($this, 'register_post_type'));
            add_action('wp_enqueue_scripts',array($this,'event_magic_enqueue_style_and_scripts'));
            // global settings
            add_action('event_magic_gs_settings',array($this,'event_early_bird_discount_gs_settings'));
            add_action('event_magic_gs_popup',array($this,'event_early_bird_discount_gs_settings_form'));
            add_action('em_after_gs_save',array($this,'event_early_bird_discount_gs_settings_save'));
            add_filter('em_load_gs_ext_options',array($this,'event_early_bird_discount_get_options'), 99, 1);
            add_filter('event_magic_gs_get_model',array($this,'event_early_bird_discount_get_options'), 99, 1);
            // event deshboard
            add_filter('eventprime_load_post_response', array($this,'event_early_bird_discount_load_into_post_response_model'),10,2);
            add_filter('eventprime_load_into_event_model', array($this,'load_event_early_bird_discount_parameters'),10,2);
            // front card view special price
            //add_action('event_magic_card_view_after_price', array($this, 'event_early_bird_discount_front_card_view_after_price'), 10, 1 );
            // front card view description after footer
            add_action('event_magic_card_view_after_footer', array($this, 'event_early_bird_discount_front_card_view_after_footer'), 10, 1 );
            // event front calendar popup
            add_action('event_magic_popup_custom_data', array($this,'event_early_bird_discount_popup_render'));
            // single event page price after
            add_action('event_magic_single_event_ticket_price_after', array($this, 'event_early_bird_discount_single_event_ticket_price_after'), 99, 2 );
            // front booking page
            add_action('event_magic_front_ebd_section', array($this, 'event_early_bird_discount_front_ebd_section'), 10, 1 );
            // front booking page special price
            add_action('event_magic_get_ebd_special_price', array($this, 'event_early_bird_get_ebd_special_price'), 10, 1 );
            // check discount after seat select
            add_action('wp_ajax_em_apply_event_ebd', array($this, 'event_early_bird_discount_apply_ebd'));
            add_action('wp_ajax_nopriv_em_apply_event_ebd', array($this, 'event_early_bird_discount_apply_ebd'));
            // offline payment filter
            add_filter('event_magic_add_offline_payment_response', array($this, 'event_early_bird_discount_add_offline_payment_response'), 99, 2);
            // without payment filter
            add_filter('event_magic_add_without_payment_response', array($this, 'event_early_bird_discount_add_without_payment_response'), 99, 2);
            // stripe payment filter
            add_filter('event_magic_add_stripe_payment_response', array($this, 'event_early_bird_discount_add_stripe_payment_response'), 99, 2);
            // confirm booking order info
            add_filter('event_magic_add_booking_order_info', array($this, 'event_early_bird_discount_add_booking_order_info'), 10, 2);
            // get final price
            add_filter('event_magic_booking_get_final_price', array($this, 'event_early_bird_discount_booking_get_final_price'), 99, 2);
            // update booking amount received data for view attendee booking
            add_filter('event_magic_view_attendee_amount_received', array($this, 'event_early_bird_discount_view_attendee_amount_received'), 99, 2);
            // update booking amount due data for view attendee booking
            add_filter('event_magic_view_attendee_amount_due', array($this, 'event_early_bird_discount_view_attendee_amount_due'), 99, 2);
            
            add_filter('event_magic_load_calender_ticket_price', array($this, 'event_early_bird_discount_load_calender_ticket_price'), 99, 2);
            
            add_action('event_magic_ebd_rule_description', array($this, 'event_early_bird_discount_rule_description'), 10, 1 );
            // user profile
            
            add_action('event_magic_front_user_booking_before_total_price', array($this, 'event_early_bird_discount_front_user_booking_before_total_price'), 10, 1);
            // action on paypal data verification
            add_filter('event_magic_paypal_data_verify_booking', array($this, 'event_early_bird_discount_data_verify_booking'), 99, 2);
            
        }

        public function register_post_type(){
            register_post_type(EM_EBD_POST_TYPE,
                array(
                    'labels' => array(
                        'name'               => __( 'Ebds','eventprime-event-automatic-discounts'),
                        'singular_name'      => __( 'Ebd','eventprime-event-automatic-discounts'),
                        'add_new'            => __( 'Add Ebd','eventprime-event-automatic-discounts'),
                        'add_new_item'       => __( 'Add New Ebd','eventprime-event-automatic-discounts'),
                        'edit'               => __( 'Edit','eventprime-event-automatic-discounts'),
                        'edit_item'          => __( 'Edit Ebd','eventprime-event-automatic-discounts'),
                        'new_item'           => __( 'New Ebd','eventprime-event-automatic-discounts'),
                        'view'               => __( 'View','eventprime-event-automatic-discounts'),
                        'view_item'          => __( 'View Ebd','eventprime-event-automatic-discounts'),
                        'not_found'          => __( 'No Ebd found','eventprime-event-automatic-discounts'),
                        'not_found_in_trash' => __( 'No Ebd found in trash','eventprime-event-automatic-discounts'),
                    ),
                    'description'         => __( 'Here you can add new ebds.','eventprime-event-automatic-discounts'),
                    'public'              => true,
                    'show_ui'             => false,
                    'map_meta_cap'        => true,
                    'publicly_queryable'  => true,
                    'exclude_from_search' => false,
                    'hierarchical'        => false, // Restrict WP to loads all records!
                    'query_var'           => true,
                    'capability_type'     => 'event_magic', 
                    'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'page-attributes', 'publicize', 'wpcom-markdown' ),
                    'show_in_nav_menus'   => false
                )
            );
        }
        
        public function event_magic_enqueue_style_and_scripts() {
            wp_register_script('em-ebd-front-js', EMEBD_BASE_URL . 'includes/public/js/em_ebd_front.js', array('jquery'), EMEBD_VERSION);
            wp_register_style('em-ebd-front-css', EMEBD_BASE_URL . 'includes/public/css/em_ebd_front.css', false, EMEBD_VERSION);
        }

        public function event_early_bird_discount_gs_settings(){?>
            <a href='javascript:void(0)' class="ep-extension-with-gs" ng-click="enableGlobalService('showEarlyBirdDiscount')">
                <div class="em-settings-box">
                    <img class="em-settings-icon" ng-src="<?php echo EMEBD_BASE_URL; ?>includes/admin/template/images/event-early-bird-discount-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Automatic Discounts', 'eventprime-event-automatic-discounts'); ?></div>
                    <span><?php _e('Auto-apply conditional discounts.', 'eventprime-event-automatic-discounts'); ?></span>
                </div>
            </a>
            <?php
        }

        public function event_early_bird_discount_gs_settings_form(){?>
            <div ng-show="showEarlyBirdDiscount">
                <div class="emrow">
                    <div class="emfield"><?php _e('Allow Automatic Discounts', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" ng-true-value="1" ng-fale-value="0" name="allow_early_bird_discount"  ng-model="data.options.allow_early_bird_discount">
                        <div class="emfield_error"></div>
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Enable Automatic Discounts.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
            </div><?php
        }

        public function event_early_bird_discount_gs_settings_save(){
            $request = EventM_Raw_Request::get_instance();
            $service =  EventM_Factory::get_service('EventM_Setting_Service');
            $model = $request->map_request_to_model('EventMEBD_Global_Settings_Model');
            $template = $service->save($model);
        }

        public function event_early_bird_discount_get_options($options){
            $emebddao = new EventMEBD_Global_Settings_DAO();
            $emebdmodel = $emebddao->get();
            $options->allow_early_bird_discount = absint($emebdmodel->allow_early_bird_discount);
            if(isset($options->load_extension_services)){
                $options->load_extension_services[] = 'showEarlyBirdDiscount';
            }
            return $options;
        }

        public function event_early_bird_discount_load_into_post_response_model($response) {
            $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
            $response = $service->load_post_response_model($response);
            return $response;
        }

        public function load_event_early_bird_discount_parameters($event, $post) {
            $event->selected_rule = metadata_exists('post',$post->ID,'em_selected_rule') ? em_get_post_meta($post->ID,'selected_rule',true) : '';
            return $event;
        }
        
        public function event_early_bird_discount_front_card_view_after_price($event) {
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount)){
                $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
                $active_rule_data = $service->get_active_rule_data($event);
                if(!empty($active_rule_data) && isset($active_rule_data['active_rule']) && !empty($active_rule_data['active_rule'])){
                    $discount = $active_rule_data['active_rule']['discount'];
                    $discount_type = $active_rule_data['active_rule']['discount_type'];
                    $ticket_price = $event->ticket_price;
                    if($discount_type == 'percentage'){
                        $percentage_price = ($ticket_price / 100) * $discount;
                        $discounted_price = number_format($ticket_price - $percentage_price, 2);
                    }
                    else{
                        $discounted_price = number_format($ticket_price - $discount, 2);
                        if($discounted_price < 0){
                            $discounted_price = 0.00;
                        }
                    } ?>
                    <div class="em_event_special_price ">
                        <?php echo em_price_with_position($discounted_price);?>
                    </div>
                    <script type="text/javascript"> 
                        var em_event_id = <?php echo $event->id ?>;
                        jQuery("#em-event-"+em_event_id+" .em_event_price").addClass('em-event-old-price');
                    </script>
                    <?php
                }
            }
        }
        
        public function event_early_bird_discount_front_card_view_after_footer($event) {            
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount)){
                wp_enqueue_script('em-ebd-front-js');
                wp_enqueue_style('em-ebd-front-css');
                $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
                $active_rule_data = $service->get_active_rule_description($event);
                if(!empty($active_rule_data) && isset($active_rule_data['active_rule']) && !empty($active_rule_data['active_rule']['show_on_front'])){
                    $rule_data = $active_rule_data['active_rule'];?>
                    <div class="em-cards-earlybird-section ep-event-detail-row"><?php
                        $top_data = $rule_data['ebd_discount_slogan'];
                        if($rule_data['rule_type'] == 'booking'){
                            $usedSeat = 0;
                            if(isset($rule_data['used_seat']) && !empty($rule_data['used_seat'])){
                                $usedSeat = $rule_data['used_seat'];
                            }
                            $remaining_seat = $rule_data['no_of_booking'] - $usedSeat;
                            $top_data = __(str_replace('{{bookings_left}}', $remaining_seat, $top_data), 'eventprime-event-automatic-discounts');
                        }
                        else if($rule_data['rule_type'] == 'user_role'){
                            $applied_user_role = $rule_data['applied_user_role'];
                            $top_data = __(str_replace('{{user_role}}', $applied_user_role, $top_data), 'eventprime-event-automatic-discounts');
                        }
                        else if($rule_data['rule_type'] == 'datetime'){
                            $date_format = get_option( 'date_format' );
                            $endDate = date($date_format, $rule_data['end_date']);
                            $top_data = __(str_replace('{{end_date}}', $endDate, $top_data), 'eventprime-event-automatic-discounts');
                        }
                        else if($rule_data['rule_type'] == 'seat'){
                            $no_of_seat = $rule_data['no_of_seat'];
                            $top_data = __(str_replace('{{free_seats}}', $no_of_seat, $top_data), 'eventprime-event-automatic-discounts');
                        }
                        if(!empty($top_data)){?>
                            <div class="em-cards-earlybird-top">
                                   <span class="material-icons ep-earlybird-icon em_color">local_offer</span>
                                <?php echo __($top_data);?>
                                <?php if(!empty($rule_data['description'])){ ?>
                                    <span class="em-cards-ebd-show-desc ep-earlybird-info em_color" data-event_id="<?php echo $event->id;?>" data-more_label="<?php echo __('More Info');?>" data-hide_label="<?php echo __('Hide Info');?>">
                                        <?php echo __('More Info');?>
                                    </span>
                                <?php }?>
                            </div>
                            <div class="em-cards-earlybird-bottom" id="em-ebd-desc-<?php echo $event->id;?>" style="display: none;"><?php echo __($rule_data['description'], 'eventprime-event-automatic-discounts');?></div><?php
                        }?>
                    </div><?php
                }
            }
        }
        
        public function event_early_bird_discount_popup_render($event){
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount)){
                wp_enqueue_script('em-ebd-front-js');
                wp_enqueue_style('em-ebd-front-css');
                $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
                $active_rule_data = $service->get_active_rule_description($event);
                if(!empty($active_rule_data) && isset($active_rule_data['active_rule']) && !empty($active_rule_data['active_rule']['show_on_front'])){
                    $rule_data = $active_rule_data['active_rule'];?>
                    <div class="em-cards-earlybird-section ep-event-detail-row"><?php
                        $top_data = $rule_data['ebd_discount_slogan'];
                        if($rule_data['rule_type'] == 'booking'){
                            $usedSeat = 0;
                            if(isset($rule_data['used_seat']) && !empty($rule_data['used_seat'])){
                                $usedSeat = $rule_data['used_seat'];
                            }
                            $remaining_seat = $rule_data['no_of_booking'] - $usedSeat;
                            $top_data = __(str_replace('{{bookings_left}}', $remaining_seat, $top_data), 'eventprime-event-automatic-discounts');
                        }
                        else if($rule_data['rule_type'] == 'user_role'){
                            $applied_user_role = $rule_data['applied_user_role'];
                            $top_data = __(str_replace('{{user_role}}', $applied_user_role, $top_data), 'eventprime-event-automatic-discounts');
                        }
                        else if($rule_data['rule_type'] == 'datetime'){
                            $date_format = get_option( 'date_format' );
                            $endDate = date($date_format, $rule_data['end_date']);
                            $top_data = __(str_replace('{{end_date}}', $endDate, $top_data), 'eventprime-event-automatic-discounts');
                        }
                        else if($rule_data['rule_type'] == 'seat'){
                            $no_of_seat = $rule_data['no_of_seat'];
                            $top_data = __(str_replace('{{free_seats}}', $no_of_seat, $top_data), 'eventprime-event-automatic-discounts');
                        }
                        if(!empty($top_data)){?>
                            <div class="em-cards-earlybird-top">
                                <span class="material-icons em_color">local_offer</span>
                                <?php echo __($top_data);?>
                                <?php if(!empty($rule_data['description'])){ ?>
                                    <span class="em-cards-ebd-show-desc em_color" id="em-cards-ebd-show-desc-<?php echo $event->id;?>" data-event_id="<?php echo $event->id;?>" data-more_label="<?php echo __('More Info');?>" data-hide_label="<?php echo __('Hide Info');?>">
                                        <?php echo __('More Info');?>
                                    </span>
                                <?php }?>
                            </div>
                            <div class="em-cards-earlybird-bottom" id="em-ebd-desc-<?php echo $event->id;?>" style="display: none;"><?php echo $rule_data['description'];?></div><?php
                        }?>
                    </div>
                    <script type="text/javascript">
                        var em_ev_id = <?php echo $event->id;?>;
                        $("#em-cards-ebd-show-desc-"+em_ev_id).click(function(e){
                            e.preventDefault();
                            e.stopPropagation();
                            if($("#em-ebd-desc-"+em_ev_id).hasClass('active')){
                                $("#em-ebd-desc-"+em_ev_id).removeClass('active');
                                $("#em-ebd-desc-"+em_ev_id).hide();
                                var more_label = $(this).data('more_label');
                                $(this).html(more_label);
                            }
                            else{
                                $("#em-ebd-desc-"+em_ev_id).addClass('active');
                                $("#em-ebd-desc-"+em_ev_id).show();
                                var hide_label = $(this).data('hide_label');
                                $(this).html(hide_label);
                            }
                        });
                    </script>
                    <?php
                }
            }
        }
        
        public function event_early_bird_discount_single_event_ticket_price_after($event, $ticketPrice) {
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount)){
                $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
                $active_rule_data = $service->get_active_rule_data($event);
                if(!empty($active_rule_data) && isset($active_rule_data['active_rule']) && !empty($active_rule_data['active_rule'])){
                    // not update price if seat type rule
                    if($active_rule_data['active_rule']['rule_type'] != 'seat'){
                        $discount = $active_rule_data['active_rule']['discount'];
                        $discount_type = $active_rule_data['active_rule']['discount_type'];
                        $ticket_price = $ticketPrice;
                        if($discount_type == 'percentage'){
                            $percentage_price = ($ticket_price / 100) * $discount;
                            $discounted_price = number_format($ticket_price - $percentage_price, 2);
                        }
                        else{
                            $discounted_price = number_format($ticket_price - $discount, 2);
                            if($discounted_price < 0){
                                $discounted_price = 0.00;
                            }
                        } ?>
                        <span class="em_event_special_price">
                            <?php echo em_price_with_position($discounted_price);?>
                        </span>
                        <script type="text/javascript"> 
                            jQuery('#em_booking .em_event_price').addClass('em-event-old-price');
                        </script><?php
                    }
                }
            }
        }
        
        public function event_early_bird_get_ebd_special_price($event){
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount)){
                $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
                $active_rule_data = $service->get_active_rule_data($event);
                if(!empty($active_rule_data) && isset($active_rule_data['active_rule']) && !empty($active_rule_data['active_rule'])){
                    // not update price if seat type rule
                    if($active_rule_data['active_rule']['rule_type'] != 'seat'){
                        $discount = $active_rule_data['active_rule']['discount'];
                        $discount_type = $active_rule_data['active_rule']['discount_type'];
                        $ticket_price = $event->ticket_price;
                        if($discount_type == 'percentage'){
                            $percentage_price = ($ticket_price / 100) * $discount;
                            $discounted_price = number_format($ticket_price - $percentage_price, 2);
                        }
                        else{
                            $discounted_price = number_format($ticket_price - $discount, 2);
                            if($discounted_price < 0){
                                $discounted_price = 0.00;
                            }
                        } ?>
                        <span class="em_event_special_price"> 
                            <?php echo em_price_with_position($discounted_price);?>
                        </span>
                        <script type="text/javascript"> 
                            jQuery('.em-booking-page-price').addClass('em-event-old-price');
                        </script><?php
                    }
                }
            }
        }
        
        public function event_early_bird_discount_front_ebd_section(){?>
            <div class="ep-ebd-wrap ep-billing-row" ng-if="ebd > 0">                
                <div class="em_ebd-label ep-billing-info-col">
                    <?php echo __("Automatic Discounts", 'eventprime-event-automatic-discounts'); ?> -&nbsp; 
                </div>
                <div class="em_ebd-amount ep-billing-info-col">
                    <strong ng-if="event.currency_position == 'before'"><?php echo em_currency_symbol();?>{{ebd}}</strong>
                    <strong ng-if="event.currency_position == 'before_space'"><?php echo em_currency_symbol();?> {{ebd}}</strong>
                    <strong ng-if="event.currency_position == 'after'">{{ebd}}<?php echo em_currency_symbol();?></strong>
                    <strong ng-if="event.currency_position == 'after_space'">{{ebd}} <?php echo em_currency_symbol();?></strong>
                </div>
            </div>
            <?php
        }

        public function event_early_bird_discount_apply_ebd(){
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount)){
                $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
                $postdata = $service->getEbdData();
                // In case of any errors
                if(isset($postdata['errors'])){
                    wp_send_json_error(array('errors' => $postdata['errors']));
                }
                wp_send_json_success($postdata);
            }
        }
        
        public function event_early_bird_discount_add_offline_payment_response($offline_response, $orders){
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount) && isset($orders[0]->applied_ebd) && !empty($orders[0]->applied_ebd)){
                $offline_response['applied_ebd'] = $orders[0]->applied_ebd;
                $offline_response['ebd_id'] = $orders[0]->ebd_id;
                $offline_response['ebd_name'] = $orders[0]->ebd_name;
                $offline_response['ebd_rule_type'] = $orders[0]->ebd_rule_type;
                $offline_response['ebd_discount_type'] = $orders[0]->ebd_discount_type;
                $offline_response['ebd_discount'] = $orders[0]->ebd_discount;
                $offline_response['ebd_discount_amount'] = $orders[0]->ebd_discount_amount;
            }
            return $offline_response;
        }
        
        public function event_early_bird_discount_add_without_payment_response($data, $orders){
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount) && isset($orders[0]->applied_ebd) && !empty($orders[0]->applied_ebd)){
                $data['applied_ebd'] = $orders[0]->applied_ebd;
                $data['ebd_id'] = $orders[0]->ebd_id;
                $data['ebd_name'] = $orders[0]->ebd_name;
                $data['ebd_rule_type'] = $orders[0]->ebd_rule_type;
                $data['ebd_discount_type'] = $orders[0]->ebd_discount_type;
                $data['ebd_discount'] = $orders[0]->ebd_discount;
                $data['ebd_discount_amount'] = $orders[0]->ebd_discount_amount;
            }
            return $data;
        }
        
        public function event_early_bird_discount_add_stripe_payment_response($stripe_response, $orders){
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount) && isset($orders[0]->applied_ebd) && !empty($orders[0]->applied_ebd)){
                $stripe_response['applied_ebd'] = $orders[0]->applied_ebd;
                $stripe_response['ebd_id'] = $orders[0]->ebd_id;
                $stripe_response['ebd_name'] = $orders[0]->ebd_name;
                $stripe_response['ebd_rule_type'] = $orders[0]->ebd_rule_type;
                $stripe_response['ebd_discount_type'] = $orders[0]->ebd_discount_type;
                $stripe_response['ebd_discount'] = $orders[0]->ebd_discount;
                $stripe_response['ebd_discount_amount'] = $orders[0]->ebd_discount_amount;
            }
            return $stripe_response;
        }
        
        public function event_early_bird_discount_add_booking_order_info($order_info, $data){
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount) && isset($data['applied_ebd']) && !empty($data['applied_ebd'])){
                $order_info['applied_ebd'] = $data['applied_ebd'];
                $order_info['ebd_id'] = $data['ebd_id'];
                $order_info['ebd_name'] = $data['ebd_name'];
                $order_info['ebd_rule_type'] = $data['ebd_rule_type'];
                $order_info['ebd_discount_type'] = $data['ebd_discount_type'];
                $order_info['ebd_discount'] = $data['ebd_discount'];
                $order_info['ebd_discount_amount'] = $data['ebd_discount_amount'];                
            }
            return $order_info;
        }
        
        public function event_early_bird_discount_booking_get_final_price($after_discount_price, $order_info) {
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount) && !empty($order_info) && isset($order_info['applied_ebd']) && !empty($order_info['applied_ebd'])){
                $ebd_discount_amount = $order_info['ebd_discount_amount'];
                $after_discount_price -= $ebd_discount_amount;
            }
            return $after_discount_price;
        }
        
        public function event_early_bird_discount_view_attendee_amount_received($amount_received, $booking) {
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            $order_info = $booking->order_info;
            if(!empty($allow_early_bird_discount) && !empty($order_info) && isset($order_info['applied_ebd']) && !empty($order_info['applied_ebd'])){
                $ebd_discount_amount = $order_info['ebd_discount_amount'];
                $amount_received -= $ebd_discount_amount;
            }
            return $amount_received;
        }
        
        public function event_early_bird_discount_view_attendee_amount_due($amount_due, $booking) {
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            $order_info = $booking->order_info;
            if(!empty($allow_early_bird_discount) && !empty($order_info) && isset($order_info['applied_ebd']) && !empty($order_info['applied_ebd'])){
                $ebd_discount_amount = $order_info['ebd_discount_amount'];
                $amount_due -= $ebd_discount_amount;
            }
            return $amount_due;
        }
        
        public function event_early_bird_discount_rule_description($event) {
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount)){
                $this->event_early_bird_discount_front_card_view_after_footer($event);
            }
        }
        
        public function event_early_bird_discount_load_calender_ticket_price($attr, $event) {
            $attr_ticket_price = '';
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount)){
                $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
                $active_rule_data = $service->get_active_rule_data($event);
                if(!empty($active_rule_data) && isset($active_rule_data['active_rule']) && !empty($active_rule_data['active_rule'])){
                    // if seat type rule then return
                    if($active_rule_data['active_rule']['rule_type'] == 'seat'){
                        return $attr;
                    }
                    $discount = $active_rule_data['active_rule']['discount'];
                    $discount_type = $active_rule_data['active_rule']['discount_type'];
                    $ticket_price = $attr;
                    if($discount_type == 'percentage'){
                        $percentage_price = ($ticket_price / 100) * $discount;
                        $discounted_price = number_format($ticket_price - $percentage_price, 2);
                    }
                    else{
                        $discounted_price = number_format($ticket_price - $discount, 2);
                        if($discounted_price < 0){
                            $discounted_price = 0.00;
                        }
                    }
                    $attr_ticket_price .= '<span class="em_event_old_price">';
                    $attr_ticket_price .= em_price_with_position($attr);
                    $attr_ticket_price .= '</span>';
                    $attr_ticket_price .= '<span class="em_event_special_price em-booking-ticket-price">';
                    $attr_ticket_price .= em_price_with_position($discounted_price);
                    $attr_ticket_price .= '</span>';
                }
            }
            if(!empty($attr_ticket_price)){
                return $attr_ticket_price;
            }
            else{
                return $attr;
            }
        }
        
        public function event_early_bird_discount_front_user_booking_before_total_price($booking){
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount)){
                $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
                $service->front_user_booking_item_details($booking);
            }
        }
        
        public function event_early_bird_discount_data_verify_booking($booking, $all_order_data) {
            $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
            if(!empty($allow_early_bird_discount)){
                if(!empty($booking) && isset($all_order_data->applied_ebd) && !empty($all_order_data->applied_ebd)){
                    $booking->order_info['applied_ebd'] = $all_order_data->applied_ebd;
                    $booking->order_info['ebd_id'] = $all_order_data->ebd_id;
                    $booking->order_info['ebd_name'] = $all_order_data->ebd_name;
                    $booking->order_info['ebd_rule_type'] = $all_order_data->ebd_rule_type;
                    $booking->order_info['ebd_discount_type'] = $all_order_data->ebd_discount_type;
                    $booking->order_info['ebd_discount'] = $all_order_data->ebd_discount;
                    $booking->order_info['ebd_discount_amount'] = $all_order_data->ebd_discount_amount;
                }
            }
            return $booking;
        }
    }
}

function em_automatic_discounts() {
    return EM_Automatic_Discounts::instance();
}
function em_automatic_discounts_checks(){ ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e( 'EventPrime Automatic Discounts Extension won\'t work as EventPrime plugin is not active/installed.', 'event-magic' ); ?></p>
    </div>
<?php }

add_action('plugins_loaded',function(){if(!class_exists('Event_Magic')){add_action('admin_notices','em_automatic_discounts_checks');}});
add_action('event_magic_loaded', 'em_automatic_discounts');
require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_automatic_discount_metadata.json',
    __FILE__,
    'eventprime-event-automatic-discount'
);