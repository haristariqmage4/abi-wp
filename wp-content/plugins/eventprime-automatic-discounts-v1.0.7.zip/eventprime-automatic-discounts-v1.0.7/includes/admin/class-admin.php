<?php
class EventPrime_Early_Bird_Discount_Admin {
    
    protected $request;
    protected $service;
    protected $dao;
    
    public function __construct() {
        $this->request = EventM_Raw_Request::get_instance();
        $this->service = EventM_Factory::get_service('EventM_Service');
        $this->dao = new EventM_Event_DAO();

        add_action('admin_enqueue_scripts', array($this,'enqueue'));
        add_action('event_magic_dashboard_early_bird_discount_link',array($this,'dashboard_link'));
        add_action('event_magic_dashboard_earlybird_list_tab',array($this,'earlybird_list_page'));
        add_action('event_magic_dashboard_earlybird_rule_tab',array($this,'earlybird_rule_page'));
        add_action('event_magic_load_strings',array($this,'load_screen_data'));
        add_action('wp_ajax_em_save_event_ebd', array($this, 'save_event_ebd'));
        add_action('wp_ajax_em_delete_event_ebd_rule', array($this, 'delete_event_ebd_rule'));
    }
    
    public function enqueue(){
        wp_register_style('em_early_bird_discount', plugin_dir_url(__DIR__) . 'admin/template/css/em_early_bird_discount.css', false, EVENTPRIME_VERSION);
        wp_register_style('em_early_bird_discount_select2', plugin_dir_url(__DIR__) . 'admin/template/css/select2.min.css', false, EVENTPRIME_VERSION);
        wp_register_script('em-early-bird-discount-controller',plugin_dir_url(__DIR__).'/admin/template/js/em-early-bird-discount-controller.js',array('em-angular-module', 'em-event-controller'));
        wp_register_script('em-early-bird-discount-select2',plugin_dir_url(__DIR__).'/admin/template/js/select2.min.js',array('em-event-controller'));
    }

    public function dashboard_link($post_id) {
        $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
        if(!empty($allow_early_bird_discount)){
            include_once('template/dashboard_icon.php');
        }
    }
    
    public function earlybird_rule_page($post_id) {
        $rule_id = event_m_get_param('rule_id');
        $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
        if(!empty($allow_early_bird_discount)){
            wp_enqueue_script('em-early-bird-discount-controller');
            wp_enqueue_style('em_early_bird_discount_select2');
            wp_enqueue_script('em-early-bird-discount-select2');
            include_once('template/settings.php');
        }
    }

    public function earlybird_list_page($post_id) {
        wp_enqueue_script('em-early-bird-discount-controller');
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_style('em_early_bird_discount');
        wp_localize_script('em-early-bird-discount-controller', 'em_js_vars', em_global_js_strings());
        include_once('template/ebds.php' );
    }

    public function load_screen_data($context){
        $allow_early_bird_discount = em_global_settings('allow_early_bird_discount');
        if(!empty($allow_early_bird_discount)){
            $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
            if($context == 'admin_early_bird_list_templates'){
                $response = $service->load_list_page();
                wp_send_json_success($response);
            }
            else if($context == 'admin_early_bird_data_templates'){
                $response = $service->load_edit_page();
                wp_send_json_success($response);   
            }
            else if($context == 'admin_early_bird_list_sorting'){
                $response = $service->load_sorted_list_page();
                wp_send_json_success($response);   
            }
        }
    }

    public function save_event_ebd(){
        $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
        $request = EventM_Raw_Request::get_instance();
        $event_id = absint(event_m_get_param('event_id'));
        $model = $request->map_request_to_model('EventM_Early_Bird_Discounts_Model');
        $model->id = absint(event_m_get_param('id'));
        $template = $service->save($model);
        // In case of any errors
        if ($template instanceof WP_Error) {
            $error_msg = $template->get_error_message(); 
            wp_send_json_error(array('errors' => array($error_msg)));
        }
        
        $redirect = admin_url('/admin.php?page=em_dashboard&tab=earlybird_list&post_id='.$event_id);
        wp_send_json_success(array('redirect' => $redirect));
    }

    public function delete_event_ebd_rule(){
        $service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
        $request = EventM_Raw_Request::get_instance();
        $template = $service->delete();
        // In case of any errors
        if ($template instanceof WP_Error) {
            $error_msg = $template->get_error_message(); 
            wp_send_json_error(array('errors' => array($error_msg)));
        }
        $post_id = absint(event_m_get_param('post_id'));
        $redirect = admin_url('/admin.php?page=em_dashboard&tab=earlybird_list&post_id='.$post_id);
        wp_send_json_success(array('redirect' => $redirect));
    }
    
    public function check_permission() {
        if (!em_is_user_admin()) {
            $error_msg = __('User not allowed to perform this operation','eventprime-event-automatic-discounts');
            wp_send_json_error(array('errors'=>array($error_msg)));
        }
    }
}
new EventPrime_Early_Bird_Discount_Admin;