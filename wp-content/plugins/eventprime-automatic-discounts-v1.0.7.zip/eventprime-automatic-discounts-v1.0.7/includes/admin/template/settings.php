<div ng-controller="eventCtrl" ng-app="eventMagicApp" ng-cloak ng-init="initialize('event_early_bird_discount')">
    <div class="kikfyre kf-container" ng-controller="earlyBirdDiscountCtrl" ng-init="initialize('edit', '<?php echo $rule_id;?>')" ng-cloak>
        <div class="kf_progress_screen" ng-show="requestInProgress"></div>
        <div class="kf-db-content" ng-hide="requestInProgress">
            <div class="kf-db-title">
                <?php _e('Automatic Discounts', 'eventprime-event-automatic-discounts'); ?>
            </div>
            <div class="form_errors">
                <ul>
                    <li class="emfield_error" ng-repeat="error in formErrors">
                        <span>{{error}}</span>
                    </li>
                </ul>
            </div>
            <!-- FORM -->
            <form name="ebdForm" ng-submit="saveEbd(ebdForm.$valid)" novalidate>
                <input type="text" name="event_id" ng-model="data.ebds.event_id" style="display: none;">
                <input type="text" name="id" ng-model="data.ebds.id" style="display: none;">
                <div class="emrow">
                    <div class="emfield"><?php _e('Discount Rule Name', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input required type="text" name="name" ng-model="data.ebd.name">
                        <div class="emfield_error">
                            <span ng-show="ebdForm.name.$error.required && !ebdForm.name.$pristine"><?php _e('This is a required field.', 'eventprime-event-automatic-discounts'); ?></span>
                        </div>
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Name of your discount rule. It will help you identify the rule among list of other rules.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                <div class="emrow">
                    <div class="emfield"><?php _e('Select Rule Type', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <select required name="rule_type" ng-model="data.ebd.rule_type" ng-options="key as value for (key, value) in data.ebds.rule_types" ng-change="changeRuleType()"></select>
                        <div class="emfield_error">
                            <span ng-show="ebdForm.rule_type.$error.required && !ebdForm.rule_type.$pristine"><?php _e('This is a required field.', 'eventprime-event-automatic-discounts'); ?></span>
                        </div>
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Choose the primary logic on which the rule will be based.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                <div class="emrow" ng-show="data.ebd.rule_type == 'datetime'">
                    <div class="emfield"><?php _e('Start Date', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input ng-required="data.ebd.rule_type == 'datetime'" type="text" id="ebd_start_date" name="ebd_start_date" ng-model="data.ebd.ebd_start_date" placeholder="<?php _e('Enter Start Date', 'eventprime-event-automatic-discounts'); ?>" autocomplete="off">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('The date and time on which the discount will commence, for date-time based rules.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                <div class="emrow" ng-show="data.ebd.rule_type == 'datetime'">
                    <div class="emfield"><?php _e('End Date', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input ng-required="data.ebd.rule_type == 'datetime'" type="text" id="ebd_end_date" name="ebd_end_date" ng-model="data.ebd.ebd_end_date" placeholder="<?php _e('Enter End Date', 'eventprime-event-automatic-discounts'); ?>" autocomplete="off">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('The date and time on which the discount will end, for date-time based rules.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>

                <div class="emrow" ng-if="data.ebd.rule_type == 'booking'">
                    <div class="emfield"><?php _e('Eligible Bookings', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input ng-required="data.ebd.rule_type == 'booking'" ng-min="0" type="number" string-to-number id="no_of_booking" name="no_of_booking" ng-model="data.ebd.no_of_booking" placeholder="<?php _e('Enter Total No. of Bookings', 'eventprime-event-automatic-discounts'); ?>">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Enter the number of initial bookings which will receive this discount. Once this number is reached, visitors will no longer see the discounted price.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                
                <div class="emrow" ng-show="data.ebd.rule_type == 'user_role' || data.ebd.rule_type == 'seat'">
                    <div class="emfield"><?php _e('Eligible Roles', 'eventprime-event-calendar-management'); ?></div>
                    <div class="eminput">
                        <select multiple id="rule_user_role" name="rule_user_role" ng-model="data.ebd.rule_user_role" ng-options="key as label for (key,label) in data.ebds.rule_user_roles"></select>
                    </div>
                    <div class="emfield_error">
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Select one or more Roles from the dropdown list. Users belonging only to these Roles will see this discount. Please remember, Role based discounts will only be visible to logged in users.', 'eventprime-event-calendar-management'); ?>
                    </div>
                </div>

                <div class="emrow" ng-if="data.ebd.rule_type == 'seat'">
                    <div class="emfield"><?php _e('Number of Free Seats per Booking', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input ng-required="data.ebd.rule_type == 'seat'" ng-min="0" type="number" string-to-number id="no_of_seat" name="no_of_seat" ng-model="data.ebd.no_of_seat" placeholder="<?php _e('Enter Total No. of Seats', 'eventprime-event-automatic-discounts'); ?>">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Set number of free seats included with every booking. Set the value to 0 for making all seats free.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>

                <div class="emrow" ng-show="data.ebd.rule_type == 'datetime' || data.ebd.rule_type == 'booking' || data.ebd.rule_type == 'user_role'">
                    <div class="emfield"><?php _e('Discount Type', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <span class="ep-recurrence-interval">
                            <select ng-required="data.ebd.rule_type == 'datetime' || data.ebd.rule_type == 'booking' || data.ebd.rule_type == 'user_role'" name="discount_type" ng-model="data.ebd.discount_type" ng-options="key as value for (key, value) in data.ebds.discount_types"></select>
                        </span>
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Choose if you wish to discount a flat fixed amount or a percentage of total price.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                <div class="emrow" ng-show="data.ebd.rule_type == 'datetime' || data.ebd.rule_type == 'booking' || data.ebd.rule_type == 'user_role'">
                    <div class="emfield"><?php _e('Discount Offered', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input ng-required="data.ebd.rule_type == 'datetime' || data.ebd.rule_type == 'booking' || data.ebd.rule_type == 'user_role'" type="number" id="discount" name="discount" ng-model="data.ebd.discount" placeholder="<?php _e('Enter Discount', 'eventprime-event-automatic-discounts'); ?>" ng-min="0" string-to-number>
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('If you have selected Fixed discount above, enter the amount, or if you have selected Percentage above, enter the percentage value. Only numbers are allowed.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                <div class="emrow">
                    <div class="emfield"><?php _e('Discount Slogan', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input type="text" id="ebd_discount_slogan" name="ebd_discount_slogan" ng-model="data.ebd.ebd_discount_slogan">
                    </div>
                    <div class="emnote" ng-non-bindable>
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('A one line slogan highlighting the discount just below the price. For example, "Get 30% off on bookings before Friday!". Use inline variables to insert end date or seats remaining before discount ends. {{end_date}} for end date. {{bookings_left}} for discounted bookings left. {{user_role}} for current user’s role and {{free_seats}} for number of free seats per booking.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                <div class="emrow kf-bg-light">
                    <div class="emfield emeditor"><?php _e('Description','eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput emeditor">
                        <?php 
                            $rule_id= event_m_get_param('rule_id');
                            $content = '';
                            if($rule_id!== null && (int)$rule_id> 0)
                            {
                                $post = get_post($rule_id);
                                if(!empty($post))
                                    $content = $post->post_content;
                            }
                            wp_editor($content,'description');
                        ?>
                    </div>
                    <div class="emnote emeditor">
                        <?php _e("Describe your offer. It can be made visible to eligible visitors when they see the event details on your website. If the discount is inactive, or the user is ineligible, this content will not appear. To display the offer, select the option below..",'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                <div class="emrow" ng-if="data.ebd.rule_type == 'user_role'">
                    <div class="emfield"><?php _e('Booking Limit', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input type="number" ng-min="0" id="rule_user_limit" name="rule_user_limit" ng-model="data.ebd.rule_user_limit" placeholder="<?php _e('Enter user limit', 'eventprime-event-automatic-discounts'); ?>" string-to-number>
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Limit the maximum number of bookings which will receive this discount. This limit works on ‘per-role’ basis and not the combined total bookings for all selected Roles. 0 will mean no limit.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                <div class="emrow">
                    <div class="emfield"><?php _e('Display Discount to the Visitors ', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" id="show_on_front" name="show_on_front" ng-model="data.ebd.show_on_front" string-to-number ng-true-value="1" ng-false-value="0">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Choose if you wish to display this discount and its description to the visitors wherever the associated event appears on your website. If you turn it on, visitors will see the discounted price along with the actual price and the discount offer details described above.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                <div class="emrow">
                    <div class="emfield"><?php _e('Active','eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" name="is_active" string-to-number ng-model="data.ebd.is_active" ng-true-value="1" ng-false-value="0">
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Only active discounts are applied to the events. If you do not wish to go live with this discount yet, you can turn off this option..','eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                <div class="emrow">
                    <div class="emfield"><?php _e('Priority', 'eventprime-event-automatic-discounts'); ?></div>
                    <div class="eminput">
                        <input type="number" ng-init="data.ebd.priority = 1" min="1" string-to-number id="priority" name="priority" ng-model="data.ebd.priority" autocomplete="off" placeholder="<?php _e('Enter rule priority', 'eventprime-event-automatic-discounts'); ?>">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('If you have created multiple discount rules, and more than one rule applies to a scenario, the visitor will see the discount offer which has a higher priority. 1 will be top priority.', 'eventprime-event-automatic-discounts'); ?>
                    </div>
                </div>
                <?php
                $extensions = event_magic_instance()->extensions;
                // check for seating extension
                if(in_array('seating', $extensions)){?>
                    <div class="emrow">
                        <div class="emfield"><?php _e('Disable on Volume Discounts', 'eventprime-event-automatic-discounts'); ?></div>
                        <div class="eminput">
                            <input type="checkbox" ng-true-value="1" ng-fale-value="0" name="disable_if_volume_discount" ng-model="data.ebd.disable_if_volume_discount" string-to-number>
                            <div class="emfield_error"></div>
                        </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php _e("Disable this discount when the booking already has volume discount applied. If allowed, this discount will be applied on the booking price after the volume discount. This option will have no effect if you have not set volume discounts.", 'eventprime-event-automatic-discounts'); ?>
                        </div>
                    </div><?php
                }
                // check for coupon code extension
                if(in_array('coupons', $extensions)){?>
                    <div class="emrow">
                        <div class="emfield"><?php _e('Disable with Discount Coupons', 'eventprime-event-automatic-discounts'); ?></div>
                        <div class="eminput">
                            <input type="checkbox" ng-true-value="1" ng-fale-value="0" name="disable_if_coupon_code_discount" ng-model="data.ebd.disable_if_coupon_code_discount" string-to-number>
                            <div class="emfield_error"></div>
                        </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php _e("Disable this discount if the user applies a discount coupon on checkout. If disabled, user will be informed that the discount has been removed on adding the coupon. It will be reapplied if discount coupon is removed.", 'eventprime-event-automatic-discounts'); ?>
                        </div>
                    </div><?php
                }?>
                <div class="dbfl kf-buttonarea">
                    <div class="em_cancel">
                        <a class="kf-cancel" href="<?php echo admin_url('/admin.php?page=em_dashboard&tab=earlybird_list&post_id=' . $post_id); ?>">
                            <?php _e('Cancel', 'eventprime-event-automatic-discounts'); ?>
                        </a>
                    </div>
                    <button type="submit" class="btn btn-primary" ng-disabled="ebdForm.$invalid || requestInProgress">
                        <?php _e('Save', 'eventprime-event-automatic-discounts'); ?>
                    </button>
                    <span class="kf-error" ng-show="ebdForm.$invalid && ebdForm.$dirty ">
                        <?php _e('Please fill all required fields.','eventprime-event-automatic-discounts'); ?></span>
                </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
    (function($){    
        $(document).ready(function(){
            $("#rule_user_role").select2({
                placeholder: "Select Roles",
                tags: true,
                width: "80%"
            });
        });
    })(jQuery);
</script>