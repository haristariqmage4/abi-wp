<?php

class EventM_Early_Bird_Discounts_Model extends EventM_Array_Model
{
    public $id;
    public $event_id;
    public $name;
    public $rule_type;
    public $ebd_start_date = '';
    public $ebd_end_date = '';
    public $rule_user_role = [];
    public $no_of_booking = '';
    public $no_of_seat = '';
    public $discount;
    public $discount_type;
    public $is_active = true;
    public $priority = 1;
    public $description = '';
    public $show_on_front = 0;
    public $rule_user_limit = 0;
    public $status = "publish";
    public $disable_if_volume_discount = 0;
    public $disable_if_coupon_code_discount = 0;
    public $ebd_discount_slogan;
}