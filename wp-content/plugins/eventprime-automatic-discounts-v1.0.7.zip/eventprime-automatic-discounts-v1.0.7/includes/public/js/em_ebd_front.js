(function( $ ) {
    'use strict';
    $(function() {
        $(".em-cards-ebd-show-desc").click(function(){
            var em_event_id = $(this).data('event_id');
            if($("#em-ebd-desc-"+em_event_id).hasClass('active')){
                $("#em-ebd-desc-"+em_event_id).removeClass('active');
                $("#em-ebd-desc-"+em_event_id).hide();
                var more_label = $(this).data('more_label');
                $(this).html(more_label);
            }
            else{
                $("#em-ebd-desc-"+em_event_id).addClass('active');
                $("#em-ebd-desc-"+em_event_id).show();
                var hide_label = $(this).data('hide_label');
                $(this).html(hide_label);
            }
        });
    });
})( jQuery );