<?php
if (!defined( 'ABSPATH')){
    exit;
}

class EventM_Early_Bird_Discount_Service {
    
    private $dao;
    private static $instance = null;
    
    private function __construct() {
        $this->dao = new EventM_Early_Bird_Discount_DAO;
    }
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function load_post_response_model($response){
        return $response;
    }

    public function load_list_page(){
        $response = new stdClass();
        $post_id = absint(event_m_get_param('post_id'));
        $response->ebds = array();
        $args = array(
            'posts_per_page' => EM_PAGINATION_LIMIT,
            'offset' => ((int) event_m_get_param('paged')-1) * EM_PAGINATION_LIMIT,
            'post_type' => EM_EBD_POST_TYPE,
            'post_status' => 'publish',
            'meta_query' => array(
                array(
                    'key'   => 'em_event_id',
                    'value' => $post_id,
                ),
                'em_priority_clause' => array(
                    'key' => 'em_priority',
                ),
            ),

            'orderby' => array(
                'em_priority_clause' => 'ASC',
            ),
            'order' => 'ASC',
        );
        $templates = get_posts($args);
        foreach($templates as $tmp){
            $template = $this->load_model_from_db($tmp->ID);
            $data = $template->to_array();
            if(!empty($data['ebd_start_date'])){
                $ebd_start_date = date("F d, Y H:i", $data['ebd_start_date']);
                $data['ebd_start_date'] = $ebd_start_date;
            }
            else{
                $data['ebd_start_date'] = '-';
            }
            if(!empty($data['ebd_end_date'])){
                $ebd_end_date = date("F d, Y H:i", $data['ebd_end_date']);
                $data['ebd_end_date'] = $ebd_end_date;
            }
            else{
                $data['ebd_end_date'] = '-';
            }
            $rule_status = 'Active';
            if(empty($data['is_active'])){
                $rule_status = 'In-Active';
            }
            $data['rule_status'] = $rule_status;
            $data['no_of_booking'] = (empty($data['no_of_booking']) ? '-' : $data['no_of_booking']);
            $data['no_of_seat'] = (empty($data['no_of_seat']) ? '-' : $data['no_of_seat']);
            $data['ebd_rule_type'] = EVENTPRIME_EBD_RULE_TYPE[$data['rule_type']];
            $response->ebds[] = $data;
        }
        $post_count_obj = wp_count_posts($this->dao->post_type);
        $post_count = $post_count_obj->publish;
        $response->total_posts = range(1, $post_count);
        $response->pagination_limit = EM_PAGINATION_LIMIT;
        $response->post_id = $post_id;
        return $response;
    }

    public function load_edit_page()
    {
        global $wp_roles;
        $response = new stdClass();
        $post_id = absint(event_m_get_param('post_id'));
        if(!empty($post_id)){
            $event_service = EventM_Factory::get_service('EventM_Service');
            $event = $event_service->load_model_from_db($post_id);
            if(!empty($event)){
                $response->ebds = array();
                $response->event = array();
                $rule_id = event_m_get_param('rule_id');
                $discount = 0;
                if(!empty($rule_id)){
                    $ebd_rule = $this->load_model_from_db($rule_id);
                    $response->ebd = $ebd_rule;
                    if(!empty($ebd_rule->ebd_start_date)){
                        $ebd_start_date = date("m/d/Y H:i", $ebd_rule->ebd_start_date);
                        $response->ebd->ebd_start_date = $ebd_start_date;
                    }
                    if(!empty($ebd_rule->ebd_end_date)){
                        $ebd_end_date = date("m/d/Y H:i", $ebd_rule->ebd_end_date);
                        $response->ebd->ebd_end_date = $ebd_end_date;
                    }
                    if(!empty($ebd_rule->discount)){
                        $discount = $ebd_rule->discount;
                    }
                }
                else{
                    $response->ebd['discount'] = $discount;
                }
                $response->event['ebd_start_booking_date'] = date("Y-m-d H:i", $event->start_booking_date);
                $response->event['ebd_last_booking_date'] = date("Y-m-d H:i", $event->last_booking_date);
                $response->ebds['event_id'] = $post_id;
                $response->ebds['discount_types'] = EVENTPRIME_EBD_DISCOUNT_TYPE;
                $response->ebds['rule_types'] = EVENTPRIME_EBD_RULE_TYPE;
                $userRoles = array();
                if(!empty($wp_roles->roles)){
                    foreach ($wp_roles->roles as $key => $value) {
                        $userRoles[$key] = $value['name'];
                    }
                }
                $response->ebds['rule_user_roles'] = $userRoles;
            }
        }
        return $response;
    }

    public function load_model_from_db($id){
        return $this->dao->get($id);
    }

    public function save($model){
        $template = $this->dao->save($model);
        return $template;
    }

    public function delete(){
        $selections = event_m_get_param('selections');
        $template = $this->dao->deleteRule($selections);
        return $template;
    }

    public function load_sorted_list_page(){
        $response = new stdClass();
        $response->ebds = array();
        $post_id = absint(event_m_get_param('post_id'));
        $rulespositions = event_m_get_param('rulespositions');
        if(!empty($rulespositions)){
            foreach ($rulespositions as $key => $ruleid) {
                $newposition = $key+1;
                update_post_meta($ruleid, 'em_priority', $newposition);
            }
            $response = $this->load_list_page();
            return $response;
        }
        return $response;
    }
    
    public function getEbdData(){
        $input = file_get_contents("php://input");
        $ebd = json_decode($input);
        $ebdData = $this->dao->fetchEbdData($ebd);
        return $ebdData;
    }
    
    public function get_active_rule_data($event) {
        $ebddata = new stdClass();
        $ebddata->event_id = $event->id;
        $ebdData = $this->dao->fetchEbdData($ebddata);
        if(!isset($ebdData['errors']) || empty($ebdData['errors'])){
            return $ebdData;
        }
        return false;
    }
    
    public function get_active_rule_description($event) {
        $ebddata = new stdClass();
        $ebddata->event_id = $event->id;
        $ebdData = $this->dao->fetchEbdData($ebddata);
        if(!isset($ebdData['errors']) || empty($ebdData['errors'])){
            if(isset($ebdData['active_rule']) && !empty($ebdData['active_rule'])){
                if($ebdData['active_rule']['rule_type'] == 'booking'){
                    $rule_data = (object) $ebdData['active_rule'];
                    $usedSeat = $this->dao->check_booking_type_ebd_rule_uses($ebdData['active_rule']['id'], $rule_data);
                    if(!empty($usedSeat)){
                        $ebdData['active_rule']['used_seat'] = $usedSeat;
                    }
                }
                return $ebdData;
            }
        }
        return false;
    }
    
    public function front_user_booking_item_details($booking) {
        if(!empty($booking) && !empty($booking->id)){
            $applied_ebd = (isset($booking->order_info['applied_ebd']) ? $booking->order_info['applied_ebd'] : '');
            if(!empty($applied_ebd)){?>
                <tr>
                    <td></td>
                    <td colspan="2" class="ep-booking-totsl-t"><?php _e('Automatic Discounts','eventprime-event-automatic-discounts'); ?></td>
                    <td class="ep-booking-total-p"><?php echo em_price_with_position($booking->order_info['ebd_discount_amount']);?></td>
                </tr><?php
            }
        }
    }
}
EventM_Early_Bird_Discount_Service::get_instance();