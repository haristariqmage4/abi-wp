<div class="kikfyre" ng-app="eventMagicApp" ng-controller="couponsCtrl" ng-init="initialize('list')" ng-cloak="">
	<div class="kf_progress_screen" ng-show="requestInProgress"></div>
	<div class="kf-hidden" style="{{requestInProgress ?'display:none':'display:block'}}">
		<!-- Operations bar Starts --> 
		<div class="kf-operationsbar dbfl">
			<div class="kf-titlebar_dark dbfl">
				<div class="kf-title kf-title-1 difl"><?php _e('Coupon Codes','eventprime-event-coupons'); ?></div>
			</div>
			<div class="kf-nav dbfl">
				<ul>
					<li><a ng-href="<?php echo admin_url('admin.php?page=em_add_new_coupon'); ?>"><?php _e('Add New', 'eventprime-event-coupons'); ?></a></li>
					<li><button class="em_action_bar_button" ng-click="deleteCoupons()" ng-disabled="selections.length == 0" ><?php _e('Delete', 'eventprime-event-coupons'); ?></button></li>
				</ul>
			</div>
		</div>
		<!--  Operations bar Ends -->
		<div class="emagic-table dbfl">
			<table class="kf-etypes-table ep-coupon-code-table "><!-- remove class for default 80% view -->
				<tr>
					<th class="table-header"><input type="checkbox" id="em_bulk_selector" ng-click="checkAll()" ng-model="selectedAll"  ng-checked="selections.length == data.coupons.length"/></th>
					<th class="table-header"><?php _e('Name', 'eventprime-event-coupons'); ?></th>
					<th class="table-header"><?php _e('Code', 'eventprime-event-coupons'); ?></th>
					<th class="table-header"><?php _e('Discount', 'eventprime-event-coupons'); ?></th>
					<th class="table-header"><?php _e('Start Date', 'eventprime-event-coupons'); ?></th>
					<th class="table-header"><?php _e('End Date', 'eventprime-event-coupons'); ?></th>
					<th class="table-header"><?php _e('No. of Uses', 'eventprime-event-coupons'); ?></th>
					<th class="table-header"><?php _e('Action', 'eventprime-event-coupons'); ?></th>
				</tr>

				<tr ng-repeat="coupon in data.coupons">
					<td>
						<input type="checkbox"  ng-model="coupon.Selected" ng-click="selectCoupon(coupon.id)"  ng-true-value="{{coupon.id}}" ng-false-value="0">
					</td>
					<td>{{coupon.name}}</td>
					<td>{{coupon.code}}</td>
					<td>{{coupon.discount}} {{coupon.discount_type}}</td>
					<td>{{coupon.start_date}}</td>
					<td>{{coupon.end_date}}</td>
					<td>{{coupon.no_of_uses}}</td>
					<td>
						<a ng-href="<?php echo admin_url('admin.php?page=em_add_new_coupon'); ?>&coupon_id={{coupon.id}}"><?php _e('View/Edit', 'eventprime-event-coupons'); ?></a>
					</td>
				</tr>
			</table>

			<div class="em_empty_card" ng-show="data.coupons.length == 0">
				<?php _e('The Coupon Codes you create will appear here in tabular Format. Presently, you do not have any coupon code created.', 'eventprime-event-coupons'); ?>
			</div>
		</div>
		<div class="kf-pagination dbfr" ng-show="data.coupons.length != 0"> 
			<ul>
				<li dir-paginate="coupon in data.total_posts | itemsPerPage: data.pagination_limit"></li>
			</ul>
			<dir-pagination-controls on-page-change="pageChanged(newPageNumber)"></dir-pagination-controls>
		</div>
	</div>
</div>