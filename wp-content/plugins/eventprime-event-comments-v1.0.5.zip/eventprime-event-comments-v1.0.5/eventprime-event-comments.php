<?php
/**
 * Plugin Name: EventPrime Event Comments
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that allows to comments on any event.
 * Version: 1.0.5
 * Author: EventPrime
 * Text Domain: eventprime-event-comments
 * Domain Path: /languages
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 6.1.1
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_Event_Comments')) {
    final class EM_Event_Comments {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.0.5';
        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;      

        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }
        /**
         * Event_Magic Constructor.
         */
        private function __construct() {
            $this->define_constants();
            $this->load_textdomain();
            $this->includes(); 
            $this->define_hooks();
            $em = event_magic_instance();
            array_push($em->extensions,'event-comments');
            add_post_type_support( 'em_event', 'comments' );
            $this->event_comment_activate_extension();
        }   

        public function define_constants(){
            $em = event_magic_instance();
            $em->define('EMEC_BASE_URL', plugin_dir_url(__FILE__));
            define('EMEC_VERSION', $this->version);
        }
      
        public function includes(){
            include_once('includes/models/class-emec-global-settings.php');
            include_once('includes/dao/class-emec-global-settings.php');
        }      

        public function define_hooks(){
            add_action('event_magic_gs_settings',array($this,'event_comments_gs_settings'));
            add_action('event_magic_gs_popup',array($this,'event_comments_gs_settings_form'));
            add_action('em_after_gs_save',array($this,'event_comments_gs_settings_save'));
            add_filter('em_load_gs_ext_options',array($this,'event_comments_get_options'), 99, 1);
            add_filter('event_magic_gs_get_model',array($this,'event_comments_get_options'), 99, 1);
            add_action('ep_popup_event_saved', array($this, 'event_comments_popup_set_comment_status'), 10, 2);
            add_filter('comment_id_fields', array($this,'event_comments_update_comment_id'), 99, 3);
            add_action('event_magic_event_comments_list',array($this,'event_comments_list_by_id'));
            add_filter('ep_before_saving_popup_event', array($this,'event_comments_update_allowed'), 99, 1);
            add_action('event_magic_save_event',array($this,'event_comments_save_event_comment_status'));
            add_action('event_magic_custom_extension_setting',array($this,'event_comment_custom_extension_setting'));

            add_filter('event_magic_format_model_from_db', array($this,'event_comment_format_model_from_db'),10,1);
            add_filter('event_magic_format_model_to_save', array($this,'event_comment_format_model_to_save'),10,1);
            add_action('event_magic_show_comment_template_for_seo_urls', array($this,'event_show_comment_template_for_seo_urls'));
            add_filter('comment_post_redirect',  array($this,'ep_custom_comment_redirect_url'),10,1);
            register_deactivation_hook( __FILE__, array($this, 'event_comment_deactivate_extension' ));
        }

        public function load_textdomain(){
            load_plugin_textdomain('eventprime-event-comments', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        public function event_comments_gs_settings(){?> 
            <a href="javascript:void(0)" class="ep-extension-with-gs" ng-click="enableGlobalService('showEventComments')">
                <div class="em-settings-box">
                    <img class="em-settings-icon"  ng-src="<?php echo EMEC_BASE_URL; ?>includes/admin/template/images/ep-event-comment-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Event Comments', 'eventprime-event-comments'); ?></div>
                    <span><?php _e('Allow users to post comments on event page.', 'eventprime-event-comments'); ?></span>
                </div>
            </a> 
            <?php
        }

        public function event_comments_gs_settings_form(){
            ?> 
            <div ng-show="showEventComments">
                <div class="emrow">
                    <div class="emfield"><?php _e('Allow Event Comments', 'eventprime-event-comments'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" ng-true-value="1" ng-fale-value="0" name="allow_event_comments"  ng-model="data.options.allow_event_comments">
                        <div class="emfield_error"></div>
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Allow users to add Comments on an Event .', 'eventprime-event-comments'); ?>
                    </div>
                </div>
            </div><?php
        }

        public function event_comments_gs_settings_save(){
            $tribe_organizer_args = get_post_type_object('em_event');
            $request = EventM_Raw_Request::get_instance();
            $service =  EventM_Factory::get_service('EventM_Setting_Service');
            $model = $request->map_request_to_model('EventMEC_Global_Settings_Model');
            $template = $service->save($model);
            $eventPage = em_global_settings('events_page');
            // update event page status
            if(!empty($eventPage) && is_int($eventPage)){
                $post = get_post($eventPage);
                if(!empty($post) && $post->post_type == 'page'){
                    if(!empty($model->allow_event_comments)){
                        $openPost = array(
                           'ID' => $post->ID,
                           'comment_status' => 'open'
                        );
                    }
                    else{
                        $openPost = array(
                           'ID' => $post->ID,
                           'comment_status' => 'closed'
                        );
                    }
                    wp_update_post($openPost);
                }
            }
        }

        public function event_comments_get_options($options){
            $emecdao = new EventMEC_Global_Settings_DAO();
            $emecmodel = $emecdao->get();
            $options->allow_event_comments = absint($emecmodel->allow_event_comments);
            if(isset($options->load_extension_services)){
                $options->load_extension_services[] = 'showEventComments';
            }
            return $options;
        }

        public function event_comments_list_by_id($model){
            add_filter('comments_array', '__return_empty_array', 10, 2);
            if(!empty(em_global_settings('allow_event_comments'))){
                wp_enqueue_style('em_event_comment_css', EMEC_BASE_URL . 'includes/css/em_event_comment_style.css', false, EVENTPRIME_VERSION);
                $event_id = $model->id;
                echo '<div class="ep-comment-section"><div class="kf-row-heading">
                        <span class="kf-row-title em_color" ><i class="fa fa-comments-o" aria-hidden="true"></i>Comments</span>
                    </div></div>
                    <ol class="commentlist ep-comment-wrap" >';
                    //Gather comments for a specific page/post 
                    $comments = get_comments(array(
                        'post_id' => $event_id
                    ));
                    //Display the list of comments
                    wp_list_comments(array(
                        'reverse_top_level' => false,
                        'callback' => array($this, 'event_comments_custom_template')
                    ), $comments);
                echo '</ol>';
                $eventPost = get_the_title($event_id);
                $ontext = __('on');
                $eventtext = __('event');
                ?>
                <script type="text/javascript">
                    document.addEventListener("DOMContentLoaded", function(event) {     
                        setTimeout(function(){
                            if( jQuery("#reply-title").length > 0 ) {
                                var replyTitle = jQuery("#reply-title").get(0).innerText;
                                var replyInnerHtml = jQuery("#reply-title").get(0).innerHTML;
                                var postTitle = '<?php echo $eventPost?>';
                                var onText = '<?php echo $ontext?>';
                                var eventText = '<?php echo $eventtext?>';
                                var newReply = replyTitle + ' ' + onText + ' ' + postTitle + ' ' + eventText;
                                var newReplyHtml = replyInnerHtml.replace(replyTitle, newReply);
                                jQuery("#reply-title").html(newReplyHtml);
                            }
                        }, 2000);
                    });
                </script>
            <?php
            }
        }

        public function event_comments_custom_template($comment, $args, $depth) {
            $GLOBALS['comment'] = $comment; 
            if ( 'div' === $args['style'] ) {
                $tag       = 'div';
                $add_below = 'comment';
            } else {
                $tag       = 'li';
                $add_below = 'div-comment';
            }?>
            <<?php echo $tag; ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?> id="comment-<?php comment_ID() ?>"><?php 
                if ( 'div' != $args['style'] ) { ?>
                    <div id="div-comment-<?php comment_ID() ?>" class="ep-comment-thread"><?php
                } ?>
                    <div class="ep-comment-body">
                        <div class="ep-comment-author"><?php 
                            if ( $args['avatar_size'] != 0 ) {
                                echo get_avatar( $comment, $args['avatar_size'] ); 
                            }
                            printf( __( '<cite class="fn">%s</cite> <span class="says">says:</span>', 'eventprime-event-comments' ), get_comment_author_link() ); ?>
                        </div>
                        <div class="ep-comment-buttons">
                            <div class="reply"><?php 
                                comment_reply_link( 
                                    array_merge( 
                                        $args, 
                                        array( 
                                            'add_below' => $add_below, 
                                            'depth'     => $depth, 
                                            'max_depth' => $args['max_depth'] 
                                        ) 
                                    ) 
                                ); ?>
                            </div>
                        </div>
                        <div class="ep-comment-content">
                            <div class="ep-comment-meta">
                                <?php printf(__('<div class="comment-admin">%s</div>'), get_comment_author_link()) ?>
                                    <div class="comment-date"> <?php printf(__('%1$s at %2$s'), get_comment_date(),  get_comment_time()) ?></div>
                                <span class="ep-edit-comment">
                                    <?php edit_comment_link( __( '(Edit)', 'eventprime-event-comments' ), '  ', '' ); ?>
                                </span>
                            </div>
                            <?php comment_text(); ?>
                        </div>
                    </div>
                    <div class="mg-comment-awaiting">   
                        <?php 
                        if ( $comment->comment_approved == '0' ) { ?>
                            <em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'eventprime-event-comments' ); ?></em><br/><?php 
                        } ?>
                    </div>
                    <?php 
                if ( 'div' != $args['style'] ) : ?>
                </div><?php 
                endif;
        }

        public function event_comments_update_comment_id($result, $id, $replytoid){
            $event_id = !empty(event_m_get_param('event')) ? event_m_get_param('event') : $id ;
            if(!empty($event_id)){
                $result    = "<input type='hidden' name='comment_post_ID' value='$event_id' id='comment_post_ID' />\n";
                $result   .= "<input type='hidden' name='comment_parent' id='comment_parent' value='$replytoid' />\n";
            }
            return $result;
        }

        public function event_comments_update_allowed($event){
            $event->allow_comments = 1;
            if(empty(em_global_settings('allow_event_comments'))){
                $event->allow_comments = 0;
            }
            return $event;
        }

        // enable comments for event by event id
        public function event_comments_popup_set_comment_status($event, $event_id){
            if(!empty($event_id)){
                if(!empty(em_global_settings('allow_event_comments'))){
                    $post = array(
                       'ID' => $event_id,
                       'comment_status' => 'open'
                    );
                    wp_update_post($post);
                }
            }
        }

        public function event_comments_save_event_comment_status($event_id){
            if(!empty($event_id)){
                if(!empty(em_global_settings('allow_event_comments'))){
                    $event_service = EventM_Factory::get_service('EventM_Service');
                    $event = $event_service->load_model_from_db($event_id);
                    $ac = event_m_get_param('allow_comments');
                    if(!empty($ac)){
                        $post = array(
                           'ID' => $event_id,
                           'comment_status' => 'open'
                        );
                        wp_update_post($post);
                        $event->allow_comments = 1;
                        $event_service->update_model($event);
                    }
                    else{
                        $post = array(
                           'ID' => $event_id,
                           'comment_status' => 'close'
                        );
                        wp_update_post($post);
                        $event->allow_comments = 0;
                        $event_service->update_model($event);
                    }
                }
            }
        }

        public function event_comment_custom_extension_setting($value=''){?>
            <div class="emrow">
                <div class="emfield"><?php _e('Allow Comments','eventprime-event-comments'); ?></div>
                <div class="eminput">
                    <input string-to-number type="checkbox" name="allow_comments"  ng-model="data.post.allow_comments" ng-true-value="1" ng-false-value="0">
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e("Allow comments on frontend.",'eventprime-event-comments'); ?>
                </div>
            </div><?php
        }

        public function event_comment_format_model_from_db($model) {
            $allowComments = isset($model->allow_comments) ? absint($model->allow_comments) : 0;
            $model->allow_comments = $allowComments;
            return $model;
        }
        
        public function event_comment_format_model_to_save($model) {
            $model->allow_comments = absint(event_m_get_param('allow_comments'));
            return $model;
        }

        public function event_comment_activate_extension(){
            $allow_event_comments = em_global_settings('allow_event_comments');
            if(!empty($allow_event_comments)){
                $eventPage = em_global_settings('events_page');
                // update event page status
                if(!empty($eventPage)){
                    $post = get_post($eventPage);
                    if(!empty($post) && $post->post_type == 'page' && $post->comment_status == 'closed'){
                        $openPost = array(
                           'ID' => $post->ID,
                           'comment_status' => 'open'
                        );
                        wp_update_post($openPost);
                    }
                }
            }
        }

        public function ep_custom_comment_redirect_url( $redirect_url ){
            if( isset($_POST['comment_post_ID']) && !empty($_POST['comment_post_ID'])){
                $event_id = $_POST['comment_post_ID'];
                $post_type = get_post_type($event_id);
                $event_service = EventM_Factory::get_service('EventM_Service');
                $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
                $event= $event_service->load_model_from_db($event_id);
                $global_settings = $setting_service->load_model_from_db();
                if( $post_type == 'em_event' ){
                    $redirect_url = em_get_single_event_page_url($event, $global_settings);
                } 
            }
            return $redirect_url;
        }

        public function event_comment_deactivate_extension(){
            $eventPage = em_global_settings('events_page');
            // update event page status
            if(!empty($eventPage)){
                $post = get_post($eventPage);
                if(!empty($post) && $post->post_type == 'page'){
                    $openPost = array(
                       'ID' => $post->ID,
                       'comment_status' => 'closed'
                    );
                    wp_update_post($openPost);
                }
            }
        }

        public function event_show_comment_template_for_seo_urls(){
            global $withcomments;
            $withcomments = 1;
            comments_template();
        }
    }
}

function em_event_comments() {
    return EM_Event_Comments::instance();
}
function em_event_comments_checks(){ ?>
    <div class="notice notice-success is-dismissible">
         <p><?php _e( 'EventPrime Event Comments Extension won\'t work as EventPrime plugin is not active/installed.', 'event-magic' ); ?></p>
    </div>
<?php }

add_action('plugins_loaded',function(){if(!class_exists('Event_Magic')){add_action('admin_notices','em_event_comments_checks');}});
add_action('event_magic_loaded', 'em_event_comments');
require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_comments_metadata.json',
    __FILE__,
    'eventprime-event-comments'
);