<?php
class EventMEC_Global_Settings_Model extends EventM_Global_Settings_Model
{
  public $allow_event_comments;
}
