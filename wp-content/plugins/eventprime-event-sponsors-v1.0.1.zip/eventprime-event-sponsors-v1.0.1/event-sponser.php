<?php
/**
 * Plugin Name: EventPrime Event Sponsors
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that allows you add and display sponsors for your events.
 * Version: 1.0.1
 * Author: EventPrime
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 5.7.2
 * Text Domain: eventprime-event-sponser
 * Domain Path: /languages
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_Sponser')) {

    final class EM_Sponser {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.0.1';

        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;

        
        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }
        /**
         * Event_Magic Constructor.
         */
        public function __construct() { 
            $this->define_constants();
            $this->load_textdomain();
            $this->includes(); 
            $this->define_hooks();
            $em= event_magic_instance();
            array_push($em->extensions,'sponser');
        }
        
        public function define_constants(){
            event_magic_instance()->define('EMSPS_BASE_URL', plugin_dir_url(__FILE__));
        }
        
        public function includes(){
            if(is_admin()){
                include('includes/admin/class-admin.php');
            }
        }
        
        public function define_hooks(){
            add_action('event_magic_event_sponsers',array($this,'event_sponsers'));
            add_action('event_magic_gs_settings',array($this,'event_sponser_gs_settings'));
        }
        
        public function event_sponsers($event){?>
            <div class="kf-event-sponsors dbfl">
                <?php 
                    $sponser_gallery_ids = $event->sponser_image_ids;
                    if (is_array($sponser_gallery_ids) && count($sponser_gallery_ids)>0):
                ?>    
                    <div class="kf-row-heading">
                    <span class="kf-row-title em_color"><i class="fa fa-hashtag" aria-hidden="true"></i><?php  echo __('Sponsors', 'eventprime-event-sponser'); ?></span></div>
                    <?php foreach ($sponser_gallery_ids as $id):
                            echo '<div class="kf-event-sponsor-logo difl">' . wp_get_attachment_image($id, 'full') . '</div>';
                    endforeach; ?>
                <?php endif; ?>
            </div>
        <?php }
        
        public function load_textdomain(){
            load_plugin_textdomain('eventprime-event-sponser', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }
        
        public function event_sponser_gs_settings(){?>
            <a href='javascript:void(0)'>
                <div class="em-settings-box ep-active-extension ep-no-global-settings-model" data-popup="ep-event-sponsors-ext" onclick="CallEPExtensionModal(this)">
                    <img class="em-settings-icon" ng-src="<?php echo EM_BASE_URL; ?>includes/admin/template/images/ep-sponser-icon.png.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Sponser', 'eventprime-event-sponser'); ?></div>
                    <span><?php _e('Add sponsors to events.', 'eventprime-event-sponser'); ?></span>
                </div>
            </a>
            <?php
        }
    }

}

function em_sponser() {
    return EM_Sponser::instance();
}

function em_sponser_checks(){ ?>
    <div class="notice notice-success is-dismissible">
         <p><?php _e( 'EventPrime Event Sponsors Extension won\'t work as EventPrime plugin is not active/installed', 'event-magic' ); ?></p>
    </div>
<?php }
add_action('plugins_loaded',function(){if(!class_exists('Event_Magic')){add_action('admin_notices','em_sponser_checks');}});
add_action('event_magic_loaded', 'em_sponser');
require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_sponser_metadata.json',
    __FILE__,
    'eventprime-event-sponser'
);