<?php
class EM_Sponser_Admin {
	
    public function __construct() { 
        add_action('event_magic_dashboard_sponser_link',array($this,'dashboard_link'));
        add_action('event_magic_dashboard_sponsers_tab',array($this,'dashboard_page'));
        add_action('event_magic_save_event',array($this,'save_event'));
    }
    
    public function dashboard_link($post_id){ ?>
        <div class="ep-grid-icon difl" id="ep-event-sponser"><a href="<?php echo admin_url("/admin.php?page=em_dashboard&tab=sponsers&post_id=$post_id") ?>" class="ep-dash-link">
                <div class="ep-grid-icon-area dbfl">
                    <img class="ep-grid-icon dibfl" src="<?php echo EM_BASE_URL . 'includes/admin/template/images/ep-sponser-icon.png.png' ?>">
                </div>
                <div class="ep-grid-icon-label dbfl"><?php _e('Sponsers', 'eventprime-event-sponser'); ?></div>
            </a>
            

        </div>
    <?php }
    
    public function dashboard_page($post_id){
        wp_enqueue_media();
        wp_enqueue_script( 'em-sponser-controller',plugin_dir_url(__DIR__) . '/admin/template/js/em-sponser-controller.js',array('em-event-controller'));
        include_once('template/sponsers.php');
    }
    
    public function save_event($event_id){
        $event_service= EventM_Factory::get_service('EventM_Service');
        $event= $event_service->load_model_from_db($event_id);
        $req = EventM_Raw_Request::get_instance();
        $post= $req->get_data();
        $event->sponser_image_ids= $post['sponser_image_ids'];
        $event_service->update_model($event);
    }
}
new EM_Sponser_Admin;
