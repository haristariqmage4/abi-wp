
/************************************* Event Controller ***********************************/
eventMagicApp.controller('sponserCtrl', function ($scope, $http, MediaUploader, Seat,TermUtility,EMRequest,PostUtility) {
    /*
     * Controller intitialization for data load 
     */
    $scope.initialize = function () {
        // Adding Jquery Sortable function for Sponser Gallery
        jQuery("#em_sponser_image_draggable").sortable({
            stop: function (event, ui) {
                $scope.data.post.sponser_image_ids = jQuery("#em_sponser_image_draggable").sortable('toArray');
                $scope.$apply();
            }
        });
    }
    
    /*
     * 
     * Uploading sponser images
     */
    $scope.sponserUploader = function (multiImage) {
        var mediaUploader = MediaUploader.openUploader(multiImage);
        mediaUploader.on('select', function () {
            attachments = mediaUploader.state().get('selection');
            attachments.map(function (attachment) {
                attachment = attachment.toJSON();
                // For gallery images
                var imageObj = attachment.sizes.thumbnail===undefined ? {src: [attachment.sizes.full.url], id: attachment.id} : {src: [attachment.sizes.thumbnail.url], id: attachment.id};
                $scope.data.post.sponser_images.push(imageObj);
                $scope.data.post.sponser_image_ids.push(attachment.id);
                $scope.$apply();
            });
        });
        // Open the uploader dialog
        mediaUploader.open();
    }
    
});

