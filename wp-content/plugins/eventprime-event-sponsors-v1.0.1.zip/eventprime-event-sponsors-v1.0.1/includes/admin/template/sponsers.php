<div ng-controller="eventCtrl" ng-app="eventMagicApp" ng-cloak ng-init="initialize('edit')">
    <div class="kikfyre kf-container"  ng-controller="sponserCtrl" ng-init="initialize()" ng-cloak>
        <div class="kf_progress_screen" ng-show="requestInProgress"></div>
        <div class="kf-db-content">
            <div class="kf-db-title">
                <?php _e('Event Sponsers', 'eventprime-event-sponser'); ?>
            </div>
            <div class="form_errors">
                <ul>
                    <li class="emfield_error" ng-repeat="error in  formErrors">
                        <span>{{error}}</span>
                    </li>
                </ul>  
            </div>
            <!-- FORM -->
            <form  name="postForm" ng-submit="savePost(postForm.$valid)" novalidate >
                <div class="emrow kf-bg-light">
                    <div class="emfield emeditor"> <?php _e('Sponsor Logos', 'eventprime-event-sponser'); ?></div>
                    <div class="eminput emeditor">
                        <input  type="button" ng-click="sponserUploader(true)" class="button kf-upload" value="<?php _e('Upload', 'eventprime-event-sponser'); ?>" />
                        <div class="em_gallery_images">
                            <ul id="em_sponser_image_draggable" class="dbfl">
                                <li class="kf-db-image difl" ng-repeat="(key, value) in data.post.sponser_images" id="{{value.id}}">
                                    <div><img ng-src="{{value.src[0]}}" />
                                        <span><input class="em-remove_button" type="button" ng-click="deleteGalleryImage(value.id, key, data.post.sponser_images, data.post.sponser_image_ids)" value="<?php _e('Remove', 'eventprime-event-sponser'); ?>" /></span> 
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="emnote emeditor">
                        <?php _e('Multiple sponsor images for gallery view on Event page under Venue information.', 'eventprime-event-sponser'); ?>
                    </div>
                </div>

                <input type="text" class="hidden"  ng-model="data.post.sponser_image_ids" />


                <div class="dbfl kf-buttonarea">
                    <div class="em_cancel"><a class="kf-cancel" href="<?php echo admin_url('/admin.php?page=em_dashboard&post_id=' . $post_id); ?>"><?php _e('Cancel', 'eventprime-event-sponser'); ?></a></div>
                    <button type="submit" class="btn btn-primary" ng-disabled="postForm.$invalid || requestInProgress"><?php _e('Save', 'eventprime-event-sponser'); ?></button>

                </div>
            </form>
        </div>
    </div>
</div>


