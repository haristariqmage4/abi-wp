<?php
/**
 * Plugin Name: EventPrime Wishlist
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that allows to wishlist event.
 * Version: 1.0.1
 * Author: EventPrime
 * Text Domain: eventprime-event-wishlist
 * Domain Path: /languages
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 5.7.1
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_Wishlist')) {

    final class EM_Wishlist {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.0.1';

        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;

        
        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }


        /**
         * Event_Magic Constructor.
         */
        private function __construct() {
            $this->define_constants();
            $this->load_textdomain();
            $this->includes();
            $this->define_hooks();
            $em= event_magic_instance();
            array_push($em->extensions,'wishlist');
        }
            
        public function define_constants(){
            $em= event_magic_instance();
            $em->define('EMW_BASE_URL', plugin_dir_url(__FILE__));
            define('EMW_VERSION', $this->version);
        }
        
        public function define_hooks(){
            add_action('wp_enqueue_scripts',array($this,'event_magic_enqueue_style_and_scripts'));
            add_action('event_magic_wishlist_link',array($this,'event_magic_wishlist_link_render'));
            add_action('wp_ajax_em_wishlist', array($this, 'event_magic_wishlist_request'));
            add_action('em_wishlist_user_profile_tab', array($this, 'event_magic_wishlist_user_profile_tab'));
            add_action('em_wishlist_user_profile_tab_content', array($this, 'event_magic_wishlist_user_profile_tab_content'));
            add_action('em_event_popup_data_scripts', array($this, 'event_magic_wishlist_popup_data_scripts'));
            add_action('event_magic_gs_settings',array($this,'event_wishlist_gs_settings'));
        }

        public function includes() {
            // Widgets
            include_once('includes/widgets/event_wishlist.php');
        }
        
        public function load_textdomain(){
            load_plugin_textdomain('eventprime-event-wishlist', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        public function event_magic_wishlist_link_render($event_model){
            $user_id = get_current_user_id();
            $wishlist_meta = get_user_meta($user_id, 'em_wishlist', true);
            $is_active = '';$div_title = __("Add To Wishlist", "eventprime-event-wishlist");
            if(!empty($wishlist_meta) && array_key_exists($event_model->id, $wishlist_meta)){
                $is_active = 'is-active';
                $div_title = __("Remove From Wishlist", "eventprime-event-wishlist");
            }
            $content = '';
            $content .= '<div class="ep-add-to-wishlist em_color '.$is_active.'" id="ep-add-to-wishlist-'.$event_model->id.'" wishlist_event_id="'.$event_model->id.'" wishlist_event_status="'.$event_model->status.'" data-active-title="'.__("Remove From Wishlist", "eventprime-event-wishlist").'" data-inactive-title="'.__("Add To Wishlist", "eventprime-event-wishlist").'" title="'.$div_title.'" data-inactive-message="'.__("Event Removed From Wishlist", "eventprime-event-wishlist").'" data-active-message="'.__("Event Added Into Wishlist", "eventprime-event-wishlist").'"></div>';
            $content .= '<div class="em_progress_screen ep-progress-loader" id="ep-wishlist-loader-'.$event_model->id.'" style="display:none;"></div>';
            if(!isset($event_model->profile_page) && empty($event_model->profile_page)){
                $content .= '<div class="ep-wishlist-message-'.$event_model->id.' ep-wishlist-message"></div>';
            }
            if(isset($event_model->has_popup) && !empty($event_model->has_popup)){
                $content .= '<script type="text/javascript">
                    jQuery("#ep-add-to-wishlist-'.$event_model->id.'").click(function(e){
                        e.preventDefault();
                        e.stopPropagation();
                        var thisclicked = this;
                        em_event_wishlist_data_update(thisclicked);
                    });
                </script>';
            }
            echo $content;
        }

        public function event_magic_enqueue_style_and_scripts() {

            wp_enqueue_script('em-wishlist-js', EMW_BASE_URL . 'includes/public/js/em_wishlist.js', array('jquery'), EMW_VERSION);
            wp_localize_script('em-wishlist-js', 'emw_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
            wp_enqueue_style('em-wishlist-css', EMW_BASE_URL . 'includes/public/css/em_wishlist.css', false, EMW_VERSION);
        }

        public function event_magic_wishlist_request() {
            if ( isset( $_POST["event_id"] ) ) {
                $event_id = $_POST['event_id'];
                $user_id = get_current_user_id();
                $wishlist_meta = get_user_meta($user_id, 'em_wishlist', true);
                if(empty($wishlist_meta)){
                    $wishlist_array = array($event_id => 1);
                    update_user_meta($user_id,'em_wishlist', $wishlist_array);
                } else {
                    if(array_key_exists($event_id,$wishlist_meta)){
                        unset($wishlist_meta[$event_id]);
                    } else {
                        $wishlist_meta[$event_id] = 1;
                    }
                    update_user_meta($user_id,'em_wishlist', $wishlist_meta);
                }
                die();
            }
        }

        public function event_magic_wishlist_user_profile_tab(){
            $content = '<div class="emtabs_head ep-wishlist-tab" data-emt-tabcontent="#tab6"><i class="material-icons">favorite</i>'.__("Event Wishlist", "eventprime-event-wishlist").'</div>';
            echo $content;
        }

        public function event_magic_wishlist_user_profile_tab_content(){
            $user_id = get_current_user_id();
            $no_item = __("You don't have any item in Wishlist.", 'eventprime-event-wishlist');
            $content = '<div id="tab6" class="tab wishlist-tab" data-no-item="'.$no_item.'">';
            $event_service = EventM_Factory::get_service('EventM_Service');
            $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
            $global_settings = $setting_service->load_model_from_db();
            $my_events = $event_service->get_wishlist_events_by_user($user_id);
            if (!empty($my_events)) {
                $content .= '<div class="ep-wishlist-message-profile-page ep-wishlist-message" style="display: none;"></div>';
                $content .= '<table class="em_profile_table">
                    <thead class="em_bg">
                        <tr>
                            <th>'.__("Event Name", 'eventprime-event-wishlist').'</th>
                            <th>'.__("Start Date", 'eventprime-event-wishlist').'</th>
                            <th>'.__("Status", 'eventprime-event-wishlist').'</th>
                            <th>'.__("Remove", 'eventprime-event-wishlist').'</th>
                            <th>'.__("Book", 'eventprime-event-wishlist').'</th>
                        </tr>
                    </thead>
                    <tbody id="em_profile_table">';
                        foreach ($my_events as $my_event) {
                            $book_now_btn = $event_service->get_book_now_button_for_event($my_event);
                            $my_event->profile_page = 1;
                            ob_start();
                            do_action('event_magic_wishlist_link',$my_event);
                            $wishlist = ob_get_contents();
                            ob_end_clean();
                            $content .= '<tr>
                                            <td class="ep-wishlist-event-name"><a href="'.add_query_arg('event',$my_event->id,get_permalink($global_settings->events_page)).'" target="_blank">'.$my_event->name.'</a></td>
                                            <td class="ep-wishlist-event-date">'.em_showDateTime($my_event->start_date, true).'</td>
                                            <td>'.ucfirst($my_event->status).'</td>
                                            <td>'.$wishlist.'</td>
                                            <td>'.$book_now_btn.'</td>
                                        </tr>';
                        }
                    $content .= '</tbody></table>';
            } else{
                $content .= $no_item;
            }

            $content .= '</div>';
            echo $content;
        }

        public function event_magic_wishlist_popup_data_scripts(){
            $content = '<script type="text/javascript">
                function em_event_wishlist_data_update(thisclicked){
                    var em_event_id = $(thisclicked).attr("wishlist_event_id");
                    var em_event_status = $(thisclicked).attr("wishlist_event_status");
                    var data = {
                        action: "em_wishlist",
                        event_id: em_event_id,
                        event_status: em_event_status,
                    };
                    console.log(data);
                    $("#ep-wishlist-loader-"+em_event_id).show();
                    $.post(emw_ajax_object.ajax_url, data, function(response) {
                        $(thisclicked).toggleClass("is-active");
                        if($(thisclicked).hasClass("is-active")){
                            var wishlistTitle = $(thisclicked).data("active-title");
                            var wishlistMessage = $(thisclicked).data("active-message");
                        }
                        else{
                            var wishlistTitle = $(thisclicked).data("inactive-title");
                            var wishlistMessage = $(thisclicked).data("inactive-message");
                            if($(".em_profile_table").length > 0){
                                $(thisclicked).closest("tr").remove();
                            }
                            if($("#em_profile_table").children("tr").length < 1){
                                var no_item_data = $(".em_profile_table").closest(".wishlist-tab").data("no-item");
                                $(".wishlist-tab").html(no_item_data);
                            }
                        }
                        $(thisclicked).attr("title", wishlistTitle);
                        $(".ep-wishlist-message-"+em_event_id).html(wishlistMessage);
                        $(".ep-wishlist-message-"+em_event_id).fadeIn("slow", function(){
                          $(".ep-wishlist-message-"+em_event_id).delay(3000).fadeOut();
                        });
                        $("#ep-wishlist-loader-"+em_event_id).hide();
                    });
                }
            </script>';
            echo $content;
        }

        public function event_wishlist_gs_settings(){?>
            <a href='javascript:void(0)'>
                <div class="em-settings-box ep-active-extension ep-no-global-settings-model" data-popup="ep-event-wishlist-ext" onclick="CallEPExtensionModal(this)">
                    <img class="em-settings-icon" ng-src="<?php echo EM_BASE_URL; ?>includes/admin/template/images/ep-save-events-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Wishlist', 'eventprime-event-wishlist'); ?></div>
                    <span><?php _e('Allow users to wish-list events.', 'eventprime-event-wishlist'); ?></span>
                </div>
            </a>
            <?php
        }
    }

}

function em_wishlist() {
    return EM_Wishlist::instance();
}
function em_wishlist_checks(){ ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e( 'EventPrime Wishlist Extension won\'t work as EventPrime plugin is not active/installed.', 'event-magic' ); ?></p>
    </div>
<?php }

add_action('plugins_loaded',function(){if(!class_exists('Event_Magic')){add_action('admin_notices','em_wishlist_checks');}});
add_action('event_magic_loaded', 'em_wishlist');
require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_wishlist_metadata.json',
    __FILE__,
    'eventprime-event-wishlist'
);