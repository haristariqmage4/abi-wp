(function( $ ) {
  'use strict';
  $(function() {
    $(".ep-add-to-wishlist").on("click", function() {
      var thisclicked = this;
      var em_event_id = $(thisclicked).attr('wishlist_event_id');
      var data = {
        action: 'em_wishlist',
        event_id: em_event_id,
        event_status: $(thisclicked).attr('wishlist_event_status'),
      };
      $("#ep-wishlist-loader-"+em_event_id).show();
      //if(data.event_status == 'publish'){
      $.post(emw_ajax_object.ajax_url, data, function(response) {
        $(thisclicked).toggleClass("is-active");
        if($(thisclicked).hasClass('is-active')){
          var wishlistTitle = $(thisclicked).data('active-title');
          var wishlistMessage = $(thisclicked).data('active-message');
        }
        else{
          var wishlistTitle = $(thisclicked).data('inactive-title');
          var wishlistMessage = $(thisclicked).data('inactive-message');
          if($(".em_profile_table").length > 0){
            $(thisclicked).closest('tr').remove();
          }
          if($("#em_profile_table").children('tr').length < 1){
            var no_item_data = $(".em_profile_table").closest('.wishlist-tab').data('no-item');
            $(".wishlist-tab").html(no_item_data);
          }
        }
        $(thisclicked).attr('title', wishlistTitle);
        $(".ep-wishlist-message-"+em_event_id).html(wishlistMessage);
        $('.ep-wishlist-message-'+em_event_id).fadeIn('slow', function(){
          $('.ep-wishlist-message-'+em_event_id).delay(3000).fadeOut();
        });
        if($(".ep-wishlist-message-profile-page").length > 0){
          $(".ep-wishlist-message-profile-page").html(wishlistMessage);
          $(".ep-wishlist-message-profile-page").fadeIn('slow', function(){
            $(".ep-wishlist-message-profile-page").delay(3000).fadeOut();
          });
        }
        $("#ep-wishlist-loader-"+em_event_id).hide();
      });
      //}
      return false;
    });
  });
})( jQuery );