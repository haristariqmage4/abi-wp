<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

if (!class_exists('EventM_Event_Wishlist')):
  class EventM_Event_Wishlist extends WP_Widget
  {
    function __construct()
    {
      parent::__construct('eventm_event_wishlist', "Event Wishlist", array());
    }

    // Display the widget
    public function widget($args, $instance)
    {
      wp_enqueue_style('em_wishlist_widget_style', plugin_dir_url(__DIR__) . 'public/css/em_wishlist.css', false, EVENTPRIME_VERSION);
      extract( $args );
      // Check the widget options
      $title    = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : '';
      $event_number     = isset( $instance['event_number'] ) ? $instance['event_number'] : '';
      // WordPress core before_widget hook (always include )
      echo $before_widget;
      // Display the widget
      echo '<div class="widget widget_popular_events"><div class="widget-content">';
      // Display widget title if defined
      if ( $title ) {
        echo '<h2 class="widget-title subheading heading-size-3">'.$before_title . $title . $after_title.'</h2>';
      }
      if(is_user_logged_in()){
        // Display text field
        $user_id = get_current_user_id();
        $content = '';
        $event_service = EventM_Factory::get_service('EventM_Service');
        $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
        $venueService = EventM_Factory::get_service('EventM_Venue_Service');
        $global_settings = $setting_service->load_model_from_db();
        $my_events = $event_service->get_wishlist_events_by_user($user_id);
        if (!empty($my_events)) {
          $numberFlag = 0;
          foreach ($my_events as $my_event) {
            if($numberFlag < $event_number){
              $numberFlag++;
              $eventData = $event_service->load_model_from_db($my_event->ID);
              $url = add_query_arg('event', $my_event->ID, get_page_link($global_settings->events_page));
              $venue = $venueService->load_model_from_db($eventData->venue);
              $book_now_btn = $event_service->get_book_now_button_for_event($my_event);
              $content .= '<div id="ep-featured-events"  class="ep-mw-wrap">';
              $content .= '<div class="ep-fimage">';
              if (!empty($eventData->cover_image_id)):
                $content .= '<a href="'.$url.'">'.get_the_post_thumbnail($event->ID, 'thumbnail').'</a>';
              else:
                $content .= '<a href="'.$url.'"><img src="'.esc_url(EM_BASE_FRONT_IMG_URL.'dummy_image.png').'" alt="'.__('Dummy Image','eventprime-list-widgets').'" ></a>';
              endif;
              $content .= '</div>';
              $content .= '<div class="ep-fdata">';
              $content .= '<div class="ep-fname"><a href="'.$url.'" target="_blank">'.$my_event->name.'</a></div>';
              $content .= '<div class="ep-fdate">'.em_showDateTime($my_event->start_date, true).'</div>';
              if(!empty($venue) && !empty($venue->address)){
                $content .= '<div class="ep-faddress">'.$venue->address.'</div>';
              }
              
              if(!empty($eventData->description)){
                $content .= '<div class="ep-fdesc">'.$eventData->description.'</div>';
              }
              $content .= '</div>';
              $content .= '<div class="em_widget_book">'.$book_now_btn.'</div>';
              $content .= '</div><hr>';
            }
          }
        } else{
          $content .= __("You have not wishlisted any events yet.", 'eventprime-event-wishlist');
        }
        echo $content;
      } else {
        echo "<p>Please login to see your Event Wishlist.</p>";
      }
      echo '</div></div>';
      // WordPress core after_widget hook (always include )
      echo $after_widget;
    }

    // The widget form (for the backend )
    public function form($instance)
    {
      // Set widget defaults
      $defaults = array(
        'title'    => 'Event Wishlist',
        'event_number'     => 5,
      );
      // Parse current settings with defaults
      extract( wp_parse_args( ( array ) $instance, $defaults ) );
      ?>
      <p>
        <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'Widget Title', 'eventprime-event-wishlist' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
      </p>
      <p>
        <label for="<?php echo esc_attr( $this->get_field_id( 'event_number' ) ); ?>"><?php _e( 'Number of Events', 'eventprime-event-wishlist' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'event_number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'event_number' ) ); ?>" type="number" value="<?php echo esc_attr( $event_number ); ?>" />
      </p>
      <?php
    }

    // Updating widget replacing old instances with new
    public function update($new_instance, $old_instance)
    {
      $instance = $old_instance;
      $instance['title']    = isset( $new_instance['title'] ) ? wp_strip_all_tags( $new_instance['title'] ) : '';
      $instance['event_number']     = isset( $new_instance['event_number'] ) ? wp_strip_all_tags( $new_instance['event_number'] ) : '';
      return $instance;
    }
  }
endif;

// Register and load the widget
function em_load_event_wishlist()
{
  register_widget('eventm_event_wishlist');
}

add_action('widgets_init', 'em_load_event_wishlist');