<?php
/**
 * Plugin Name: EventPrime Events Import Export
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that allows to import and export events in popular file formats like CSV, ICS, XML and JSON.
 * Version: 1.0.0
 * Author: EventPrime
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 5.6
 * Text Domain: eventprime-events-import-export
 * Domain Path: /languages
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_Events_Import_Export')) {
    final class EM_Events_Import_Export {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.0.0';

        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;
        
        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        /**
         * Cloning is forbidden.
         */
        public function __clone() {
            _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'event_magic'), $this->version);
        }

        /**
         * Unserializing instances of this class is forbidden.
         */
        public function __wakeup() {
            _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'event_magic'), $this->version);
        }

        /**
         * Event_Magic Constructor.
         */
        public function __construct() { 
            $this->define_constants();
            $this->load_textdomain();
            $this->includes();
            $this->define_hooks();
            $em = event_magic_instance();
            array_push($em->extensions,'file_import_export_events');
        }

        public function define_constants(){
            event_magic_instance()->define('EMFIX_BASE_URL', plugin_dir_url(__FILE__));
        }        

        public function includes(){
            if(is_admin()){
                include('includes/admin/class-admin.php');
                include_once('includes/services/class-event-export.php');
                include_once('includes/services/class-event-import.php');
                include_once('includes/services/ICal.php');
                include_once('includes/services/Event.php');
            }
        }

        public function define_hooks(){
            add_action('init', array($this, 'init'));
            add_action('wp_ajax_em_import_file_upload', array($this, 'ix_import_file_upload'));
            add_action('wp_ajax_em_ix_file_import', array($this, 'ix_file_import'));
            add_action('event_magic_gs_settings',array($this,'event_ix_file_gs_settings'));
        }       

        public function load_textdomain(){
            load_plugin_textdomain('eventprime-events-import-export', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        public function init() {
            // em ix actions
            $em_ix_action = isset($_GET['ep-ix-tab']) ? sanitize_text_field($_GET['ep-ix-tab']) : '';
            if($em_ix_action == 'file-export'){
                $this->ix_file_export();
            }
        }

        public function ix_file_export() {
            $service = EventM_Factory::get_service('EventM_Event_File_Export_Service');
            $postdata = $service->em_ix_file_export();
        }

        // upload file before import
        public function ix_import_file_upload(){
            $service = EventM_Factory::get_service('EventM_Event_File_Import_Service');
            $postdata = $service->em_ix_file_upload();
            if(isset($postdata['errors'])){
                wp_send_json_error(array('errors' => $postdata['errors']));
            }
            if(isset($postdata['success'])){
                wp_send_json_success($postdata['success']);
            }
        }

        public function ix_file_import() {
            $service = EventM_Factory::get_service('EventM_Event_File_Import_Service');
            $postdata = $service->em_ix_file_import();
            if(isset($postdata['errors'])){
                wp_send_json_error(array('errors' => $postdata['errors']));
            }
            if(isset($postdata['success'])){
                wp_send_json_success(array("success" => $postdata['success']));
            }
        }

        public function event_ix_file_gs_settings(){?>
            <a href='javascript:void(0)'>
                <div class="em-settings-box ep-active-extension ep-no-global-settings-model" data-popup="ep-event-file-ix-ext" onclick="CallEPExtensionModal(this)">
                    <img class="em-settings-icon" ng-src="<?php echo EM_BASE_URL; ?>includes/admin/template/images/ep-file-import-export-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Events Import Export', 'eventprime-event-google-import-export'); ?></div>
                    <span><?php _e('Allow Events Import / Export.', 'eventprime-event-google-import-export'); ?></span>
                </div>
            </a>
            <?php
        }
    }
}

function em_events_import_export() {
    return EM_Events_Import_Export::instance();
}

function em_events_import_export_checks(){ ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e( 'EventPrime Events Import Export won\'t work as EventPrime plugin is not active/installed', 'event-magic' ); ?></p>
    </div>
<?php }

add_action('plugins_loaded',function(){if(!class_exists('Event_Magic')){add_action('admin_notices','em_events_import_export_checks');}});
add_action('event_magic_loaded', 'em_events_import_export');
require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/events_import_export_metadata.json',
    __FILE__,
    'eventprime-event-import-export'
);