<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class EM_Events_Import_Export_Admin {
	
    public function __construct() { 
        add_action('event_magic_menus', array($this, 'menus'));
        add_action('admin_enqueue_scripts', array($this,'enqueue'));
        $this->current_page = isset($_GET['page']) ? $_GET['page'] : '';
    }
    
    public function menus(){
        add_submenu_page("event_magic", __('Events Import / Export', 'eventprime-events-import-export'), __('Events Import / Export', 'eventprime-events-import-export'), "manage_options", "em_file_import_export_events", array($this, 'file_import_export'));
    }
    
    public function file_import_export() {
        wp_enqueue_style('em_admin_file_import_export', EMFIX_BASE_URL.'includes/admin/template/css/em_admin_file_import_export.css', false, EVENTPRIME_VERSION);
        wp_enqueue_script('em-file-import-export-controller');
        if($this->current_page == 'em_file_import_export_events'){
            include_once('template/file_import_export_events.php' );
        }
    }
    
    public function enqueue(){
        wp_register_script('em-file-import-export-controller', EMFIX_BASE_URL.'includes/admin/template/js/em-file-import-export-controller.js',array('em-angular-module'));
    }
}
new EM_Events_Import_Export_Admin;