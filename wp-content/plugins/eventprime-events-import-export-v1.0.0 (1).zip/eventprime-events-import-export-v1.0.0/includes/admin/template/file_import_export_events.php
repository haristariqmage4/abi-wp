<?php
$ix_tab = isset($_GET['ep-ix-tab']) ? sanitize_text_field($_GET['ep-ix-tab']) : 'file-import';
$ix_action = isset($_GET['ep-ix-action']) ? sanitize_text_field($_GET['ep-ix-action']) : '';
$export_url = admin_url('admin-ajax.php')."?page=em_file_import_export_events";
$import_url = admin_url()."?page=em_file_import_export_events";?>
<div class="kikfyre" ng-app="eventMagicApp" ng-controller="fileImportExportCtrl" ng-init="initialize('<?php echo $ix_tab;?>', '<?php echo $ix_action;?>')" ng-cloak="">
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>
    <div class="kf-hidden" style="{{requestInProgress ?'display:none':'display:block'}}">
        <!-- Operations bar Starts --> 
        <div class="kf-operationsbar dbfl">
            <div class="kf-titlebar_dark dbfl">
                <div class="kf-title kf-title-1 difl"><?php _e('File Import / Export Events','eventprime-events-import-export'); ?></div>
            </div>
            <div class="kf-nav dbfl">
                <ul class="em-file-ie-header">
                    <li><a href="javascript:void(0)" ng-click="showMainTab('showImportTab')" ng-class="{'active': showImportTab}"><?php _e('Import Events from File', 'eventprime-events-import-export'); ?></a></li>
                    <li><a href="javascript:void(0)" ng-click="showMainTab('showExportTab')" ng-class="{'active': showExportTab}"><?php _e('Export Events to File', 'eventprime-events-import-export'); ?></a></li>
                </ul>
            </div>
        </div>
        <!--  Operations bar Ends -->
        <div class="emagic-table em-file-ie-page dbfl" ng-show="showImportTab == true || showExportTab == true">
            <div class="em-import-tab" ng-show="showImportTab == true">
                <div class="em-import-contant">
                    <div class="em-import-section em-import-file-contant">
                        
                    </div>
                </div>
            </div>
            <div class="em-export-tab" ng-show="showExportTab == true">
                <div class="em-export-contant ep-file-export-section">
                    <div class="em-export-section em-export-file-contant">
                         <div class="emrow ep-section-subhead-wrap">
                       <div class="ep-subhead-title"><?php _e('Export all your events to a file', 'eventprime-events-import-export'); ?></div>
                            <div class="em-export-row ep-subhead-info epnotice"><?php _e('Select desired file format below to begin your download.', 'eventprime-events-import-export'); ?></div>
                         </div>
                           <div class="emrow">
                        <ul>
                            <li><a href="<?php echo esc_url(add_query_arg(array('ep-ix-tab' => 'file-export', 'format' => 'ical'), $export_url));?>"><?php _e('iCal', 'eventprime-events-import-export'); ?></a></li>
                            <li><a href="<?php echo esc_url(add_query_arg(array('ep-ix-tab' => 'file-export', 'format' => 'csv'), $export_url));?>"><?php _e('CSV', 'eventprime-events-import-export'); ?></a></li>
                            <!-- <li><a href="<?php echo esc_url(add_query_arg(array('ep-ix-tab' => 'file-export', 'format' => 'ms-excel'), $export_url));?>"><?php _e('MS Excel', 'eventprime-events-import-export'); ?></a></li> -->
                            <li><a href="<?php echo esc_url(add_query_arg(array('ep-ix-tab' => 'file-export', 'format' => 'xml'), $export_url));?>"><?php _e('XML', 'eventprime-events-import-export'); ?></a></li>
                            <li><a href="<?php echo esc_url(add_query_arg(array('ep-ix-tab' => 'file-export', 'format' => 'json'), $export_url));?>"><?php _e('JSON', 'eventprime-events-import-export'); ?></a></li>
                        </ul>
                           </div>
                    </div>
                </div>
            </div>
            <div class="em-import-tab" ng-show="showImportTab == true">
                <div class="em-import-contant ep-file-import-section">
                    <div class="em-import-section em-import-xml-feed dbfl" id="em-import-xml-feed">
                        <div class="emrow ep-section-subhead-wrap">
                            <div class="ep-subhead-title"><?php _e('Import from XML Feed', 'eventprime-events-import-export'); ?></div>
                        </div>
                        <div class="emrow">
                            <div class="eminput em-import-row">
                                <input type="file" name="feed" id="xml-feed" title="<?php esc_attr_e('XML Feed', 'eventprime-events-import-export'); ?>" file-input="files" data-file_type_error="<?php _e('Only XML file allowed.', 'eventprime-events-import-export') ?>">
                            </div>
                            <div class="emfield"><button class="ep-file-action-btn" ng-click="event_import('xml', '<?php _e('Please select feed file'); ?>')"><?php _e('Upload & Import', 'eventprime-events-import-export'); ?></button></div>
                            <div class="emnote GSnote">
                            	<i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('You can import events via XML file from another website. Select file from your computer and click upload button.', 'eventprime-events-import-export') ?>
                            </div>
                            <div class="em_ierror_isuccess">
                                <div class="em_ix_errors" id="xml-error">
                                    <div class="emfield_error epnotice" ng-repeat="error in formxErrors">
                                        <span>{{error}}</span>
                                    </div>
                                </div>
                                <div class="em_ix_success" id="xml-success">
                                    <div class="emfield_success epnotice" ng-repeat="success in formxSuccess">
                                        <span ng-bind-html="success | unsafe"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="em-import-section em-import-ics-feed dbfl" id="em-import-ics-feed">
                        <div class="emrow ep-section-subhead-wrap">
                            <div class="ep-subhead-title"><?php _e('Import from ICS file', 'eventprime-events-import-export'); ?></div>
                        </div>
                        <div class="emrow">
                            <div class="eminput em-import-row">
                                <input type="file" name="feed" id="ics-feed" title="<?php esc_attr_e('ICS Feed', 'eventprime-events-import-export'); ?>" file-input="files" data-file_type_error="<?php _e('Only ICS file allowed.', 'eventprime-events-import-export') ?>">
                            </div>
                            <div class="emfield"><button class="ep-file-action-btn" ng-click="event_import('ics', '<?php _e('Please select feed file'); ?>')"><?php _e('Upload & Import', 'eventprime-events-import-export'); ?></button></div>
                            <div class="emnote GSnote">
                            	<i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Import events from popular ICS calendar file format. Select file from your computer and click upload button.', 'eventprime-events-import-export') ?>
                            </div>
                            <div class="em_ierror_isuccess">
                                <div class="em_ix_errors" id="ics-error">
                                    <div class="emfield_error epnotice" ng-repeat="error in formiErrors">
                                        <span>{{error}}</span>
                                    </div>
                                </div>
                                <div class="em_ix_success" id="ics-success">
                                    <div class="emfield_success epnotice" ng-repeat="success in formiSuccess">
                                        <span ng-bind-html="success | unsafe"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="em-import-section em-import-csv-feed dbfl" id="em-import-csv-feed">
                        <div class="emrow ep-section-subhead-wrap">
                            <div class="ep-subhead-title"><?php _e('Import from CSV file', 'eventprime-events-import-export'); ?></div>
                        </div>
                        <div class="emrow">
                            <div class="eminput em-import-row">
                                <input type="file" name="feed" id="csv-feed" title="<?php esc_attr_e('CSV Feed', 'eventprime-events-import-export'); ?>" file-input="files" data-file_type_error="<?php _e('Only CSV file allowed.', 'eventprime-events-import-export') ?>">
                            </div>
                            <div class="emfield"><button class="ep-file-action-btn" ng-click="event_import('csv', '<?php _e('Please select feed file'); ?>')"><?php _e('Upload & Import', 'eventprime-events-import-export'); ?></button></div>
                            <div class="emnote GSnote">
                            	<i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Import events from popular CSV file format. Select file from your computer and click upload button.', 'eventprime-events-import-export') ?>
                            </div>
                            <div class="em_ierror_isuccess">
                                <div class="em_ix_errors" id="csv-error">
                                    <div class="emfield_error epnotice" ng-repeat="error in formcErrors">
                                        <span>{{error}}</span>
                                    </div>
                                </div>
                                <div class="em_ix_success" id="csv-success">
                                    <div class="emfield_success epnotice" ng-repeat="success in formcSuccess">
                                        <span ng-bind-html="success | unsafe"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="em-import-section em-import-json-feed dbfl" id="em-import-json-feed">
                        <div class="emrow ep-section-subhead-wrap">
                            <div class="ep-subhead-title"><?php _e('Import from JSON file', 'eventprime-events-import-export'); ?></div>
                        </div>
                        <div class="emrow">
                            <div class="eminput em-import-row">
                                <input type="file" name="feed" id="json-feed" title="<?php esc_attr_e('JSON Feed', 'eventprime-events-import-export'); ?>" file-input="files" data-file_type_error="<?php _e('Only JSON file allowed.', 'eventprime-events-import-export') ?>">
                            </div>
                            <div class="emfield"><button class="ep-file-action-btn" ng-click="event_import('json', '<?php _e('Please select feed file');?>')"><?php _e('Upload & Import', 'eventprime-events-import-export'); ?></button></div>
                            <div class="emnote GSnote">
                            	<i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Import events from JSON file format. Select file from your computer and click upload button.', 'eventprime-events-import-export') ?>
                            </div>
                            <div class="em_ierror_isuccess">
                                <div class="em_ix_errors" id="json-error">
                                    <div class="emfield_error epnotice" ng-repeat="error in formjErrors">
                                        <span>{{error}}</span>
                                    </div>
                                </div>
                                <div class="em_ix_success" id="json-success">
                                    <div class="emfield_success epnotice" ng-repeat="success in formjSuccess">
                                        <span ng-bind-html="success | unsafe"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>