eventMagicApp.controller('fileImportExportCtrl', function($scope, $http, EMRequest){
    $scope.data = {};
    $scope.requestInProgress = false;
    $scope.formxErrors = [];
    $scope.formiErrors = [];
    $scope.formcErrors = [];
    $scope.formjErrors = [];
    $scope.formxSuccess = [];
    $scope.formiSuccess = [];
    $scope.formcSuccess = [];
    $scope.formjSuccess = [];
    $scope.fileAttachmentId = '';
    $scope.importTarget = '';
    $scope.showImportTab = true;
    $ = jQuery;

    $scope.progressStart = function()
    {
        $scope.requestInProgress = true;
    }

    $scope.progressStop = function()
    {
        $scope.requestInProgress = false;
    }
    
    $scope.initialize = function (tab, action) {
        // Loading all the required data before form load
        if(tab == 'file-export'){
            $scope.showImportTab = false;
            $scope.showExportTab = true;
        }
        $scope.preparePageData();
    };
    
    //Load presaved setting data
    $scope.preparePageData = function () {
        
    }

    $scope.showMainTab = function(type){
        $scope.showImportTab = false;
        $scope.showExportTab = false;
        $scope[type] = true;
    }

    $scope.event_import = function(ftype, ferror){
        if($scope.fileAttachmentId && $scope.importTarget){
            $scope.data.attachment_id = $scope.fileAttachmentId;
            $scope.data.event_target = $scope.importTarget;
            $scope.progressStart();
            EMRequest.send('em_ix_file_import',$scope.data).then(function(response){
                $scope.progressStop();
                $scope.formxSuccess = [];
                $scope.formiSuccess = [];
                $scope.formcSuccess = [];
                $scope.formjSuccess = [];
                $scope.formxErrors = [];
                $scope.formiErrors = [];
                $scope.formcErrors = [];
                $scope.formjErrors = [];
                var responseBody = response.data;
                if(responseBody.success){
                    if(responseBody.data.hasOwnProperty('success')){
                        if($scope.importTarget == 'xml-feed'){
                            $scope.formxSuccess.push(responseBody.data.success);
                            setTimeout(function(){
                                $scope.$apply(function(){
                                    $scope.formxSuccess = [];
                                });
                            }, 8000);
                        }
                        if($scope.importTarget == 'ics-feed'){
                            $scope.formiSuccess.push(responseBody.data.success);
                            setTimeout(function(){
                                $scope.$apply(function(){
                                    $scope.formiSuccess = [];
                                });
                            }, 8000);
                        }
                        if($scope.importTarget == 'csv-feed'){
                            $scope.formcSuccess.push(responseBody.data.success);
                            setTimeout(function(){
                                $scope.$apply(function(){
                                    $scope.formcSuccess = [];
                                });
                            }, 8000);
                        }
                        if($scope.importTarget == 'json-feed'){
                            $scope.formjSuccess.push(responseBody.data.success);
                            setTimeout(function(){
                                $scope.$apply(function(){
                                    $scope.formjSuccess = [];
                                });
                            }, 8000);
                        }
                    }
                }
                if(responseBody.data.errors){
                    if($scope.importTarget == 'xml-feed'){
                        $scope.formxErrors.push(responseBody.data.errors);
                        setTimeout(function(){
                            $scope.$apply(function(){
                                $scope.formxErrors = [];
                            });
                        }, 8000);
                    }
                    if($scope.importTarget == 'ics-feed'){
                        $scope.formiErrors.push(responseBody.data.errors);
                        setTimeout(function(){
                            $scope.$apply(function(){
                                $scope.formiErrors = [];
                            });
                        }, 8000);
                    }
                    if($scope.importTarget == 'csv-feed'){
                        $scope.formcErrors.push(responseBody.data.errors);
                        setTimeout(function(){
                            $scope.$apply(function(){
                                $scope.formcErrors = [];
                            });
                        }, 8000);
                    }
                    if($scope.importTarget == 'json-feed'){
                        $scope.formjErrors.push(responseBody.data.errors);
                        setTimeout(function(){
                            $scope.$apply(function(){
                                $scope.formjErrors = [];
                            });
                        }, 8000);
                    }
                }
                angular.element("input[type='file']").val(null);
                setTimeout(function(){
                    jQuery('html, body').animate({
                        scrollTop: jQuery("#em-import-"+$scope.importTarget).offset().top + 10
                    }, 'slow');
                }, 2000);
            });
        }
        else{
            var fileErrors = '<div class="emfield_error epnotice"><span>'+ferror+'</span></div>'
            if(ftype == 'xml'){
                angular.element("#xml-error").html(fileErrors);
                setTimeout(function(){
                    $scope.$apply(function(){
                        angular.element("#xml-error").html('');
                    });
                }, 8000);
            }
            if(ftype == 'ics'){
                angular.element("#ics-error").html(fileErrors);
                setTimeout(function(){
                    $scope.$apply(function(){
                        angular.element("#ics-error").html('');
                    });
                }, 8000);
            }
            if(ftype == 'csv'){
                angular.element("#csv-error").html(fileErrors);
                setTimeout(function(){
                    $scope.$apply(function(){
                        angular.element("#csv-error").html('');
                    });
                }, 8000);
            }
            if(ftype == 'json'){
                angular.element("#json-error").html(fileErrors);
                setTimeout(function(){
                    $scope.$apply(function(){
                        angular.element("#json-error").html('');
                    });
                }, 8000);
            }
        }
    }

})
.directive("fileInput", ['$http', '$parse', function($http, $parse){  
    return{  
        link: function($scope, element, attrs){  
            element.on("change", function(event){ 
                var files = event.target.files;
                if(files){
                    var fileType = files[0].type;
                    if(event.target.id == 'xml-feed'){
                        var allowedFileType = ['text/xml'];
                        angular.element("#ics-feed").val(null);
                        angular.element("#csv-feed").val(null);
                        angular.element("#json-feed").val(null);
                    }
                    if(event.target.id == 'ics-feed'){
                        var allowedFileType = ['text/calendar'];
                        angular.element("#xml-feed").val(null);
                        angular.element("#csv-feed").val(null);
                        angular.element("#json-feed").val(null);
                    }
                    if(event.target.id == 'csv-feed'){
                        var allowedFileType = ['text/csv', 'application/vnd.ms-excel'];
                        angular.element("#ics-feed").val(null);
                        angular.element("#xml-feed").val(null);
                        angular.element("#json-feed").val(null);
                    }
                    if(event.target.id == 'json-feed'){
                        var allowedFileType = ['application/json'];
                        angular.element("#ics-feed").val(null);
                        angular.element("#csv-feed").val(null);
                        angular.element("#xml-feed").val(null);
                    }
                    if(allowedFileType.indexOf(fileType) > -1){
                        $scope.progressStart();
                        var ajUrl = em_ajax_object.ajax_url + "?action=em_import_file_upload";
                        $scope.form = [];
                        $scope.form.feedfile = element[0].files[0];
                        $http({
                            method  : 'POST',
                            url     : ajUrl,
                            processData: false,
                            transformRequest: function (data) {
                                var formData = new FormData();
                                formData.append("file", $scope.form.feedfile);  
                                formData.append("target_id", event.target.id);  
                                return formData;  
                            },  
                            data : $scope.form,
                            headers: {
                                'Content-Type': undefined
                            }
                        }).success(function(response){
                            $scope.progressStop();
                            if(response.data.errors){
                                var fileErrors = '<div class="emfield_error epnotice"><span>'+response.data.errors+'</span></div>'
                                if(event.target.id == 'xml-feed'){
                                    angular.element("#xml-error").html(fileErrors);
                                    setTimeout(function(){
                                        $scope.$apply(function(){
                                            angular.element("#xml-error").html('');
                                        });
                                    }, 8000);
                                }
                                if(event.target.id == 'ics-feed'){
                                    angular.element("#ics-error").html(fileErrors);
                                    setTimeout(function(){
                                        $scope.$apply(function(){
                                            angular.element("#ics-error").html('');
                                        });
                                    }, 8000);
                                }
                                if(event.target.id == 'csv-feed'){
                                    angular.element("#csv-error").html(fileErrors);
                                    setTimeout(function(){
                                        $scope.$apply(function(){
                                            angular.element("#csv-error").html('');
                                        });
                                    }, 8000);
                                }
                                if(event.target.id == 'json-feed'){
                                    angular.element("#json-error").html(fileErrors);
                                    setTimeout(function(){
                                        $scope.$apply(function(){
                                            angular.element("#json-error").html('');
                                        });
                                    }, 8000);
                                }
                            }
                            else{
                                $scope.fileAttachmentId = response.data.attachment_id;
                                $scope.importTarget = event.target.id;
                            }
                            setTimeout(function(){
                                jQuery('html, body').animate({
                                    scrollTop: jQuery("#em-import-"+event.target.id).offset().top + 10
                                }, 'slow');
                            }, 1500);
                        });
                    }
                    else{
                        var dataAattr = event.target.getAttribute('data-file_type_error');
                        var fileErrors = '<div class="emfield_error epnotice"><span>'+dataAattr+'</span></div>'
                        if(event.target.id == 'xml-feed'){
                            angular.element("#xml-error").html(fileErrors);
                            setTimeout(function(){
                                $scope.$apply(function(){
                                    angular.element("#xml-error").html('');
                                });
                            }, 8000);
                        }
                        if(event.target.id == 'ics-feed'){
                            angular.element("#ics-error").html(fileErrors);
                            setTimeout(function(){
                                $scope.$apply(function(){
                                    angular.element("#ics-error").html('');
                                });
                            }, 8000);
                        }
                        if(event.target.id == 'csv-feed'){
                            angular.element("#csv-error").html(fileErrors);
                            setTimeout(function(){
                                $scope.$apply(function(){
                                    angular.element("#csv-error").html('');
                                });
                            }, 8000);
                        }
                        if(event.target.id == 'json-feed'){
                            angular.element("#json-error").html(fileErrors);
                            setTimeout(function(){
                                $scope.$apply(function(){
                                    angular.element("#json-error").html('');
                                });
                            }, 8000);
                        }
                        angular.element("input[type='file']").val(null);
                        setTimeout(function(){
                            jQuery('html, body').animate({
                                scrollTop: jQuery("#em-import-"+event.target.id).offset().top + 10
                            }, 'slow');
                        }, 1500);
                    }
                }
            });  
        }  
    }  
}]);

eventMagicApp.filter('unsafe', function($sce) {
    return function(val) {
        return $sce.trustAsHtml(val);
    };
});