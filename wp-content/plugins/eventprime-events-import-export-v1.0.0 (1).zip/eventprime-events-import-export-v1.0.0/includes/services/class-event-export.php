<?php
if (!defined( 'ABSPATH')){
    exit;
}

class EventM_Event_File_Export_Service {
    
    private $dao;
    private static $instance = null;
    
    private function __construct() {
        
    }
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function em_ix_file_export() {
        $file_format = event_m_get_param('format');
        if(!empty($file_format)){
            $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
            $options = $setting_service->load_model_from_db();
            $event_service = EventM_Factory::get_service('EventM_Service');
            $venue_serv = EventM_Factory::get_service('EventM_Venue_Service');
            $event_type_serv = EventM_Factory::get_service('EventTypeM_Service');
            $events = $event_service->get_all();
            $remove_keys = array("seats", "enable_recurrence", "recurrence_interval", "recurrence_step", "recurrence_limit", "selected_weekly_day", "monthly_weekno", "monthly_fullweekday", "monthly_month", "yearly_weekno", "yearly_fullweekday", "yearly_monthday", "is_daily_event", "is_weekly_recurrence", "is_monthly_recurrence", "is_advanced_recurrence", "advanced_month", "advanced_recurr", "is_yearly_recurrence", "is_custom_dates_recurrence", "recurrence_custom_dates", "enable_recurrence_automatic_booking", "child_exists");
            switch($file_format){
                case 'ical':
                    $output = '';
                    foreach($events as $event){
                        $output .= $this->ix_get_single_ical($event);                
                    }
                    $ical_calendar = $this->ix_ical_calendar($output);
                    header('Content-type: application/force-download; charset=utf-8'); 
                    header('Content-Disposition: attachment; filename="ep-events-'.date('YmdTHi').'.ics"');
                    echo $ical_calendar;
                    exit;
                break;
                case 'csv':
                    header('Content-Type: text/csv; charset=utf-8');
                    header('Content-Disposition: attachment; filename="ep-events-'.md5(time().mt_rand(100, 999)).'.csv"');
                    
                    $columns = array(
                        __('ID', 'eventprime-events-import-export'), 
                        __('Title', 'eventprime-events-import-export'), 
                        __('Description', 'eventprime-events-import-export'), 
                        __('Start Date', 'eventprime-events-import-export'), 
                        __('End Date', 'eventprime-events-import-export'),
                        __('Start Booking Date', 'eventprime-events-import-export'), 
                        __('End Booking Date', 'eventprime-events-import-export'), 
                        __('All Day', 'eventprime-events-import-export'), 
                        __('Link', 'eventprime-events-import-export'), 
                        __('Event Type', 'eventprime-events-import-export'), 
                        __('Event Cost', 'eventprime-events-import-export'),
                        __('Location', 'eventprime-events-import-export'), 
                        __('Address', 'eventprime-events-import-export'), 
                        __('Latitude', 'eventprime-events-import-export'), 
                        __('Longitude', 'eventprime-events-import-export'), 
                        __('Seating Capacity', 'eventprime-events-import-export'), 
                        __('Operator', 'eventprime-events-import-export'), 
                        __('Performers', 'eventprime-events-import-export'), 
                        __('Organizer', 'eventprime-events-import-export'), 
                        __('Organizer Phone', 'eventprime-events-import-export'), 
                        __('Organizer Email', 'eventprime-events-import-export'));
                    
                    $output = fopen('php://output', 'w');
                    fputcsv($output, $columns);
                    foreach($events as $event){
                        $event_data = array();
                        $event_url = add_query_arg(array('event' => $event->id), get_permalink($options->events_page));
                        if(isset($event->event_type) && !empty($event->event_type)){
                            $event_type = $event_type_serv->load_model_from_db($event->event_type);
                        }
                        if(isset($event->venue) && !empty($event->venue)) {
                            $venue = $venue_serv->load_model_from_db($event->venue);
                        }
                        $event_performer_name = array();
                        if(isset($event->performer) && !empty($event->performer)){
                            $event_performer_serv = EventM_Factory::get_service('EventM_Performer_Service');
                            foreach ($event->performer as $performer) {
                                $event_performer = $event_performer_serv->load_model_from_db($performer);
                                $event_performer_name[] = $event_performer->name;
                            }
                        }
                        $event_data = array(
                            $event->id,
                            $event->name,
                            $event->description,
                            date('d-m-Y H:i', $event->start_date),
                            date('d-m-Y H:i', $event->end_date),
                            date('d-m-Y H:i', $event->start_booking_date),
                            date('d-m-Y H:i', $event->last_booking_date),
                            $event->all_day,
                            $event_url,
                            (!empty($event_type) ? $event_type->name : ''),
                            $event->ticket_price,
                            (!empty($venue) ? $venue->name : ''),
                            (!empty($venue) ? $venue->address : ''),
                            (!empty($venue) ? $venue->lat : ''),
                            (!empty($venue) ? $venue->lng : ''),
                            (!empty($event->seating_capacity) ? $event->seating_capacity : ''),
                            (!empty($venue) ? $venue->seating_organizer : ''),
                            (!empty($event_performer_name) ? implode(',', $event_performer_name) : ''),
                            (!empty($event->organizer_name) ? $event->organizer_name : ''),
                            (!empty($event->organizer_phones) ? implode(",", $event->organizer_phones) : ''),
                            (!empty($event->organizer_emails) ? implode(",", $event->organizer_emails) : '')
                        );                        
                        fputcsv($output, $event_data);
                    }
                    exit;
                break;
                /*case 'ms-excel':
                    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
                    header('Content-Disposition: attachment; filename="ep-events-'.md5(time().mt_rand(100, 999)).'.csv"');
                    
                    $columns = array(
                        __('ID', 'eventprime-events-import-export'), 
                        __('Title', 'eventprime-events-import-export'), 
                        __('Description', 'eventprime-events-import-export'), 
                        __('Start Date', 'eventprime-events-import-export'), 
                        __('End Date', 'eventprime-events-import-export'),
                        __('Start Booking Date', 'eventprime-events-import-export'), 
                        __('End Booking Date', 'eventprime-events-import-export'), 
                        __('All Day', 'eventprime-events-import-export'),
                        __('Link', 'eventprime-events-import-export'), 
                        __('Event Type', 'eventprime-events-import-export'), 
                        __('Event Cost', 'eventprime-events-import-export'),
                        __('Location', 'eventprime-events-import-export'), 
                        __('Address', 'eventprime-events-import-export'), 
                        __('Latitude', 'eventprime-events-import-export'), 
                        __('Longitude', 'eventprime-events-import-export'), 
                        __('Seating Capacity', 'eventprime-events-import-export'), 
                        __('Operator', 'eventprime-events-import-export'), 
                        __('Performers', 'eventprime-events-import-export'), 
                        __('Organizer', 'eventprime-events-import-export'), 
                        __('Organizer Phone', 'eventprime-events-import-export'), 
                        __('Organizer Email', 'eventprime-events-import-export'));
                    
                    $output = fopen('php://output', 'w');
                    fwrite($output, "sep=\t".PHP_EOL);
                    fputcsv($output, $columns, "\t");
                    foreach($events as $event){
                        $event_data = array();
                        $event_url = add_query_arg(array('event' => $event->id), get_permalink($options->events_page));
                        if(isset($event->event_type) && !empty($event->event_type)){
                            $event_type = $event_type_serv->load_model_from_db($event->event_type);
                        }
                        if(isset($event->venue) && !empty($event->venue)) {
                            $venue = $venue_serv->load_model_from_db($event->venue);
                        }
                        $event_performer_name = array();
                        if(isset($event->performer) && !empty($event->performer)){
                            $event_performer_serv = EventM_Factory::get_service('EventM_Performer_Service');
                            foreach ($event->performer as $performer) {
                                $event_performer = $event_performer_serv->load_model_from_db($performer);
                                $event_performer_name[] = $event_performer->name;
                            }
                        }
                        $event_data = array(
                            $event->id,
                            $event->name,
                            $event->description,
                            date('d-m-Y H:i', $event->start_date),
                            date('d-m-Y H:i', $event->end_date),
                            date('d-m-Y H:i', $event->start_booking_date),
                            date('d-m-Y H:i', $event->last_booking_date),
                            $event->all_day,
                            $event_url,
                            (!empty($event_type) ? $event_type->name : ''),
                            $event->ticket_price,
                            (!empty($venue) ? $venue->name : ''),
                            (!empty($venue) ? $venue->address : ''),
                            (!empty($venue) ? $venue->lat : ''),
                            (!empty($venue) ? $venue->lng : ''),
                            (!empty($event->seating_capacity) ? $event->seating_capacity : ''),
                            (!empty($venue) ? $venue->seating_organizer : ''),
                            (!empty($event_performer_name) ? implode(',', $event_performer_name) : ''),
                            (!empty($event->organizer_name) ? $event->organizer_name : ''),
                            (!empty($event->organizer_phones) ? implode(",", $event->organizer_phones) : ''),
                            (!empty($event->organizer_emails) ? implode(",", $event->organizer_emails) : '')
                        );
                        
                        fputcsv($output, $event_data, "\t");
                    }
                    exit;
                break;*/
                case 'xml':
                    $output = array();
                    foreach($events as $event) {
                        $eventData = $event_service->load_model_from_db($event->id);
                        $single_event = (array) $eventData;
                        // not taken recurr events
                        //if(!empty($single_event['parent'])) continue;
                        // remove non used keys
                        foreach ($remove_keys as $value) {
                            if(isset($single_event[$value])){
                                unset($single_event[$value]);
                            }
                        }
                        if(isset($event->event_type) && !empty($event->event_type)){
                            $event_type = $event_type_serv->load_model_from_db($event->event_type);
                            $single_event['event_type'] = $event_type->name;
                        }
                        if(isset($event->venue) && !empty($event->venue)) {
                            $venue = $venue_serv->load_model_from_db($event->venue);
                            $single_event['venue'] = $venue->name;
                            $single_event['address'] = $venue->address;
                            $single_event['lat'] = $venue->lat;
                            $single_event['lng'] = $venue->lng;
                        }
                        $event_performer_name = array();
                        if(isset($event->performer) && !empty($event->performer)){
                            $event_performer_serv = EventM_Factory::get_service('EventM_Performer_Service');
                            foreach ($event->performer as $performer) {
                                $event_performer = $event_performer_serv->load_model_from_db($performer);
                                $event_performer_name[] = $event_performer->name;
                            }
                            $single_event['performer'] = $event_performer_name;
                        }

                        $eventData = (object) $single_event;
                        $output[] = $eventData;
                    }
                    $xml_feed = $this->convert_to_xml(array('events' => $output));
                    header('Content-type: application/force-download; charset=utf-8'); 
                    header('Content-Disposition: attachment; filename="ep-events-'.date('YmdTHi').'.xml"');
                    echo $xml_feed;
                    exit;
                break;
                case 'json':
                    $output = array();
                    foreach($events as $event) {
                        $eventData = $event_service->load_model_from_db($event->id);
                        $single_event = (array) $eventData;
                        // not taken recurr events
                        //if(!empty($single_event['parent'])) continue;
                        // remove non used keys
                        foreach ($remove_keys as $value) {
                            if(isset($single_event[$value])){
                                unset($single_event[$value]);
                            }
                        }
                        if(isset($event->event_type) && !empty($event->event_type)){
                            $event_type = $event_type_serv->load_model_from_db($event->event_type);
                            $single_event['event_type'] = $event_type->name;
                        }
                        if(isset($event->venue) && !empty($event->venue)) {
                            $venue = $venue_serv->load_model_from_db($event->venue);
                            $single_event['venue'] = $venue->name;
                            $single_event['address'] = $venue->address;
                            $single_event['lat'] = $venue->lat;
                            $single_event['lng'] = $venue->lng;
                        }
                        $event_performer_name = array();
                        if(isset($event->performer) && !empty($event->performer)){
                            $event_performer_serv = EventM_Factory::get_service('EventM_Performer_Service');
                            foreach ($event->performer as $performer) {
                                $event_performer = $event_performer_serv->load_model_from_db($performer);
                                $event_performer_name[] = $event_performer->name;
                            }
                            $single_event['performer'] = $event_performer_name;
                        }

                        $eventData = (object) $single_event;
                        $output[] = $eventData;
                    }
                    header('Content-type: application/force-download; charset=utf-8'); 
                    header('Content-Disposition: attachment; filename="ep-events-'.date('YmdTHi').'.json"');
                    echo json_encode($output);
                    exit;
                break;
            }
        }
    }
    
    public function ix_get_single_ical($event) {
        $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
        $options = $setting_service->load_model_from_db();
        $event_url = add_query_arg(array('event' => $event->id), get_permalink($options->events_page));

        $ical = "BEGIN:VEVENT"."\r\n";
        $ical .= "UID:EP-".md5(strval($event->id))."@".em_get_site_domain()."\r\n";
        $ical .= "DTSTART:".gmdate('Ymd\\THi00', $event->start_date)."\r\n";
        $ical .= "DTEND:".gmdate('Ymd\\THi00', $event->end_date)."\r\n";
        $ical .= "DTSTAMP:".gmdate('Ymd\\THi00')."\r\n";
        $ical .= "CREATED:".get_the_date('Ymd', $event->id)."\r\n";
        $ical .= "LAST-MODIFIED:".get_the_modified_date('Ymd', $event->id)."\r\n";
        $ical .= "SUMMARY:".html_entity_decode($event->name, ENT_NOQUOTES, 'UTF-8')."\r\n";
        $ical .= "DESCRIPTION:".html_entity_decode(trim(strip_tags($event->description)), ENT_NOQUOTES, 'UTF-8')."\r\n";
        $ical .= "URL:".$event_url."\r\n";
        // event attachment
        $cover_image_id = get_post_thumbnail_id($event->id);
        if (!empty($cover_image_id) && $cover_image_id > 0) {
            $event_service = EventM_Factory::get_service('EventM_Service');
            $cover_image_url = $event_service->get_event_cover_image($event->id,'full');
            $ical .= "ATTACH;FMTTYPE=".get_post_mime_type($cover_image_id).":".$cover_image_url."\r\n";
        }
        // event location
        if ($event->venue != 0) {
            $venue_serv = EventM_Factory::get_service('EventM_Venue_Service');
            $venue = $venue_serv->load_model_from_db($event->venue);
            $ical .= "LOCATION:".trim(strip_tags($venue->address))."\r\n";
        }
        // event type
        if(isset($event->event_type) && !empty($event->event_type)){
            $event_type_serv = EventM_Factory::get_service('EventTypeM_Service');
            $event_type = $event_type_serv->load_model_from_db($event->event_type);
            $ical .= "EVENT-TYPE:".trim(strip_tags($event_type->name))."\r\n";
        }
        // performer
        if(isset($event->performer) && !empty($event->performer)){
            $event_performer_serv = EventM_Factory::get_service('EventM_Performer_Service');
            foreach ($event->performer as $performer) {
                $event_performer = $event_performer_serv->load_model_from_db($performer);
                $event_performer_name[] = $event_performer->name;
            }
            if(!empty($event_performer)){
                $ical .= "PERFORMER:".trim(implode(',', $event_performer_name))."\r\n";
            }
        }
        // organizer
        if(isset($event->organizer_name) && !empty($event->organizer_name)){
            $ical .= "ORGANIZER:".trim(strip_tags($event->organizer_name))."\r\n";
            if(!empty($event->organizer_phones)){
                $phones = implode(',', $event->organizer_phones);
                $ical .= "ORGANIZER-PHONE:".trim($phones)."\r\n";
            }
            if(!empty($event->organizer_emails)){
                $emails = implode(',', $event->organizer_emails);
                $ical .= "ORGANIZER-EMAIL:".trim($emails)."\r\n";
            }
        }

        $ical .= "END:VEVENT"."\r\n";
        
        return $ical;
    }
    
    public function ix_ical_calendar($events_ical) {
        $ical  = "BEGIN:VCALENDAR"."\r\n";
        $ical .= "VERSION:2.0"."\r\n";
        $ical .= "METHOD:PUBLISH"."\r\n";
        $ical .= "CALSCALE:GREGORIAN"."\r\n";
        $ical .= "PRODID:-//WordPress - EPv".EVENTPRIME_VERSION."//EN"."\r\n";
        $ical .= "X-ORIGINAL-URL:".home_url().'/'."\r\n";
        $ical .= $events_ical;
        $ical .= "END:VCALENDAR";
        
        return $ical;
    }

    public function convert_to_xml($data){
        $main_node = array_keys($data);        
        // Creating SimpleXMLElement object
        $xml = new SimpleXMLElement('<?xml version="1.0"?><'.$main_node[0].'></'.$main_node[0].'>');
        // Convert array to xml
        $this->array_to_xml($data[$main_node[0]], $xml);
        // Return XML String
        return $xml->asXML();
    }

    public function array_to_xml($data, &$xml){
        foreach($data as $key => $value){
            if(is_numeric($key)) $key = 'item';

            if(is_array($value)){
                $subnode = $xml->addChild($key);
                $this->array_to_xml($value, $subnode);
            }
            elseif(is_object($value)){
                $subnode = $xml->addChild($key);
                $this->array_to_xml($value, $subnode);
            }
            else{
                $xml->addChild($key, htmlspecialchars($value));
            }
        }
    }
}
EventM_Event_File_Export_Service::get_instance();