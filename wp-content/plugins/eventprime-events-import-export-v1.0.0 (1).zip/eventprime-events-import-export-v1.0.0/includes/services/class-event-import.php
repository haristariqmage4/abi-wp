<?php
if (!defined( 'ABSPATH')){
    exit;
}

use ICal\ICal;

class EventM_Event_File_Import_Service {
    
    private $dao;
    private static $instance = null;
    
    private function __construct() {
        
    }
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function em_ix_file_upload(){
        if(isset($_FILES["file"]) && !empty($_FILES["file"])){
            $extension = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
            $targetId = $_POST['target_id'];
            if($targetId == 'xml-feed' && $extension != 'xml'){
                $returnData['errors'] = __('Only XML files allowed', 'eventprime-events-import-export');
                return $returnData;
            }
            if($targetId == 'ics-feed' && $extension != 'ics'){
                $returnData['errors'] = __('Only ICS files allowed', 'eventprime-events-import-export');
                return $returnData;
            }
            if($targetId == 'csv-feed' && $extension != 'csv'){
                $returnData['errors'] = __('Only ICS files allowed', 'eventprime-events-import-export');
                return $returnData;
            }
            if($targetId == 'json-feed' && $extension != 'json'){
                $returnData['errors'] = __('Only JSON files allowed', 'eventprime-events-import-export');
                return $returnData;
            }
            $file = $_FILES['file'];
            $filename = $file['name'];
            $tmp_name = $file['tmp_name'];
            $upload_dir = wp_upload_dir();
            if (move_uploaded_file($file["tmp_name"], $upload_dir['path'] . "/" . $filename)) {
                $uploaded_file['file_name'] = $filename;
                $uploaded_file['upload_url'] = $upload_dir['url'] . "/" . $filename;
                $wp_filetype = wp_check_filetype($filename, null );
                $attachment = array(
                    'guid'           => $uploaded_file['upload_url'],
                    'post_mime_type' => $wp_filetype['type'],
                    'post_title'     => preg_replace( '/\.[^.]+$/', '', $filename ),
                    'post_content'   => '',
                    'post_status'    => 'inherit'
                );
                $attachment_id = wp_insert_attachment( $attachment, $upload_dir['path'] . "/" . $filename );
                if ( ! is_wp_error( $attachment_id ) ) {
                    require_once(ABSPATH . "wp-admin" . '/includes/file.php');
                    $attachment_data = wp_generate_attachment_metadata( $attachment_id, $upload_file['file'] );
                    wp_update_attachment_metadata( $attachment_id,  $attachment_data );
                    $returnData['success'] = array('attachment_id' => $attachment_id);
                }
            }
            else{
                $returnData['errors'] = __($upload_file['error']);
            }
        }
        return $returnData;
    }
    
    public function em_ix_file_import() {
        $attachment_id = event_m_get_param('attachment_id');
        $event_target = event_m_get_param('event_target');
        $feed_file = get_attached_file($attachment_id);
        $timezone = em_get_site_timezone();
        $event_service = EventM_Factory::get_service('EventM_Service');
        if(!empty($feed_file)){
            $exp = explode('.', $feed_file);
            $extension = end($exp);
            if(strtolower($extension) == 'xml'){
                $xml_string = str_replace(':i:', 'iii', $this->read_file($feed_file));
                // load xml and check
                $XML = simplexml_load_string($xml_string);
                if($XML === false){
                    $returnData['errors'] = __('Not a valid XML file');
                    return $returnData;
                }
                $event_ids = array();
                if(!empty($XML->children())){
                    foreach($XML->children() as $event){
                        $event_venue_id = $event_type_id = '';
                        // save event
                        $event_service = EventM_Factory::get_service('EventM_Service');
                        $ix_event_data = (array) $event;
                        $event_feed_id = $ix_event_data['id'];
                        $event_dao = new EventM_Event_DAO();
                        $event_data = $event_service->load_model_from_db(0);
                        $event_data->name = htmlspecialchars_decode(sanitize_text_field(strip_tags($ix_event_data['name'])));
                        $event_data->description = sanitize_text_field($ix_event_data['description']);
                        $start_date = $ix_event_data['start_date'];
                        $end_date = $ix_event_data['end_date'];
                        $allday = (int) $ix_event_data['all_day'];
                        if(!empty($allday) || !trim($start_date) && !trim($end_date)){
                            $allDayDate = date('m/d/Y', $ix_event_data['start_date']);
                            $allday = 1;
                            $start_hour = '00';
                            $start_minutes = '00';
                            $end_hour = '00';
                            $end_minutes = '00';
                            $start_date = em_timestamp($allDayDate.' '.$start_hour.':'.$start_minutes);
                            $allEndDate = date('m/d/Y', strtotime($allDayDate. ' + 1 days'));
                            $end_date = em_timestamp($allEndDate.' '.$end_hour.':'.$end_minutes);
                        }
                        $event_data->start_date = !empty($start_date) ? $start_date : '';
                        $event_data->end_date = !empty($end_date) ? $end_date : '';
                        $event_data->start_booking_date = '';
                        $event_data->last_booking_date = '';
                        $event_data->all_day = $allday;
                        $event_data->hide_event_from_calendar = (int) $ix_event_data['hide_event_from_calendar'];
                        $event_data->hide_event_from_events = (int) $ix_event_data['hide_event_from_events'];
                        $event_data->ticket_template = $ix_event_data['ticket_template'];
                        $event_data->max_tickets_per_person = (int) $ix_event_data['max_tickets_per_person'];
                        $event_data->allow_cancellations = (int) $ix_event_data['allow_cancellations'];
                        $event_data->allow_discount = (int) $ix_event_data['allow_discount'];
                        $event_data->discount_no_tickets = (int) $ix_event_data['discount_no_tickets'];
                        $event_data->discount_per = $ix_event_data['discount_per'];
                        $event_data->ticket_price = (int) $ix_event_data['ticket_price'];
                        $event_data->hide_organizer = (int) $ix_event_data['hide_organizer'];
                        $event_data->hide_booking_status = (int) $ix_event_data['hide_booking_status'];
                        $event_data->last_booking_date = (!empty($ix_event_data['last_booking_date']) ? $ix_event_data['last_booking_date'] : '');
                        $event_data->start_booking_date = (!empty($ix_event_data['start_booking_date']) ? $ix_event_data['start_booking_date'] : '');
                        $event_data->rm_form = (int) $ix_event_data['rm_form'];
                        $event_data->booked_seats = (int) $ix_event_data['booked_seats'];
                        $event_data->enable_booking = (int) $ix_event_data['enable_booking'];
                        $event_data->custom_link_enabled = (int) $ix_event_data['custom_link_enabled'];
                        $event_data->custom_link = (string) $ix_event_data['custom_link'];
                        $event_data->enable_attendees = (int) $ix_event_data['enable_attendees'];
                        $event_data->show_attendees = (int) $ix_event_data['show_attendees'];
                        $event_data->is_featured = (int) $ix_event_data['is_featured'];
                        $event_data->allow_comments = (int) $ix_event_data['allow_comments'];
                        $event_data->event_text_color = (string) $ix_event_data['event_text_color'];
                        $event_data->fixed_event_price = (int) $ix_event_data['fixed_event_price'];
                        $event_data->show_fixed_event_price = (int) $ix_event_data['show_fixed_event_price'];
                        $event_data->parent = (int) $ix_event_data['parent'];
                        $event_data->facebook_page = sanitize_text_field($ix_event_data['facebook_page']);
                        // venue
                        if(!empty(trim($ix_event_data['venue']))){
                            $location_name = $ix_event_data['venue'];
                            $location_term = get_term_by('name', $location_name, 'em_venue');
                        }
                        else{
                            if(!empty(trim($ix_event_data['address']))){
                                $location_exp = explode(",", $ix_event_data['address']);
                                $location_name = $location_exp[0];
                                $location_term = get_term_by('name', $location_name, 'em_venue');
                            }
                        }
                        if(empty($location_term)){
                            $venue_service = EventM_Factory::get_service('EventM_Venue_Service');
                            $venue_model = new EventM_Venue_Model();
                            $venue_model->name = sanitize_text_field($location_name);
                            $venue_model->type = 'standings';                            
                            $venue_model->address = sanitize_text_field($ix_event_data['address']);
                            if(empty($ix_event_data['address'])){
                                $venue_model->address = sanitize_text_field(trim($ix_event_data['venue']));
                            }
                            $venue_model->seating_capacity = 0;
                            $venue = $venue_service->save($venue_model);
                            $event_venue_id = $venue->id;
                            if(!empty($event_venue_id)){
                                $event_data->venue = $event_venue_id;
                            }
                        }
                        else{
                            $event_venue_id = $location_term->term_id;
                            $event_data->venue = $event_venue_id;
                        }
                        if(!empty($ix_event_data['performer'])){
                            $performer_service = EventM_Factory::get_service('EventM_Performer_Service');
                            $all_performers = $performer_service->get_all();
                            $performer_ids = array();
                            foreach ($ix_event_data['performer'] as $imp_per) {
                                foreach ($all_performers as $per) {
                                    if($per->name == $imp_per){
                                        $performer_ids[] = $per->id;
                                        break;
                                    }
                                    else{
                                        $performer_model = new EventM_Performer_Model();
                                        $performer_model->name = $imp_per;
                                        $performer_model->type = empty($type) ? 'person' : $type;
                                        $performer = $performer_service->save($performer_model);
                                        $performer_ids[] = $performer;
                                        break;
                                    }
                                }
                            }
                            $event_data->performer = $performer_ids;
                            if(!empty($event_data->performer)){
                                $event_data->enable_performer = 1;
                            }
                        }
                        if(!empty($ix_event_data['organizer_name'])){
                            $event_data->organizer_name = sanitize_text_field($ix_event_data['organizer_name']);
                        }
                        if(!empty($ix_event_data['organizer_phones'])){
                            foreach ($ix_event_data['organizer_phones'] as $key => $value) {
                                $event_data->organizer_phones[$key] = sanitize_text_field($value);
                            }
                        }
                        if(!empty($ix_event_data['organizer_emails'])){
                            foreach ($ix_event_data['organizer_emails'] as $key => $value) {
                                $event_data->organizer_emails[$key] = sanitize_text_field($value);
                            }
                        }
                        if(!empty($ix_event_data['organizer_websites'])){
                            foreach ($ix_event_data['organizer_websites'] as $key => $value) {
                                $event_data->organizer_websites[$key] = sanitize_text_field($value);
                            }
                        }
                        // event type
                        if(!empty(trim($ix_event_data['event_type']))){
                            $eventType = $ix_event_data['event_type'];
                            $type_term = get_term_by('name', $eventType, 'em_event_type');
                        }
                        if(empty($type_term)){
                            $type_service = EventM_Factory::get_service('EventTypeM_Service');
                            $type = new EventM_Event_Type_Model();
                            $type->name = sanitize_text_field($ix_event_data['event_type']);
                            $ev_type = $type_service->save($type);
                            $event_type_id = $ev_type->id;
                            if(!empty($event_type_id)){
                                $event_data->event_type = $event_type_id;
                            }
                        }
                        else{
                            $event_type_id = $type_term->term_id;
                            $event_data->event_type = $event_type_id;
                        }
                        // custom meta
                        $custom_meta = array(
                            'ix_source' => 'ep-calendar',
                            'ix_feed_id' => $event_feed_id,
                        );
                        $event_data->custom_meta = $custom_meta;
                        // first check
                        $defaults = array(
                            'post_status' => 'any',
                            'post_type' => EM_EVENT_POST_TYPE,
                            'numberposts' => -1
                        );
                        $posts = get_posts($defaults);
                        $is_feed_exist = 0;
                        if(!empty($posts)){
                            foreach ($posts as $postData) {
                                $customVal = em_get_post_meta($postData->ID, 'custom_meta');
                                if(!empty($customVal)){
                                    foreach ($customVal as $csval) {
                                        if($csval['ix_feed_id'] == $event_feed_id){
                                            $is_feed_exist = 1;
                                            break;
                                        }
                                    }
                                }
                                if($is_feed_exist == 1){
                                    break;
                                }
                            }
                        }
                        if($is_feed_exist == 1){
                            continue;
                        }
                        // if event ID and name empty then not insert
                        if(empty($event_data->name)){
                            continue;
                        }
                        // save event
                        $events_id = $event_dao->save($event_data);
                        if(!empty($event_venue_id)){
                            $event_dao->set_venue($events_id, $event_venue_id);
                            $event_dao->set_meta($events_id, 'venue', $event_venue_id);
                        }
                        if(!empty($event_type_id)){
                            $event_dao->set_type($events_id, $event_type_id);
                            $event_dao->set_meta($events_id, 'event_type', $event_type_id);
                        }
                        $event_ids[] = $events_id;
                    }
                    $eventsCount = count($event_ids);
                    if($eventsCount == 0){
                        $returnData['success'] = __('No Event(s) Imported. All Event(s) Already Exist!','eventprime-events-import-export');
                    }
                    else{
                        $returnData['success'] = count($event_ids).__(' Event(s) Imported Successfully!','eventprime-events-import-export');
                    }
                }
                else{
                    $returnData['errors'] = __('No Event found in uploaded file', 'eventprime-events-import-export');
                }
                return $returnData;
            }
            else if(strtolower($extension) == 'ics'){
                $parsed = $this->parse_ics($feed_file);
                $events = $parsed->events();
                if(!empty($events)){
                    foreach ($events as $event) {
                        $event_venue_id = $event_type_id = '';
                        $event_feed_id = $event->uid;
                        // save event
                        $event_service = EventM_Factory::get_service('EventM_Service');
                        $event_dao = new EventM_Event_DAO();
                        $event_data = $event_service->load_model_from_db(0);
                        $event_data->name = htmlspecialchars_decode(sanitize_text_field(strip_tags($event->summary)));
                        $event_data->description = sanitize_text_field($event->description);
                        $date_start = new DateTime($event->dtstart);
                        $date_start->setTimezone(new DateTimeZone($timezone));
                        $start_date = $date_start->format('U');
                        $date_end = new DateTime($event->dtend);
                        $date_end->setTimezone(new DateTimeZone($timezone));
                        $end_date = $date_end->format('U');
                        $allday = (int) $event->all_day;
                        if(!empty($allday) || !trim($start_date) && !trim($end_date)){
                            $allDayDate = date('m/d/Y', $date_start->format('U'));
                            $allday = 1;
                            $start_hour = '00';
                            $start_minutes = '00';
                            $end_hour = '00';
                            $end_minutes = '00';
                            $start_date = em_timestamp($allDayDate.' '.$start_hour.':'.$start_minutes);
                            $allEndDate = date('m/d/Y', strtotime($allDayDate. ' + 1 days'));
                            $end_date = em_timestamp($allEndDate.' '.$end_hour.':'.$end_minutes);
                        }
                        $event_data->start_date = !empty($start_date) ? $start_date : '';
                        $event_data->end_date = !empty($end_date) ? $end_date : '';
                        $event_data->start_booking_date = '';
                        $event_data->last_booking_date = '';
                        $event_data->all_day = $allday;
                        $event_data->hide_event_from_calendar = (int) $event->hide_event_from_calendar;
                        $event_data->hide_event_from_events = (int) $event->hide_event_from_events;
                        $event_data->ticket_template = $event->ticket_template;
                        $event_data->max_tickets_per_person = (int) $event->max_tickets_per_person;
                        $event_data->allow_cancellations = (int) $event->allow_cancellations;
                        $event_data->allow_discount = (int) $event->allow_discount;
                        $event_data->discount_no_tickets = (int) $event->discount_no_tickets;
                        $event_data->discount_per = $event->discount_per;
                        $event_data->ticket_price = (int) $event->ticket_price;
                        $event_data->hide_organizer = (int) $event->hide_organizer;
                        $event_data->hide_booking_status = (int) $event->hide_booking_status;
                        $event_data->last_booking_date = $event->last_booking_date;
                        $event_data->start_booking_date = $event->start_booking_date;
                        $event_data->rm_form = (int) $event->rm_form;
                        $event_data->booked_seats = (int) $event->booked_seats;
                        $event_data->enable_booking = (int) $event->enable_booking;
                        $event_data->custom_link_enabled = (int) $event->custom_link_enabled;
                        $event_data->custom_link = (string) $event->custom_link;
                        $event_data->enable_attendees = (int) $event->enable_attendees;
                        $event_data->show_attendees = (int) $event->show_attendees;
                        $event_data->is_featured = (int) $event->is_featured;
                        $event_data->allow_comments = (int) $event->allow_comments;
                        $event_data->event_text_color = $event->event_text_color;
                        $event_data->fixed_event_price = (int) $event->fixed_event_price;
                        $event_data->show_fixed_event_price = (int) $event->show_fixed_event_price;
                        $event_data->parent = (int) $event->parent;
                        $event_data->facebook_page = sanitize_text_field($event->facebook_page);
                        // venue
                        if(!empty(trim($event->location))){
                            $location_name = $event->location;
                            $location_term = get_term_by('name', $location_name, 'em_venue');
                            if(!empty($location_term)){
                                $event_data->venue = $location_term->term_id;
                            }
                        }
                        if(empty($location_term)){
                            $venue_service = EventM_Factory::get_service('EventM_Venue_Service');
                            $venue_model = new EventM_Venue_Model();
                            $venue_model->name = sanitize_text_field($location_name);
                            $venue_model->type = 'standings';
                            $venue_model->address = sanitize_text_field($event->location);
                            $venue_model->seating_capacity = 0;
                            $venue = $venue_service->save($venue_model);
                            $event_venue_id = $venue->id;
                            if(!empty($event_venue_id)){
                                $event_data->venue = $event_venue_id;
                            }
                        }
                        else{
                            $event_venue_id = $location_term->term_id;
                            $event_data->venue = $event_venue_id;
                        }
                        if(!empty($event->performer)){
                            $performer_service = EventM_Factory::get_service('EventM_Performer_Service');
                            $all_performers = $performer_service->get_all();
                            $performer_ids = array();
                            foreach ($event->performer as $imp_per) {
                                foreach ($all_performers as $per) {
                                    if($per->name == $imp_per){
                                        $performer_ids[] = $per->id;
                                        break;
                                    }
                                    else{
                                        $performer_model = new EventM_Performer_Model();
                                        $performer_model->name = $imp_per;
                                        $performer_model->type = empty($type) ? 'person' : $type;
                                        $performer = $performer_service->save($performer_model);
                                        $performer_ids[] = $performer;
                                        break;
                                    }
                                }
                            }
                            $event_data->performer = $performer_ids;
                            if(!empty($event_data->performer)){
                                $event_data->enable_performer = 1;
                            }
                        }
                        if(!empty($event->organizer)){
                            $event_data->organizer_name = sanitize_text_field($event->organizer);
                        }
                        if(!empty($event->organizer_phones)){
                            foreach ($event->organizer_phones as $key => $value) {
                                $event_data->organizer_phones[$key] = sanitize_text_field($value);
                            }
                        }
                        if(!empty($event->organizer_emails)){
                            foreach ($event->organizer_emails as $key => $value) {
                                $event_data->organizer_emails[$key] = sanitize_text_field($value);
                            }
                        }
                        if(!empty($event->organizer_websites)){
                            foreach ($event->organizer_websites as $key => $value) {
                                $event_data->organizer_websites[$key] = sanitize_text_field($value);
                            }
                        }
                        // event type
                        if(!empty(trim($event->event_type))){
                            $eventType = $event->event_type;
                            $type_term = get_term_by('name', $eventType, 'em_event_type');
                            if(!empty($type_term)){
                                $event_data->event_type = $type_term->term_id;
                            }
                        }
                        if(empty($type_term)){
                            $type_service = EventM_Factory::get_service('EventTypeM_Service');
                            $type = new EventM_Event_Type_Model();
                            $type->name = sanitize_text_field($event->event_type);
                            $ev_type = $type_service->save($type);
                            $event_type_id = $ev_type->id;
                            if(!empty($event_type_id)){
                                $event_data->event_type = $event_type_id;
                            }
                        }
                        else{
                            $event_type_id = $type_term->term_id;
                            $event_data->event_type = $event_type_id;
                        }
                        // custom meta
                        $custom_meta = array(
                            'ix_source' => 'ep-ics-calendar',
                            'ix_feed_id' => $event_feed_id,
                        );
                        $event_data->custom_meta = $custom_meta;
                        // first check
                        $defaults = array(
                            'post_status' => 'any',
                            'post_type' => EM_EVENT_POST_TYPE,
                            'numberposts' => -1
                        );
                        $posts = get_posts($defaults);
                        $is_feed_exist = 0;
                        if(!empty($posts)){
                            foreach ($posts as $postData) {
                                $customVal = em_get_post_meta($postData->ID, 'custom_meta');
                                if(!empty($customVal)){
                                    foreach ($customVal as $csval) {
                                        if($csval['ix_feed_id'] == $event_feed_id){
                                            $is_feed_exist = 1;
                                            break;
                                        }
                                    }
                                }
                                if($is_feed_exist == 1){
                                    break;
                                }
                            }
                        }
                        if($is_feed_exist == 1){
                            continue;
                        }
                        // if event ID and name empty then not insert
                        if(empty($event_data->name)){
                            continue;
                        }
                        // save event
                        $events_id = $event_dao->save($event_data);
                        if(!empty($event_venue_id)){
                            $event_dao->set_venue($events_id, $event_venue_id);
                            $event_dao->set_meta($events_id, 'venue', $event_venue_id);
                        }
                        if(!empty($event_type_id)){
                            $event_dao->set_type($events_id, $event_type_id);
                            $event_dao->set_meta($events_id, 'event_type', $event_type_id);
                        }
                        $event_ids[] = $events_id;
                    }
                    $eventsCount = count($event_ids);
                    if($eventsCount == 0){
                        $returnData['success'] = __('No Event(s) Imported. All Event(s) Already Exist!','eventprime-events-import-export');
                    }
                    else{
                        $returnData['success'] = count($event_ids).__(' Event(s) Imported Successfully!','eventprime-events-import-export');
                    }
                }
                else{
                    $returnData['errors'] = __('No Event found in uploaded file', 'eventprime-events-import-export');
                }
                return $returnData;
            }
            else if(strtolower($extension) == 'csv'){
                $rows_string = $this->read_file($feed_file);
                if(!empty($rows_string)){
                    $csv_string = array_map("str_getcsv", explode("\n", $rows_string));
                    $i = 0;
                    foreach ($csv_string as $value) {
                        $event_venue_id = $event_type_id = '';
                        if($i == 0){
                            $i++;
                            continue;
                        }
                        $event_feed_id = $value[0];
                        $title = $value[1];
                        $description = $value[2];
                        $csv_start_date = $value[3];
                        $csv_end_date = $value[4];
                        $csv_booking_start_date = $value[5];
                        $csv_booking_end_date = $value[6];
                        $event_all_day = $value[7];
                        $event_url = $value[8];
                        $event_type = $value[9];
                        $event_cost = $value[10];
                        $location_name = $value[11];
                        $address = $value[12];
                        $latitude = $value[13];
                        $longitude = $value[14];
                        $seating_capacity = $value[15];
                        $operator = $value[16];
                        $performers = $value[17];
                        $organizer = $value[18];
                        $organizer_phones = $value[19];
                        $organizer_emails = $value[20];

                        // save event
                        $event_service = EventM_Factory::get_service('EventM_Service');
                        $event_dao = new EventM_Event_DAO();
                        $event_data = $event_service->load_model_from_db(0);
                        $event_data->name = htmlspecialchars_decode(sanitize_text_field(strip_tags($title)));
                        $event_data->description = sanitize_text_field($event->description);
                        if(!empty($csv_start_date)){
                            $csv_start_date = date("Y-m-d H:i", strtotime($csv_start_date));
                            $date_start = new DateTime($csv_start_date);
                            $date_start->setTimezone(new DateTimeZone($timezone));
                            $start_date = $date_start->format('U');
                        }
                        if(!empty($csv_end_date)){
                            $csv_end_date = date("Y-m-d H:i", strtotime($csv_end_date));
                            $date_end = new DateTime($csv_end_date);
                            $date_end->setTimezone(new DateTimeZone($timezone));
                            $end_date = $date_end->format('U');
                        }
                        $allday = (int) $event_all_day;
                        if(!empty($allday) || !trim($start_date) && !trim($end_date)){
                            $allDayDate = date('m/d/Y', $date_start->format('U'));
                            $allday = 1;
                            $start_hour = '00';
                            $start_minutes = '00';
                            $end_hour = '00';
                            $end_minutes = '00';
                            $start_date = em_timestamp($allDayDate.' '.$start_hour.':'.$start_minutes);
                            $allEndDate = date('m/d/Y', strtotime($allDayDate. ' + 1 days'));
                            $end_date = em_timestamp($allEndDate.' '.$end_hour.':'.$end_minutes);
                        }
                        $event_data->start_date = !empty($start_date) ? $start_date : '';
                        $event_data->end_date = !empty($end_date) ? $end_date : '';
                        if(!empty($csv_booking_start_date)){
                            $csv_booking_start_date = date("Y-m-d H:i", strtotime($csv_booking_start_date));
                            $date_booking_start = new DateTime($csv_booking_start_date);
                            $date_booking_start->setTimezone(new DateTimeZone($timezone));
                            $start_booking_date = $date_booking_start->format('U');
                        }
                        if(!empty($csv_booking_end_date)){
                            $csv_booking_end_date = date("Y-m-d H:i", strtotime($csv_booking_end_date));
                            $date_booking_end = new DateTime($csv_end_date);
                            $date_booking_end->setTimezone(new DateTimeZone($timezone));
                            $end_booking_date = $date_booking_end->format('U');
                        }
                        $event_data->start_booking_date = !empty($start_booking_date) ? $start_booking_date : '';
                        $event_data->last_booking_date = !empty($end_booking_date) ? $end_booking_date : '';
                        $event_data->ticket_price = $event_cost;
                        if(!empty(trim($location_name))){
                            $location_term = get_term_by('name', $location_name, 'em_venue');
                        }
                        else{
                            if(!empty(trim($address))){
                                $location_exp = explode(",", $address);
                                $location_name = $location_exp[0];
                                $location_term = get_term_by('name', $location_name, 'em_venue');
                            }
                        }
                        if(empty($location_term)){
                            $venue_service = EventM_Factory::get_service('EventM_Venue_Service');
                            $venue_model = new EventM_Venue_Model();
                            $venue_model->name = sanitize_text_field($location_name);
                            $venue_model->type = 'standings';
                            $venue_model->address = sanitize_text_field($address);
                            if(empty($address)){
                                $venue_model->address = sanitize_text_field($location_name);
                            }
                            $venue_model->seating_capacity = $seating_capacity;
                            $venue_model->lng = $longitude;
                            $venue_model->lat = $latitude;
                            $venue = $venue_service->save($venue_model);
                            $event_venue_id = $venue->id;
                            if(!empty($event_venue_id)){
                                $event_data->venue = $event_venue_id;
                            }
                        }
                        else{
                            $event_venue_id = $location_term->term_id;
                            $event_data->venue = $event_venue_id;
                        }
                        if(!empty($performers)){
                            $performer_service = EventM_Factory::get_service('EventM_Performer_Service');
                            $all_performers = $performer_service->get_all();
                            $performer_ids = array();
                            foreach ($performers as $imp_per) {
                                foreach ($all_performers as $per) {
                                    if($per->name == $imp_per){
                                        $performer_ids[] = $per->id;
                                        break;
                                    }
                                    else{
                                        $performer_model = new EventM_Performer_Model();
                                        $performer_model->name = $imp_per;
                                        $performer_model->type = empty($type) ? 'person' : $type;
                                        $performer = $performer_service->save($performer_model);
                                        $performer_ids[] = $performer;
                                        break;
                                    }
                                }
                            }
                            $event_data->performer = $performer_ids;
                            if(!empty($event_data->performer)){
                                $event_data->enable_performer = 1;
                            }
                        }
                        if(!empty($organizer)){
                            $event_data->organizer_name = sanitize_text_field($organizer);
                        }
                        if(!empty($organizer_phones)){
                            foreach ($organizer_phones as $key => $value) {
                                $event_data->organizer_phones[$key] = sanitize_text_field($value);
                            }
                        }
                        if(!empty($organizer_emails)){
                            foreach ($organizer_emails as $key => $value) {
                                $event_data->organizer_emails[$key] = sanitize_text_field($value);
                            }
                        }
                        // event type
                        if(!empty(trim($event_type))){
                            $eventType = $event_type;
                            $type_term = get_term_by('name', $eventType, 'em_event_type');
                        }
                        if(empty($type_term)){
                            $type_service = EventM_Factory::get_service('EventTypeM_Service');
                            $type = new EventM_Event_Type_Model();
                            $type->name = sanitize_text_field($event_type);
                            $ev_type = $type_service->save($type);
                            $event_type_id = $ev_type->id;
                            if(!empty($event_type_id)){
                                $event_data->event_type = $event_type_id;
                            }
                        }
                        else{
                            $event_type_id = $type_term->term_id;
                            $event_data->event_type = $event_type_id;
                        }
                        // custom meta
                        $custom_meta = array(
                            'ix_source' => 'ep-csv-calendar',
                            'ix_feed_id' => $event_feed_id,
                        );
                        $event_data->custom_meta = $custom_meta;
                        // first check
                        $defaults = array(
                            'post_status' => 'any',
                            'post_type' => EM_EVENT_POST_TYPE,
                            'numberposts' => -1
                        );
                        $posts = get_posts($defaults);
                        $is_feed_exist = 0;
                        if(!empty($posts)){
                            foreach ($posts as $postData) {
                                $customVal = em_get_post_meta($postData->ID, 'custom_meta');
                                if(!empty($customVal)){
                                    foreach ($customVal as $csval) {
                                        if($csval['ix_feed_id'] == $event_feed_id){
                                            $is_feed_exist = 1;
                                            break;
                                        }
                                    }
                                }
                                if($is_feed_exist == 1){
                                    break;
                                }
                            }
                        }
                        if($is_feed_exist == 1){
                            continue;
                        }
                        // if event name empty then not insert
                        if(empty($event_data->name)){
                            continue;
                        }
                        // save event
                        $events_id = $event_dao->save($event_data);
                        if(!empty($event_venue_id)){
                            $event_dao->set_venue($events_id, $event_venue_id);
                            $event_dao->set_meta($events_id, 'venue', $event_venue_id);
                        }
                        if(!empty($event_type_id)){
                            $event_dao->set_type($events_id, $event_type_id);
                            $event_dao->set_meta($events_id, 'event_type', $event_type_id);
                        }
                        $event_ids[] = $events_id;
                        $i++;
                    }
                    $eventsCount = count($event_ids);
                    if($eventsCount == 0){
                        $returnData['success'] = __('No Event(s) Imported. All Event(s) Already Exist!','eventprime-events-import-export');
                    }
                    else{
                        $returnData['success'] = count($event_ids).__(' Event(s) Imported Successfully!','eventprime-events-import-export');
                    }
                }
                else{
                    $returnData['errors'] = __('No Event found in uploaded file', 'eventprime-events-import-export');
                }
                return $returnData;            
            }
            else if(strtolower($extension) == 'json'){
                $rows_string = $this->read_file($feed_file);
                if(!empty($rows_string)){
                    $json_string = json_decode($rows_string, true);
                    if(!empty($json_string)){
                        foreach($json_string as $event){
                            $event_venue_id = $event_type_id = '';
                            // save event
                            $event_service = EventM_Factory::get_service('EventM_Service');
                            $ix_event_data = (array) $event;
                            $event_feed_id = $ix_event_data['id'];
                            $event_dao = new EventM_Event_DAO();
                            $event_data = $event_service->load_model_from_db(0);
                            $event_data->name = htmlspecialchars_decode(sanitize_text_field(strip_tags($ix_event_data['name'])));
                            $event_data->description = sanitize_text_field($ix_event_data['description']);
                            $start_date = $ix_event_data['start_date'];
                            $end_date = $ix_event_data['end_date'];
                            $allday = (int) $ix_event_data['all_day'];
                            if(!empty($allday) || !trim($start_date) && !trim($end_date)){
                                $allDayDate = date('m/d/Y', $ix_event_data['start_date']);
                                $allday = 1;
                                $start_hour = '00';
                                $start_minutes = '00';
                                $end_hour = '00';
                                $end_minutes = '00';
                                $start_date = em_timestamp($allDayDate.' '.$start_hour.':'.$start_minutes);
                                $allEndDate = date('m/d/Y', strtotime($allDayDate. ' + 1 days'));
                                $end_date = em_timestamp($allEndDate.' '.$end_hour.':'.$end_minutes);
                            }
                            $event_data->start_date = !empty($start_date) ? $start_date : '';
                            $event_data->end_date = !empty($end_date) ? $end_date : '';
                            $event_data->start_booking_date = '';
                            $event_data->last_booking_date = '';
                            $event_data->all_day = $allday;
                            $event_data->hide_event_from_calendar = (int) $ix_event_data['hide_event_from_calendar'];
                            $event_data->hide_event_from_events = (int) $ix_event_data['hide_event_from_events'];
                            $event_data->ticket_template = $ix_event_data['ticket_template'];
                            $event_data->max_tickets_per_person = (int) $ix_event_data['max_tickets_per_person'];
                            $event_data->allow_cancellations = (int) $ix_event_data['allow_cancellations'];
                            $event_data->allow_discount = (int) $ix_event_data['allow_discount'];
                            $event_data->discount_no_tickets = (int) $ix_event_data['discount_no_tickets'];
                            $event_data->discount_per = $ix_event_data['discount_per'];
                            $event_data->ticket_price = (int) $ix_event_data['ticket_price'];
                            $event_data->hide_organizer = (int) $ix_event_data['hide_organizer'];
                            $event_data->hide_booking_status = (int) $ix_event_data['hide_booking_status'];
                            $event_data->last_booking_date = (!empty($ix_event_data['last_booking_date']) ? $ix_event_data['last_booking_date'] : '');
                            $event_data->start_booking_date = (!empty($ix_event_data['start_booking_date']) ? $ix_event_data['start_booking_date'] : '');
                            $event_data->rm_form = (int) $ix_event_data['rm_form'];
                            $event_data->booked_seats = (int) $ix_event_data['booked_seats'];
                            $event_data->enable_booking = (int) $ix_event_data['enable_booking'];
                            $event_data->custom_link_enabled = (int) $ix_event_data['custom_link_enabled'];
                            $event_data->custom_link = (string) $ix_event_data['custom_link'];
                            $event_data->enable_attendees = (int) $ix_event_data['enable_attendees'];
                            $event_data->show_attendees = (int) $ix_event_data['show_attendees'];
                            $event_data->is_featured = (int) $ix_event_data['is_featured'];
                            $event_data->allow_comments = (int) $ix_event_data['allow_comments'];
                            $event_data->event_text_color = (string) $ix_event_data['event_text_color'];
                            $event_data->fixed_event_price = (int) $ix_event_data['fixed_event_price'];
                            $event_data->show_fixed_event_price = (int) $ix_event_data['show_fixed_event_price'];
                            $event_data->parent = (int) $ix_event_data['parent'];
                            $event_data->facebook_page = sanitize_text_field($ix_event_data['facebook_page']);
                            // venue
                            if(!empty(trim($ix_event_data['venue']))){
                                $location_name = $ix_event_data['venue'];
                                $location_term = get_term_by('name', $location_name, 'em_venue');
                            }
                            else{
                                if(!empty(trim($ix_event_data['address']))){
                                    $location_exp = explode(",", $ix_event_data['address']);
                                    $location_name = $location_exp[0];
                                    $location_term = get_term_by('name', $location_name, 'em_venue');
                                }
                            }
                            if(empty($location_term)){
                                $venue_service = EventM_Factory::get_service('EventM_Venue_Service');
                                $venue_model = new EventM_Venue_Model();
                                $venue_model->name = sanitize_text_field($location_name);
                                $venue_model->type = 'standings';
                                $venue_model->address = sanitize_text_field($ix_event_data['address']);
                                if(empty($ix_event_data['address'])){
                                    $venue_model->address = sanitize_text_field($location_name);
                                }
                                $venue_model->seating_capacity = 0;
                                $venue = $venue_service->save($venue_model);
                                $event_venue_id = $venue->id;
                                if(!empty($event_venue_id)){
                                    $event_data->venue = $event_venue_id;
                                }
                            }
                            else{
                                $event_venue_id = $location_term->term_id;
                                $event_data->venue = $event_venue_id;
                            }
                            if(!empty($ix_event_data['performer'])){
                                $performer_service = EventM_Factory::get_service('EventM_Performer_Service');
                                $all_performers = $performer_service->get_all();
                                $performer_ids = array();
                                foreach ($ix_event_data['performer'] as $imp_per) {
                                    foreach ($all_performers as $per) {
                                        if($per->name == $imp_per){
                                            $performer_ids[] = $per->id;
                                            break;
                                        }
                                        else{
                                            $performer_model = new EventM_Performer_Model();
                                            $performer_model->name = $imp_per;
                                            $performer_model->type = empty($type) ? 'person' : $type;
                                            $performer = $performer_service->save($performer_model);
                                            $performer_ids[] = $performer;
                                            break;
                                        }
                                    }
                                }
                                $event_data->performer = $performer_ids;
                                if(!empty($event_data->performer)){
                                    $event_data->enable_performer = 1;
                                }
                            }
                            if(!empty($ix_event_data['organizer_name'])){
                                $event_data->organizer_name = sanitize_text_field($ix_event_data['organizer_name']);
                            }
                            if(!empty($ix_event_data['organizer_phones'])){
                                foreach ($ix_event_data['organizer_phones'] as $key => $value) {
                                    $event_data->organizer_phones[$key] = sanitize_text_field($value);
                                }
                            }
                            if(!empty($ix_event_data['organizer_emails'])){
                                foreach ($ix_event_data['organizer_emails'] as $key => $value) {
                                    $event_data->organizer_emails[$key] = sanitize_text_field($value);
                                }
                            }
                            if(!empty($ix_event_data['organizer_websites'])){
                                foreach ($ix_event_data['organizer_websites'] as $key => $value) {
                                    $event_data->organizer_websites[$key] = sanitize_text_field($value);
                                }
                            }
                            // event type
                            if(!empty(trim($ix_event_data['event_type']))){
                                $eventType = $ix_event_data['event_type'];
                                $type_term = get_term_by('name', $eventType, 'em_event_type');
                            }
                            if(empty($type_term)){
                                $type_service = EventM_Factory::get_service('EventTypeM_Service');
                                $type = new EventM_Event_Type_Model();
                                $type->name = sanitize_text_field($ix_event_data['event_type']);
                                $ev_type = $type_service->save($type);
                                $event_type_id = $ev_type->id;
                                if(!empty($event_type_id)){
                                    $event_data->event_type = $event_type_id;
                                }
                            }
                            else{
                                $event_type_id = $type_term->term_id;
                                $event_data->event_type = $event_type_id;
                            }
                            // custom meta
                            $custom_meta = array(
                                'ix_source' => 'ep-calendar',
                                'ix_feed_id' => $event_feed_id,
                            );
                            $event_data->custom_meta = $custom_meta;
                            // first check
                            $defaults = array(
                                'post_status' => 'any',
                                'post_type' => EM_EVENT_POST_TYPE,
                                'numberposts' => -1
                            );
                            $posts = get_posts($defaults);
                            $is_feed_exist = 0;
                            if(!empty($posts)){
                                foreach ($posts as $postData) {
                                    $customVal = em_get_post_meta($postData->ID, 'custom_meta');
                                    if(!empty($customVal)){
                                        foreach ($customVal as $csval) {
                                            if($csval['ix_feed_id'] == $event_feed_id){
                                                $is_feed_exist = 1;
                                                break;
                                            }
                                        }
                                    }
                                    if($is_feed_exist == 1){
                                        break;
                                    }
                                }
                            }
                            if($is_feed_exist == 1){
                                continue;
                            }
                            // if event ID and name empty then not insert
                            if(empty($event_data->name)){
                                continue;
                            }
                            // save event
                            $events_id = $event_dao->save($event_data);
                            if(!empty($event_venue_id)){
                                $event_dao->set_venue($events_id, $event_venue_id);
                                $event_dao->set_meta($events_id, 'venue', $event_venue_id);
                            }
                            if(!empty($event_type_id)){
                                $event_dao->set_type($events_id, $event_type_id);
                                $event_dao->set_meta($events_id, 'event_type', $event_type_id);
                            }
                            $event_ids[] = $events_id;
                        }
                        $eventsCount = count($event_ids);
                        if($eventsCount == 0){
                            $returnData['success'] = __('No Event(s) Imported. All Event(s) Already Exist!','eventprime-events-import-export');
                        }
                        else{
                            $returnData['success'] = count($event_ids).__(' Event(s) Imported Successfully!','eventprime-events-import-export');
                        }
                    }
                    else{
                        $returnData['errors'] = __('No Event found in uploaded file', 'eventprime-events-import-export');
                    }
                }
                else{
                    $returnData['errors'] = __('No Event found in uploaded file', 'eventprime-events-import-export');
                }
                return $returnData;
            }
        }
    }

    private function read_file($filename){
        $fh = fopen($filename, 'rb');
        if(false === $fh) return false;
        clearstatcache();
        if($fsize = @filesize($filename)){
            $data = fread($fh, $fsize);
            fclose($fh);
            return $data;
        }
        else{
            fclose($fh);
            return false;
        }
    }

    private function parse_ics($feed){
        try {
            return new ICal($feed, array(
                'defaultSpan'                 => 2,     // Default value
                'defaultTimeZone'             => 'UTC',
                'defaultWeekStart'            => 'MO',  // Default value
                'disableCharacterReplacement' => false, // Default value
                'skipRecurrence'              => true, // Default value
                //'useTimeZoneWithRRules'       => false, // Default value
            ));
        }
        catch(\Exception $e)
        {
            return false;
        }
    }
    
}
EventM_Event_File_Import_Service::get_instance();