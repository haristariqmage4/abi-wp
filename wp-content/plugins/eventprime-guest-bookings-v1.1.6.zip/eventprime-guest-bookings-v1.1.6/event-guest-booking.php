<?php
/**
 * Plugin Name: EventPrime Guest Bookings
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that allows attendees to complete their event bookings without registering or logging in.
 * Version: 1.1.6
 * Author: EventPrime
 * Text Domain: eventprime-event-guest-booking
 * Domain Path: /languages
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 6.1.1
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_Guest_Booking')) {

    final class EM_Guest_Booking {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.1.6';

        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;

        
        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }


        /**
         * Event_Magic Constructor.
         */
        private function __construct() {
            $this->define_constants();
            $this->load_textdomain();
            $this->includes(); 
            $this->define_hooks();
            $em= event_magic_instance();
            array_push($em->extensions,'guest-booking');
        }
            
        public function define_constants(){
            $em= event_magic_instance();
            $em->define('EMGB_BASE_URL', plugin_dir_url(__FILE__));
            define('EMGB_VERSION', $this->version);
        }
        
        public function includes(){
            include_once('includes/models/class-emgb-global-settings.php');
            include_once('includes/dao/class-emgb-global-settings.php');
        }
        
        public function define_hooks(){
            add_action('wp_enqueue_scripts',array($this,'event_magic_enqueue_style_and_scripts'));
            add_action('event_magic_gs_settings',array($this,'event_guest_booking_gs_settings'));
            add_action('event_magic_gs_popup',array($this,'event_guest_booking_gs_settings_form'));
            add_action('em_after_gs_save',array($this,'event_guest_booking_gs_settings_save'));
            add_filter('em_load_gs_ext_options',array($this,'event_guest_booking_get_options'), 99, 1);
            add_filter('event_magic_gs_get_model',array($this,'event_guest_booking_get_options'), 99, 1);
            add_action('event_magic_guest_booking_user_info_block',array($this,'event_magic_guest_booking_user_info_block'), 10, 1);
            add_action('event_magic_guest_booking_user_info_block_view',array($this,'event_magic_guest_booking_user_info_block_view'));
            add_action('event_magic_admin_offline_handle',array($this,'event_magic_show_gb_fields'));
            add_action('wp_ajax_em_guest_booking_show_order_detail',array($this,'guest_booking_show_order_details'));
            add_action('wp_ajax_nopriv_em_guest_booking_show_order_detail',array($this,'guest_booking_show_order_details'));

            add_action('wp_ajax_em_get_custom_form_builder_fields',array($this,'get_custom_form_builder_fields'));
            add_action('wp_ajax_em_save_default_guest_booking_fields',array($this,'save_default_guest_booking_fields'));
            add_filter('event_magic_filter_event_data_for_booking',array($this,'event_guest_booking_filter_event_data_for_booking'), 99, 1);
            add_action('event_magic_guest_booking_order_detail_redirect',array($this,'guest_booking_order_detail_redirect'));
        }
        
        
        public function load_textdomain(){
            load_plugin_textdomain('eventprime-event-guest-booking', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        public function event_guest_booking_gs_settings(){?> 
            <a href='javascript:void(0)' class="ep-extension-with-gs" ng-click="enableGlobalService('showUserEventGuestBooking')">
                <div class='em-settings-box'>
                    <img class='em-settings-icon' ng-src='<?php echo EMGB_BASE_URL; ?>includes/admin/template/images/event-guest-booking-icon.png'>
                    <div class='em-settings-description'>

                    </div>
                    <div class='em-settings-subtitle'><?php _e('Guest Booking', 'eventprime-event-guest-booking'); ?></div>
                    <span><?php _e('Configure guest bookings.', 'eventprime-event-guest-booking'); ?></span>
                </div>
            </a> 
        <?php
        }

        public function event_guest_booking_gs_settings_form(){
            wp_enqueue_style('em-guest-admin-css', EMGB_BASE_URL . 'includes/public/css/em_guest_admin.css', false, EMGB_VERSION);
            wp_enqueue_script('em-guest-booking-admin-js', EMGB_BASE_URL . 'includes/admin/js/em_guest_booking.js', false, EMGB_VERSION);?> 
            <div ng-show="showUserEventGuestBooking">
                <div class="emrow">
                    <div class="emfield"><?php _e('Allow Guest Bookings', 'eventprime-event-guest-booking'); ?></div>
                    <div class="eminput">
                            <input type="checkbox" ng-true-value="1" ng-fale-value="0" name="allow_guest_bookings"  ng-model="data.options.allow_guest_bookings">
                            <div class="emfield_error">

                            </div>
                        </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Allow users to book event without registration.', 'eventprime-event-guest-booking'); ?>
                    </div>
                </div>
                <div ng-show="showUserEventGuestBooking && data.options.allow_guest_bookings==1">
                    <div class="emrow">
                        <div class="emfield"><?php _e('Auto Create Guest Account', 'eventprime-event-guest-booking'); ?></div>
                        <div class="eminput">
                                <input type="checkbox" ng-true-value="1" ng-fale-value="0" name="auto_create_guest_account"  ng-model="data.options.auto_create_guest_account">
                                <div class="emfield_error">

                                </div>
                            </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php _e('Auto create user account with subscriber role.', 'eventprime-event-guest-booking'); ?>
                        </div>
                    </div>
                    
                    <div class="emrow">
                        <div class="emfield"><?php _e('Redirect Page', 'eventprime-event-guest-booking'); ?></div>
                        <div class="eminput">
                            <select name="guest_booking_page_redirect" ng-model="data.options.guest_booking_page_redirect"  ng-options="pages.id as pages.name for pages in data.options.pages"></select>
                        </div>
                        <div class="emfield_error"></div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php _e('Redirect Page after booking.', 'eventprime-event-guest-booking'); ?>
                        </div>
                    </div>

                     <div class="emrow">
                        <div class="emfield"><?php _e('Use Custom Checkout Fields', 'eventprime-event-guest-booking'); ?></div>
                        <div class="eminput">
                                <input type="checkbox" ng-true-value="1" ng-fale-value="0" name="allow_guest_custom_booking_fields" ng-model="data.options.allow_guest_custom_booking_fields">
                                <div class="emfield_error">

                                </div>
                            </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php _e('Add and manage custom fields during checkout to collect guest user information.', 'eventprime-event-guest-booking'); ?>
                        </div>
                    </div>
                    <div class="emrow" ng-controller="guestBookingsCtrl" ng-show="showUserEventGuestBooking && data.options.allow_guest_custom_booking_fields == 1" ng-init="initializeGuest()" >
                        <div class="eminput em-gcbf-builder">
                            <div class="em-gcbf-container">
                                <ul id="em-gcbf-fields">
                                    <guest-custom-field></guest-custom-field>
                                </ul>
                                <div id="em-gcbf-types">
                                    <button type="button" class="button" ng-repeat="(key, value) in data.options.custom_fields_option" data-type="{{key}}" ng-click="addGuestFieldInCustomizer(key)" id="{{key}}-field">{{value}}</button> 
                                </div>
                            </div>
                        </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php _e('Add new fields using the buttons below. You can make them mandatory and set labels.', 'eventprime-event-calendar-management'); ?>
                        </div>
                    </div>
                </div> 
            </div> 
            <?php
        }

        public function event_guest_booking_gs_settings_save(){
            $request = EventM_Raw_Request::get_instance();
            $service=  EventM_Factory::get_service('EventM_Setting_Service');
            $model = $request->map_request_to_model('EventMGB_Global_Settings_Model');
            $template= $service->save($model);
        }

        public function event_guest_booking_get_options($options){
            $emgbdao= new EventMGB_Global_Settings_DAO();
            $emgbmmodel = $emgbdao->get();
            $options->allow_guest_bookings= absint($emgbmmodel->allow_guest_bookings);
            $options->auto_create_guest_account= absint($emgbmmodel->auto_create_guest_account);
            $options->guest_booking_page_redirect= absint($emgbmmodel->guest_booking_page_redirect);
            $options->allow_guest_custom_booking_fields= absint($emgbmmodel->allow_guest_custom_booking_fields);
            $options->custom_guest_booking_field_data = $emgbmmodel->custom_guest_booking_field_data;
            if(isset($options->load_extension_services)){
                $options->load_extension_services[] = 'showUserEventGuestBooking';
            }
            return $options;
        }

        public function event_magic_enqueue_style_and_scripts() {
            wp_enqueue_style('em-guest-booking-css', EMGB_BASE_URL . 'includes/public/css/em_guest_booking.css', false, EMGB_VERSION);
        }

        public function event_magic_guest_booking_user_info_block($venue_type){
            if(!(is_user_logged_in())){
                wp_enqueue_script('em-guest-booking-front-js', EMGB_BASE_URL . 'includes/public/js/em_guest_booking_front.js', array( 'em-booking-controller', 'jquery-ui-datepicker' ), EMGB_VERSION);
                $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
                $global_settings = $setting_service->load_model_from_db();
                if(!empty($global_settings->allow_guest_custom_booking_fields) && isset($global_settings->custom_guest_booking_field_data) && count($global_settings->custom_guest_booking_field_data) > 1){?>
                    <div class="ep-guest-booking-wrap difl ng-scope pInfo" ng-controller="guestBookingsFrontCtrl" ng-init="gbInitialize()">
                        <div class="ep-guest-booking-heading-text">
                            <?php _e('Personal Information','eventprime-event-guest-booking'); ?>
                        </div>
                        <ul class="ep-guest-booking ng-scope pLi">
                            <div class="ep-guest-booking-sub-heading dbfl">
                                <?php _e('Please fill your personal information','eventprime-event-guest-booking'); ?>
                            </div>
                            <li ng-repeat="field in event.custom_guest_booking_field_data" ng-if="field.type">
                                <div ng-if="field.type == 'text'">
                                    <label for="ep-gbinput-<?php echo $venue_type;?>-{{$index}}">
                                        <span ng-show="field.label">{{field.label}}</span>
                                        <span ng-show="!field.label">{{field.type | capitalize}}</span>
                                        <span class="perror" ng-show="field.required == 1">*</span>
                                    </label>
                                    <input type="text" ng-model="gbdata[$index].value" placeholder="{{field.label}}" id="ep-gbinput-<?php echo $venue_type;?>-{{$index}}">
                                    <span class="perror em-gb-data-{{$index}}"></span>
                                </div>
                                <div ng-if="field.type == 'email'">
                                    <label for="ep-gbinput-<?php echo $venue_type;?>-{{$index}}">
                                        <span ng-show="field.label">{{field.label}}</span>
                                        <span ng-show="!field.label">{{field.type | capitalize}}</span>
                                        <span class="perror" ng-show="field.required == 1">*</span>
                                    </label>
                                    <input type="email" ng-model="gbdata[$index].value" placeholder="{{field.label}}" id="ep-gbinput-<?php echo $venue_type;?>-{{$index}}">
                                    <span class="perror em-gb-data-{{$index}}"></span>
                                </div>
                                <div ng-if="field.type == 'tel'">
                                    <label for="ep-gbinput-<?php echo $venue_type;?>-{{$index}}">
                                        <span ng-show="field.label">{{field.label}}</span>
                                        <span ng-show="!field.label">{{field.type | capitalize}}</span>
                                        <span class="perror" ng-show="field.required == 1">*</span>
                                    </label>
                                    <input type="tel" ng-model="gbdata[$index].value" placeholder="{{field.label}}" id="ep-gbinput-<?php echo $venue_type;?>-{{$index}}">
                                    <span class="perror em-gb-data-{{$index}}"></span>
                                </div>
                                <div ng-if="field.type == 'date'">
                                    <label for="ep-gbinput-<?php echo $venue_type;?>-{{$index}}">
                                        <span ng-show="field.label">{{field.label}}</span>
                                        <span ng-show="!field.label">{{field.type | capitalize}}</span>
                                        <span class="perror" ng-show="field.required == 1">*</span>
                                    </label>
                                    <input type="text" class="em-gbf-datepicker" ng-model="gbdata[$index].value" placeholder="{{field.label}}" id="ep-gbinput-<?php echo $venue_type;?>-{{$index}}">
                                    <span class="perror em-gb-data-{{$index}}"></span>
                                </div>
                            </li>
                        </ul>
                    </div><?php
                } else{?>
                    <div class="ep-guest-booking-wrap difl ng-scope pInfo">
                        <div class="ep-guest-booking-heading-text">
                            <?php _e('Personal Information','eventprime-event-guest-booking'); ?>
                        </div>
                        <ul class="ep-guest-booking ng-scope pLi">
                            <div class="ep-guest-booking-sub-heading dbfl">
                                <?php _e('Please fill your personal information','eventprime-event-guest-booking'); ?>
                            </div>
                            <li>
                                <label><?php _e('Name: ','eventprime-event-guest-booking'); ?>
                                    <span class="perror">*</span></label>
                                <input type="text" placeholder="Your Name" class="em_gb_pi_name" ng-model="gbname">
                                <div class="emfield_error" >
                                    <span class="perror" id="em_gb_pi_name_error">{{error}}</span>
                                </div>
                            </li>
                            <li>
                                <label><?php _e('Email: ','eventprime-event-guest-booking'); ?>
                                    <span class="perror">*</span> 
                                </label>
                                <input type="text" placeholder="Your Email" class="em_gb_pi_email" ng-model="gbemail">
                                <div class="emfield_error" >
                                    <span class="perror" id="em_gb_pi_email_error">{{error}}</span>
                                </div>
                            </li>
                            <li>
                                <label><?php _e('Phone: ','eventprime-event-guest-booking'); ?>
                                    <span class="perror">*</span>
                                </label>
                                <input type="text" placeholder="Your Phone" class="em_gb_pi_phone" ng-model="gbphone">
                                <div class="emfield_error" >
                                    <span class="perror" id="em_gb_pi_phone_error">{{error}}</span>
                                </div>
                            </li>  
                            <div class="ep-form_errors">
                                <div class="emfield_error" ng-repeat="error in formErrors">
                                    <span><span class="material-icons">error_outline</span>{{error}}</span>
                                </div>  
                            </div>
                        </ul>
                    </div><?php
                }
            }
        }

        public function event_magic_guest_booking_user_info_block_view(){
            if(!(is_user_logged_in())){?>
                <div class="ep-guest-booking-wrap ep-guest-booking-checkout difl ng-scope">
                    <div class="ep-guest-booking-heading-text"><?php _e('Personal Information','eventprime-event-guest-booking'); ?></div> 
                    <div>
                        <ul class="ep-guest-booking-input ng-scope pLi"><?php
                            $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
                            $global_settings = $setting_service->load_model_from_db();
                            if(!empty($global_settings->allow_guest_custom_booking_fields) && isset($global_settings->custom_guest_booking_field_data) && count($global_settings->custom_guest_booking_field_data) > 1){ ?>
                                <li ng-repeat="field in event.custom_guest_booking_field_data" ng-if="field.type">
                                    <div class="ep-guest-booking-info">
                                        <div class="ep-guest-booking-label">
                                            <span ng-show="field.label !== ''">{{field.label}}</span>
                                            <span ng-show="field.label === ''">{{field.type}}</span>
                                        </div> 
                                        <div class="ep-guest-booking-meta">{{gbdata[$index].value}}</div>
                                    </div>
                                </li><?php
                            } else{?>
                                <li>
                                    <div class="ep-guest-booking-info">
                                        <div class="ep-guest-booking-label">
                                            <?php _e('Name: ','eventprime-event-guest-booking'); ?>
                                        </div> 
                                        <div class="ep-guest-booking-meta">{{gbname}}</div>
                                    </div>
                                </li>
                                <li>
                                    <div class="ep-guest-booking-info">
                                        <div class="ep-guest-booking-label">
                                          <?php _e('Email: ','eventprime-event-guest-booking'); ?> 
                                        </div> 
                                        <div class="ep-guest-booking-meta">{{gbemail}}</div>
                                    </div>
                                </li>
                                <li>
                                    <div class="ep-guest-booking-info">
                                        <div class="ep-guest-booking-label">
                                            <?php _e('Phone: ','eventprime-event-guest-booking'); ?> 
                                        </div>
                                        <div class="ep-guest-booking-meta"> {{gbphone}}</div>
                                    </div>
                                    <p></p>
                                </li><?php
                            }?>
                        </ul>
                    </div>
                </div><?php
            }
        }

        public function event_magic_show_gb_fields(){?>
            <div class="em-booking-row" ng-show="data.post.order_info.user_phone">
                <span class="em-booking-label"><?php _e('Booking Phone', 'eventprime-event-guest-booking'); ?>:</span> <span class="em-booking-detail">{{data.post.order_info.user_phone}}</span>
            </div>
            <div class="em-booking-row" ng-show="data.post.order_info.guest_booking == 1">
                <span class="em-booking-label"><?php _e('Booking Type', 'eventprime-event-guest-booking'); ?>:</span> 
                <span class="em-booking-detail"><?php _e('Guest Booking' ,'eventprime-event-guest-booking'); ?> </span>
            </div><?php
        }

        public function guest_booking_show_order_details(){
            $booking_id = absint(event_m_get_param('gbid'));
            $redirect_url = event_m_get_param('redirect_url');
            $booking_service = EventM_Factory::get_service('EventM_Booking_Service');
            $venue_service = EventM_Factory::get_service('EventM_Venue_Service');
            $event_service = EventM_Factory::get_service('EventM_Service');
            $booking = $booking_service->load_model_from_db($booking_id);
            if (empty($booking->id))
                die("No such booking exists");
            
            $event = $event_service->load_model_from_db($booking->event);
            if(!empty($event->venue)){
                $venue = $venue_service->load_model_from_db($event->venue);
                if(empty($venue->id)){
                    $venue = null;
                }
            }
            $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
            $global_settings = $setting_service->load_model_from_db();
            $booking_service = EventM_Factory::get_service('EventM_Booking_Service');
            $total_price = $booking_service->get_final_price($booking->id);         
            $total_price = empty($total_price) ? __('Free','eventprime-event-guest-booking') : em_price_with_position($total_price, $booking->order_info['currency']);
            $offline_status = isset($booking->payment_log['offline_status']) ? $booking->payment_log['offline_status'] : null;
            ?>
            <div class="em_modal_wrapper" id="em_guest_booking_details_modal">
                <div class="em_guest_booking-wrap">
                <div id="em_message_bar">
                <?php if($booking->status=='pending'){
                        _e('**Ticket download link will be available after Confirmation.','eventprime-event-guest-booking');
                    }
                    else if($booking->status=='cancelled'){
                        _e('**Booking cancelled successfully.','eventprime-event-guest-booking');
                    }
                    else if($booking->status=='completed'){
                        _e('Congratulations, your booking has been confirmed!','eventprime-event-guest-booking');
                    }
                    else if($booking->status=='refunded'){
                       _e('**We have issued a refund for this booking.','eventprime-event-guest-booking');
                } ?>
                </div>
                <table class="em_modal_table">
                    <tr>
                        <td><?php _e('Booking ID','eventprime-event-guest-booking'); ?></td>
                        <td><?php echo $booking->id; ?></td>
                    </tr>
                    <tr>
                        <td><?php _e('No. of Attendees','eventprime-event-guest-booking'); ?></td>
                        <td><?php echo $booking->order_info['quantity']; ?></td>
                    </tr>
                    <tr> 
                        <td><?php _e('Attendees','eventprime-event-calendar-management'); ?></td>
                        <td><?php 
                            if(!isset($booking->order_info['is_custom_booking_field']) || $booking->order_info['is_custom_booking_field'] == 0){
                                echo implode(', ', $booking->attendee_names);
                            }
                            else{
                                foreach($booking->attendee_names as $attendees){
                                    echo '<table>';
                                        foreach($attendees as $label => $value){
                                            echo '<tr>';
                                                echo '<td>'.$label.'</td>';
                                                echo '<td>'.$value.'</td>';
                                            echo '</tr>';
                                        }
                                    echo '</table>';
                                }
                            } ?>
                        </td>
                    </tr>
                    <?php
                    if(isset($booking->order_info['coupon_code']) && !empty($booking->order_info['coupon_code']) && isset($booking->order_info['coupon_discount']) && !empty($booking->order_info['coupon_discount'])){?>
                        <tr>
                            <td><?php _e('Price','eventprime-event-guest-booking'); ?></td>
                            <td><?php  echo em_price_with_position($booking->order_info['item_price'], $booking->order_info['currency']); ?></td>
                        </tr>
                        <tr>
                            <td><?php _e('Coupon Amount','eventprime-event-guest-booking'); ?></td>
                            <td><?php  echo em_price_with_position($booking->order_info['coupon_discount'], $booking->order_info['currency']); ?></td>
                            
                        </tr>
                        <tr>
                            <td><?php _e('Total Price','eventprime-event-guest-booking'); ?></td>
                            <td><?php  echo $total_price; ?></td>
                        </tr>
                        <?php
                    }
                    else{?>
                        <tr>
                            <td><?php _e('Total Price','eventprime-event-guest-booking'); ?></td>
                            <td><?php  echo $total_price; ?></td>
                        </tr>
                        <?php
                    }?>
                    <?php if(!empty($venue) && $venue->type=='seats' && $booking->order_info['seat_sequences']>0): ?>
                        <tr> 
                            <td><?php _e('Seats','eventprime-event-guest-booking'); ?></td>
                            <td><?php echo implode(',',$booking->order_info['seat_sequences']); ?></td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td><?php _e('Booking Status','eventprime-event-guest-booking'); ?></td>
                        <td id="em_booking_status"><?php echo EventM_Constants::$status[$booking->status]; ?></td>
                    </tr>
                    <?php do_action('event_magic_front_user_booking_details', $offline_status); ?>
                    <?php if(($booking->status=="completed") && !empty($event->allow_cancellations)): ?>
                        <tr id="em_action_bar">
                            <td><?php _e('Action','eventprime-event-guest-booking'); ?></td>
                            <td><input type="button" id="em_cancelled_btn" value="Cancellation Request " onclick="em_cancel_booking(<?php echo $booking->id; ?>)" /></td>
                        </tr>
                    <?php endif; ?>
                    <?php do_action('event_magic_print_ticket',$booking); ?>
                    <tr>
                        <td colspan="2" align="right">
                            <a href="<?php echo $redirect_url;?>" class="em-guest-booking-next-btn">
                                <button> <?php _e('Next.','eventprime-event-guest-booking');?></button>
                            </a>
                        </td>
                    </tr>
                </table>
                </div>
            </div><?php
            die;
        }

        public function get_custom_form_builder_fields() {
            $gs = EventM_Factory::get_service('EventM_Setting_Service');
            $custom_field_data = array();
            $custom_field_data['text']  = $gs->get_text_field(':em:', 'guest_booking');
            $custom_field_data['email'] = $gs->get_email_field(':em:', 'guest_booking');
            $custom_field_data['tel']   = $gs->get_tel_field(':em:', 'guest_booking');
            $custom_field_data['date']  = $gs->get_date_field(':em:', 'guest_booking');
            wp_send_json_success(array('custom_field_data' => $custom_field_data));
        }

        public function save_default_guest_booking_fields() {
            $custom_guest_booking_field_data = event_m_get_param('custom_guest_booking_field_data');
            $global_settings = get_option( EM_GLOBAL_SETTINGS );
            $global_settings['custom_guest_booking_field_data'] = $custom_guest_booking_field_data;
            update_option( EM_GLOBAL_SETTINGS, $global_settings );
            wp_send_json_success();
        }

        public function event_guest_booking_filter_event_data_for_booking($event) {
            $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
            $global_settings = $setting_service->load_model_from_db();
            if(!empty($global_settings->allow_guest_custom_booking_fields) && isset($global_settings->custom_guest_booking_field_data) && count($global_settings->custom_guest_booking_field_data) > 1){
                $event->custom_guest_booking_field_data = $global_settings->custom_guest_booking_field_data;
            }
            return $event;
        }
        
        public function guest_booking_order_detail_redirect(){
            $page_id = em_global_settings('guest_booking_page_redirect');
            if( isset( $page_id ) && ! empty( $page_id ) ){
                $redirect_url = get_page_link( $page_id );
                ?>
                    <td colspan="2" align="right">
                        <a href="<?php echo $redirect_url;?>" class="em-guest-booking-next-btn">
                            <button> <?php _e('Next','eventprime-event-guest-booking');?></button>
                        </a>
                    </td>
                <?php
            }
        }
    }

}

function em_guest_booking() {
    return EM_Guest_Booking::instance();
}
function em_guest_booking_checks(){ ?>
    <div class="notice notice-success is-dismissible">
         <p><?php _e( 'EventPrime Guest Booking Extension won\'t work as EventPrime plugin is not active/installed.', 'event-magic' ); ?></p>
    </div>
<?php }

add_action('plugins_loaded',function(){if(!class_exists('Event_Magic')){add_action('admin_notices','em_guest_booking_checks');}});
add_action('event_magic_loaded', 'em_guest_booking');
require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_guest_booking_metadata.json',
    __FILE__,
    'eventprime-event-guest-booking'
);