/**
 * 
 * Guest Bookings controller
 */
eventMagicApp.controller('guestBookingsCtrl', function ($scope, $http,EMRequest, $compile) {
    $scope.data = {};
    $scope.requestInProgress= false;
  
    $= jQuery;
    $scope.fieldKey = '';
    $scope.fieldAction = '';
    $scope.guestButtonKey = 1;
    $scope.guestCustomField = '';
    $scope.someGuestValue = false;
   
    $scope.progressStart= function()
    {
        $scope.requestInProgress = true;
    }
    
    $scope.progressStop= function()
    {
        $scope.requestInProgress = false;
    }

    $scope.$on('initilizeSettingChild', function(e) {  
        $scope.data.options = $scope.$parent.data.options;
        if($scope.data.options.custom_guest_booking_field_data && $scope.data.options.custom_guest_booking_field_data.length > 0){
            var existingFields = $scope.data.options.custom_guest_booking_field_data;
            if(existingFields.length > 0){
                EMRequest.send('em_get_custom_form_builder_fields', $scope.data.options).then(function(response){
                    var responseBody = response.data;
                    $scope.data.options.custom_guest_field_data = responseBody.data.custom_field_data;
                    $scope.prepareGuestFieldData(existingFields);
                });
            }
        }else{
            EMRequest.send('em_get_custom_form_builder_fields', $scope.data.options).then(function(response){
                var responseBody = response.data;
                $scope.data.options.custom_guest_booking_field_data = [];
                $scope.data.options.custom_guest_field_data = responseBody.data.custom_field_data;
                $scope.defaultGuestFields = 1;
                $scope.addGuestFieldInCustomizer('text');
                setTimeout(function(){
                    angular.element(document.querySelector('#email-field')).triggerHandler('click');
                    setTimeout(function(){
                        angular.element(document.querySelector('#tel-field')).triggerHandler('click');
                        $scope.defaultGuestFields = 0;

                        $scope.setFieldValidation();
                        EMRequest.send('em_save_default_guest_booking_fields', $scope.data.options).then(function(response){
                            var responseBody = response.data;
                        });
                    }, 500);
                }, 500);
            });
        }
    });

    $scope.setFieldValidation = function(){
        for(let i = 1; i < 4; i++){
            angular.element("#guest_booking_required"+i).attr('disabled', 'disabled');
            angular.element("#guest_booking_required"+i).attr('readonly', 'true');
            angular.element("#em_guest_booking_remove"+i).css('display', 'none');
            if(i == 3){
                angular.element("#guest_booking_required"+i).removeAttr('disabled');
                angular.element("#guest_booking_required"+i).attr('readonly', 'false');
            }
        }
    }
   
    $scope.addGuestFieldInCustomizer = function(key) {
        let newField = $scope.data.options.custom_guest_field_data[key];
        let keyReplace = newField.replace(/:em:/g, $scope.guestButtonKey);
        $scope.guestCustomField += keyReplace;
        $scope.fieldKey = key;
        $scope.someGuestValue = true;
        $scope.fieldAction = 'add';
    }

    $scope.removeFieldFromCustomizer = function(key) {
        if(key > 3){
            $scope.fieldAction = 'remove';
            if($scope.data.options.custom_guest_booking_field_data[key]){
                $scope.data.options.custom_guest_booking_field_data[key].required = 0;
                $scope.data.options.custom_guest_booking_field_data[key].label = '';            
            }
            var sp = $scope.guestCustomField.split('<li');
            sp.splice(key, 1);
            $scope.data.options.custom_guest_booking_field_data.splice(key, 1);
            var keyReplace = '';
            var j = 1;
            for(var i = 0; i < sp.length; i++){
                var splc = sp[i].split(' data-keyval="');
                if(splc[1]){
                    var rsplc = splc[1].split('">');
                    var spsdata = sp[i].replaceAll(rsplc[0], j);
                    sp[i] = spsdata;
                    j++;
                }
            }
            $scope.guestButtonKey = j;
            $scope.guestCustomField = '';
            $scope.someGuestValue = true;
            var jo = sp.join('<li');
            $scope.guestCustomField = jo;
            $scope.someGuestValue = true;

            if($scope.data.options.custom_guest_booking_field_data.length == 1){
                $scope.data.options.custom_guest_booking_field_data = [];
            }
        }
    }

    $scope.prepareGuestFieldData = function(existingFields) {
        let totalFields = 0;
        existingFields.forEach(function(item, key){
            if(item){
                let newField = $scope.data.options.custom_guest_field_data[item.type];
                let keyReplace = newField.replace(/:em:/g, key);
                $scope.guestCustomField += keyReplace;
                $scope.fieldKey = item.type;
                $scope.data.options.custom_guest_booking_field_data[key] = item;
                totalFields++;
            }
        });
        $scope.guestButtonKey = totalFields;
        $scope.someGuestValue = true;
        $scope.fieldAction = 'edit';
        setTimeout(function(){
            $scope.setFieldValidation();
        }, 5000);
    }

})
.directive("guestCustomField", function($compile) {
    return { 
        scope: true,
        link: function($scope, element, attrs, ngModel) {
            $scope.$watch('someGuestValue', function (val) {
                if (val) {
                    $(element).html($scope.$parent.guestCustomField).show();
                    $compile($('.em_custom_guest_booking_field_html'))($scope);
                    if($scope.$parent.fieldAction == 'add'){
                        if(!$scope.$parent.data.options.custom_guest_booking_field_data[$scope.$parent.guestButtonKey]){
                            if($scope.defaultGuestFields == 1){
                                if($scope.$parent.fieldKey == 'text'){
                                    $scope.$parent.data.options.custom_guest_booking_field_data[$scope.$parent.guestButtonKey] = {required: 1, type: $scope.$parent.fieldKey, label: 'Your Name', default: 1, fieldNo: $scope.$parent.guestButtonKey};
                                }
                                if($scope.$parent.fieldKey == 'email'){
                                    $scope.$parent.data.options.custom_guest_booking_field_data[$scope.$parent.guestButtonKey] = {required: 1, type: $scope.$parent.fieldKey, label: 'Your Email', default: 1, fieldNo: $scope.$parent.guestButtonKey};
                                }
                                if($scope.$parent.fieldKey == 'tel'){
                                    $scope.$parent.data.options.custom_guest_booking_field_data[$scope.$parent.guestButtonKey] = {required: 1, type: $scope.$parent.fieldKey, label: 'Your Phone', default: 1, fieldNo: $scope.$parent.guestButtonKey};
                                }
                            } else{
                                $scope.$parent.data.options.custom_guest_booking_field_data[$scope.$parent.guestButtonKey] = {required: 0, type: $scope.$parent.fieldKey, label: '', default: 0, fieldNo: $scope.$parent.guestButtonKey};
                            }
                        }
                        $scope.$parent.guestButtonKey++;
                    }
                    if($scope.$parent.fieldAction == 'edit'){
                        $scope.$parent.guestButtonKey++;
                    }
                    $scope.$parent.someGuestValue = false;
                    $scope.$parent.setFieldValidation();
                }
            });
        },
    }
});