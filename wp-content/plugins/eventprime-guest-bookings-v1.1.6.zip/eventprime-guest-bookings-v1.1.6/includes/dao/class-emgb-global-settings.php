<?php
if (!defined( 'ABSPATH')){
    exit; // Exit if accessed directly
}

class EventMGB_Global_Settings_DAO 
{ 
    public function get() { 
        $options= get_option(EM_GLOBAL_SETTINGS);
        $settings= new EventMGB_Global_Settings_Model();
        foreach ($options as $key=>$val) {
            $key= str_replace('em_','',$key);
            if (property_exists($settings, $key)) {
               $settings->{$key}= maybe_unserialize($val);
            }
        }
        $settings= apply_filters('event_magic_gsgb_get_model',$settings,$options);
        return $settings;
    }
}
