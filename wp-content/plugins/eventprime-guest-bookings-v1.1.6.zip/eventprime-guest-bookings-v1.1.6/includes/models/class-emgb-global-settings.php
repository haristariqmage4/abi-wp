<?php

class EventMGB_Global_Settings_Model extends EventM_Global_Settings_Model
{
  public $allow_guest_bookings;
  public $auto_create_guest_account;
  public $guest_booking_page_redirect;
  public $allow_guest_custom_booking_fields;
  public $custom_guest_booking_field_data = array();
}

