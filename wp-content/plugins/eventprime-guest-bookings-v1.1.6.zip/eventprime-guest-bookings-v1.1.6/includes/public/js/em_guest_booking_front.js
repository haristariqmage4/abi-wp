/**
 * 
 * Guest Bookings Front controller
 */
eventMagicApp.controller('guestBookingsFrontCtrl', function ($scope, $http,EMRequest, $compile) {
    $scope.data = {};
    $scope.requestInProgress = false;
    $ = jQuery;

    $scope.progressStart = function() {
        $scope.requestInProgress = true;
    }
    
    $scope.progressStop = function() {
        $scope.requestInProgress = false;
    }

    $scope.$on('initilizeBookingChild', function(e) {  
        $scope.event = $scope.$parent.event;
        setTimeout(function(){
            jQuery(".em-gbf-datepicker").datepicker({
                changeMonth: true,
                changeYear: true
            });
        }, 1000);
    });

    $scope.gbInitialize = function() {
    }

});
eventMagicApp.filter('capitalize', function() {
    return function(input) {
      return (angular.isString(input) && input.length > 0) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : input;
    }
});