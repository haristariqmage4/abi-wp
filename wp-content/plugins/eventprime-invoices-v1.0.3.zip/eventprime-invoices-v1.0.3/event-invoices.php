<?php
/**
 * Plugin Name: EventPrime Invoices
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that generate and send PDF Invoices after order. It allows fully customizable PDF invoices, complete with your company branding, to be generated and emailed with booking details to your users.
 * Version: 1.0.3
 * Author: EventPrime
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 6.1.1
 * Text Domain: eventprime-event-invoices
 * Domain Path: /languages
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_Event_Invoices')) {
    final class EM_Event_Invoices {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.0.3';

        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;
        
        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        /**
         * Cloning is forbidden.
         */
        public function __clone() {
            _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'event_magic'), $this->version);
        }

        /**
         * Unserializing instances of this class is forbidden.
         */
        public function __wakeup() {
            _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'event_magic'), $this->version);
        }

        /**
         * Event_Magic Constructor.
         */
        public function __construct() { 
            $this->define_constants();
            $this->load_textdomain();
            $this->includes();
            $this->define_hooks();
            $em = event_magic_instance();
            array_push($em->extensions,'event_invoices');
        }

        public function define_constants(){
            event_magic_instance()->define('EMEI_BASE_URL', plugin_dir_url(__FILE__));
            define('EMEI_VERSION', $this->version);
        }        

        public function includes(){
            include_once( 'includes/models/class-emei-global-settings.php' );
            include_once( 'includes/dao/class-emei-global-settings.php' );
            if (!class_exists('TCPDF')){
                require_once EM_BASE_DIR . 'includes/lib/tcpdf_min/tcpdf.php';
            }
            include_once( 'includes/services/class-invoice.php' );
            include_once( 'includes/services/class-eppdf.php' );
        }

        public function define_hooks(){
            add_action( 'event_magic_gs_settings', array( $this, 'event_invoices_gs_section_setting') );
            add_action( 'event_magic_gs_popup', array( $this, 'event_invoices_gs_settings_form' ) );
            add_action( 'em_after_gs_save', array( $this, 'event_invoices_gs_settings_save' ) );
            add_filter( 'em_load_gs_ext_options', array( $this, 'event_invoices_load_gs_ext_options' ), 99, 1 );
            add_filter( 'event_magic_gs_get_model', array( $this, 'event_invoices_load_gs_ext_options' ), 99, 1 );
            add_action( 'em_after_gs_save', array( $this, 'event_invoices_gs_settings_save' ) );
            add_action( 'event_magic_print_ticket', array( $this, 'event_invoices_print_ticket' ) );
            add_action( 'event_magic_print_ticket_btn', array( $this, 'event_invoices_booking_print_ticket' ) );
            add_action( 'wp_ajax_event_invoices_front_print_invoice', array( $this, 'event_invoices_front_print_invoice' ) );
            add_action( 'wp_ajax_nopriv_event_invoices_front_print_invoice', array( $this, 'event_invoices_front_print_invoice' ) );
            add_filter( 'event_magic_booking_confirmed_notification_attachments', array( $this, 'event_invoices_booking_confirmed_notification_attachments' ), 99, 2 );
            add_action( 'wp_ajax_em_ei_upload_custom_attachment', array( $this, 'event_invoices_upload_custom_attachment' ) );
        }       

        public function load_textdomain(){
            load_plugin_textdomain('eventprime-event-invoices', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        public function event_invoices_gs_section_setting() {?>
            <a href="javascript:void(0)" class="ep-extension-with-gs" ng-click="enableGlobalService('showGlobalInvoiceService')">
                <div class="em-settings-box">
                    <img class="em-settings-icon" ng-src="<?php echo EMEI_BASE_URL; ?>includes/admin/template/images/ep-invoice-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Invoices', 'eventprime-event-invoices'); ?></div>
                    <span><?php _e('Generate and send PDF invoices.', 'eventprime-event-invoices'); ?></span>
                </div>
            </a><?php
        }

        public function event_invoices_gs_settings_form() {
            wp_enqueue_script( 'em-event-invoices-admin-js', EMEI_BASE_URL . 'includes/admin/js/em_admin_event_invoices.js', false, EMEI_VERSION );
            wp_localize_script( 'em-event-invoices-admin-js', 'em_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );?>
            <div ng-show="showGlobalInvoiceService">
                <div ng-controller="eventInvoicesCtrl">
                    <div class="emrow">
                        <div class="emfield"><?php _e('Use Invoices', 'eventprime-event-invoices'); ?></div>
                        <div class="eminput">
                            <input type="checkbox" ng-true-value="1" ng-fale-value="0" name="allow_event_invoices"  ng-model="data.options.allow_event_invoices">
                            <div class="emfield_error"></div>
                        </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php _e('Turn on invoicing feature for event bookings.', 'eventprime-event-invoices'); ?>
                        </div>
                    </div>
                    <div ng-show="showGlobalInvoiceService && data.options.allow_event_invoices == 1">
                        <div class="emrow">
                            <div class="emfield"><?php _e('Company Name', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input type="text" name="ei_company_name" ng-model="data.options.ei_company_name">
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Enter Company Name.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>
                        <div class="emrow">
                            <div class="emfield"><?php _e('Company Email', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input type="email" name="ei_company_email" ng-model="data.options.ei_company_email" ng-pattern="/^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/">
                                <div class="emfield_error">
                                    <span ng-show="optionForm.ei_company_email.$error.pattern && optionForm.ei_company_email.$dirty"><?php _e('Invalid Email.','eventprime-event-invoices'); ?></span>
                                </div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Enter Company Email.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>
                        <div class="emrow">
                            <div class="emfield"><?php _e('Company Phone', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input type="tel" name="ei_company_phone" ng-model="data.options.ei_company_phone" ng-pattern="/^(\+?(\d{1}|\d{2}|\d{3})[- ]?)?\d{3}[- ]?\d{3}[- ]?\d{4}$/">
                                <div class="emfield_error">
                                    <span ng-show="optionForm.ei_company_phone.$error.pattern && optionForm.ei_company_phone.$dirty"><?php _e('Invalid Phone Number.','eventprime-event-invoices'); ?></span>
                                </div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Enter Company Phone.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>
                        <div class="emrow">
                            <div class="emfield"><?php _e('VAT Number', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input type="text" name="ei_company_vat" ng-model="data.options.ei_company_vat">
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Enter VAT Number.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>
                        <div class="emrow">
                            <div class="emfield"><?php _e('Company Logo', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input type="button" ng-click="mediaUploader(false, 'ei_company_logo')" class="button kf-upload" value="<?php _e('Upload','eventprime-event-invoices'); ?>" />
                                <div class="em_cover_image ep-company-logo ep-invoice-pdf-logo">
                                    <img ng-src="{{data.options.ei_company_logo_url}}" />
                                </div>
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Select Company Logo.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>
                        <div class="emrow" ng-show="data.options.ei_company_logo_width">
                            <div class="emfield"><?php _e('Logo Width (in px)', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input type="text" name="ei_company_logo_width" ng-model="data.options.ei_company_logo_width">
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Please adjust logo width if it appears too large or too small on invoice PDF. If you are just setting up, anything between 200px to 400px can be a good place to start.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>
                        <div class="emrow">
                            <div class="emfield"><?php _e('Company Address', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <textarea name="ei_company_address" ng-model="data.options.ei_company_address" ></textarea>
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Enter Company Address.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>
                        <div class="emrow">
                            <div class="emfield"><?php _e('Custom Note', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <textarea name="ei_description" ng-model="data.options.ei_description"></textarea>
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Anything you wish to mention in the invoice apart from regular fields.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>
                        <div class="emrow">
                            <div class="emfield"><?php _e('Footer', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input type="checkbox" ng-true-value="1" ng-fale-value="0" name="ei_enable_event_invoice_footer" ng-model="data.options.ei_enable_event_invoice_footer" ng-click="enable_invoice_footer()">
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Add a footer area to your invoice PDF.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>
                        <div class="emrow" ng-show="data.options.ei_enable_event_invoice_footer == 1">
                            <div class="emfield"></div>
                            <div class="eminput">
                                <div class="eminput emeditor">
                                    <?php
                                    $content = '';
                                    $settings = array(
                                        'wpautop' => true,
                                        'media_buttons' => false,
                                        'textarea_name' => 'description',
                                        'textarea_rows' => 20,
                                        'tabindex' => '',
                                        'tabfocus_elements' => ':prev,:next', 
                                        'editor_css' => '', 
                                        'editor_class' => '',
                                        'teeny' => false,
                                        'dfw' => false,
                                        'tinymce' => true,
                                        'quicktags' => true
                                    );
                                    wp_editor($content, 'ei_footer_invoice_secion', $settings);
                                    ?>
                                    <div class="emfield_error"></div>
                                </div>
                            </div>
                        </div>

                        <div class="emrow">
                            <div class="emfield"><?php _e('Left Margin (in px)', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input type="number" name="ei_invoice_left_margin" ng-model="data.options.ei_invoice_left_margin">
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Set PDF Left Margin.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>

                        <div class="emrow">
                            <div class="emfield"><?php _e('Top Margin (in px)', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input type="number" name="ei_invoice_top_margin" ng-model="data.options.ei_invoice_top_margin">
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Set PDF Top Margin.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>

                        <div class="emrow">
                            <div class="emfield"><?php _e('Right Margin (in px)', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input type="number" name="ei_invoice_right_margin" ng-model="data.options.ei_invoice_right_margin">
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Set PDF Right Margin.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>
                        
                        <div class="emrow">
                            <div class="emfield"><?php _e('Page Break Margin (in px)', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input type="number" name="ei_page_break_margin" ng-model="data.options.ei_page_break_margin">
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Set PDF Page Break Margin.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>

                        <div class="emrow">
                            <div class="emfield"><?php _e('Custom Attachment', 'eventprime-event-invoices'); ?></div>
                            <div class="eminput">
                                <input class="ep-ei-attachment-file" type="file" invoice-file-input="files" name="ei_custom_attachment_file" accept="application/pdf">
                                <input type="hidden" name="ei_custom_attachment" ng-model="data.options.ei_custom_attachment">
                                <br/>
                                <div ng-show="data.options.ei_custom_attachment_name" class="ep-ei-invoice-pdf-section">
                                    {{data.options.ei_custom_attachment_name}}
                                    <span class="ep-ei-remove-image" ng-click="removeCustomAttachment()" style="color:blue; cursor: pointer;"> - Remove</span>
                                </div>
                                <div class="emfield_error"></div>
                            </div>
                            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                <?php _e('Attach an additional file to the booking confirmation email along with the invoice (for e.g. Terms and Conditions). Only PDF files allowed.', 'eventprime-event-invoices'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div><?php
        }

        public function event_invoices_gs_settings_save(){
            $request  = EventM_Raw_Request::get_instance();
            $service  =  EventM_Factory::get_service( 'EventM_Setting_Service' );
            $model    = $request->map_request_to_model( 'EventMEI_Global_Settings_Model' );
            $template = $service->save( $model );
        }

        public function event_invoices_load_gs_ext_options($options) {
            $emeidao = new EventMEI_Global_Settings_DAO();
            $emeimmodel = $emeidao->get();
            $options->allow_event_invoices           = absint($emeimmodel->allow_event_invoices);
            $options->ei_company_name                = $emeimmodel->ei_company_name;
            $options->ei_company_email               = $emeimmodel->ei_company_email;
            $options->ei_company_phone               = $emeimmodel->ei_company_phone;
            $options->ei_company_vat                 = $emeimmodel->ei_company_vat;
            $options->ei_company_logo                = $emeimmodel->ei_company_logo;
            $options->ei_company_address             = $emeimmodel->ei_company_address;
            $options->ei_description                 = $emeimmodel->ei_description;
            $options->ei_company_logo_url            = $this->get_image( $emeimmodel->ei_company_logo );
            $options->ei_enable_event_invoice_footer = absint($emeimmodel->allow_event_invoices);
            $options->ei_footer_invoice_secion       = $emeimmodel->ei_footer_invoice_secion;
            $options->ei_invoice_left_margin         = $emeimmodel->ei_invoice_left_margin;
            $options->ei_invoice_top_margin          = $emeimmodel->ei_invoice_top_margin;
            $options->ei_invoice_right_margin        = $emeimmodel->ei_invoice_right_margin;
            $options->ei_page_break_margin           = $emeimmodel->ei_page_break_margin;
            $options->ei_company_logo_width          = $emeimmodel->ei_company_logo_width;
            $options->ei_custom_attachment           = $emeimmodel->ei_custom_attachment;
            $options->ei_custom_attachment_name      = ( ! empty( $emeimmodel->ei_custom_attachment ) ) ? basename( get_attached_file( $emeimmodel->ei_custom_attachment ) ) : '';
            if(isset($options->load_extension_services)){
                $options->load_extension_services[]  = 'showGlobalInvoiceService';
            }
            return $options;
        }


        public function get_image($id, $size = 'full') {
            $img = wp_get_attachment_image_src($id, $size);
            if (!empty($img))
                return $img[0];
            return null;
        }

        public function event_invoices_print_ticket($booking){
            $allow_event_invoices = em_global_settings('allow_event_invoices');
            if(!empty($allow_event_invoices)){?>
                <tr id="em_print_bar">
                    <?php 
                    if($booking->status == 'completed'){?>
                        <td>
                            <a href="<?php echo admin_url('admin-ajax.php?action=event_invoices_front_print_invoice&id='.$booking->id) ?>"><?php _e('Print Invoice','eventprime-event-invoices'); ?></a>
                        </td><?php 
                    } ?>
                </tr><?php
            }
        }        

        public function event_invoices_front_print_invoice(){
            $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
            $gs = $setting_service->load_model_from_db();
            $allow_event_invoices = $gs->allow_event_invoices;
            if ( empty( $allow_event_invoices ) ) {
                die(__( 'Invoice not enabled.', 'eventprime-event-invoices' ) );
            }
            $booking_id = event_m_get_param( 'id' );
            $bs = EventM_Factory::get_service( 'EventM_Booking_Service' );
            $booking = $bs->load_model_from_db( $booking_id );
            if ( empty( $booking->id ) ) {
                die(__( 'Booking does not exist.', 'eventprime-event-invoices' ) );
            }
            // Check if booking belongs to current user
            $user = wp_get_current_user();
            if ( !current_user_can( 'manage_options' ) ) {
                if(empty($user->ID) && !em_show_book_now_for_guest_users()){
                    die(__('You are not authorized to access the resource','eventprime-event-invoices'));
                }
                if($booking->user != $user->ID && !em_show_book_now_for_guest_users()){
                    die(__('You are not allowed to access the resource','eventprime-event-invoices'));
                }
            }
            
            $es = EventM_Factory::get_service('EventM_Service');
            $event = $es->load_model_from_db($booking->event);
            
            $html = EventM_Invoice_Service::get_invoice_data( $booking );
            $args = array('name' => 'Invoice-'.$booking->id);
            $args['title'] = esc_html__( 'Invoice', 'eventprime-event-invoices' );
            
            EventM_Invoice_Service::print_invoice($html, $args);
            
            exit();
        }

        public function event_invoices_booking_confirmed_notification_attachments( $attachments, $booking ) {
            $allow_event_invoices = em_global_settings('allow_event_invoices');
            if( ! empty( $allow_event_invoices ) ) {
                $invoice_no = 'Invoice-' . $booking->id;
                $path = plugin_dir_path( __DIR__ ) . 'invoices/';
                if ( !file_exists( $path ) ) {
                    mkdir($path, 0777, true);
                }
                $invoice_file = plugin_dir_path( __DIR__ ) . 'invoices/' . $invoice_no . '.pdf';
                if ( file_exists( $invoice_file ) ) {
                    $attachments[] = $invoice_file;
                } else{
                    $bs = EventM_Factory::get_service( 'EventM_Booking_Service' );
                    $booking = $bs->load_model_from_db( $booking->id );
                    $html = EventM_Invoice_Service::get_invoice_data( $booking );
                    $args = array('name' => 'Invoice-'.$booking->id);
                    $args['title'] = esc_html__( 'Invoice', 'eventprime-event-invoices' );
                    
                    $invoice_file = EventM_Invoice_Service::save_invoice($html, $args);
                    if ( file_exists( $invoice_file ) ) {
                        $attachments[] = $invoice_file;
                    }
                }
                $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
                $gs = $setting_service->load_model_from_db();
                if( ! empty( $gs->ei_custom_attachment ) ) {
                    $attachment_id = $gs->ei_custom_attachment;
                    $attachment_url = get_attached_file( $attachment_id );
                    if ( file_exists( $attachment_url ) ) {
                        $attachments[] = $attachment_url;
                    }
                }
            }
            return $attachments;
        }

        public function event_invoices_upload_custom_attachment() {
            if(isset($_FILES["ei_attachment"]) && !empty($_FILES["ei_attachment"])){
                $extension = pathinfo($_FILES["ei_attachment"]["name"], PATHINFO_EXTENSION);
                if($extension != 'pdf'){
                    wp_send_json_error( array( 'errors' => array( 'Only PDF File Allowed.' ) ) );
                }
                $file = $_FILES['ei_attachment'];
                $filename = $file['name'];
                $tmp_name = $file['tmp_name'];
                $upload_dir = wp_upload_dir();
                $uploaded_file = array();
                if (move_uploaded_file($file["tmp_name"], $upload_dir['path'] . "/" . $filename)) {
                    $uploaded_file['file_name'] = $filename;
                    $uploaded_file['upload_url'] = $upload_dir['url'] . "/" . $filename;
    
                    $wp_filetype = wp_check_filetype($filename, null );
                    $attachment = array(
                        'guid'           => $uploaded_file['upload_url'],
                        'post_mime_type' => $wp_filetype['type'],
                        'post_title'     => preg_replace( '/\.[^.]+$/', '', $filename ),
                        'post_content'   => '',
                        'post_status'    => 'inherit'
                    );
                    $attachment_id = wp_insert_attachment( $attachment, $upload_dir['path'] . "/" . $filename );
         
                    if ( ! is_wp_error( $attachment_id ) ) {
                        require_once(ABSPATH . "wp-admin" . '/includes/image.php');
                        $attachment_data = wp_generate_attachment_metadata( $attachment_id, $uploaded_file['upload_url'] );
                        wp_update_attachment_metadata( $attachment_id,  $attachment_data );
                        wp_send_json_success(array('attachment_id' => $attachment_id));
                    }
                }
                else{
                    wp_send_json_error(array('errors'=>array($upload_file['error'])));
                }
            }
        }

        public function event_invoices_booking_print_ticket(){
            $allow_event_invoices = em_global_settings('allow_event_invoices');
            if(!empty($allow_event_invoices)){?>
                <tr id="em_print_bar">
                    <td>
                        <a href="<?php echo admin_url('admin-ajax.php?action=event_invoices_front_print_invoice&id=') ?>{{data.post.id}}"><?php _e('Print Invoice','eventprime-event-invoices'); ?>&nbsp;&nbsp;</a>
                    </td>
                </tr><?php
            }
        }
    }
}

function em_event_invoices() {
    return EM_Event_Invoices::instance();
}

function em_event_invoices_checks(){ ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e( 'EventPrime Event Invoices extension won\'t work as EventPrime plugin is not active/installed', 'event-magic' ); ?></p>
    </div>
<?php }

add_action('plugins_loaded',function(){if(!class_exists('Event_Magic')){add_action('admin_notices','em_event_invoices_checks');}});
add_action('event_magic_loaded', 'em_event_invoices');

require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_invoices_metadata.json',
    __FILE__,
    'eventprime-invoices'
);