/**
 * 
 * Guest Bookings controller
 */
eventMagicApp.controller('eventInvoicesCtrl', function ($scope, $http, EMRequest, $compile) {
    $ = jQuery;
    $scope.data = {};
    $scope.requestInProgress = false;
   
    $scope.progressStart= function() {
        $scope.requestInProgress = true;
    }
    
    $scope.progressStop= function() {
        $scope.requestInProgress = false;
    }

    $scope.$on('initilizeSettingChild', function(e) {  
        $scope.data.options = $scope.$parent.data.options;
        tinymce.get('ei_footer_invoice_secion').setContent($scope.data.options.ei_footer_invoice_secion);
        /*if(!$scope.data.options.footer_invoice_secion) {
            $scope.data.options.footer_invoice_secion = [];
        }*/
        //console.log($scope.data.options);
    });

    /*$scope.enable_invoice_footer = function() {
        if($scope.data.options.ei_enable_event_invoice_footer == 1){
            if($scope.data.options.footer_invoice_secion.length == 0){
                $scope.addInvoiceSection();
            }
        }
    }
    $scope.addInvoiceSection = function() {
        if(!$scope.data.options.footer_invoice_secion || $scope.data.options.footer_invoice_secion.length < 4){
            var footLen = $scope.data.options.footer_invoice_secion.length;
            $scope.data.options.footer_invoice_secion.push({
                'ei_footer_blocks'+footLen : ''
            });
        } else{
            console.log("Max 4");
        }
    }
    $scope.removeInvoiceSection = function (index) {
        $scope.data.options.footer_invoice_secion.splice(index, 1);
        if($scope.data.options.footer_invoice_secion == 0){
            $scope.data.options.ei_enable_event_invoice_footer = 0;
        }
    };*/

    $scope.removeCustomAttachment = function(){
        $scope.data.options.ei_custom_attachment = '';
        $scope.data.options.ei_custom_attachment_name = '';
    }
})
.directive("invoiceFileInput", ['$http', '$parse', function($http, $parse){  
    return{  
        link: function($scope, element, attrs){  
            element.on("change", function(event){
                var files = event.target.files;
                var fileType = files[0].type;
                var allowedFileType = ['application/pdf'];
                if(allowedFileType.indexOf(fileType) > -1){
                    $scope.$parent.progressStart();
                    var ajUrl = em_ajax_object.ajax_url + "?action=em_ei_upload_custom_attachment";
                    $scope.form = [];
                    $scope.form.ei_attachment = element[0].files[0];
                    $http({
                        method  : 'POST',
                        url     : ajUrl,
                        processData: false,
                        transformRequest: function (data) {
                            var formData = new FormData();
                            formData.append("ei_attachment", $scope.form.ei_attachment);  
                            return formData;  
                        },  
                        data : $scope.form,
                        headers: {
                            'Content-Type': undefined
                        }
                    }).success(function(response){
                        $scope.$parent.progressStop();
                        $scope.data.options.ei_custom_attachment = response.data.attachment_id;
                        var reader = new FileReader();
                        reader.onload = function (event) {
                            /*$scope.PreviewInvoiceImage = files[0].name;
                            $scope.$apply();*/
                        };
                        reader.readAsDataURL(event.target.files[0]);
                    });
                }
                else{
                    alert("Only PDF File Allowed");
                    $scope.PreviewInvoiceImage = null;
                    angular.element("input[type='file']").val(null);
                    $scope.$parent.progressStop();
                }
            });  
        }  
    }
}]);