<?php

class EventMEI_Global_Settings_Model extends EventM_Global_Settings_Model
{
  public $allow_event_invoices;
  public $ei_company_name;
  public $ei_company_email;
  public $ei_company_phone;
  public $ei_company_vat;
  public $ei_company_logo;
  public $ei_company_address;
  public $ei_description;
  public $ei_enable_event_invoice_footer;
  public $ei_footer_invoice_secion;
  public $ei_invoice_left_margin = 5;
  public $ei_invoice_top_margin = 5;
  public $ei_invoice_right_margin = 5;
  public $ei_custom_attachment;
  public $ei_company_logo_width;
  public $ei_page_break_margin = 5;
}