<style type="text/css">
    .ep-invoice-table-main td{line-height: 25px;}
    .ei-booking-details-header-row {line-height: 20px;}
    .ep-ei-mid-td{ padding: 15px 10px; }
    .ep-ei-booking-item-th{ padding: 50px 10px; border-bottom: 2px solid #e7e8e9; }
    /*.ep-booking-item .ep-ei-booking-item-td{ padding: 0px 0px 10px 0px;  border-bottom: 1px solid #e7e8e9;line-height: 20px; }*/
    .ep-booking-item {}
     .ep-ei-booking-item-td { border-bottom: 1px solid #e7e8e9; vertical-align: text-top; line-height: 18px;}
    .ep-ei-booking-attendees-wrap{ 
        border: 1px solid #e7e8e9;
        background-color: #fcfcfc; 
        box-shadow: 0 1px 9px -8px #4d5358; 
        margin-right: 10px; 
        padding-top: 10px;
    }
    
    table.ep-ei-mid-table { box-sizing: border-box;box-shadow: 0 1px 9px -8px #4d5358;border: 1px solid #e7e8e9;padding-bottom: 10px}
    table.ep-ei-mid-table td, th { paddingt: 10px 10px; min-width: 170px; text-align: left; }
    table.ep-ei-mid-table tr { display: block;  }
    
    .ep_ei_header_left > div {
        font-size: 14px;
        font-weight: bold;
        color:#000;
    }
    
    table.ep-company-invoice-info td {
        white-space:nowrap;
        text-align:left;
        padding-left: 20px;
    }
    
    table.ep-booking-items-table th {
        font-weight: bold;
        font-size: 14px;

    }
    
    table.ep-booking-items-table .ep-ei-booking-item-th {
        line-height: 20px;
    }

    
    .ep-booking-totsl-t { padding: 5px 0 10px; border-bottom: 1px solid #e7e8e9; line-height: 30px;}
    .ep-booking-total-p {padding: 5px 0 10px; border-bottom: 1px solid #e7e8e9; line-height: 30px;}

</style>

<table border="0" cellpadding="0" cellspacing="0" width="100%" class="ep-ei-invoice-table">
    <tr>
        <td>
            <!-- Invoice logo-->
            <table  border="0" cellpadding="0" cellspacing="0" width="100%" class="ep-logo-table" style="border-collapse: collapse;table-layout: fixed;">
                <tr>
                    <td>
                        <div class="ep-invoice-company-logo" style="height: auto; margin: 0 0 0px; width: 100%; margin: 0px; padding: 0px">
                            <span class="ep-invoice-logo">
                               <img src="<?php echo $data['ei_company_logo_url']; ?>" alt="Company Logo" style="border: 0; line-height: 100%; outline: 0; -ms-interpolation-mode: bicubic; display: block; font-size: 14px; width: <?php echo esc_attr($data['ei_company_logo_width']);?>px;height:auto; margin: 0px; padding: 0px" />
                            </span>
                        </div>         
                    </td>
                </tr>
            </table> 
            <br/>
            <br/>
            <br/>
            <!-- Invoice logo End-->
            <!-- Company Invoice Information--> 
            <table border="0" cellpadding="0" cellspacing="0" width="100%" >
                <tr>
                    <td width="40%">
                        <?php if( isset( $data['ei_company_name'] ) && ! empty( $data['ei_company_name'] ) ) {?>
                            <h3 style="color: #000; font-size: 24px; font-weight: bold; line-height: 10px; margin: 0px 0 15px;"><?php echo $data['ei_company_name']; ?></h3><?php
                        }
                        if( isset( $data['ei_company_name'] ) && ! empty( $data['ei_company_name'] ) ) {?>
                            <p style="color: #75787b;  font-size: 12px; font-weight: 400; line-height: 16px; margin: 0 0 5px;"><?php echo $data['ei_description']; ?></p><?php
                        }?>
                    </td>  
                    
                    <td width="60%">
                        <table border="0" width="100%" style="width:100%;border-collapse: collapse;table-layout: fixed;" class="ep-company-invoice-info">
                            <?php if( isset( $data['ei_company_email'] ) && ! empty( $data['ei_company_email'] ) ) {?>
                                <tr>
                                    <td class="ep_ei_header_left" width="25%">
                                        <div class="ep-company-email" style="margin:0px; padding: 0px; line-height: 10px"><strong><?php esc_html_e('E-mail:', 'eventprime-event-invoices'); ?></strong></div>
                                    </td>
                                    <td class="ep_ei_header_right" width="75%" style="text-align:left;white-space:nowrap;">
                                        <div class="ep-company-email" style="margin:0px; padding: 0px; line-height: 10px"><?php echo esc_html($data['ei_company_email']); ?></div>
                                    </td>
                                </tr><?php
                            }
                            if( isset($data['ei_company_address'] ) && ! empty( $data['ei_company_address'] ) ) {?>
                                <tr>
                                    <td class="ep_ei_header_left" width="25%">
                                        <div class="ep-company-address" style="margin:0px; padding: 0px; line-height: 10px"><strong><?php esc_html_e('Address:', 'eventprime-event-invoices'); ?></strong></div>
                                    </td>
                                    <td class="ep_ei_header_right" width="75%" style="text-align:left;white-space:nowrap;">
                                        <div class="ep-company-address" style="margin:0px; padding: 0px; line-height: 12px"><?php echo esc_html($data['ei_company_address']); ?></div>
                                    </td>
                                </tr><?php
                            }
                            if( isset($data['ei_company_phone'] ) && ! empty( $data['ei_company_phone'] ) ) {?>
                                <tr>
                                    <td class="ep_ei_header_left" width="25%" >
                                        <div class="ep-company-phone" style="margin:0px; padding: 0px; line-height: 10px"><strong><?php esc_html_e('Phone:', 'eventprime-event-invoices'); ?></strong></div>
                                    </td>
                                    <td class="ep_ei_header_right" width="75%" style="text-align:left;white-space:nowrap;">
                                        <div class="ep-company-phone" style="margin:0px; padding: 0px; line-height: 10px"><?php echo esc_html($data['ei_company_phone']); ?></div>
                                    </td>
                                </tr><?php
                            }
                            if( isset($data['ei_company_vat'] ) && ! empty( $data['ei_company_vat'] ) ) {?>
                                <tr>
                                    <td class="ep_ei_header_left" width="25%">
                                        <div class="ep-company-vat" style="margin:0px; padding: 0px; line-height: 10px"><strong><?php esc_html_e('Vat Number:', 'eventprime-event-invoices'); ?></strong></div>
                                    </td>
                                    <td class="ep_ei_header_right" width="75%" style="text-align:left;white-space:nowrap;">
                                        <div class="ep-company-vat" style="margin:0px; padding: 0px; line-height: 10px"><?php echo esc_html($data['ei_company_vat']); ?></div>
                                    </td>
                                </tr><?php
                            }?>
                        </table>
                    </td>
                </tr>
            </table>
            <!-- Company Invoice Information End-->  
            <br/>
            <br/>
            <br/>

            <table width="100%" class="ep-ei-mid-table" style="border-collapse: collapse;table-layout: fixed; border-spacing: 2px; background-color: #f6f8fA;border-bottom: 2px solid #e7e8e9;border-top: 1px solid #e7e8e9; padding: 10px 0px ">
                <tr>
                    <td width="70%">
                        <table border="0" width="100%">
                            <tr style="padding-bottom:20px;">
                                <td class="ep_ei_header_left" width="30%" style="line-height: 22px;color: #000;font-size:14px;">                           
                                    <?php esc_html_e('Invoice No.', 'eventprime-event-invoices'); ?>           
                                </td>
                                <td class="ep_ei_header_right" width="70%" style="font-size:12px; line-height: 22px; color: #75787b;">
                                    <?php echo '#' . $data['booking_id']; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="ep_ei_header_left" width="30%" style="line-height: 22px;color: #000;font-size:14px;">
                                    <?php esc_html_e('Invoice Date', 'eventprime-event-invoices'); ?>
                                </td>
                                <td class="ep_ei_header_right" width="70%" style="font-size:12px; line-height: 22px; color: #75787b;">
                                    <?php echo $data['booking_date']; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="ep_ei_header_left" width="30%" style="line-height: 22px;color: #000;font-size:14px;">
                                    <?php esc_html_e('Event Name', 'eventprime-event-invoices'); ?>
                                </td>
                                <td class="ep_ei_header_right" width="70%" style="font-size:12px; line-height: 22px; color: #75787b;">
                                    <?php echo $data['event_title']; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="ep_ei_header_left" width="30%" style="line-height: 22px;color: #000;font-size:14px;">
                                    <?php esc_html_e('Event Date', 'eventprime-event-invoices'); ?>
                                </td>
                                <td class="ep_ei_header_right" width="70%" style="font-size:12px; line-height: 22px; color: #75787b;">
                                    <?php echo $data['event_date']; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="ep_ei_header_left" width="30%" style="line-height: 22px;color: #000;font-size:14px;">                                 
                                    <?php esc_html_e('Payment Method', 'eventprime-event-invoices'); ?>
                                </td>
                                <td class="ep_ei_header_right" width="70%" style="font-size:12px; line-height: 22px; color: #75787b;">
                                    <?php echo $data['payment_method']; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="ep_ei_header_left" width="30%" style="line-height: 22px;color: #000;font-size:14px;">
                                    <?php esc_html_e('Currency', 'eventprime-event-invoices'); ?>
                                </td>
                                <td class="ep_ei_header_right" width="70%" style="font-size:12px; line-height: 22px; color: #75787b;">
                                    <?php echo $data['currency']; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="ep_ei_header_left" width="30%" style="line-height: 22px;color: #000;font-size:14px;">
                                    <?php esc_html_e('Booking Status', 'eventprime-event-invoices'); ?>
                                </td>
                                <td class="ep_ei_header_right" width="70%" style="font-size:12px; line-height: 22px; color: #75787b;">
                                    <?php echo $data['booking_status']; ?>
                                </td>
                            </tr>
                            
                        </table>
                    </td>
                    <td width="30%">
                        <table border="0" width="100%">
                            <tr>
                                <td><?php
                                    $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
                                    $global_settings = $setting_service->load_model_from_db();
                                    if ($global_settings->show_qr_code_on_ticket == 1) {?>
                                        <span class="kf-event-attr difl">
                                            <?php
                                            $url = get_permalink($global_settings->booking_details_page);
                                            $url = add_query_arg('id', $data['booking_id'], $url);
                                            $file_name = 'ep_qr_' . md5($url) . '.png';
                                            $upload_dir = wp_upload_dir();
                                            $file_path = $upload_dir['basedir'] . '/ep/' . $file_name;
                                            if (!file_exists($file_path)) {
                                                if (!file_exists(dirname($file_path))) {
                                                    mkdir(dirname($file_path), 0755);
                                                }
                                                require_once EM_BASE_DIR . 'includes/lib/qrcode.php';
                                                $qrCode = new QRcode();
                                                $qrCode->png($url, $file_path, 'M', 4, 2);
                                            }
                                            $image_url = $upload_dir['baseurl'] . '/ep/' . $file_name;
                                            ?>
                                            <div class="ep-qrcode-details"  style="width:100%; text-align: center">
                                                <img src="<?php echo $image_url; ?>" width="120" height="120" alt="<?php echo __('QR Code', 'eventprime-event-invoices'); ?>" />
                                            </div>
                                        </span><?php 
                                    }?>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <br/>
            <br/>
            <br/>
 
             <?php if (isset($data['booking']->order_info) && !empty($data['booking']->order_info)) { ?>
                <table align="center" border="0" cellspacing="0" cellpadding="0" width="100%" class="ep-ei-order-info-table" >
                    <tbody>
                        <tr>
                            <td class="ep-booking-items-w ep-booking-items-bottom" style="text-align: left;">
                                <div class="ep-booking-items-title">
                                    <strong><?php esc_html_e('ORDER DETAILS', 'eventprime-event-invoices'); ?></strong>
                                </div>
                                <!-- Invoice Items -->
                                <table width="100%" border="0" cellspacing="0" cellpadding="0" class="ep-booking-items-table">
                                    <thead>
                                        <tr class="ei-booking-details-header-row">
                                            <th style="width: 55%; text-align:left;">
                                                <div class="ep-ei-booking-item-th">
                                                    <?php esc_html_e('Seat', 'eventprime-event-invoices'); ?>
                                                </div>
                                            </th>
                                            <th style="width: 15%;">
                                                <div class="ep-ei-booking-item-th">
                                                    <?php esc_html_e('Price', 'eventprime-event-invoices'); ?>
                                                </div>
                                            </th>
                                            <th style="width: 15%;">
                                                <div class="ep-ei-booking-item-th">
                                                    <?php esc_html_e('Qty', 'eventprime-event-invoices'); ?>
                                                </div>
                                            </th>
                                            <th style="width: 20%;">
                                                <div class="ep-ei-booking-item-th">
                                                    <?php esc_html_e('Total', 'eventprime-event-invoices'); ?>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (!isset($data['booking']->order_info['order_item_data'])) {
                                            if (!empty($data['venue'])) {
                                                if ($data['venue']->type == 'seats' && count($data['booking']->order_info['seat_sequences']) > 0) {?>
                                                    <tr>
                                                        <td class="ep-booking-item" style="text-align: left;"  >
                                                            <div class="ep-ei-booking-item-td">
                                                                <?php echo implode(',', $data['booking']->order_info['seat_sequences']); ?>
                                                            </div>
                                                        </td>
                                                        <td class="ep-booking-item">
                                                            <div class="ep-ei-booking-item-td">
                                                                <?php
                                                                if (isset($data['booking']->order_info['subtotal'])) {
                                                                    $em_price = em_price_with_position($data['booking']->order_info['subtotal'], $data['booking']->order_info['currency']);
                                                                } else {
                                                                    $em_price = em_price_with_position($data['booking']->order_info['item_price'], $data['booking']->order_info['currency']);
                                                                }
                                                                echo $em_price;
                                                                if (isset($data['booking']->multi_price_id) && !empty($data['booking']->multi_price_id) && isset($data['booking']->payment_log['multi_price_option_data']) && !empty($data['booking']->payment_log['multi_price_option_data']->name)) {
                                                                    echo ' (' . $data['booking']->payment_log['multi_price_option_data']->name . ')';
                                                                }
                                                                ?>
                                                            </div>
                                                        </td>
                                                        <td class="ep-booking-item">
                                                            <div class="ep-ei-booking-item-td">
                                                                <?php echo $data['booking']->order_info['quantity']; ?>
                                                            </div>
                                                        </td>
                                                        <td class="ep-booking-item">
                                                            <div class="ep-ei-booking-item-td">
                                                                <?php echo em_price_with_position($data['booking']->order_info['item_price'] * $data['booking']->order_info['quantity'], $data['booking']->order_info['currency']); ?>
                                                            </div>
                                                        </td>
                                                    </tr><?php
                                                } else {
                                                    if (isset($data['booking']->multi_price_id) && !empty($data['booking']->multi_price_id)) {
                                                        if (isset($data['booking']->payment_log['multi_price_option_data']) && !empty($data['booking']->payment_log['multi_price_option_data'])) {
                                                            ?>
                                                            <tr>
                                                                <td class="ep-booking-item" style="text-align: left;">
                                                                    <div class="ep-ei-booking-item-td">
                                                                    <?php echo $data['booking']->payment_log['multi_price_option_data']->name; ?>
                                                                    </div>
                                                                </td>
                                                                <td class="ep-booking-item">
                                                                    <div class="ep-ei-booking-item-td">
                                                                        <?php echo em_price_with_position($data['booking']->order_info['item_price'], $data['booking']->order_info['currency']); ?>
                                                                    </div>
                                                                </td>
                                                                <td class="ep-booking-item">
                                                                    <div class="ep-ei-booking-item-td">
                                                                        <?php echo $data['booking']->order_info['quantity']; ?>
                                                                    </div>
                                                                </td>
                                                                <td class="ep-booking-item">
                                                                    <div class="ep-ei-booking-item-td">
                                                                        <?php echo em_price_with_position($data['booking']->order_info['item_price'] * $data['booking']->order_info['quantity'], $data['booking']->order_info['currency']); ?>
                                                                    </div>
                                                                </td>
                                                            </tr><?php } else {?>
                                                            <tr>
                                                                <td class="ep-booking-item" style="text-align: left;">
                                                                    <div class="ep-ei-booking-item-td">
                                                                        <?php echo $event->name; ?>
                                                                    </div>
                                                                </td>
                                                                <td class="ep-booking-item">
                                                                    <div class="ep-ei-booking-item-td">
                                                                        <?php echo em_price_with_position($data['booking']->order_info['item_price'], $data['booking']->order_info['currency']); ?>
                                                                    </div>
                                                                </td>
                                                                <td class="ep-booking-item">
                                                                    <div class="ep-ei-booking-item-td">
                                                                        <?php echo $data['booking']->order_info['quantity']; ?>
                                                                    </div>
                                                                </td>
                                                                <td class="ep-booking-item">
                                                                    <div class="ep-ei-booking-item-td">
                                                                        <?php echo em_price_with_position($data['booking']->order_info['item_price'] * $data['booking']->order_info['quantity'], $data['booking']->order_info['currency']); ?>
                                                                    </div>
                                                                </td>
                                                            </tr><?php
                                                        }
                                                    } else { ?>
                                                        <tr>
                                                            <td class="ep-booking-item" style="text-align: left;">
                                                                <div class="ep-ei-booking-item-td">
                                                                    <?php echo $event->name; ?>
                                                                </div>
                                                            </td>
                                                            <td class="ep-booking-item">
                                                                <div class="ep-ei-booking-item-td">
                                                                    <?php echo em_price_with_position($data['booking']->order_info['item_price'], $data['booking']->order_info['currency']); ?>
                                                                </div>
                                                            </td>
                                                            <td class="ep-booking-item">
                                                                <div class="ep-ei-booking-item-td">
                                                                    <?php echo $data['booking']->order_info['quantity']; ?>
                                                                </div>
                                                            </td>
                                                            <td class="ep-booking-item">
                                                                <div class="ep-ei-booking-item-td">
                                                                    <?php echo em_price_with_position($data['booking']->order_info['item_price'] * $data['booking']->order_info['quantity'], $data['booking']->order_info['currency']); ?>
                                                                </div>
                                                            </td>
                                                        </tr><?php
                                                    }
                                                }
                                            }
                                        } else {
                                            foreach ($data['booking']->order_info['order_item_data'] as $ikey => $ivalue) {?>
                                                <tr><?php if (!empty($data['venue']) && $data['venue']->type == 'seats') { ?>
                                                    <td class="ep-booking-item em-with-seat-sequences" style="text-align: left;">
                                                        <div class="ep-ei-booking-item-td">
                                                            <?php
                                                            echo $ivalue->seatNo;
                                                            if (!empty($ivalue->variation_name)) {
                                                                echo ' (' . $ivalue->variation_name . ')';
                                                            } ?>
                                                        </div>
                                                        </td><?php } else {?>
                                                        <td class="ep-booking-item" style="text-align: left;">
                                                            <div class="ep-ei-booking-item-td">
                                                                <?php
                                                                //echo $ivalue->seatNo;
                                                                if (!empty($ivalue->variation_name)) {
                                                                    echo $ivalue->variation_name;
                                                                } ?>
                                                            </div>
                                                        </td><?php } ?>
                                                        <td class="ep-booking-item">
                                                            <div class="ep-ei-booking-item-td">
                                                                <?php echo em_price_with_position($ivalue->price, $data['booking']->order_info['currency']); ?>
                                                            </div>
                                                        </td>
                                                        <td class="ep-booking-item">
                                                            <div class="ep-ei-booking-item-td">
                                                                <?php echo $ivalue->quantity; ?>
                                                            </div>
                                                        </td>
                                                        <td class="ep-booking-item">
                                                            <div class="ep-ei-booking-item-td">
                                                                <?php echo em_price_with_position($ivalue->sub_total, $data['booking']->order_info['currency']); ?>
                                                            </div>
                                                        </td>
                                                    </tr><?php
                                                }
                                            } ?>
                                    </tbody>
                                    <tfoot>
                                        <?php if (isset($data['booking']->order_info['fixed_event_price']) && $data['booking']->order_info['fixed_event_price'] > 0) { ?>
                                            <tr> 
                                                <td></td>
                                                <td colspan="2" class="ep-booking-totsl-t"><?php _e('One-Time event Fee', 'eventprime-event-invoices'); ?></td>
                                                <td class="ep-booking-total-p"><?php echo em_price_with_position($data['booking']->order_info['fixed_event_price'], $data['booking']->order_info['currency']); ?></td>
                                            </tr><?php
                                        }
                                        if (isset($data['booking']->order_info['discount']) && !empty($data['booking']->order_info['discount'])) {
                                            ?>
                                            <tr> 
                                                <td></td>
                                                <td colspan="2" class="ep-booking-totsl-t"><?php _e('Discount', 'eventprime-event-invoices'); ?></td>
                                                <td class="ep-booking-total-p"><?php echo em_price_with_position($data['booking']->order_info['discount'], $data['booking']->order_info['currency']); ?></td>
                                            </tr><?php
                                        }
                                        if (isset($data['booking']->order_info['coupon_code']) && !empty($data['booking']->order_info['coupon_code']) && isset($data['booking']->order_info['coupon_discount']) && !empty($data['booking']->order_info['coupon_discount'])) {?>
                                            <tr> 
                                                <td></td>
                                                <td colspan="2" class="ep-booking-totsl-t"><?php _e('Coupon Amount', 'eventprime-event-invoices'); ?></td>
                                                <td class="ep-booking-total-p"><?php echo em_price_with_position($data['booking']->order_info['coupon_discount'], $data['booking']->order_info['currency']); ?></td>
                                            </tr><?php 
                                        }?>
                                        <?php do_action('event_magic_front_user_booking_before_total_price', $data['booking']); ?>
                                        <tr> 
                                            <td></td>
                                            <td colspan="2" class="ep-booking-totsl-t"><strong><?php _e('Total Price', 'eventprime-event-invoices'); ?></strong></td>
                                            <td class="ep-booking-total-p"><strong><?php echo $data['total_price']; ?></strong></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table><?php 
            }?>
           <div class="ep-ei-booking-attendees-title">
                <strong><?php esc_html_e('Attendees', 'eventprime-event-invoices');?></strong>
            </div>
            <table border="0" width="100%">
                <tbody>
                    <tr>
                        <?php
                        if (!isset($data['booking']->order_info['is_custom_booking_field']) || $data['booking']->order_info['is_custom_booking_field'] == 0 || empty($data['booking']->order_info['is_custom_booking_field'])) {?>
                            <td>
                                <div class="" ><?php
                                    echo implode(', ', $data['booking']->attendee_names);?>
                                </div>
                            </td><?php
                        } else {
                            $row_counter = 1;$rowtd_counter = 1;
                            $attCount = count($data['booking']->attendee_names);
                            foreach ($data['booking']->attendee_names as $attendees) {
                                if( $row_counter % 2 != 0 ) { echo '<tr>'; } ?>
                            
                                <td width="49%" style="border: 1px solid #e7e8e9;background-color: #fcfcfc;">
                                    <div class="ep-ei-booking-attendees-wrap">
                                        <table border="0" width="100%" style="padding-top: 10px;"><?php
                                            foreach ($attendees as $label => $value) {?>
                                                <tr>
                                                    <td width="35%" ><?php echo $label;?></td>
               
                                                    <td width="65%" ><?php echo $value;?></td>
                                                </tr><?php
                                            }?>
                                        </table>
                                    </div>
                                </td><?php
                                if($rowtd_counter == 1 ) {?>
                                    <td width="3%">&nbsp;</td>
                                    <?php
                                    $rowtd_counter = 0;
                                }
                            if( $row_counter % 2 == 0 || $row_counter == $attCount ) { 
                                echo '</tr>';
                                $rowtd_counter = 1;
                            }
                            $row_counter++; }
                        }?>
                    </tr>
                </tbody>
            </table>
            <?php if(isset($data['ei_enable_event_invoice_footer']) && !empty($data['ei_enable_event_invoice_footer'])){
                if(!empty($data['ei_footer_invoice_secion'])){
                    echo $data['ei_footer_invoice_secion'];
                }
            }?>
        </td>
    </tr>
</table>