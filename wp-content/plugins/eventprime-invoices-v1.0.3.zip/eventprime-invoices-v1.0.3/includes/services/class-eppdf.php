<?php
if (!defined( 'ABSPATH')){
    exit;
}

class EPPDF extends TCPDF {
    
    public function Footer() {
        $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
        $gs = $setting_service->load_model_from_db();
        /* if(!empty($gs->ei_enable_event_invoice_footer)){
            $this->SetFont('dejavusans', '', 10);
            $this->writeHTML($gs->ei_footer_invoice_secion, true, false, true, false, '');
        } */
    }
    
}
