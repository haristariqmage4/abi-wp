<?php
if (!defined( 'ABSPATH')){
    exit;
}

class EventM_Invoice_Service {
    
    private static $instance = null;
    
    private function __construct() {

    }
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }
    
    public static function get_invoice_data( $booking ) {   
        $booking_service = EventM_Factory::get_service('EventM_Booking_Service');
        $event_service = EventM_Factory::get_service('EventM_Service');
        $event_type_service = EventM_Factory::get_service('EventTypeM_Service');
        $tpl_location = plugin_dir_path( __DIR__ ).'print/invoice.php';
        $data = array();
        $event = $event_service->load_model_from_db( $booking->event );
        $event_type = $event_type_service->load_model_from_db( $event->event_type );
        $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
        $gs = $setting_service->load_model_from_db();
        $allow_event_invoices = $gs->allow_event_invoices;
        $data['ei_company_name'] = $gs->ei_company_name;
        $data['ei_company_email'] = $gs->ei_company_email;
        $data['ei_company_phone'] = $gs->ei_company_phone;
        $data['ei_company_vat'] = $gs->ei_company_vat;
        $ei_logo = $gs->ei_company_logo_url;
        if(empty($ei_logo)){
            $custom_logo_id = get_theme_mod( 'custom_logo' );
            $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
            $ei_logo = $image[0];
            if(empty($ei_logo)){
                $ei_logo = EM_BASE_URL . '/includes/admin/template/images/eventprime-logo-new';
            }
        }
        $data['ei_company_logo_url'] = $ei_logo;
        $data['ei_company_logo_width'] = $gs->ei_company_logo_width;
        $data['ei_company_address'] = $gs->ei_company_address;
        $data['ei_description'] = $gs->ei_description;
        $data['ei_enable_event_invoice_footer'] = $gs->ei_enable_event_invoice_footer;
        $data['ei_footer_invoice_secion'] = $gs->ei_footer_invoice_secion;
        $data['booking_id'] = $booking->id;
        $data['event_title'] = $event->name;
        $data['booking_date'] = date_i18n(get_option('date_format').' '.get_option('time_format'), $booking->date);
        if(!empty($event->all_day)){
            if(is_multidate_event($event)){
                $data['event_date'] = date_i18n(get_option('date_format'), $event->start_date) . ' - ' . date_i18n(get_option('date_format'), $event->end_date);
            }
            else{
                $data['event_date'] = date_i18n(get_option('date_format'),$event->start_date).' - '.__('ALL DAY','eventprime-event-calendar-management');
            }
        }
        else{
            $data['event_date'] = date_i18n(get_option('date_format').' '.get_option('time_format'),$event->start_date);
            $data['event_date'] . ' - ';
            $data['event_date'] .= date_i18n(get_option('date_format').' '.get_option('time_format'),$event->end_date);
        }

        $data['payment_method'] = isset($booking->order_info['payment_gateway']) ? ucfirst($booking->order_info['payment_gateway']) : 'N/A'; 
        $data['currency'] = isset($booking->payment_log['currency']) ? $booking->payment_log['currency'] : $booking->order_info['currency'];
        $data['booking_status'] = EventM_Constants::$status[$booking->status];
        $data['booking'] = $booking;
        $venue_service = EventM_Factory::get_service('EventM_Venue_Service');
        $data['venue'] = (isset($event->venue) && !empty($event->venue)) ? $venue_service->load_model_from_db($event->venue) : array();
        $total_price = $booking_service->get_final_price($booking->id); 
        $total_price = empty($total_price) ? __('Free','eventprime-event-calendar-management') : em_price_with_position($total_price, $booking->order_info['currency']);
        $data['total_price'] = $total_price;
        
        $data = apply_filters( 'event_magic_data_before_print', $data, $event, $booking );
        if ( file_exists( $tpl_location ) ) {
            ob_start();
            include( $tpl_location );
            $html = ob_get_clean();
        }
        return $html;
    }

    public static function print_invoice( $html, $args = array() ){
        // create new PDF document
        $pdf = new EPPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        // set document information
        $pdf->SetCreator(PDF_CREATOR);
        if(!empty($args['title'])){
            $pdf->SetTitle($args['title']);
        }
        
        // set header and footer fonts
        $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
        $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

        // set default monospaced font
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        // set margins
        //$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
        $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
        $gs = $setting_service->load_model_from_db();
        $margin_left = (!empty($gs->ei_invoice_left_margin) ? $gs->ei_invoice_left_margin : 5);
        $margin_top = (!empty($gs->ei_invoice_top_margin) ? $gs->ei_invoice_top_margin : 5);
        $margin_right = (!empty($gs->ei_invoice_right_margin) ? $gs->ei_invoice_right_margin : 5);
        $pdf->SetMargins($margin_left, $margin_top, $margin_right);
        $pdf->setPrintHeader(false);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

        // set auto page breaks
        //$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
        $pdf->SetAutoPageBreak(TRUE, $gs->ei_page_break_margin);

        // set image scale factor
        $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

        // set font
        /*$font=  isset($args['font']) ? $args['font'] : 'courier';
        $pdf->SetFont($font, '', 10);*/
        $pdf->SetFont('dejavusans', '', 10);

        // add a page
        $pdf->AddPage();
        $pdf->writeHTML($html, true, false, true, false, '');
        $name = isset($args['name']) ? $args['name'] : '';
        /*$pdf_name = plugin_dir_path( __DIR__ ) . 'invoices/' . $name . '.pdf';
        $pdf->Output("$pdf_name.pdf", 'F');*/
        $pdf->Output("$name.pdf", 'D');
    }

    public static function save_invoice( $html, $args = array() ){ 
        if (!class_exists('TCPDF'))
            require_once EM_BASE_DIR . 'includes/lib/tcpdf_min/tcpdf.php';

        // create new PDF document
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        // set document information
        $pdf->SetCreator(PDF_CREATOR);
        if(!empty($args['title'])){
            $pdf->SetTitle($args['title']);
        }
        
        // set header and footer fonts
        $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
        $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

        // set default monospaced font
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        // set margins
        //$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
        $pdf->SetMargins(5, 5, 5);
        $pdf->setPrintHeader(false);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

        // set auto page breaks
        //$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
        $pdf->SetAutoPageBreak(TRUE, 5);

        // set image scale factor
        $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

        // set font
        /*$font=  isset($args['font']) ? $args['font'] : 'courier';
        $pdf->SetFont($font, '', 10);*/
        $pdf->SetFont('dejavusans', '', 10);

        // add a page
        $pdf->AddPage();
        $pdf->writeHTML($html, true, false, true, false, '');
        $name = isset($args['name']) ? $args['name'] : '';
        $path = plugin_dir_path( __DIR__ ) . 'invoices/';
        if ( !file_exists( $path ) ) {
            mkdir($path, 0777, true);
        }
        $pdf_name = plugin_dir_path( __DIR__ ) . 'invoices/' . $name . '.pdf';
        $pdf->Output($pdf_name, 'F');
        return $pdf_name;
    }
}
