<?php
/**
 * Plugin Name: EventPrime Ticketing & Seating
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that adds unique ticketing and seating arrangement options.
 * Version: 1.0.7
 * Author: EventPrime
 * Text Domain: eventprime-event-seating
 * Domain Path: /languages
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 6.0.3
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_Seating')) {

    final class EM_Seating {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.0.7';

        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;

        
        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }


        /**
         * Event_Magic Constructor.
         */
        private function __construct() {
            $this->define_constants();
            $this->load_textdomain();
            $this->includes(); 
            $this->define_hooks();
            $em= event_magic_instance();
            array_push($em->extensions,'seating');
        }
        
        public function register_post_type(){
            register_post_type(EM_TICKET_POST_TYPE,
                array(
                    'labels' => array(
                        'name'                  => __( 'Tickets','eventprime-event-seating'),
                        'singular_name'         => __( 'Ticket','eventprime-event-seating'),
                        'add_new'               => __( 'Add Ticket','eventprime-event-seating'),
                        'add_new_item'          => __( 'Add New Ticket','eventprime-event-seating'),
                        'edit'                  => __( 'Edit','eventprime-event-seating'),
                        'edit_item'             => __( 'Edit Ticket','eventprime-event-seating'),
                        'new_item'              => __( 'New Ticket','eventprime-event-seating'),
                        'view'                  => __( 'View Ticket','eventprime-event-seating'),
                        'view_item'             => __( 'View Ticket','eventprime-event-seating'),
                        'not_found'             => __( 'No Tickets found','eventprime-event-seating'),
                        'not_found_in_trash'    => __( 'No Tickets found in trash','eventprime-event-seating'),
                        'featured_image'        => __( 'Ticket Image','eventprime-event-seating'),
                        'set_featured_image'    => __( 'Set ticket image','eventprime-event-seating'),
                        'remove_featured_image' => __( 'Remove ticket image','eventprime-event-seating'),
                        'use_featured_image'    => __( 'Use as ticket image','eventprime-event-seating'),
                    ),
                    'description'         => __( 'Here you can add new events.','eventprime-event-seating'),
                    'public'              => true,
                    'show_ui'             => false,
                    'map_meta_cap'        => true,
                    'publicly_queryable'  => true,
                    'exclude_from_search' => false,
                    'hierarchical'        => false, // Restrict WP to loads all records!
                    'query_var'           => true,
                    'capability_type'     => array('ticket', 'tickets'), 
                    'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'page-attributes', 'publicize', 'wpcom-markdown' ),
                    'show_in_nav_menus'   => false
                )
            );
        }
        
        public function define_constants(){
            $em= event_magic_instance();
            $em->define('EMS_BASE_URL', plugin_dir_url(__FILE__));
            $em->define('EM_TICKET_POST_TYPE','em_ticket');
        }
        
        public function includes(){
            include_once('includes/models/class-ticket.php'); // Loading model
            include_once('includes/dao/class-ticket.php'); // Loading DAO
            include_once('includes/services/class-ticket.php'); // Loading service class
            include('includes/class-public.php');
            if(is_admin()){
                include('includes/admin/class-admin.php');
            }
        }
        
        public function define_hooks(){
            add_action( 'init', array( $this, 'register_post_type' ) );
            add_filter( 'event_magic_ticket_templates', array( $this, 'get_ticket_templates' ) );
            add_filter( 'event_magic_admin_pages', array( $this, 'admin_pages' ) );
            add_action( 'event_magic_event_saved', array( $this, 'event_saved' ) );
            add_filter( 'event_magic_before_venue_save', array( $this, 'before_venue_save' ) );
            add_action( 'wp_ajax_em_save_event_ticket', array( $this, 'save_ticket' ) );
            add_action( 'event_magic_gs_settings', array( $this, 'event_seating_gs_settings' ) );
            add_filter( 'event_magic_booking_confirmed_notification_attachments', array( $this, 'live_seating_booking_confirmed_notification_attachments' ), 99, 2 );
        }
        
        function update_model_before_save($model){
            $request = EventM_Raw_Request::get_instance();
            $data = $request->get_data();
            
            return $model;
        }
        
        function save_ticket(){
            $request = EventM_Raw_Request::get_instance();
            $service = EventM_Factory::get_service('EventM_Ticket_Service');
            $model = $request->map_request_to_model('EventM_Ticket_Model');
            $template = $service->save($model);
            $response = new stdClass();
            $response->redirect = admin_url('/admin.php?page=em_ticket_templates');
            echo json_encode($response);
            wp_die();
        }
        
        public function event_saved($event){
            if(empty($event) || empty($event->id) || empty($event->venue)){
                return;
            }
            $event_service = EventM_Factory::get_service('EventM_Service');
            $event_seats = $venue_seats = array();
            $venue_seats = em_get_term_meta($event->venue, 'seats', true);
            if (empty($venue_seats)) {
                $event->seats= array();
                $event_service->update_model($event);
            }
            elseif(empty($event->seats)) {
                $capacity = em_get_term_meta($event->venue, 'seating_capacity', true);
                $event->seats= $venue_seats;
                $event->seating_capacity= $capacity;
                $event_service->update_model($event);
            } 
        }
        
        public function before_venue_save($venue){
            if($venue->type=='standings'){
                $venue->seating_capacity= 0;
                $venue->seats= array();
            }
            return $venue;
        }
        
        public function admin_pages($pages){
            array_push($pages,'em_ticket_templates');
            return $pages;
        }
        
        public function get_ticket_templates($templates)
        {
            $service = EventM_Factory::get_service('EventM_Ticket_Service');
            $results = $service->get_templates();
            if(!empty($results)){
                return $results;
            }
            return $templates;
        }
        
        public function load_textdomain(){
            load_plugin_textdomain('eventprime-event-seating', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        public function event_seating_gs_settings(){?>
            <a href='javascript:void(0)'>
                <div class="em-settings-box ep-active-extension ep-no-global-settings-model" data-popup="ep-live-seating-ext" onclick="CallEPExtensionModal(this)">
                    <img class="em-settings-icon" ng-src="<?php echo EM_BASE_URL; ?>includes/admin/template/images/seating-integration-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Live Seating', 'eventprime-event-seating'); ?></div>
                    <span><?php _e('Add seat plan and seat selection.', 'eventprime-event-seating'); ?></span>
                </div>
            </a>
            <?php
        }

        public function live_seating_booking_confirmed_notification_attachments($attachments, $booking) {
            $service = EventM_Factory::get_service('EventM_Service');
            $event = $service->load_model_from_db($booking->event);
            if(empty($event->en_ticket))
                return;
            $order_info = $booking->order_info;
            if(!empty($order_info['seat_sequences'])){
                foreach($order_info['seat_sequences'] as $seat_id){
                    $html = EventM_Print::front_ticket($booking, $seat_id);
                    $args = array('name' => $event->name.'-ticket-'.$seat_id);
                    if(!empty($event->ticket_template)){
                        $ts = EventM_Factory::get_service('EventM_Ticket_Service');
                        $tt = $ts->load_model_from_db($event->ticket_template);
                        if(!empty($tt->id)){
                            $args['font'] = $tt->font1;
                        }
                    }
                    $args['title'] = __('Ticket','eventprime-event-seating');
                    $ticket_file = EventM_Print::save_ticket_html($html, $args);
                    if ( file_exists( $ticket_file ) ) {
                        $attachments[] = $ticket_file;
                    }
                }
            }
            return $attachments;
        }
    }

}

function em_seating() {
    return EM_Seating::instance();
}
function em_seating_checks(){ ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e( 'EventPrime Seating Extension won\'t work as EventPrime plugin is not active/installed.', 'event-magic' ); ?></p>
    </div>
<?php }

add_action('plugins_loaded', function(){
    if(!class_exists('Event_Magic')){
        add_action('admin_notices','em_seating_checks');
    }
});
add_action('event_magic_loaded', 'em_seating');
require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_seating_metadata.json',
    __FILE__,
    'eventprime-event-seating'
);