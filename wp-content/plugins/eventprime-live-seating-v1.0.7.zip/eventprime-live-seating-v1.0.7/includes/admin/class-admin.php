<?php

class EM_Seating_Admin {
	
    public function __construct() {
        add_action('event_magic_menus', array($this, 'menus'));
        add_action('admin_enqueue_scripts',array($this,'enqueue'));
        add_action('event_magic_load_strings',array($this,'load_screen_data'));
        add_action('event_magic_dashboard_seating_link',array($this,'dashboard_links'));
        add_action('event_magic_dashboard_ticket_settings',array($this,'ticket_settings_link'));
        add_action('event_magic_dashboard_tickets_tab',array($this,'ticket_settings_tab'));
        add_action('event_magic_dashboard_seating_tab',array($this,'seating_tab'));
        add_action('wp_ajax_em_save_event_ticket',array($this,'save_event_ticket'));
        add_action('event_magic_venue_seatings',array($this,'venue_add'));
        add_filter('event_magic_seating_types',array($this,'seating_type'));
        add_filter('event_magic_manager_navs',array($this,'manager_navs'));
        add_filter('em_event_capacity_validation',array($this,'capacity_validation'),10,2);
        add_action('wp_ajax_admin_print_ticket',array($this,'print_ticket'));
        add_action('event_magic_print_ticket_btn',array($this,'print_ticket_btn'));
        add_action('event_magic_save_event',array($this,'save_event'));
    }
    
    public function menus(){
        add_submenu_page("event_magic", __('Tickets', 'eventprime-event-seating'), __('Tickets', 'eventprime-event-seating'), "manage_options", "em_ticket_templates", array($this, 'ticket_templates'));
    }
    
    public function enqueue(){
        wp_register_script('em-ticket-controller',EMS_BASE_URL.'includes/admin/template/js/em-ticket-controller.js', array('em-angular-module'));
        wp_register_script('em-venue-seat-controller',EMS_BASE_URL.'includes/admin/template/js/em-venue-controller.js', array('em-venue-controller'));
    }
    
    public function load_screen_data($context){
        $service = EventM_Factory::get_service('EventM_Ticket_Service');
        if($context=='admin_ticket_templates'){
            $response= $service->load_list_page();
            wp_send_json_success($response);
        }
        else if($context=='admin_ticket_template'){
            $ticket= $service->load_edit_page();
            wp_send_json_success(array('post'=>$ticket));
        }
    }
    
    public function ticket_templates(){
        $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
        if ('em_ticket_templates'!==$page) {
            return;
        }
        wp_enqueue_script('em-ticket-controller');
        $tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : '';
        if($tab=='add')
        {
            wp_enqueue_media();  
            include_once('template/ticket_add.php');
        }
        else
        {   
            include_once('template/ticket_templates.php');
        }
    }
    
    public function dashboard_ticket_templates_link(){ ?>
        <a target="_blank" href="<?php echo admin_url("/admin.php?page=em_ticket_templates"); ?>"><?php _e('Ticket Manager','eventprime-event-seating'); ?></a>
    <?php }
    
    public function dashboard_links($post_id){ ?>
        <div class="ep-grid-icon difl" id="ep-ticket-integration">
            <a  class="ep-dash-link" href="<?php echo admin_url("/admin.php?page=em_dashboard&tab=tickets&post_id=$post_id") ?>">
                <div class="ep-grid-icon-area dbfl">
                    <img class="ep-grid-icon dibfl" src="<?php echo EM_BASE_URL . 'includes/admin/template/images/ep-ticket-integration-icon.png' ?>">
                </div>
                <div class="ep-grid-icon-label dbfl"><?php _e('Tickets', 'eventprime-event-seating'); ?></div>
            </a>
        </div>
        
        <div class="ep-grid-icon difl" id="ep-seating-integration">
            <a  class="ep-dash-link" href="<?php echo admin_url("/admin.php?page=em_dashboard&tab=seating&post_id=$post_id") ?>">
                <div class="ep-grid-icon-area dbfl">
                    <img class="ep-grid-icon dibfl" src="<?php echo EM_BASE_URL . 'includes/admin/template/images/ep-seating-integration-icon.png' ?>">
                </div>
                <div class="ep-grid-icon-label dbfl"><?php _e('Seating Arrangement', 'eventprime-event-seating'); ?></div>
            </a>
        </div>
    <?php }
    
  
    
    public function ticket_settings_tab($post_id){
        $service= EventM_Service::get_instance();
        $event= $service->load_model_from_db($post_id);
        wp_enqueue_script('em-event-controller');
        include('template/tickets.php');
    }
    
    public function seating_tab($post_id){
        wp_enqueue_script('em-event-controller');
        include('template/seating.php');
    }
    
    public function venue_add($term_id){
        wp_enqueue_script('em-venue-seat-controller');
        em_localize_map_info();
        include('template/venue_add.php');
    }
    
    public function save_event_ticket(){
        $service = EventM_Factory::get_service('EventM_Ticket_Service');
        $request = EventM_Raw_Request::get_instance();
        
        $model = $request->map_request_to_model('EventM_Ticket_Model');
        $model->id = absint(event_m_get_param('id'));
        $template= $service->save($model);
        // In case of any errors
        if ($template instanceof WP_Error) {
            $error_msg= $template->get_error_message(); 
            wp_send_json_error(array('errors'=>array($error_msg)));
        }
        
        $redirect= admin_url('/admin.php?page=em_ticket_templates');
        wp_send_json_success(array('redirect'=>$redirect));
    }
    
    public function seating_type($types){
        $types['seats']= __('Seating','eventprime-event-seating');
        return $types;
    }
    
    public function manager_navs($manager_navs){
        $manager_navs[]= array('key'=>'em_ticket_templates','label'=>__('Ticket Manager','eventprime-event-seating'));
        return $manager_navs;
    }
    
    public function capacity_validation($errors,$event){
        $seating_capacity = absint(event_m_get_param('seating_capacity'));
        $venue_id=absint(event_m_get_param('venue'));
        if(empty($venue_id))
            return $errors;
        $venue_service= EventM_Factory::get_service('EventM_Venue_Service');
        $venue= $venue_service->load_model_from_db($venue_id);
        if(!empty($venue->id) && $venue->type!='standings'){
            if(empty($seating_capacity)){
                $errors[]= __('Capacity can not be 0.','eventprime-event-seating');
            }
            else{
                if ($venue->seating_capacity<$seating_capacity) {
                    $errors[]= sprintf(__('Event capacity exceeded more than the Event Site capacity. Please <a target="_blank" href="%s">sync</a> with the Event Site and save again','eventprime-event-seating'),admin_url('admin.php?page=em_dashboard&tab=seating&post_id='.$model->id));
                }
            }
        }
        return $errors;
    }
    
    public function print_ticket(){
        if(!em_is_user_admin()){
            $error_msg= __('You are not allowed to access this page.','eventprime-event-seating');
            wp_send_json_error(array('errors'=>array($error_msg)));
        }
        
        $booking_id= event_m_get_param('id');
        $bs= EventM_Factory::get_service('EventM_Booking_Service');
        $booking=$bs->load_model_from_db($booking_id);
        if(empty($booking->id))
            die(__('Booking does not exist.','eventprime-event-seating'));
        // Check if booking belongs to current user
        $user= wp_get_current_user();
        if(empty($user->ID))
            die(__('User does not exists.','eventprime-event-seating'));
        
        
        $es= EventM_Factory::get_service('EventM_Service');
        $event= $es->load_model_from_db($booking->event);
        $vs= EventM_Factory::get_service('EventM_Venue_Service');
        $venue=$vs->load_model_from_db($event->venue);
        if(!empty($booking->order_info['seat_pos'])){
                $seat_no= event_m_get_param('seat_no');
                $html = EventM_Print::front_ticket($booking,$seat_no);
                $args= array('name'=>$event->name.'-ticket-'.$seat_no);
                if(!empty($event->ticket_template)){
                    $ts= EventM_Factory::get_service('EventM_Ticket_Service');
                    $tt= $ts->load_model_from_db($event->ticket_template);
                    if(!empty($tt->id)){
                        $args['font']= $tt->font1;
                    }
                }
                $args['title']= __('Ticket','eventprime-event-seating');
        }
        else{ // Printing standing type of event
            $html = EventM_Print::front_ticket($booking);
            $args= array('name'=>$event->name.'-ticket');
            // Check for any font
            if(!empty($event->ticket_template)){
                $ts= EventM_Factory::get_service('EventM_Ticket_Service');
                $tt= $ts->load_model_from_db($event->ticket_template);
                if(!empty($tt->id)){
                    $args['font']= $tt->font1;
                }
            }
            $args['title']= __('Ticket','eventprime-event-seating');
        }
            EventM_Print::print_html($html,$args);
        
        exit();
    
    }
    
    public function print_ticket_btn(){ ?>
        <div ng-if="data.post.ticket">
            <div ng-if="data.post.type == 'seats' &&  data.post.event_status !='trash'" ng-show="data.post.status !='Pending' " class="em_booking_buttons em_seat_sequence">
                <span  ng-repeat="seat_sequence in data.post.order_info.seat_sequences" >
                    <span><a id={{seat_sequence}} href="<?php echo admin_url("admin-ajax.php?action=admin_print_ticket&id=") ?>{{data.post.id}}&seat_no={{seat_sequence}}" class="btn-primary">{{seat_sequence}}</a>
                </span>    
            </div>

            <span  ng-if="data.post.type != 'seats'" ng-show="data.post.status !='Pending' && data.post.event_status !='trash'" >
                <a href="<?php echo admin_url('admin-ajax.php?action=admin_print_ticket&id='); ?>{{data.post.id}}"  class="btn-primary"><?php _e('Print Ticket','eventprime-event-seating'); ?></a>
            </span>
        </div>
    <?php }
    
    
    
    public function save_event($event_id){
        $event_service= EventM_Factory::get_service('EventM_Service');
        $event= $event_service->load_model_from_db($event_id);
        $screen= event_m_get_param('screen');
        if($screen=='save_tickets'){
            $event->en_ticket= absint(event_m_get_param('en_ticket'));
            $event->ticket_template= absint(event_m_get_param('ticket_template'));
            $event->max_tickets_per_person= absint(event_m_get_param('max_tickets_per_person'));
            $event->allow_discount= absint(event_m_get_param('allow_discount'));
            $event->discount_no_tickets= absint(event_m_get_param('discount_no_tickets'));
            $event->discount_per= (float) event_m_get_param('discount_per');
        }
        else if($screen=='save_seating'){
            $event->seats= event_m_get_param('seats');
        }
        $event_service->update_model($event);
    }
}
new EM_Seating_Admin;