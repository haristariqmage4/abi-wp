eventMagicApp.controller('venueSeatCtrl',function($scope, $http,MediaUploader,PostUtility,EMRequest,Seat){
    $scope.selectedSeats = [];
    $scope.seatPopup = false;
    $scope.currentSeat = '';
    $scope.currentSelection = '';
    $scope.scheme_popup = false;
    $=jQuery;
        
    $scope.selectRow = function (index) {
        $scope.resetSelections();
        for (var i = 0; i < $scope.data.term.seats[index].length; i++) {
            $scope.data.term.seats[index][i].type = 'selected';
            $scope.selectedSeats.push($scope.data.term.seats[index][i]);
        }

        $scope.currentSelection = 'row';
        $scope.currentSelectionIndex = index;

    };

    $scope.selectColumn = function (index) {
        $scope.resetSelections();
        for (var i = 0; i < $scope.data.term.seats.length; i++) {

            $scope.data.term.seats[i][index].type = 'selected';
            $scope.selectedSeats.push($scope.data.term.seats[i][index]);
        }
        $scope.currentSelection = 'col'
        $scope.currentSelectionIndex = index;
    };

    $scope.createAisles = function () {
        var type = 'isles';
        var selectedRow;
        var selectedColumn;
        var width = parseInt($scope.seat_container_width.width);

        for (var i = 0; i < $scope.selectedSeats.length; i++) {
            $scope.selectedSeats[i].type = type;

            if ($scope.currentSelection == 'col') {
                if ($scope.selectedSeats[i].columnMargin == 0) {
                    $scope.selectedSeats[i].columnMargin += 30;
                    $scope.seat_container_width.width = width + 30 + "px";
                } else
                {

                    $scope.selectedSeats[i].columnMargin = 0;
                    $scope.seat_container_width.width = width - 30 + "px";
                }

            }


            if ($scope.currentSelection == 'row') {
                if ($scope.selectedSeats[i].rowMargin == 0)
                    $scope.selectedSeats[i].rowMargin += 30;
                else
                    $scope.selectedSeats[i].rowMargin = 0;
            }


        }

        $scope.resetSelections();

        //  console.log($scope.term.seats);
    }

    $scope.reserveSeat = function (rcolor) {
        var type = 'reserve';
        for (var i = 0; i < $scope.selectedSeats.length; i++) {
            $scope.selectedSeats[i].type = type;
            $scope.selectedSeats[i].seatColor = '#'+rcolor;
            $scope.selectedSeats[i].seatBorderColor = '3px solid #'+rcolor;
        }
        $scope.selectedSeats = [];
        $scope.currentSelection = '';
    }
    
    $scope.selectSeat = function (seat, row, col, scolor, sel_color) {
        if ($scope.currentSelection == 'row' || $scope.currentSelection == 'col') {
            $scope.resetSelections();
        }

        if (seat.type == 'selected' && seat.type != 'general')
        {
            var index = $scope.selectedSeats.indexOf(seat);
            if (index >= 0) {
                $scope.selectedSeats.splice(index, 1);
            }
            seat.type = 'general';
            seat.seatColor = '#'+scolor;
            seat.seatBorderColor = '3px solid #'+scolor;
        } else {
            seat.type = 'selected';
            $scope.selectedSeats.push(seat);
            seat.seatColor = '#'+sel_color;
            seat.seatBorderColor = '3px solid #'+sel_color;
        }
        $scope.currentSelection = 'seat';
        //$scope.showPopup();
        $scope.em_call_popup("#pm-change-password");

    }
    
    $scope.resetSelections = function () {
        var term_seat_color = $scope.$parent.data.term.seat_color;
        for (var i = 0; i < $scope.selectedSeats.length; i++) {
            $scope.selectedSeats[i].type = 'general';
            if(term_seat_color){
                $scope.selectedSeats[i].seatColor = '#'+term_seat_color;
                $scope.selectedSeats[i].seatBorderColor = '3px solid #'+term_seat_color;
            }
        }
        $scope.selectedSeats = [];
        $scope.currentSelection = '';
        $scope.currentSelectionIndex = '';
    }
    
    $scope.createSeats = function (rows, columns, seat_color) {
        $scope.progressStart();
        $scope.data.term.seats = new Array(rows);
        for (var i = 0; i < rows; i++) {
            $scope.data.term.seats[i] = [];
        }
        
        for (var i = 0; i < rows; i++) {
            for (var j = 0; j < columns; j++) {
                $scope.data.term.seats[i][j] = new Seat('general', 9, i, j, seat_color);
            }
        }

        // Update Seating capacity field
        if (rows * columns > 0)
            $scope.data.term.seating_capacity = rows * columns;
        else
            $scope.data.term.seating_capacity = 0;
        $scope.progressStop();
        var seat_container_width = ($scope.data.term.seats[0].length * 40) + 80 + "px";
        $scope.seat_container_width = {"width": seat_container_width};
        if ($scope.data.term.seating_capacity == rows * columns) {
            $scope.termForm.seating_capacity.$setValidity("invalidCapacity", true);
        }
    }
    
    $scope.em_call_scheme_popup = function (dialog) {

        var selectedSeatSeq = [];
        for (var i = 0; i < $scope.selectedSeats.length; i++) {
            selectedSeatSeq[i] = $scope.selectedSeats[i].seatSequence;
        }


        jQuery("#custom_seat_sequences").val(selectedSeatSeq.join());

        var pmId = dialog + "-dialog";

        jQuery(pmId).siblings('.pm-popup-mask').show();
        jQuery(pmId).show();
        jQuery('.pm-popup-container').css("animation", "pm-popup-in 0.3s ease-out 1");

        $scope.scheme_popup = $scope.scheme_popup ? false : true;
    }
    
    $scope.showSeatOptions = function (seat)
    {
        $scope.currentSeat = seat;
    }

    $scope.updateCurrentSeat = function ()
    {
        $scope.currentSeat.seatSequence = jQuery("#custom_seat_seq").val();
    }

    $scope.updateCurrentSeatScheme = function ()
    {
        var str = jQuery("#custom_seat_sequences").val();
        var strval = str.split(',');
        if (strval.length == $scope.selectedSeats.length && strval.length > 0) {

            for (var i = 0; i < $scope.selectedSeats.length; i++) {
                //  console.log(strval[i]);
                if (strval[i].trim() != "")
                    $scope.selectedSeats[i].seatSequence = strval[i];
            }
        } 
        $scope.scheme_popup= false;
    }
    $scope.$on('beforeVenueSave', function(e) {  
        $scope.resetSelections(); 
        if($scope.data.term.type!='standings'){
            var totalSeats= $scope.rows*$scope.columns;
            if($scope.data.term.seats.length==0 || totalSeats!=($scope.data.term.seats.length*$scope.data.term.seats[0].length))
            {
                $scope.$parent.formErrors.push("Number of seats are not matching with capacity. Please click on 'Create Seating Arrangement' to generate seats as per given rows and column values.");
                jQuery('html, body').animate({scrollTop: 0}, 'slow');
            }
        }
        
    });

    $scope.changeSeatColor = function(color){
        $scope.seat_border_color = '3px solid #'+color;
        $scope.seat_color = '#'+color;
    }
});