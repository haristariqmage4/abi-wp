<div class="kikfyre kf-container"  ng-controller="eventCtrl" ng-app="eventMagicApp" ng-cloak ng-init="initialize('save_seating')">
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>
    <div class="kf-db-content">
        <div class="kf-db-title">
            <?php _e('Seating Arrangement', 'eventprime-event-seating'); ?>
        </div>
        <div class="form_errors">
            <ul>
                <li class="emfield_error" ng-repeat="error in  formErrors">
                    <span>{{error}}</span>
                </li>
            </ul>  
        </div>
        <!-- FORM -->
        <form  name="postForm" ng-submit="savePost(postForm.$valid)" novalidate>
            <div>
                <!--<span class="kf_dragger">&#x2020;</span> <a ng-click="showSeats = !showSeats" /><button class="kf-seatinng-arrangement"><?php //_e('Edit Seating Arrangement', 'eventprime-event-seating'); ?></button></a>-->
                <div ng-show="data.post.venue>0 && data.post.seats.length>0">
                    <div class="emrow em_seat_table kf-bg-light" >
                        <table class="em_venue_seating" ng-style="seat_container_width">
                            <tr ng-repeat="row in data.post.seats" class="row isles_row_spacer" id="row{{$index}}" ng-style="{'margin-top':row[0].rowMargin}">
                                <td class="row_selection_bar" ng-click="selectRow($index)">
                                    <div class="em_seat_row_number">{{getRowAlphabet($index)}}</div>
                                </td>
                                <td ng-repeat="seat in row" ng-init="adjustContainerWidth(seat.columnMargin, $parent.$index)" class="seat isles_col_spacer" ng-class="seat.type" id="ui{{$parent.$index}}-{{$index}}" ng-style="{'margin-left':seat.columnMargin, 'border':seat.seatBorderColor, 'border-bottom': 0}">
                                    <div  ng-click="selectColumn($index)" ng-if="$parent.$index == 0" class="em_seat_col_number">{{$index + 1}}</div>
                                    <div class="seat_avail seat_avail_number seat_status">{{seat.col + 1}}</div>
                                    <div  id="pm_seat"  class="seat_avail seat_status" ng-click="selectSeat(seat, $parent.$index, $index, data.post.seat_color, data.post.selected_seat_color)" ng-click="showSeatOptions(seat)" ng-style="{'background-color': seat.seatColor}">{{seat.uniqueIndex}} </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="action_bar" ng-show="data.post.seats.length>0">
                        <ul>
                            <li class="difl"><input type="button" value="<?php _e('Reserve','eventprime-event-seating'); ?>" ng-click="reserveSeat(data.post.reserved_seat_color)"/></li>
                            <li class="difl"><input type="button" value="<?php _e('Reset current Selection','eventprime-event-seating'); ?>" ng-click="resetSelections(data.post.seat_color)"/></li>
                            <li class="difl"><input type="button" value="<?php _e('Sync with Event Site','eventprime-event-seating'); ?>" ng-click="syncWithVenue()"/></li>
                            <li class="difl"><input type="button" ng-disabled="selectedSeats.length==0" value="<?php _e('Select Scheme','eventprime-event-seating'); ?>" ng-click="em_call_scheme_popup('#change-scheme')"/></li>
                        </ul>
                    </div>
                </div>
                <div ng-show="data.post.venue==0 || data.post.venue=='' || data.post.seats.length==0">
                    <?php _e('No seats are available to arrange.','eventprime-event-seating'); ?>
                </div>
            </div>
            <div class="dbfl kf-buttonarea">
                <div class="em_cancel"><a class="kf-cancel" href="<?php echo admin_url('/admin.php?page=em_dashboard&post_id=' . $post_id); ?>"> <?php _e('Cancel', 'eventprime-event-seating'); ?></a></div>
                <button type="submit" class="btn btn-primary" ng-disabled="postForm.$invalid || requestInProgress"> <?php _e('Save', 'eventprime-event-seating'); ?></button>
            </div>
            <div class="dbfl kf-required-errors" ng-show="postForm.$dirty && postForm.$invalid">
                <h3></h3>
            </div>
        </form>
        <div id="show_popup" ng-show="scheme_popup">
            <div class="pm-popup-mask"></div>
            <div id="change-scheme-dialog">
                <div class="pm-popup-container">
                    <div class="pm-popup-title pm-dbfl pm-bg-lt pm-pad10 pm-border-bt">
                        <div class="pm-popup-action pm-dbfl pm-pad10 pm-bg">
                            <div class="pm-login-box GCal-confirm-message">
                                <div class="pm-login-box-error pm-pad10" style="display:none;" id="pm_reset_passerror">
                                </div>
                                <!-----Form Starts----->
                                <div class="kf-seat_schemes dbfl">
                                    <div class="kf-seat_schemes-titlebar">
                                        <div class="kf-seat_schemes-title"><?php _e('Scheme(s)','eventprime-event-seating'); ?></div>
                                        <span  class='kf-popup-close' ng-click="scheme_popup = false">&times;</span>
                                    </div>
                                    <div class="emrow">
                                        <div class="emfield"> <?php _e('Current scheme(s)','eventprime-event-seating'); ?></div>
                                        <div class="eminput"> <div class="kf-seat_scheme difl" ng-repeat="row in selectedSeats" >
                                                {{row.seatSequence}}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="emrow">
                                        <div class="emfield"> <?php _e('Change scheme(s)','eventprime-event-seating'); ?></div>
                                        <div class="eminput">  <textarea id="custom_seat_sequences"></textarea></div>
                                    </div>
                                    <div class="emrow kf-popup-button-area">
                                        <input type="button" value="Update" ng-click="updateCurrentSeatScheme()" /></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>        
</div>