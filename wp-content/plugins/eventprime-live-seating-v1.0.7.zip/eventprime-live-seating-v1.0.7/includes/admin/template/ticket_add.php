<div class="kikfyre kf-container"  ng-controller="eventTicketCtrl" ng-app="eventMagicApp" ng-cloak ng-init="initialize('edit')">
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>

    <div class="kf-db-content">
        <div class="kf-db-title">
            <?php _e('Add/Edit Ticket', 'eventprime-event-seating'); ?>
        </div>
        <div class="form_errors">
            <ul>
                {{formErrors}} 
            </ul>

        </div>

        <!-- FORM -->
        <form name="postForm" ng-submit="saveEventTicket(postForm.$valid)" novalidate class="em_ticket_form">

            <div class="em_ticket_template">
                <div class="kf-ticket-wrapper"> 
                    <div class="kf-event-details-wrap">
                        <div class="kf-font-color1 kf-event-title dbfl" ng-style="data.ticket_font_family1"><?php echo _e('Event Name','eventprime-event-seating'); ?></div>
                        <div class="kf-logo-details dbfl">
                            <div class="kf-event-logo difl">
                                <img  ng-src="{{data.post.logo_image}}" >&nbsp;
                            </div>
                            <div class="event-details difl">
                                <div class="dbfl">
                                    <div class="kf-ticket-row dbfl">
                                        <div class="kf-font-color1 kf-event-title"></div>
                                        <p class="kf-font-color1 kf-font1" ng-style="data.ticket_font_family1"><?php _e('21st December, 2017 4:30 PM-7:00 PM', 'eventprime-event-seating'); ?></p>
                                    </div>
                                    <div class="kf-spacer dbfl"></div>
                                    <div class="kf-ticket-row dbfl">
                                        <p class="kf-font-color1 kf-font1" ng-style="data.ticket_font_family1"><?php _e('EVENT SITE NAME', 'eventprime-event-seating'); ?></p>
                                        <p class="kf-font-color1 kf-font2" ng-style="data.ticket_font_family1"><?php _e('Address Line 1, Address Line 2, City  ZipCode', 'eventprime-event-seating'); ?></p>
                                    </div>
                                    <div class="kf-ticket-row dbfl">
                                        <p class="kf-font-color1 kf-font1" ng-style="data.ticket_font_family1"><?php _e('BOOKING COORDINATOR', 'eventprime-event-seating'); ?></p>
                                    </div>
                                    <div class="kf-ticket-row dbfl">
                                        <p class="kf-font-color1 kf-font1" ng-style="data.ticket_font_family1"><?php _e('Age group: 18 years and above', 'eventprime-event-seating'); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="kf-ticket-blank">&nbsp;</div>
                        </div>
                        <div class="kf-note-price-wrap dbfl">
                            <div class="kf-note-price">
                                <div class="kf-special-note kf-font-color1"  ng-style="data.ticket_font_family1">
                                    <?php _e('Special Instructions: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sagittis eget
                                        ex sit amet tempor. Maecenas mi nunc, pellentesque quis eleifend eget, fermentum vel nulla.', 'eventprime-event-seating'); ?>
                                </div>
                                <div class="kf-ticket-price">
                                    <span class="kf-font-color1 kf-font1 kf-price-tag dbfl"  ng-style="data.ticket_font_family1"><?php _e('Price', 'eventprime-event-seating'); ?></span>
                                    <span class="kf-price dbfl kf-font-color1"  ng-style="data.ticket_font_family1"><?php _e('$10', 'eventprime-event-seating'); ?><sup class="kf-font-color1">.00</sup></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Seat Number -->
                    <div class="kf-seat-wrap">
                        <div class="dbfl">
                            <p class="kf-font-color1 kf-seat-tag" ng-style="data.ticket_font_family1"><?php _e('SEAT NO.', 'eventprime-event-seating'); ?></p>
                            <div class="kf-font-color1 kf-seat-no" ng-style="data.ticket_font_family1"><?php _e('A-21', 'eventprime-event-seating'); ?></div>
                            <p class=" kf-font-color1 kf-seat-id" ng-style="data.ticket_font_family1"><?php _e('ID # 1003459234', 'eventprime-event-seating'); ?></p>
                        </div>
                    </div>
                </div>

                <div class="emrow">
                    <div class="emfield"><?php _e('Name', 'eventprime-event-seating'); ?><sup>*</sup></div>
                    <div class="eminput">
                        <input placeholder="" required  type="text" name="name"  ng-model="data.post.name">
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Unique template name for identification.', 'eventprime-event-seating'); ?>
                    </div>
                </div>

                <div class="emrow">
                    <div class="emfield"><?php _e('Font', 'eventprime-event-seating'); ?></div>
                    <div class="eminput">
                        <select name="font1" ng-change="changeStyle()" ng-model="data.post.font1"  ng-options="font as font for font in data.post.fonts"></select>
                        <div class="emfield_error">
                        </div>
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Font to be used in ticket template.', 'eventprime-event-seating'); ?>
                    </div>
                </div>
                <!-- -->
                <div class="emrow">
                    <div class="emfield"><?php _e('Font Color', 'eventprime-event-seating'); ?></div>
                    <div class="eminput">
                        <input id="em_font1_color_picker" ng-change="changeStyle()" class="jscolor"  type="text" name="font_color"  ng-model="data.post.font_color" >
                        <div class="emfield_error">
                        </div>
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e("Ticket font's color. Will be visible in PDF format.", 'eventprime-event-seating'); ?>
                    </div>
                </div>

                <!-- -->
                <div class="emrow">
                    <div class="emfield"><?php _e('Background Color', 'eventprime-event-seating'); ?></div>
                    <div class="eminput">
                        <input id="em_background_color_picker" ng-change="changeStyle()" class="jscolor"  type="text" name="background_color"  ng-model="data.post.background_color" >
                        <div class="emfield_error">
                        </div>
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Ticket background color. Will be visible in PDF format.', 'eventprime-event-seating'); ?>
                    </div>
                </div>

                <div class="emrow">
                    <div class="emfield"><?php _e('Border Color', 'eventprime-event-seating'); ?></div>
                    <div class="eminput">
                        <input id="em_border_color_picker" ng-change="changeStyle()" class="jscolor" type="text" name="border_color"  ng-model="data.post.border_color" >
                        <div class="emfield_error">
                        </div>
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Ticket border color. Will be visible in PDF format.', 'eventprime-event-seating'); ?>
                    </div>
                </div>

                <div class="emrow">
                    <div class="emfield"><?php _e('Logo','eventprime-event-seating'); ?></div>
                    <div class="eminput">
                        <input type="button" class="kf-upload" value="<?php _e('Upload', 'eventprime-event-seating'); ?>" ng-click="mediaUploader(false)" />
                        <div class="em_cover_image">
                            <image ng-src="{{data.post.logo_image}}" />
                        </div>
                        <div class="emfield_error">
                        </div>
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Logo for the Event or Organizer. This will be visible on ticket printouts.', 'eventprime-event-seating'); ?>
                    </div>
                </div>




                <input type="text" name="logo" ng-model="data.post.logo" class="hidden" />
                <div class="dbfl kf-buttonarea">
                    <div class="em_cancel"><a class="kf-cancel" ng-href="<?php echo admin_url('/admin.php?page=em_ticket_templates'); ?>"><?php _e('Cancel', 'eventprime-event-seating'); ?></a></div>
                    <button type="submit" class="btn btn-primary" ng-disabled="postForm.$invalid"><?php _e('Save', 'eventprime-event-seating'); ?></button>


                </div>

                <div class="dbfl kf-required-errors" ng-show="postForm.$invalid && postForm.$dirty">
                    <h3><?php _e("Looks like you missed out filling some required fields (*). You will not be able to save until all required fields are filled in. Here’s what's missing", 'eventprime-event-seating'); ?> - 

                        <span ng-show="postForm.name.$error.required"><?php _e('Name', 'eventprime-event-seating'); ?></span>
                    </h3>
                </div>


            </div>
        </form>
    </div>
</div>
