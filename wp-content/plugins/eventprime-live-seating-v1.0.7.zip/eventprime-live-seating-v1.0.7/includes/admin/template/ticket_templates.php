<div class="kikfyre" ng-app="eventMagicApp" ng-controller="eventTicketCtrl" ng-init="initialize('list')" ng-cloak>
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>     
    <div class="kf-operationsbar dbfl">
             <div class="kf-title difl">
        <?php $manager_navs= em_manager_navs(); ?>
        <select class="kf-dropdown" onchange="em_manager_nav_changed(this.value)">
            <?php foreach($manager_navs as $nav): ?>
            <option <?php echo $nav['key']=='em_ticket_templates' ? 'selected' : ''; ?> value="<?php echo $nav['key']; ?>"><?php echo $nav['label']; ?></option>
            <?php endforeach; ?>
        </select>
             </div>
        <div class="kf-icons difr">
           
        </div>
        <div class="kf-nav dbfl">
            <ul>
                <li><a class="em_action_bar_button" href="<?php echo admin_url('/admin.php?page=em_ticket_templates&tab=add'); ?>"><?php _e('Add New','eventprime-event-seating'); ?></a></li>
                <li><button class="em_action_bar_button" ng-click="duplicatePosts()" ng-disabled="selections.length == 0" ><?php _e('Duplicate','eventprime-event-seating'); ?></button></li>
                <li><button class="em_action_bar_button" ng-click="deletePosts()" ng-disabled="selections.length == 0" ><?php _e('Delete','eventprime-event-seating'); ?></button></li>          
            </ul>
        </div>

    </div>

    <div class="emagic-table dbfl">
                <table class="kf-tickets-table"><!-- remove class for default 80% view -->
                    <tr>
                        <th class="table-header"><input type="checkbox" ng-model="selectedAll" ng-click="markAll()" /></th>
                        <th class="table-header"><?php _e('Name','eventprime-event-seating'); ?></th>
                        <th class="table-header"><?php _e('Action','eventprime-event-seating'); ?></th>
                    </tr>
                    
                    <tr ng-repeat="post in data.posts">
                        <td>
                            <input type="checkbox"  ng-model="post.Selected" ng-click="selectPost(post.id)"  ng-true-value="{{post.id}}" ng-false-value="0" id="{{post.id}}"><label for="{{post.id}}">{{post.name}}</label>
                        </td>
                        <td>{{post.name}}</td>
                        <td>
                            <a ng-href="<?php echo admin_url('/admin.php?page=em_ticket_templates&tab=add'); ?>&post_id={{post.id}}"><?php _e('View/Edit','eventprime-event-seating'); ?></a>
                        </td>
                    </tr>
                </table>
            </form>
            
            <div class="em_empty_card" ng-show="data.posts.length==0">
                <?php _e('Ticket Template you create will appear here in tabular Format . Presently, you do not have any Ticket Template created.','eventprime-event-seating'); ?>
            </div>
            
    </div>
    
    
    <div class="kf-pagination dbfr" ng-show="data.posts.length!==0"> 
        <ul>
             <li dir-paginate="post in data.total_posts| itemsPerPage: data.pagination_limit"></li>
        </ul>
         <dir-pagination-controls on-page-change="pageChanged(newPageNumber)"></dir-pagination-controls>
    </div>
</div>



