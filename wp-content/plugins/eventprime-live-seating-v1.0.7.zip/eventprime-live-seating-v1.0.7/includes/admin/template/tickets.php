<div class="kikfyre kf-container"  ng-controller="eventCtrl" ng-app="eventMagicApp" ng-cloak ng-init="initialize('save_tickets')">
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>
    <div class="kf-db-content">
        <div class="kf-db-title">
            <?php _e('Tickets', 'eventprime-event-seating'); ?>
        </div>
        <div class="form_errors">
            <ul>
                <li class="emfield_error" ng-repeat="error in  formErrors">
                    <span>{{error}}</span>
                </li>
            </ul>  
        </div>
        
        <!-- FORM -->
        <form  name="postForm" ng-submit="savePost(postForm.$valid)" novalidate>

            <div class="emrow" >
                <div class="emfield"> <span class="kf_dragger">&#x2020;</span><?php _e('Enable Ticket', 'eventprime-event-seating'); ?></div>
                <div class="eminput">
                    <input type="checkbox" name="en_ticket"  ng-model="data.post.en_ticket" ng-true-value="1" ng-false-value="0" ng-disabled="<?php echo !empty($event->enable_booking) ? false: true; ?>">
                </div>
            </div>


            <div ng-show="data.post.en_ticket == 1" class="<?php echo !empty($event->enable_booking) ? '' : 'em-disabled' ?>">
                <div class="emrow">
                    <div class="emfield"><?php _e('Ticket Template', 'eventprime-event-seating'); ?></div>
                    <div class="eminput">
                        <select name="ticket_template"  ng-model="data.post.ticket_template" ng-options="ticket_template.id as ticket_template.name for ticket_template in data.post.ticket_templates"></select>
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Ticket template to be used in emails and printing. You may add/customize it with Ticket Manager.', 'eventprime-event-seating'); ?>
                    </div>
                </div>

                <div class="emrow" >            
                    <div class="emfield"><span class="kf_dragger">&#x2020;</span><?php _e('Max Tickets Per Booking', 'eventprime-event-seating'); ?></div>
                    <div class="eminput">
                        <input  type="number" ng-min="0"  name="max_tickets_per_person"  ng-model="data.post.max_tickets_per_person" >

                        <div class="emfield_error">
                            <span ng-show="postForm.max_tickets_per_person.$error.number && !postForm.max_tickets_per_person.$pristine"><?php _e('Only numeric value allowed.', 'eventprime-event-seating'); ?></span>
                            <span ng-show="postForm.max_tickets_per_person.$error.min"><?php _e('Invalid Value.', 'eventprime-event-seating'); ?></span>
                            <span ng-show="postForm.max_tickets_per_person.$error.exceededCapacity"><?php _e('Value can not exceed total capacity.', 'eventprime-event-seating'); ?></span>
                        </div>
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('No. of seats allowed per booking.', 'eventprime-event-seating'); ?>
                    </div>
                </div>

                <div class="emrow" >

                    <div class="emfield"> <span class="kf_dragger">&#x2020;</span><?php _e('Allow Volume Discount', 'eventprime-event-seating'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" name="allow_discount"  ng-model="data.post.allow_discount" ng-true-value="1" ng-false-value="0">
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Enable volume discount for booking multiple tickets.', 'eventprime-event-seating'); ?>
                    </div>
                </div>

                <div id="em_volume_discount" >

                    <div class="emrow">
                        <div class="emfield"><?php echo _e('Minimum Number Of Tickets', 'eventprime-event-seating'); ?><sup>*</sup></div>
                        <div class="eminput">
                            <input ng-required="post.allow_discount==1" ng-min="2" type="number" name="discount_no_tickets"  ng-model="data.post.discount_no_tickets">
                            <div class="emfield_error">
                                <span ng-show="postForm.discount_no_tickets.$error.number && !postForm.discount_no_tickets.$pristine"><?php _e('Only numeric value allowed.', 'eventprime-event-seating') ?></span>
                                <span ng-show="postForm.discount_no_tickets.$error.min && !postForm.discount_no_tickets.$pristine"><?php _e('Invalid Value', 'eventprime-event-seating'); ?></span>
                                <span ng-show="postForm.discount_no_tickets.$error.exceededCapacity"><?php _e('Value can not exceed total capacity.', 'eventprime-event-seating'); ?></span>
                                <span ng-show="postForm.discount_no_tickets.$error.required && !postForm.discount_no_tickets.$pristine"><?php _e('This is a required field.', 'eventprime-event-seating'); ?></span>
                            </div>
                        </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php echo _e('Minimum no. of tickets to be applicable for volume discount.', 'eventprime-event-seating'); ?>
                        </div>
                    </div>

                    <div class="emrow" >
                        <div class="emfield"><?php echo _e('Discount Percentage(%)', 'eventprime-event-seating'); ?><sup>*</sup></div>
                        <div class="eminput">
                            <input ng-required="post.allow_discount==1" ng-max="100"  type="number" name="discount_per"  ng-model="data.post.discount_per">
                            <div class="emfield_error">
                                <span ng-show="postForm.discount_per.$error.number && !postForm.discount_per.$pristine"><?php _e('Only numeric value allowed.', 'eventprime-event-seating') ?></span>
                                <span ng-show="postForm.discount_per.$error.min && !postForm.discount_per.$pristine"><?php _e('Invalid Value', 'eventprime-event-seating') ?></span>
                                <span ng-show="postForm.discount_per.$error.max && !postForm.discount_per.$pristine"><?php _e('Can not be more than 100%', 'eventprime-event-seating') ?></span>
                                <span ng-show="postForm.discount_per.$error.required && !postForm.discount_per.$pristine"><?php _e('This is a required field.', 'eventprime-event-seating') ?></span>
                            </div>
                        </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php echo _e('Discount percentage allowed on volume discount.', 'eventprime-event-seating'); ?>
                        </div>
                    </div>
                </div>

            </div>        


            <div class="dbfl kf-buttonarea">
                <div class="em_cancel"><a class="kf-cancel" href="<?php echo admin_url('/admin.php?page=em_dashboard&post_id=' . $post_id); ?>"> <?php _e('Cancel', 'eventprime-event-seating'); ?></a></div>
                <button type="submit" class="btn btn-primary" ng-disabled="postForm.$invalid || requestInProgress"> <?php _e('Save', 'eventprime-event-seating'); ?></button>

            </div>


            <div class="dbfl kf-required-errors" ng-show="postForm.$dirty && postForm.$invalid">
                <h3>
                    <span ng-show="postForm.discount_no_tickets.$error.required"><?php _e('Discount : No. of tickets', 'eventprime-event-seating'); ?></span>
                    <span ng-show="postForm.discount_per.$error.required"><?php _e('Discount(%)', 'eventprime-event-seating'); ?></span>
                </h3>

            </div>

        </form>
    </div>
</div>


