<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
class EM_Seating_Public {

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'event_magic_print_ticket',array($this,'print_ticket'));
        add_filter('event_magic_data_before_print',array($this,'data_before_print'),10,3);
        add_action('wp_ajax_front_print_ticket',array($this,'front_print_ticket'));
        add_action('wp_ajax_nopriv_front_print_ticket',array($this,'front_print_ticket'));
        add_action('event_magic_venue_seatings_frontend_submission',array($this,'venue_add_fes'));
    }
    
    public function print_ticket($booking){
        $service = EventM_Factory::get_service('EventM_Service');
        $event = $service->load_model_from_db($booking->event);
        if(empty($event->en_ticket))
            return;
        $order_info = $booking->order_info;?>
        <tr id="em_print_bar">
            <?php 
            if($booking->status == 'completed'):
                $send_ticket_opr = em_global_settings('send_ticket_on_payment_received');
                $custom_note_tpa = em_global_settings('custom_note_ticket_print_area');

                if( $order_info['payment_gateway'] == 'offline' && isset($send_ticket_opr) && $send_ticket_opr == 1 && isset($custom_note_tpa) && !empty($custom_note_tpa)){ ?>
                    <td><?php printf( __( '%s', 'eventprime-event-seating' ), $custom_note_tpa ); ?></td>
                    <td>
                        <select id="em_seat_no" onchange="em_show_ticket_print_btn(this.value)">
                            <option selected="" disabled="disabled" value=""><?php _e('Select Ticket','eventprime-event-seating'); ?></option>
                        </select>
                    </td>
                <?php
                }else{   
                    if(!empty($order_info['seat_sequences'])):?>
                        <td><?php _e('Select seat no. to download Ticket','eventprime-event-seating'); ?></td>
                        <td>
                            <select id="em_seat_no" onchange="em_show_ticket_print_btn(this.value)">
                                <option selected="" disabled="disabled" value=""><?php _e('Select Ticket','eventprime-event-seating'); ?></option>
                                <?php foreach($order_info['seat_sequences'] as $seats): ?>
                                    <option value="<?php echo $seats;?>"><?php echo $seats;?></option>
                                <?php endforeach;?>
                            </select>
                            <input onclick="print_seating_ticket('<?php echo admin_url("admin-ajax.php?action=front_print_ticket&id=".$booking->id) ?>')" id="em_print_btn" type="button" style="display:none" value="<?php _e('Print','eventprime-event-seating'); ?>" />
                        </td>
                    <?php else: ?>
                        <td><?php _e('Click here to download Ticket','eventprime-event-seating'); ?></td>
                        <td>
                            <a href="<?php echo admin_url('admin-ajax.php?action=front_print_ticket&id='.$booking->id) ?>"><?php _e('Ticket','eventprime-event-seating'); ?></a>
                        </td>
                    <?php endif; ?>
                <?php }?>
            <?php endif; ?>
        </tr>   
    <?php }
    
    public function data_before_print($data,$event,$booking){
        if(empty($event->en_ticket))
            return $data;
        $ticket_service= EventM_Factory::get_service('EventM_Ticket_Service');
        $ticket= $ticket_service->load_model_from_db($event->ticket_template);
        $data['font_color'] = empty($ticket->font_color) ? '865C16' : $ticket->font_color;
        $data['font1'] = empty($ticket->font2) ? 'Times' : $ticket->font2;
        $logo= wp_get_attachment_url($ticket->logo);
        $data['ticket_logo1'] = empty($logo) ? '' : $logo;
        $data['background_color']= empty($ticket->background_color) ? 'E2C699' : $ticket->background_color;
        $data['border_color']= empty($ticket->border_color) ? 'C8A366' : $ticket->border_color;
        return $data;
    }
    
    public function front_print_ticket(){ 
        $booking_id= event_m_get_param('id');
        $bs= EventM_Factory::get_service('EventM_Booking_Service');
        $booking=$bs->load_model_from_db($booking_id);
        if(empty($booking->id)){
            die(__('Booking does not exist.','eventprime-event-seating'));
        }
        // Check if booking belongs to current user
        $user = wp_get_current_user();
        if(empty($user->ID) && !em_show_book_now_for_guest_users()){
            die(__('You are not authorized to access the resource','eventprime-event-seating'));
        }
        if($booking->user != $user->ID && !em_show_book_now_for_guest_users()){
            die(__('You are not allowed to access the resource','eventprime-event-seating'));
        }
        
        $es= EventM_Factory::get_service('EventM_Service');
        $event= $es->load_model_from_db($booking->event);
        $vs= EventM_Factory::get_service('EventM_Venue_Service');
        $venue=$vs->load_model_from_db($event->venue);
        if(!empty($booking->order_info['seat_pos'])){
            $seat_no= event_m_get_param('seat_no');
            $html = EventM_Print::front_ticket($booking,$seat_no);
            $args= array('name'=>$event->name.'-ticket-'.$seat_no);
            if(!empty($event->ticket_template)){
                $ts= EventM_Factory::get_service('EventM_Ticket_Service');
                $tt= $ts->load_model_from_db($event->ticket_template);
                if(!empty($tt->id)){
                    $args['font']= $tt->font1;
                }
            }
            $args['title']= __('Ticket','eventprime-event-seating');
        }
        else{ // Printing standing type of event
            $html = EventM_Print::front_ticket($booking);
            $args= array('name'=>$event->name.'-ticket');
            // Check for any font
            if(!empty($event->ticket_template)){
                $ts= EventM_Factory::get_service('EventM_Ticket_Service');
                $tt= $ts->load_model_from_db($event->ticket_template);
                if(!empty($tt->id)){
                    $args['font']= $tt->font1;
                }
            }
            $args['title']= __('Ticket','eventprime-event-seating');
        }
        
        EventM_Print::print_html($html,$args);
        
        exit();
    }

    public function venue_add_fes($term_id){
        wp_register_script('em-venue-seat-fes-controller', EMS_BASE_URL.'includes/front/js/em-venue-fes-controller.js');
        wp_enqueue_script('em-venue-seat-fes-controller');
        wp_register_style('em-venue-seat-fes-css', EMS_BASE_URL.'includes/front/css/em-venue-fes.css');
        wp_enqueue_style('em-venue-seat-fes-css');
        em_localize_map_info();
        include('front/venue_add_fes.php');
    }
}

return new EM_Seating_Public();