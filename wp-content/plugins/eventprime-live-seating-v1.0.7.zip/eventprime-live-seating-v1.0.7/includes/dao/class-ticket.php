<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * @summary Dao class for Event Ticket. 
 * 
 * Functions
 * 1. edit_event_ticket :  Responsible for adding and editing the record.
 */
class EventM_Event_Ticket_DAO extends EventM_Post_Dao
{
    
    public function __construct() {
        $this->post_type= EM_TICKET_POST_TYPE;
    }
    public function get_templates($args= array()){
        $defaults = array(
	'orderby'          => 'date',
	'order'            => 'DESC',
	'post_type'        => $this->post_type,
	'post_status'      => 'publish',
        'numberposts'      =>  -1
            );
        $args= wp_parse_args($args,$defaults);  
        $posts= get_posts($args);
        if(empty($posts))
            return null;
        
        return $posts;
    }
    
    public function get($id)
    {
        $post= get_post($id);
        if(empty($post))
            return new EventM_Ticket_Model(0);
        
        $ticket= new EventM_Ticket_Model($id);
        $meta= $this->get_meta($id,'',true);
        foreach ($meta as $key=>$val) {
            $key= str_replace('em_','',$key);
            if (property_exists($ticket, $key)) {
               $ticket->{$key}= maybe_unserialize($val[0]);
            }
        }
        $ticket->id= $post->ID;
        $ticket->name=$post->post_title;
        return $ticket;
    }
    
}
