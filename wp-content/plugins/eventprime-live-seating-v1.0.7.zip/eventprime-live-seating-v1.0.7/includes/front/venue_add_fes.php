<div class="ep-seat-booking-container kf-container" ng-controller="venueSeatFesCtrl" ng-cloak>
    <div ng-show="data.settings.seating_type == 'seats'">
        <div class="em_input_row dbfl">           
            <div class="em_input_form_field">
                <label class="em_input_label"><?php _e('Seating Capacity', 'eventprime-event-seating'); ?><sup>*</sup></label>
                <input class="em_input_field" ng-required="data.settings.seating_type == 'seats'" type="number" name="seating_capacity"  ng-model="data.settings.seating_capacity">
                <div class="emfield_error">
                    <span ng-show="emEventSubmitForm.seating_capacity.$error.number && chkFormSubmitted"><?php _e('Only numeric value allowed.', 'eventprime-event-seating'); ?></span>
                    <span ng-show="emEventSubmitForm.seating_capacity.$error.min && chkFormSubmitted"><?php _e('Value should be greater than 0', 'eventprime-event-seating'); ?></span>
                    <span ng-show="emEventSubmitForm.seating_capacity.$error.required && chkFormSubmitted"><?php _e('This is a required field.', 'eventprime-event-seating'); ?></span>
                    <span ng-show="emEventSubmitForm.seating_capacity.$error.invalidCapacity && chkFormSubmitted"><?php _e('Capacity does not match with seating structure.', 'eventprime-event-seating'); ?></span>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                <?php _e('Seating capacity. This should be in sync with seating area (Rows and Columns).', 'eventprime-event-seating'); ?>
               </div>
            </div>
            
        </div>
        <div class="em_input_row ep_input_row_half dbfl">
             <div class="em_input_form_field">
            <label class="em_input_label"><?php _e('Rows', 'eventprime-event-seating'); ?><sup>*</sup></label>           
                <input class="em_input_field" id="row" ng-required="data.settings.seating_type == 'seats'" ng-min='1' type="number" ng-model="rows" name="rows" />
                <div class="emfield_error">
                    <span ng-show="emEventSubmitForm.rows.$error.number && chkFormSubmitted"><?php _e('Only numeric value allowed.', 'eventprime-event-seating'); ?></span>
                    <span ng-show="emEventSubmitForm.rows.$error.required && chkFormSubmitted"><?php _e('This is a required field.', 'eventprime-event-seating'); ?></span>
                    <span ng-show="emEventSubmitForm.rows.$error.min && chkFormSubmitted"><?php _e('Value should be greater than 0', 'eventprime-event-seating'); ?></span>
                </div>
            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                <?php _e('No. of rows in the seating area.', 'eventprime-event-seating'); ?>
            </div>
            </div>

        </div>
        <div class="em_input_row ep_input_row_half dbfl">
            <div class="em_input_form_field">
                <label class="em_input_label"><?php _e('Columns', 'eventprime-event-seating'); ?><sup>*</sup></label>         
                <input id="col" class="em_input_field" ng-required="data.settings.seating_type == 'seats'" ng-min='1' type="number" ng-model="columns" name="columns" />
                <div class="emfield_error">
                    <span ng-show="emEventSubmitForm.columns.$error.number && chkFormSubmitted"><?php _e('Only numeric value allowed.', 'eventprime-event-seating'); ?></span>
                    <span ng-show="emEventSubmitForm.columns.$error.required && chkFormSubmitted"><?php _e('This is a required field.', 'eventprime-event-seating'); ?></span>
                    <span ng-show="emEventSubmitForm.columns.$error.min && chkFormSubmitted"><?php _e('Value should be greater than 0', 'eventprime-event-seating'); ?></span>
                </div>
            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                <?php _e('No. of columns in the seating area.', 'eventprime-event-seating'); ?>
            </div>
            </div>

        </div>
        <div class="em_input_row ep_input_row_half dbfl">
            <div class="em_input_form_field">
                <label class="em_input_label"><?php _e('Seat Available Color', 'eventprime-event-seating'); ?></label>
                <input id="em_color_picker" class="jscolor em_input_field"  type="text" name="seat_color" ng-model="data.settings.seat_color" ng-change="changeSeatColor(data.settings.seat_color)" >
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Define the color of the available seat icon in dashboard seat plan and frontend user seat selection view.', 'eventprime-event-seating'); ?>
                </div>
            </div>

        </div>
        <div class="em_input_row ep_input_row_half dbfl">
            <div class="em_input_form_field">
                <label class="em_input_label"><?php _e('Seat Booked Color', 'eventprime-event-seating'); ?></label>
                <input id="em_color_picker_booked" class="jscolor em_input_field"  type="text" name="booked_seat_color"  ng-model="data.settings.booked_seat_color">
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e(' Define the color of the already booked seat icon in dashboard seat plan and frontend user seat selection view.', 'eventprime-event-seating'); ?>
                </div>

            </div>

        </div>
        <div class="em_input_row ep_input_row_half dbfl">
            <div class="em_input_form_field">
                <label class="em_input_label"><?php _e('Seat Reserved Color', 'eventprime-event-seating'); ?></label>          
                <input id="em_color_picker_reserved" class="jscolor em_input_field"  type="text" name="reserved_seat_color"  ng-model="data.settings.reserved_seat_color">
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Define the color of the reserved seat icon in dashboard seat plan and frontend user seat selection view.', 'eventprime-event-seating'); ?>
                </div>
            </div>
        </div>
        
        <div class="em_input_row ep_input_row_half dbfl">
            <div class="em_input_form_field">
                <label class="em_input_label"><?php _e('Seat Selected Color', 'eventprime-event-seating'); ?></label>
                <input id="em_color_picker_selected" class="jscolor em_input_field"  type="text" name="selected_seat_color"  ng-model="data.settings.selected_seat_color">
            </div>
            <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                <?php _e('Define the color of the selected seat icon in frontend user seat selection view.', 'eventprime-event-seating'); ?>
            </div>
        </div>
        
        <div class="em_input_row  dbfl">
                <div class="difr ep-seat_sequence-bt"><input type="button" value="<?php _e('Create Seating Arrangement', 'eventprime-event-seating') ?>" ng-click="createSeats(rows, columns, data.settings.seat_color)" ng-disabled="(!rows) || (!columns)" class="kf-upload" /></div>
        </div>
        
        <div class="emrow em_seat_table kf-bg-light">
            <table class="em_venue_seating" ng-style="seat_container_width">
                <tr ng-repeat="row in data.settings.seats" class="row isles_row_spacer" id="row{{$index}}" ng-style="{'margin-top':row[0].rowMargin }">
                    <td class="row_selection_bar" ng-click="selectRow($index)">
                        <div title="Select Row">{{getRowAlphabet($index)}}</div>
                    </td>
                    <!--<div ng-if="$index==0" ng-click="selectColumn($index)">C-{{$index}}</div>-->
                    <td id="pm_seat" ng-repeat="seat in row" ng-init="adjustContainerWidth(seat)" class="seat isles_col_spacer" ng-class="seat.type" id="ui{{$parent.$index}}-{{$index}}"
                        ng-style="{'margin-left':seat.columnMargin, 'border':seat.seatBorderColor, 'border-bottom': 0}">
                        <div  class="kf-col-index em_seat_col_number" ng-if="$parent.$index == 0" ng-click="selectColumn($index)">{{$index+1}}</div>
                        <div  id="pm_seat"  class="seat_avail seat_status" ng-click="selectSeat(seat, $parent.$index, $index, data.settings.seat_color, data.settings.selected_seat_color)" ng-click="showSeatOptions(seat)" ng-style="{'background-color': seat.seatColor}">{{seat.uniqueIndex}} </div>
                    </td>
                </tr>
            </table>
        </div>
        <div class="ep-action_bar">
            <ul>
                <li class="difl"><input type="button" value="<?php _e('Add/Remove aisles', 'eventprime-event-seating'); ?>" ng-click="createAisles()" ng-disabled="currentSelection != 'row' && currentSelection != 'col'"/></li>
                <li class="difl"><input type="button" value="<?php _e('Reserve', 'eventprime-event-seating'); ?>" ng-click="reserveSeat(data.settings.reserved_seat_color)"/></li>
                <li class="difl"><input type="button" value="<?php _e('Reset Current Selection', 'eventprime-event-seating'); ?>" ng-click="resetSelections()"/></li>
                <li class="difl"><input type="button" ng-disabled="selectedSeats.length==0" value="<?php _e('Select Scheme', 'eventprime-event-seating'); ?>" ng-click="em_call_scheme_popup('#pm-change-password1')"/></li>
            </ul>
        </div>    
    </div>
    <div id="show_popup" ng-show = "scheme_popup">
        <div class="pm-popup-mask"></div>    
        <div id="pm-change-password1-dialog">
            <div class="pm-popup-container">
                <div class="pm-popup-title pm-dbfl pm-bg-lt pm-pad10 pm-border-bt">
                    <div class="pm-popup-action pm-dbfl pm-pad10 pm-bg">
                        <div class="kf-popup-box GCal-confirm-message">
                            <div class="pm-login-box-error pm-pad10" style="display:none;" id="pm_reset_passerror">
                            </div>
                            <!-----Form Starts----->
                            <div class="kf-seat_schemes dbfl">
                                <div class="kf-seat_schemes-titlebar">
                                    <div class="kf-seat_schemes-title"><?php _e('Scheme(s)', 'eventprime-event-seating'); ?></div>
                                    <span  class='kf-popup-close' ng-click="scheme_popup = false">&times;</span>
                                </div>
                                <div class="emrow em-fes-row">
                                    <div class="emfield"> <?php _e('Current Scheme(s)', 'eventprime-event-seating'); ?></div>
                                    <div class="eminput"> 
                                        <div class="kf-seat_scheme difl" ng-repeat="row in selectedSeats" >
                                            {{row.seatSequence}}
                                        </div>
                                    </div>
                                </div>
                                <div class="emrow em-fes-row">
                                    <div class="emfield"> <?php _e('Change Scheme(s)', 'eventprime-event-seating'); ?></div>
                                    <div class="eminput">  
                                        <textarea id="custom_seat_sequences"></textarea>
                                    </div>
                                </div>
                                <div class="emrow kf-popup-button-area">
                                    <input type="button" value="Update" ng-click="updateCurrentSeatScheme()" />
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>