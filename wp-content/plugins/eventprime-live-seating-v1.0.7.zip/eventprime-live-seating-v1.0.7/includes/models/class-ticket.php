<?php

class EventM_Ticket_Model extends EventM_Array_Model
{
    public $id;
    public $name;
    public $description='';
    public $template='';
    public $background_color;
    public $font_color;
    public $border_color;
    public $font1='';
    public $logo;
    public $fonts;
    public $slug;
    public $status="publish";
}