<?php
if (!defined( 'ABSPATH')){
    exit;
}

class EventM_Ticket_Service {
    
    private $dao;
    private static $instance = null;
    
    private function __construct() {
        $this->dao= new EventM_Event_Ticket_DAO();
    }
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }
    
    public function load_edit_page()
    {
        $id = absint(event_m_get_param('post_id')); 
        $ticket= $this->load_model_from_db($id);
        $ticket->fonts= $this->get_fonts_dropdown();
        $ticket->logo_image= $this->get_logo_image($ticket->logo);
        return $ticket;
    }
    
    public function load_list_page()
    {
        $response= new stdClass();
        $response->posts= array();
         
        $args = array(
            'posts_per_page' => EM_PAGINATION_LIMIT,
            'offset' => ((int) event_m_get_param('paged')-1) * EM_PAGINATION_LIMIT,
            'post_type' => EM_TICKET_POST_TYPE,
            'post_status' => 'publish');
        $templates = get_posts($args);
        
        foreach($templates as $tmp){
           $template= $this->load_model_from_db($tmp->ID);
           $data= $template->to_array();
           $response->posts[]= $data;
        }
        
        $post_count_obj = wp_count_posts($this->dao->post_type);
        $post_count= $post_count_obj->publish;
        $response->total_posts= range(1,$post_count);
        $response->pagination_limit= EM_PAGINATION_LIMIT;
        return $response;
    }
    
    public function save($model)
    {
        $template= $this->dao->save($model);
        return $template;
    }
    
    public function load_model_from_db($id)
    {
        return $this->dao->get($id);
    }
    
    public function map_request_to_model($id,$model=null)
    {  
        $ticket= new EventM_Event_Ticket_Model($id);
        $data= (array) $model;
        
        if(!empty($data) && is_array($data))
        {
            foreach($data as $key=>$val)
            {
                $method= "set_".$key;
                if(method_exists($ticket, $method))
                {
                    $ticket->$method($val);
                }
            }
        }
        return $ticket;
        
    }
    
    public function get_fonts_dropdown()
    {
        $fonts= EventM_Constants::get_fonts_cons();
        return $fonts;
    }
   
    public function get_logo_image($attach_id,$size='thumbnail')
    {
        $img= wp_get_attachment_image_src($attach_id,$size);
        if($img)
           return $img[0];
    }
    
    public function get_templates(){
        return $this->dao->get_templates();
    }
}
