<?php
/**
 * Plugin Name: EventPrime MailPoet
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that connect users with Mailpoet list.
 * Version: 1.0.2
 * Author: EventPrime
 * Text Domain: eventprime-event-mailpoet
 * Domain Path: /languages
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 6.0.1
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_MailPoet')) {

    final class EM_MailPoet {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.0.2';

        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;

        
        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }


        /**
         * Event_Magic Constructor.
         */
        private function __construct() {
            ob_start();
            $this->define_constants();
            $this->load_textdomain();
            $this->includes(); 
            $this->define_hooks();
            $em= event_magic_instance();
            array_push($em->extensions,'em_mailpoet');
        }
            
        public function define_constants(){
            $em= event_magic_instance();
            $em->define('EMMP_BASE_URL', plugin_dir_url(__FILE__));
            define('EMMP_VERSION', $this->version);
        }
        
        public function includes(){
            include_once('includes/dao/class-eventprime-mailpoet-activator.php');
            include_once('includes/dao/class-eventprime-mailpoet-dbhandler.php');
            include_once('includes/dao/class-eventprime-mailpoet-integration.php');
        }
        
        public function define_hooks(){
            add_action('wp_enqueue_scripts',array($this,'event_magic_enqueue_style_and_scripts'));
            add_action('event_magic_gs_settings',array($this,'event_mailpoet_gs_settings'));
            add_action('event_magic_custom_extensions_link',array($this,'dashboard_links'));
            add_action('event_magic_dashboard_mailpoet_tab',array($this,'mailpoet_tab'));
            add_action('event_magic_menus', array($this, 'menus'));
            
            add_action('event_magic_additional_fields',array($this,'em_show_optin_check_box_html'),10,1);
            
            // offline payment filter
            add_filter('event_magic_add_offline_payment_response', array($this, 'add_offline_payment_response'), 99, 2);
            // stripe payment filter
            add_filter('event_magic_add_stripe_payment_response', array($this, 'add_stripe_payment_response'), 99, 2);
            // without payment filter
            add_filter('event_magic_add_without_payment_response', array($this, 'add_without_payment_response'), 99, 2);
            // action on paypal data verification
            add_filter('event_magic_paypal_data_verify_booking', array($this, 'paypal_data_verify_booking'), 99, 2);
            // confirm booking order info
            add_filter('event_magic_add_booking_order_info', array($this, 'add_booking_order_info'), 10, 2);
            add_action('event_magic_automatic_recurrence_booking',array($this,'em_confirm_booking'),10,1);
            
            add_action('em_wishlist_user_profile_tab', array($this, 'event_magic_mailpoet_user_profile_tab'),9999);
            add_action('em_wishlist_user_profile_tab_content', array($this, 'event_magic_mailpoet_user_profile_tab_content'),9999);
            add_action( 'wp_ajax_em_mailpoet_update_user_subscription',array($this,'em_mailpoet_update_user_subscription') );
                
        }
        
        public function em_mailpoet_update_user_subscription() {
            $dbhandler = new EPMP_DBhandler;
            $pm_mailpoet = new EM_MailPoet_Integtation;
            $subscribe = $_POST['is_checked'];
            $listid = $_POST['listid'];
            $current_user = wp_get_current_user();
            $userid = $current_user->ID;
            $listdata = $dbhandler->get_row('MAILPOET',$listid);
            $list_meta = maybe_unserialize($listdata->list_meta);
            $mlistid = $list_meta['mailpoet_list'];
            $subscription = maybe_unserialize(get_user_meta($userid,'em_mailpoet_subscription',true));
            if(empty($subscription)) {
                $subscription = array();
            }
            if($subscribe == '1') {
                $array = array('email' => $current_user->user_email);
                $pm_mailpoet->em_mailpoet_subscribe_to_list($array, $mlistid);
                $subscription[] = $listid ;
                update_user_meta( $userid,'em_mailpoet_subscription',$subscription);
            }
            else {
                $to_remove = array();
                $to_remove[] = $listdata->id; 
                $subscription = array_diff($subscription, $to_remove);
                $response =  $pm_mailpoet->em_mailpoet_unsubscribe_to_list($current_user->user_email,array($mlistid));
                if(is_array($response)) {
                    update_user_meta( $userid,'em_mailpoet_subscription',$subscription);
                }
                else {
                    echo $response;
                }
            }
            die;
        }
        
        public function event_magic_mailpoet_user_profile_tab(){
            
            $content = '<div class="emtabs_head ep-mailpoet-tab em-menu-tab" data-emt-tabcontent="#ep_mailpoet"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><path d="M0 0h24v24H0z" fill="none"/><path d="M20 6H10v2h10v12H4V8h2v4h2V4h6V0H6v6H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2z"/></svg>'.__("Mailpoet", "eventprime-event-mailpoet").'</div>';
            echo $content;
        }

        public function event_magic_mailpoet_user_profile_tab_content(){
            $user_id = get_current_user_id();
            $dbhandler = new EPMP_DBhandler;
            $mailpoet_lists = $dbhandler->EP_get_all_user_event_booking_avalilable_mailpoet_list($user_id);
            if(!empty($mailpoet_lists)){
                ob_start();
                echo '<div id="ep_mailpoet" class="tab mailpoet-tab">';
                    $this->em_optin_get_html($mailpoet_lists,$user_id);
                echo '</div>';
                $content = ob_get_contents();
                ob_clean();
                echo $content;
            }
        }
        
        public function add_offline_payment_response($offline_response, $orders) {
            if(isset($orders[0]->event_magic_mailpoet_optin_box) && !empty($orders[0]->event_magic_mailpoet_optin_box)){
                $offline_response['event_magic_mailpoet_optin_box'] = $orders[0]->event_magic_mailpoet_optin_box;
            }
            return $offline_response;
        }

        public function add_stripe_payment_response($stripe_response, $orders){
            if(isset($orders[0]->event_magic_mailpoet_optin_box) && !empty($orders[0]->event_magic_mailpoet_optin_box)){
                $stripe_response['event_magic_mailpoet_optin_box'] = $orders[0]->event_magic_mailpoet_optin_box;
            }
            return $stripe_response;
        }

        public function add_without_payment_response($data, $orders){
            file_put_contents('text.txt', maybe_serialize($data));
            file_put_contents('text2.txt', maybe_serialize($orders));
            if(isset($orders[0]->event_magic_mailpoet_optin_box) && !empty($orders[0]->event_magic_mailpoet_optin_box)){
                $data['event_magic_mailpoet_optin_box'] = $orders[0]->event_magic_mailpoet_optin_box;
            }
            return $data;
        }

        public function paypal_data_verify_booking($booking, $all_order_data){
            if(isset($all_order_data->event_magic_mailpoet_optin_box) && !empty($all_order_data->event_magic_mailpoet_optin_box)){
                $booking->order_info['event_magic_mailpoet_optin_box'] = $all_order_data->event_magic_mailpoet_optin_box;
            }
            return $booking;
        }

        public function add_booking_order_info($order_info, $data){
            file_put_contents('text3.txt', maybe_serialize($order_info));
            file_put_contents('text4.txt', maybe_serialize($data));
            
            if(isset($data['event_magic_mailpoet_optin_box']) && !empty($data['event_magic_mailpoet_optin_box'])){
                $order_info['event_magic_mailpoet_optin_box'] = $data['event_magic_mailpoet_optin_box'];
            }
            return $order_info;
        }
        
        public function em_show_optin_check_box_html($event) {
            $event_id = $event->id;
            $user_id = get_current_user_id();
            $dbhandler = new EPMP_DBhandler;
            $enable_mailpoet_event = $dbhandler->get_event_meta($event_id,'em_enable_mailpoet');
            $em_mailpoet_lists = maybe_unserialize($dbhandler->get_event_meta($event_id,'em_mailpoet_lists'));
            if(isset($enable_mailpoet_event) && $enable_mailpoet_event == 1 && !empty($em_mailpoet_lists)) {
                $this->em_optin_get_html_on_booking_page($em_mailpoet_lists, $user_id);
            }
        }

        public function em_optin_get_html_on_booking_page($em_mailpoet_lists, $uid = false) {
            $dbhandler = new EPMP_DBhandler;
            $subscription = [];
            if($uid!=false) {
                $subscription = $dbhandler->EP_get_all_user_event_booking_avalilable_mailpoet_list($uid);
                //$subscription = maybe_unserialize(get_user_meta($uid,'em_mailpoet_subscription',true));
                echo '<div class="em-mailpoet-loader"></div>';
            }

            echo '<div class="ep-mailpoet-wrap dbfl">';
            foreach($em_mailpoet_lists as $list) {
                $listdata = $dbhandler->get_row('MAILPOET',$list);
                if(!empty($listdata) && $listdata->optin_checkbox == 1) { 
                    if(empty($subscription) || !in_array($listdata->id, $subscription)){?>
                        <div class="ep-mailpoet-box">
                            <div class="ep-left-mailpoet-checkbox">
                                <input type="checkbox" title="mailpoet-checkbox" class="ep-mc-checkbox-toggle" id="event_magic_mailpoet_optin_box<?php echo esc_attr($listdata->id); ?>" name="event_magic_mailpoet_optin_box[]" value="<?php echo esc_attr($listdata->id); ?>" <?php if (isset($subscription) && !empty($subscription) && in_array($listdata->id, $subscription)) echo 'checked'; ?> <?php if (isset($subscription)) echo 'onchange="ep_mailpoet_subscription(this)"'; ?> ng-model="event_magic_mailpoet_optin_box[<?php echo esc_attr($listdata->id); ?>]" /> 
                                <label for="event_magic_mailpoet_optin_box<?php echo esc_attr($listdata->id); ?>" data-off="<?php _e('OFF','eventprime-event-mailpoet');?>" data-on="<?php _e('ON','eventprime-event-mailpoet');?>" class="ep-mailpoet-toggle"><b></b><span class="ep-toggle__handler"></span></label>
                            </div>
                            <div class="ep-right-mailpoet-text">
                                <div class="ep-mailpoet-list-name"><?php echo $listdata->list_name; ?></div>
                                <div class="ep-mailpoet-description"><?php echo html_entity_decode($listdata->description); ?></div>
                            </div>
                        </div><?php
                    }
                }
            }
            echo '</div>';
        }

        public function em_confirm_booking($booking) {
            $dbhandler = new EPMP_DBhandler;
            $pm_mailpoet = new EM_MailPoet_Integtation();
            $user_email = $booking->order_info['user_email'];
            $user_name = $booking->order_info['user_name'];
            $user = get_user_by('email',$user_email);
            $event_id = $booking->event;
            $booking_id = $booking->id;
            $user_optin_box_data = isset($booking->order_info['event_magic_mailpoet_optin_box']) ? $booking->order_info['event_magic_mailpoet_optin_box'] : array();
            $user_optin_box = array();
            $subscription = array();
            if($user) {
                $user_id = $user->ID;
                $subscription = maybe_unserialize(get_user_meta($user_id,'em_mailpoet_subscription',true));
                if(!isset($subscription) || empty($subscription))
                {
                    $subscription = array();
                }
            }
            if(!empty($user_optin_box_data)) {
                foreach($user_optin_box_data as $key => $value) {
                    if($value == 1) {
                        $user_optin_box[]=$key;
                    }
                }
            }
            
            $enable_mailpoet_event = $dbhandler->get_event_meta($event_id,'em_enable_mailpoet');
            $em_mailpoet_lists = maybe_unserialize($dbhandler->get_event_meta($event_id,'em_mailpoet_lists'));
                
            if(isset($enable_mailpoet_event) && $enable_mailpoet_event==1) {
                foreach($em_mailpoet_lists as $list) {
                    $listdata = $dbhandler->get_row('MAILPOET',$list);
                    $list_meta = maybe_unserialize($listdata->list_meta);
                    $listid = $list_meta['mailpoet_list'];
                    $array = array('email' =>$user_email,'first_name'=>$user_name);
                    if($listdata->optin_checkbox=='1') {
                        if(isset($user_optin_box) && !empty($user_optin_box) && in_array($listdata->id,$user_optin_box)) {
                            $subscription[] = $listdata->id;
                            $pm_mailpoet->em_mailpoet_subscribe_to_list($array, $listid);
                        }
                    }
                    else {
                        $subscription[] = $listdata->id;
                        $pm_mailpoet->em_mailpoet_subscribe_to_list($array, $listid);
                    }
                    unset($listdata);
                    unset($list_meta);
                    unset($array);
                    unset($listid);
                }
                update_user_meta( $user_id,'em_mailpoet_subscription',$subscription);
            }
            
            //file_put_contents('booking.txt', maybe_serialize($booking));
        }
        
        public function em_optin_get_html($em_mailpoet_lists, $uid = false) {
            $dbhandler = new EPMP_DBhandler;
            if($uid!=false) {
                $subscription = maybe_unserialize(get_user_meta($uid,'em_mailpoet_subscription',true));
                echo '<div class="em-mailpoet-loader"></div>';
            }

            echo '<div class="ep-mailpoet-wrap dbfl">';
            foreach($em_mailpoet_lists as $list) {
                $listdata = $dbhandler->get_row('MAILPOET',$list);
                if(!empty($listdata) && ($listdata->optin_checkbox == 1 || $uid != false)) {?>
                    <div class="ep-mailpoet-box">
                        <div class="ep-left-mailpoet-checkbox">
                            <input type="checkbox" title="mailpoet-checkbox" class="ep-mc-checkbox-toggle" id="event_magic_mailpoet_optin_box<?php echo esc_attr($listdata->id); ?>" name="event_magic_mailpoet_optin_box[]" value="<?php echo esc_attr($listdata->id); ?>" <?php if (isset($subscription) && !empty($subscription) && in_array($listdata->id, $subscription)) echo 'checked'; ?> <?php if (isset($subscription)) echo 'onchange="ep_mailpoet_subscription(this)"'; ?> ng-model="event_magic_mailpoet_optin_box[<?php echo esc_attr($listdata->id); ?>]" /> 
                            <label for="event_magic_mailpoet_optin_box<?php echo esc_attr($listdata->id); ?>" data-off="<?php _e('OFF','eventprime-event-mailpoet');?>" data-on="<?php _e('ON','eventprime-event-mailpoet');?>" class="ep-mailpoet-toggle"><b></b><span class="ep-toggle__handler"></span></label>
                        </div>
                        <div class="ep-right-mailpoet-text">
                            <div class="ep-mailpoet-list-name"><?php echo $listdata->list_name; ?></div>
                            <div class="ep-mailpoet-description"><?php echo html_entity_decode($listdata->description); ?></div>
                        </div>
                    </div><?php
                }
            }
            echo '</div>';
        }
        
        public function menus()	{
            add_submenu_page("event_magic",__("MailPoet","eventprime-event-mailpoet"),__("MailPoet","eventprime-event-mailpoet"),"manage_options","em_mailpoet",array( $this, 'em_mailpoet' ));
            add_submenu_page("",__("MailPoet List","eventprime-event-mailpoet"),__("MailPoet List","eventprime-event-mailpoet"),"manage_options","em_add_mailpoet_list",array( $this, 'em_add_mailpoet_list' ));
            //add_submenu_page("",__("MailPoet Settings","eventprime-event-mailpoet"),__("MailPoet Settings","eventprime-event-mailpoet"),"manage_options","em_mailpoet_settings",array( $this, 'em_mailpoet_settings' ));
        }
        
        public function em_mailpoet(){
            wp_enqueue_style('em_admin_css', EM_BASE_URL . 'includes/admin/template/css/em_admin.css', false, EVENTPRIME_VERSION);
            include('includes/admin/template/mailpoet-lists.php');
        }
        
        public function em_add_mailpoet_list(){
            wp_enqueue_style('em_admin_css', EM_BASE_URL . 'includes/admin/template/css/em_admin.css', false, EVENTPRIME_VERSION);
            include('includes/admin/template/add-mailpoet-list.php');
        }
        
        public function mailpoet_tab($post_id){
            wp_enqueue_script('em-event-controller');
            include('includes/admin/template/mailpoet.php');
        }

        public function dashboard_links($post_id){ ?>
            <div class="ep-grid-icon difl" id="ep-ticket-integration">
                <a  class="ep-dash-link" href="<?php echo admin_url("/admin.php?page=em_dashboard&tab=mailpoet&post_id=$post_id") ?>">
                    <div class="ep-grid-icon-area dbfl">
                        <img class="ep-grid-icon dibfl" src="<?php echo EMMP_BASE_URL . 'includes/admin/template/images/event-mailpoet-icon.png' ?>">
                    </div>
                    <div class="ep-grid-icon-label dbfl"><?php _e('MailPoet', 'eventprime-event-mailpoet'); ?></div>
                </a>
            </div><?php 
        }
        
        public function load_textdomain(){
            load_plugin_textdomain('eventprime-event-mailpoet', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        public function event_mailpoet_gs_settings(){?> 
            <a href='javascript:void(0)'>
                <div class="em-settings-box ep-active-extension ep-no-global-settings-model" data-popup="ep-event-mailpoet-ext" onclick="CallEPExtensionModal(this)">
                    <img class="em-settings-icon" ng-src="<?php echo EM_BASE_URL; ?>includes/admin/template/images/event-mailpoet-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Mailpoet', 'eventprime-event-mailpoet'); ?></div>
                    <span><?php _e('Integration with MailPoet Plugin.', 'eventprime-event-mailpoet'); ?></span>
                </div>
            </a><?php
        }

        public function event_magic_enqueue_style_and_scripts() {
            wp_enqueue_style('em-mailpoet-css', EMMP_BASE_URL . 'includes/public/css/em_mailpoet.css', false, EMMP_VERSION);
            wp_enqueue_script('eventprime-mailpoet-public',EMMP_BASE_URL . 'includes/public/js/eventprime-mailpoet-public.js',array('jquery'), $this->version, true );
            wp_localize_script('eventprime-mailpoet-public', 'em_ajax_object',array( 'ajax_url' => admin_url( 'admin-ajax.php')));
        }
        
    }
}

function em_mailpoet() {
    return EM_MailPoet::instance();
}
function em_mailpoet_checks(){ ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e( 'EventPrime Mailpoet Extension won\'t work as EventPrime plugin is not active/installed.', 'event-magic' ); ?></p>
    </div>
<?php }

function em_mailpoet_integration_checks_mailpoet_activation(){ ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e( 'EventPrime Mailpoet Integration Extension won\'t work as Mailpoet plugin is not active/installed.', 'event-magic' ); ?></p>
    </div><?php
    deactivate_plugins( plugin_basename( __FILE__ ) );
}

add_action('plugins_loaded',function(){
    if(!class_exists('Event_Magic')){
        add_action('admin_notices','em_mailpoet_checks');
    }
    $all_plugins = apply_filters('active_plugins', get_option('active_plugins'));
    if(!stripos(implode($all_plugins), 'mailpoet/mailpoet.php')){
        add_action('admin_notices','em_mailpoet_integration_checks_mailpoet_activation');
    }
});
add_action('event_magic_loaded', 'em_mailpoet');

require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_mailpoet_metadata.json',
    __FILE__,
    'eventprime-event-mailpoet'
);

function activate_eventprime_mailpoet() {
    include_once('includes/dao/class-eventprime-mailpoet-activator.php');
	$mailpoet_activator = new EP_Mailpoet_Activator;
	$mailpoet_activator->activate();
}

register_activation_hook( __FILE__, 'activate_eventprime_mailpoet' );

