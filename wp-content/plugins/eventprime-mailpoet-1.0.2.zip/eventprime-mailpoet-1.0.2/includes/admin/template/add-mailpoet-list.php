<?php
$dbhandler = new EPMP_DBhandler;
$pm_activator = new EP_Mailpoet_Activator;
//$pmrequests = new PM_request;
$path =  plugin_dir_url(__FILE__);
$identifier = 'MAILPOET';
$id = filter_input(INPUT_GET, 'id');
$group_options = array();
$list_arg = array('count' => 500);
$mailpoet = new EM_MailPoet_Integtation();
$mailpoet_lists = $mailpoet->get_lists();
$mailpoet_fields = $mailpoet->get_fields();
if($id == false || $id == NULL) {
	$id = 0;
}else {
	$row = $dbhandler->get_row($identifier,$id);
	if($row->list_meta != "") {
		$list_meta = maybe_unserialize($row->list_meta);
	}
}
if(!empty($mailpoet_lists)):
	if(filter_input(INPUT_POST,'submit_list')) {
		$retrieved_nonce = filter_input(INPUT_POST,'_wpnonce');
		if (!wp_verify_nonce($retrieved_nonce, 'save_em_add_mailpoet_list' ) ) die( 'Failed security check' );
		$list_id = filter_input(INPUT_POST,'list_id');
		$exclude = array("_wpnonce","_wp_http_referer","submit_list","list_id");
		$post = $pm_activator->sanitize_request($_POST,$identifier,$exclude);
		if($post != false) {
			if(!isset($post['optin_checkbox'])) $post['optin_checkbox'] = 0;
			foreach($post as $key=>$value) {
				$data[$key] = $value;
				$arg[] = $pm_activator->get_db_table_field_type($identifier,$key);
			}
		}
		if($list_id==0) {
			$dbhandler->insert_row($identifier, $data,$arg);
		} else {
			$dbhandler->update_row($identifier,'id',$list_id,$data,$arg,'%d');	
		}
		wp_redirect('admin.php?page=em_mailpoet');exit;
	}?>
	<div class="kikfyre kf-container">
		<div class="kf-db-content">
			<?php if($id==0): ?>
				<div class="kf-db-title">
					<?php _e( 'New List Connection for MailPoet','eventprime-event-mailpoet' ); ?>
				</div>
			<?php else: ?>
				<div class="kf-db-title">
					<?php _e( 'Edit List','eventprime-event-mailpoet' ); ?>
				</div>
			<?php endif; ?>
			<div class="form_errors">
				<ul class="ng-binding"></ul>
			</div>
			<!-- FORM -->
			<form name="em_add_mailpoet_list" id="em_add_mailpoet_list" method="post">
				<div class="em_ticket_template">
					<div class="emrow">
						<div class="emfield">
							<?php _e('List Name','eventprime-event-mailpoet');?>
							<sup>*</sup>
						</div>
						<div class="eminput pm_required">
							<input type="text" name="list_name" id="list_name" value="<?php if(!empty($row)) echo esc_attr($row->list_name); ?>" required />
							<div class="errortext"></div>
						</div>
						<div class="uimnote"><?php _e("It can be same as MailPoet subscriber list you wish to connect to, or something entirely different. The name will appear on frontend during event booking checkout when opting in and user account area. For example, 'Sales and Promotions', 'Event Updates' etc.",'eventprime-event-mailpoet');?></div>
					</div>      
					<div class="emrow">
						<div class="emfield">
							<?php _e('Description','eventprime-event-mailpoet');?>
						</div>
						<div class="eminput">
							<?php
							if(!empty($row)) {
								$description =  html_entity_decode($row->description);
							}
							else {
								$description ='';
							}
							$settings = array(
								'wpautop' => true,
								'media_buttons' => false,
								'textarea_name' => 'description',
								'textarea_rows' => 20,
								'tabindex' => '',
								'tabfocus_elements' => ':prev,:next', 
								'editor_css' => '', 
								'editor_class' => '',
								'teeny' => false,
								'dfw' => false,
								'tinymce' => true,
								'quicktags' => true
							);
							wp_editor( $description, 'description',$settings); ?>
							<div class="errortext"></div>
						</div>
						<div class="uimnote"><?php _e('The description will appear on frontend during event booking checkout when opting in and user account area, below the name. It is optional and you can leave it empty if you do not want it to appear.','eventprime-event-mailpoet');?></div>
					</div>   
					<div class="emrow" id="mailpoet">
						<div class="emfield">
							<?php _e( 'Subscribe to MailPoet List','eventprime-event-mailpoet' ); ?>
						</div>
						<div class="eminput pm_select_required">
							<select name="list_meta[mailpoet_list]" id="mailpoet_list">
								<option value=""><?php _e('Select a List','eventprime-event-mailpoet');?></option>
								<?php
								foreach($mailpoet_lists as $list){?>
									<option value="<?php echo $list['id'];?>"<?php if(!empty($list_meta) && isset($list_meta['mailpoet_list'])) selected($list_meta['mailpoet_list'], $list['id'] ); ?>><?php echo $list['name'];?></option>
									<?php
								}?>
							</select>
							<div class="errortext"></div>
						</div>
						<div class="uimnote"><?php _e('Select the MailPoet subscribers list you wish to add users to using this connection.','eventprime-event-mailpoet');?></div>
					</div>
					<div class="emrow">
						<div class="emfield">
							<?php _e( 'Show Opt-In Toggle','eventprime-event-mailpoet' ); ?>
						</div>
						<div class="eminput">
							<input name="optin_checkbox" id="optin_checkbox" type="checkbox" value="1" <?php if(!empty($row) && $row->optin_checkbox==1){ echo "checked";}?>/>
							<label for="optin_checkbox"></label>
						</div>
						<div class="uimnote"><?php _e('Allow users to subscribe or unsubscribe to the list during checkout and from their user account area.','eventprime-event-mailpoet');?></div>
					</div>
					<div class="dbfl kf-buttonarea">
						<div class="em_cancel"><a class="kf-cancel" href="admin.php?page=em_mailpoet">Cancel</a></div>
						<button type="submit" class="btn btn-primary" name="submit_list" id="submit_list" value="submit">Save</button>
						<input type="hidden" name="list_id" id="list_id" value="<?php echo $id;?>" />
						<?php wp_nonce_field('save_em_add_mailpoet_list'); ?>
					</div>
				</div>
			</form>
		</div>
	</div>
<?php endif;?>