<?php
$dbhandler = new EPMP_DBhandler;
$path =  plugin_dir_url(__FILE__); 
$identifier = 'MAILPOET';
$pagenum = filter_input(INPUT_GET, 'pagenum');
$pagenum = isset($pagenum) ? absint($pagenum) : 1;
$limit = 20; // number of rows in page
$offset = ( $pagenum - 1 ) * $limit;
$i = 1 + $offset;
$totallist = $dbhandler->pm_count($identifier);
$lists =  $dbhandler->get_all_result($identifier,'*',1,'results',$offset,$limit,'id');
$num_of_pages = ceil( $totallist/$limit);
$pagination = $dbhandler->pm_get_pagination($num_of_pages,$pagenum);
if(filter_input(INPUT_GET, 'delete')) {
	$selected = filter_input(INPUT_GET, 'selected', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
	foreach($selected as $lid) {
		$dbhandler->remove_row($identifier,'id',$lid,'%d');
	}
	wp_redirect('admin.php?page=em_mailpoet');exit;
}?>

<div class="kikfyre">
    <form name="mailpoet_manager" id="em_mailpoet_manager" action="" method="get">
        <div class="kf-operationsbar dbfl">
            <input type="hidden" name="page" value="em_mailpoet" />
            <input type="hidden" name="pagenum" value="<?php echo $pagenum;?>" />
            <div class="kf-title difl">
                <?php _e('MailPoet List','eventprime-event-mailpoet');?>
            </div>     
            <div class="kf-icons difr"></div>
            <div class="kf-nav dbfl">
                <ul>
                    <li>
                        <a class="em_action_bar_button" href="admin.php?page=em_add_mailpoet_list">
                            <?php _e('Add New','eventprime-event-mailpoet');?>
                        </a>
                    </li>
                    <li>
                        <a class="em_action_bar_button">
                            <input class="em-delete-button" type="submit" name="delete" value="<?php _e('Delete','eventprime-event-mailpoet');?>" data-delete_msg="<?php _e('Are you sure you want to delete the selected list!', 'eventprime-event-mailpoet');?>" style="background: none; color: #617FDE; cursor:pointer;" />
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="emagic-table dbfl">
            <table class="ep-mailpoet-list-table">
                <tbody>
                    <tr>
                        <th><input type="checkbox" id="select-all-list" onclick="select_all_list()" /></th>
                        <th>&nbsp;</th>
                        <th><?php _e('Name','eventprime-event-mailpoet');?></th>
                        <th><?php _e('Mailpoet List','eventprime-event-mailpoet');?></th>
                        <th><?php _e('Opt-In','eventprime-event-mailpoet');?></th>
                        <th><?php _e('Action','eventprime-event-mailpoet');?></th>
                    </tr>
                    <?php
                    if(!empty($lists)):
                        foreach($lists as $list) {?>
                            <tr>
                                <td><input class="list-check" type="checkbox" name="selected[]" value="<?php echo $list->id; ?>" /></td>
                                <td>&nbsp;</td>
                                <td><?php echo $list->list_name;?></td>
                                <td><?php echo $dbhandler->get_mailpoet_list_name($list->list_meta);?></td>
                                <td><?php echo (!empty($list->optin_checkbox) ? 'Yes' : 'No');?></td>
                                <td><a href="admin.php?page=em_add_mailpoet_list&id=<?php echo $list->id;?>">
                                    <?php _e('Edit','eventprime-event-mailpoet');?>
                                </a></td>
                            </tr>
                        <?php $i++; }
                        echo $pagination;
                    endif;?>
                </tbody>
            </table>
            <?php if(empty($lists)):?>
                <div class="em_empty_card">
                    <?php _e('You haven’t created any MailPoet List yet. Why don’t you go ahead and create one now!','eventprime_event_mailpoet');?>
                </div>
            <?php endif; ?>
        </div>
    </form>
    
    <!--<div class="kf-pagination dbfr ng-hide" ng-show="data.posts.length!==0"> 
        <ul>
            <li ng-repeat="post in data.total_posts| itemsPerPage: data.pagination_limit" class="ng-scope"></li>
        </ul>
        <dir-pagination-controls on-page-change="pageChanged(newPageNumber)" class="ng-isolate-scope"></dir-pagination-controls>
    </div>-->
</div>

<script>
    jQuery(document).ready(function(){
        jQuery(".em-delete-button").click(function(e){
            var selectedList = 0;
            jQuery(".list-check").each(function(){
                if(jQuery(this).is(":checked")){
                    selectedList = 1;
                }
            });
            if(selectedList == 1){
                var delete_msg = jQuery(".em-delete-button").data('delete_msg');
                if (confirm(delete_msg) == true) {
                    //jQuery("#em_mailpoet_manager").submit();
                }
                else{
                    e.preventDefault();
                }
            }
            else{
                e.preventDefault();
            }
        });
    });
    function select_all_list(){
        var chkAll = jQuery("#select-all-list").is(':checked');
        jQuery(".list-check").each(function(){
            if(chkAll){
                jQuery(this).prop('checked', true).attr('checked', 'checked');
            }
            else{
                jQuery(this).prop('checked', false).removeAttr('checked');
            }
        });
    }
</script>