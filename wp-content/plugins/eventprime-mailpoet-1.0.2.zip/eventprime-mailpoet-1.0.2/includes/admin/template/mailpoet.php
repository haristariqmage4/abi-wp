<?php
$dbhandler = new EPMP_DBhandler;
$path =  plugin_dir_url(__FILE__);
$id = filter_input(INPUT_GET, 'post_id');

$lists = $dbhandler->get_all_result('MAILPOET');
$mailpoet_integration = new EM_MailPoet_Integtation();
$enable_mailpoet = $dbhandler->get_event_meta($id,'em_enable_mailpoet');
$em_mailpoet_lists = maybe_unserialize($dbhandler->get_event_meta($id,'em_mailpoet_lists'));
if(filter_input(INPUT_POST,'submit_list')) {
	$retrieved_nonce = filter_input(INPUT_POST,'_wpnonce');
	if (!wp_verify_nonce($retrieved_nonce, 'save_em_add_mailpoet_list' ) ) die( 'Failed security check' );
	$em_enable_mailpoet_value = filter_input(INPUT_POST,'em_enable_mailpoet');
	if(!isset($em_enable_mailpoet_value))$em_enable_mailpoet_value=0;
	$em_mailpoet_lists_value = maybe_serialize(filter_input(INPUT_POST, 'em_mailpoet_lists', FILTER_DEFAULT, FILTER_FORCE_ARRAY) );
	update_post_meta($id,'em_enable_mailpoet',$em_enable_mailpoet_value);
	update_post_meta($id,'em_mailpoet_lists',$em_mailpoet_lists_value);
	/* recurring events */
	$child_events_data = array( 'parent_post_id' => $id, 'enable_mailpoet' => $em_enable_mailpoet_value, 'mailpoet_lists' => $em_mailpoet_lists_value );
	do_action( 'update_child_events_mailpoet_post_meta', $child_events_data );
	wp_redirect("admin.php?page=em_dashboard&post_id=$id");exit;
}?>
<div class="kikfyre kf-container">
	<div class="kf-db-content">
		<div class="kf-db-title">
			<?php _e('Mailpoet Lists', 'eventprime-event-mailpoet'); ?>
		</div>
		<?php
		if(!empty($lists)): ?>
			<form name="em_mailpoet_list_form" id="em_mailpoet_list_form" method="post">
				<div class="emrow">
					<div class="emfield">
						<?php _e( 'Enable MailPoet:','eventprime-event-mailpoet' ); ?>
					</div>
					<div class="eminput">
						<input name="em_enable_mailpoet" id="em_enable_mailpoet" type="checkbox"  value="1" onClick="em_show_hide(this,'mailpoet_html')" <?php if(isset($enable_mailpoet) && $enable_mailpoet==1){ echo "checked";}?>/>
						<label for="em_enable_mailpoet"></label>
					</div>
				</div>
				<div class="childfieldsrow" id="mailpoet_html" style=" <?php if(isset($enable_mailpoet) && $enable_mailpoet==1){echo 'display:block;';} else { echo 'display:none;';} ?>">
					<div class="emrow">
						<div class="emfield"><?php _e('Select List', 'eventprime-event-mailpoet');?></div>
						<div class="eminput <?php if(isset($enable_mailpoet) && $enable_mailpoet==1){echo 'em_checkbox_required';}?>">
							<ul class="uimradio">
								<?php 
								foreach($lists as $list):
									if(!empty($list->optin_checkbox)){
										$listMeta = unserialize($list->list_meta);?>
										<li>  
											<input type="checkbox" class="ep-mailpoet-list" name="em_mailpoet_lists[]" value="<?php echo $list->id;?>" <?php if(!empty($em_mailpoet_lists) && in_array($list->id,$em_mailpoet_lists)) echo 'checked'; ?>>
											<?php echo $list->list_name . ' ('.$mailpoet_integration->get_list_name($listMeta['mailpoet_list']) . ')';?> 
										</li><?php 
									}
								endforeach;?>
							</ul>
							<label for="mailpoet_list"></label>
							<div class="errortext"></div>
						</div>
						<div class="uimnote"><?php _e('Select MailPoet list which you want to show on frontend.', 'eventprime-event-mailpoet'); ?></div>          
					</div>
				</div>
				<div class="dbfl kf-buttonarea">
					<div class="em_cancel"><a class="kf-cancel" ng-href="admin.php?page=em_mailpoet" href="admin.php?page=em_dashboard&post_id=<?php echo $id; ?>">Cancel</a></div>
					<button type="submit" class="btn btn-primary" name="submit_list" id="submit_list" value="submit" >Save</button>
					<input type="hidden" name="post_id" id="post_id" value="<?php echo $id;?>" />
					<?php wp_nonce_field('save_em_add_mailpoet_list'); ?>
				</div> 
			</form>
		<?php else:?>
			<div class="emrow">
				<div class="emfield">&nbsp;</div>
				<div class="eminput">
					<?php _e("MailPoet list will be available for mapping here once you have created at least one MailPoet list in your MailPoet account. Looks like you don't have any lists right now. ",'eventprime-event-mailpoet');?><a href="admin.php?page=em_add_mailpoet_list"><?php _e('Click Here','eventprime-event-mailpoet');?></a>
				</div>
			</div>
			<div class="dbfl kf-buttonarea">
				<div class="em_cancel">
					<a class="kf-cancel" href="<?php echo admin_url('/admin.php?page=em_dashboard&post_id=' . $id); ?>">Cancel</a>
				</div>
			</div>
		<?php endif;?>
	</div>        
</div>
<script>
	// jQuery(document).ready(function(){
	// 	jQuery(".ep-mailpoet-list").click(function(){
	// 		var show_save_btn = 0;
	// 		jQuery(".ep-mailpoet-list").each(function(){
	// 			if(jQuery(this).is(":checked")){
	// 				show_save_btn = 1;
	// 			}
	// 		});
	// 		if(show_save_btn == 1){
	// 			jQuery("#submit_list").show();
	// 		}
	// 		else{
	// 			jQuery("#submit_list").hide();
	// 		}
	// 	})
	// });
	function em_show_hide(obj,primary,secondary,trinary) {	
		a = jQuery(obj).is(':checked');
		if (a == true) {
			jQuery('#'+primary).show(500);
			if(secondary!='') {
				jQuery('#'+secondary).hide(500);
			}
			if(trinary!='')	{
				jQuery('#'+trinary).hide(500);
			}
		}
		else {
			jQuery('#'+primary).hide(500);
			if(secondary!='') {
				jQuery('#'+secondary).show(500);
			}
			if(trinary!='')	{
				jQuery('#'+trinary).show(500);
			}
		}
	}
</script>