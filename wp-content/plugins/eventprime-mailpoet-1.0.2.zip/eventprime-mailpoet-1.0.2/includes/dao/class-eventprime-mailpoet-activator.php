<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class EP_Mailpoet_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
    public function activate() {
        global $wpdb;
        if (class_exists('Event_Magic') ) {
            if ( is_multisite()) {
                // Get all blogs in the network and activate plugin on each one
                $blog_ids = $wpdb->get_col( "SELECT blog_id FROM $wpdb->blogs" );
                foreach ( $blog_ids as $blog_id ) {
                    switch_to_blog( $blog_id );
                    $this->create_table();
                    restore_current_blog();
                }
            } else {
                $this->create_table();
            }
        }
    }
         
    public function create_table() {
        global $wpdb;
        require_once( ABSPATH . 'wp-includes/wp-db.php');
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        
        $charset_collate = $wpdb->get_charset_collate();
        $table_name= $this->get_db_table_name('MAILPOET');
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `list_name` longtext DEFAULT NULL,
            `description` longtext DEFAULT NULL,
            `optin_checkbox` int(11) DEFAULT NULL,
            `optin_text` longtext DEFAULT NULL,
            `list_meta` longtext DEFAULT NULL,
            PRIMARY KEY (`id`)
            )$charset_collate;";
        dbDelta($sql);
    }
         
    public function get_db_table_name($identifier) {
        global $wpdb;
        $plugin_prefix = $wpdb->prefix.'em_';
        $table_name= $plugin_prefix."mailpoet";
        switch($identifier)
        {
            case 'MAILPOET':
                $table_name= $plugin_prefix."mailpoet";
                break;
            case 'MAILPOET_FORMS':
                $table_name= $wpdb->prefix."mailpoet_forms";
                break;
            case 'MAILPOET_SUBSCRIBERS':
                $table_name= $wpdb->prefix."mailpoet_subscribers";
                break;
            case 'MAILPOET_SUBSCRIBERS_FIELDS':
                $table_name= $wpdb->prefix."mailpoet_subscriber_custom_field";
                break;
        }
        return $table_name;
	}
        
    public function get_db_table_unique_field_name($identifier) {
		switch ($identifier) {
			case 'MAILPOET':
				$unique_field_name = 'id';
				break;
            case 'WP_OPTION':
				$unique_field_name= 'option_id';
				break;
			case 'MAILPOET_FORMS':
				$unique_field_name = 'field_id';
				break;
			case 'MAILPOET_SUBSCRIBERS':
				$unique_field_name = 'id';
				break;
			case 'MAILPOET_SUBSCRIBERS_FIELDS':
				$unique_field_name = 'id';
				break;
			default:
                return false; 
		}
		return $unique_field_name;
	}

	public function get_db_table_field_type($identifier,$field) {
		$functionname = 'get_field_format_type_'.$identifier;
		if (method_exists('EP_Mailpoet_Activator',$functionname)) {
            $format = $this->$functionname($field);
		} else {
            return false; 
		}
		return $format;
	}
	
    public function get_field_format_type_MAILPOET($field) {
		switch ($field)
		{
			case 'id':
				$format = '%d';
				break;
            case 'optin_checkbox':
				$format = '%d';
				break;
			default:
				$format = '%s';
		}
		return $format;
	}
        
    public function sanitize_request($post,$identifier,$exclude=array()) {
        $post = $this->remove_magic_quotes($post);
        foreach ($post as $key => $value) {
            if( !in_array($key, $exclude) ) {
                if ( !is_array($value) ) {
                    $data[$key] = $this->get_sanitized_fields($identifier, $key, $value);
                } else {
                    $data[$key] = maybe_serialize( $this->sanitize_request_array($value, $identifier) );
                }
            }
        }
        if ( isset($data) ) { return $data; }
            else { return NULL; }
	}
        
    public function sanitize_request_array($post, $identifier) {
        foreach ($post as $key => $value) {
            if ( is_array($value) ) {
                $data[$key] = $this->sanitize_request_array($value, $identifier);
            } else {
                $data[$key] = $this->get_sanitized_fields($identifier, $key, $value);
            }
        }

        if ( isset($data) ) { return $data; }
        else { return NULL; }
	}
        
    public function get_sanitized_fields($identifier,$field,$value) {
        $sanitize_method = 'get_sanitized_' . strtolower($identifier) . '_field';
        $sanitized_value = '';
        if ( method_exists($this, $sanitize_method) ) {
            $sanitized_value = $this->$sanitize_method($field, $value);
        } 

        return $sanitized_value;
	}
	
	public function get_sanitized_mailpoet_field($field,$value){
        switch($field)
        {
            case 'id':
                $sanitized_value = sanitize_text_field($value);
                break;
            case 'list_name':
                $sanitized_value = sanitize_text_field($value);
                break;
            case 'description':
                $allowed_html = wp_kses_allowed_html( 'post' );
                $sanitized_value = wp_kses(htmlentities($value), $allowed_html);
                break;
            case 'optin_checkbox':
                $sanitized_value = sanitize_text_field($value);
                break;
            case 'optin_text':
                $sanitized_value = sanitize_text_field($value);
                break;
            case 'list_meta':
                $sanitized_value = sanitize_text_field($value);
                break;
            default:
                $sanitized_value = sanitize_text_field($value);
        }
        return $sanitized_value;
	}
        
    public function remove_magic_quotes($input){
        foreach ($input as $key => $value) {
            if ( is_array( $value ) ) {
                $input[$key] = $this->remove_magic_quotes( $value );
            } elseif ( is_string( $value ) ) {
                $input[$key] = stripslashes( $value );
            }
        }
        return $input;
    }
	
}