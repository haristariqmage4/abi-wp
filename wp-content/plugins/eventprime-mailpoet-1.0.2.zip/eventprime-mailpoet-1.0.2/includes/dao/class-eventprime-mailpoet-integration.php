<?php
class EM_MailPoet_Integtation
{
    public $mailpoet_active= false;
    
    public function __construct() 
    {
        if (is_plugin_active('mailpoet/mailpoet.php')) {
            $this->mailpoet_active = true;
        }
        else
        {
           $this->mailpoet_active= false;
        }
    }
    
    public function get_fields()
    {
        if (class_exists(\MailPoet\API\API::class)) {
            $mailpoet_api = \MailPoet\API\API::MP('v1');
            return $mailpoet_api->getSubscriberFields();
        }
        else
        {
            return false;
        }
    }

    public function get_lists()
    {
        if (class_exists(\MailPoet\API\API::class)) {
            $mailpoet_api = \MailPoet\API\API::MP('v1');
            return $mailpoet_api->getLists();
        }
        else
        {
            return false;
        }
    }
 
    public function em_mailpoet_subscribe_to_list($subscriber,$list_id)
    {
        if (class_exists(\MailPoet\API\API::class)) 
        {
            // Get MailPoet API instance
            $mailpoet_api = \MailPoet\API\API::MP('v1');
            $list_ids = array($list_id);
            // Check if subscriber exists. If subscriber doesn't exist an exception is thrown
            try {
                $get_subscriber = $mailpoet_api->getSubscriber($subscriber['email']);
                // error_log(maybe_serialize($get_subscriber));
            } catch (\Exception $e) {}

            try {
                if (!$get_subscriber) {
                    $mailpoet_api->addSubscriber($subscriber, $list_ids);
                } else {
                    $mailpoet_api->subscribeToLists($subscriber['email'], $list_ids);
                    //$this->em_add_fields_value_to_subscriber_account($subscriber,$get_subscriber);
              }
            } catch (\Exception $e) {
                echo $error_message = $e->getMessage(); 
                error_log(maybe_serialize($error_message));die;
            }
        }
    }
    
    public function em_add_fields_value_to_subscriber_account($data,$subscriber)
    {
        $dbhandler = new EPMP_DBhandler;
        $user = get_user_by('email',$data['email']);
        $subid = $subscriber['id'];
        $array = array('first_name'=>$data['first_name'],'last_name'=>$data['last_name']);
        $dbhandler->update_row('MAILPOET_SUBSCRIBERS','id',$subid, $array);
        foreach($data as $key=>$value)
        {
            if(strpos($key,'cf_')!==false)
            {
                $custom_field_id = intval(substr($key,3));
                $this->em_insert_update_field_value($subid,$custom_field_id,$value);
            }
        }
    }
    
    public function em_insert_update_field_value($subid,$custom_field_id,$value)
    {
        $dbhandler = new EPMP_DBhandler;
        $where = array('subscriber_id'=>$subid,'custom_field_id'=>$custom_field_id);
        $field_exist = $dbhandler->get_all_result('MAILPOET_SUBSCRIBERS_FIELDS','*',$where);
       
        if(empty($field_exist))
        {
            $time = current_time( 'mysql' );
            $format = array('%d','%d','%s','%s','%s');
            $data = array('subscriber_id'=>$subid,'custom_field_id'=>$custom_field_id,'value'=>$value,'created_at'=>$time,'updated_at'=>$time);
            $dbhandler->insert_row('MAILPOET_SUBSCRIBERS_FIELDS', $data, $format);
        }
    }
    
    public function em_mailpoet_unsubscribe_to_list($email,$list)
    {
        if (class_exists(\MailPoet\API\API::class)) 
        {
            // Get MailPoet API instance
            $mailpoet_api = \MailPoet\API\API::MP('v1');
            try {
               return $mailpoet_api->unsubscribeFromLists($email,$list); 
            } catch (\Exception $e) {
                return  $e->getMessage(); 
            }
        }
    }

    public function get_list_name($list_id){
        if (class_exists(\MailPoet\Models\Segment::class)) {
            $mailpoet_api = \MailPoet\Models\Segment::Where('id', $list_id)->findOne();
            if(!empty($mailpoet_api)){
                return $mailpoet_api->name;
            }
        }
        return '';
    }
}