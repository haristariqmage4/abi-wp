<?php
class EventMMP_Global_Settings_Model extends EventM_Global_Settings_Model
{
  public $enable_mailpoets;
}
