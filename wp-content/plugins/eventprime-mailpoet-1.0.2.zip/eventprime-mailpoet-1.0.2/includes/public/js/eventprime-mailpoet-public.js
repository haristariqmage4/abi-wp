function ep_mailpoet_subscription(a) {
    jQuery('.em-mailpoet-box').hide();
    jQuery('.em-mailpoet-loader').html('<div class="em-loader"></div>');
    var elementid = a.id;
    var listid = a.value;
    var is_checked = jQuery('#'+elementid+':checked').length;
    params = {action: 'em_mailpoet_update_user_subscription',listid:listid,is_checked:is_checked}
    jQuery.post(em_ajax_object.ajax_url, params, function(response) {
        jQuery('.em-mailpoet-box').show();
        jQuery('.em-mailpoet-loader').html('');
    });	
}