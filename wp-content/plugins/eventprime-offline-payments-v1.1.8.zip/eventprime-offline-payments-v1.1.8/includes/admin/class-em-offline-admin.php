<?php

class EventM_Offline_Admin {
    
    private static $instance = null;
    protected $payment_service;
    protected $request;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        $this->payment_service = new EventM_Offline_Payment_Service();
        $this->request = EventM_Raw_Request::get_instance();
        add_action('event_magic_gs_pp', array($this, 'global_settings'));
        add_action('event_magic_gs_ppof_options', array($this, 'offline_options'));
        add_filter('event_magic_gs_before_save', array($this, 'save_options'));
        add_action('event_magic_admin_offline_handle', array($this, 'offline_handle'));
        add_action('wp_ajax_em_cancel_offline_booking', array($this, 'cancel_offline_booking'));
        add_action('wp_ajax_em_save_offline_booking_status', array($this, 'save_offline_booking_status'));
        add_filter('em_load_gs_ext_options', array($this, 'get_options_from_db'),10,1);
    }

    // Adding Offline Checkbox Button
    public function global_settings() {
        include_once(EM_OFFLINE_PLUGIN_DIR."/includes/html/admin/offline_option.php");
    }

    public function offline_options() {
        $em = event_magic_instance();?>
        <div id="kf_pproc_config_parent_backdrop" class="pg_options kf_config_pop_wrap"  ng-show="configure_offline">
            <div id="kf_pproc_config_parent" class="kf-offline_settings kf_config_pop" ng-show="data.options.offline_processor == 1">
                <div  class="kf_pproc_config_single" id="kf_pproc_config_paypal">
                    <div class="kf_pproc_config_single_titlebar">
                        <div class="kf_pproc_title">
                            <img src="<?php echo EM_OFFLINE_BASE_URL; ?>/includes/html/images/offline-payment.png" alt=""></div>
                        <span ng-click="configure_offline = false" class="kf-popup-close">×</span>
                    </div>
                </div>

                <div id="offline_options">
                  
                    <div class="emrow">
                        <div class="emfield"><?php _e('Send Tickets on Payment Confirmation', 'eventprime-offline'); ?></div>
                        <div class="eminput">
                            <input type="checkbox" ng-disabled="<?php if( !in_array( 'seating', $em->extensions ) ){ echo 'true'; } else{ echo'false'; } ?>" name="send_ticket_on_payment_received"  ng-model="data.options.send_ticket_on_payment_received" ng-true-value="1" ng-fale-value="0">
                        </div>
                        <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php esc_html_e("Users will only be allowed to download event tickets once their payment status has been marked ‘Received’ by the admin. Please note, system will also automatically email a payment confirmation email with tickets as attachments once status of an offline payment has been changed to ‘Received’.", 'eventprime-offline') ?>
                        </div>
                    </div>

                    <div class="emrow" ng-show="data.options.send_ticket_on_payment_received==1">
                        <div class="emfield"><?php _e('Tickets Restriction Notice', 'eventprime-event-calendar-management'); ?></div>
                        <div class="eminput">
                            <input type="text" name="custom_note_ticket_print_area" ng-model="data.options.custom_note_ticket_print_area">
                            <div class="emfield_error">
                            </div>
                        </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php _e('This message will be displayed above tickets download button as long as the payment status is incomplete. You can use this message to inform your users that the tickets will be available after payment completion.', 'eventprime-offline'); ?>
                        </div>
                    </div>

                    <div class="emrow">
                        <div class="emfield"><?php _e('Booking Notice', 'eventprime-event-calendar-management'); ?></div>
                        <div class="eminput">
                            <textarea id="offline_payment_note" name="offline_payment_note" ng-model="data.options.offline_payment_note"></textarea>
                            <div class="emfield_error">
                            </div>
                        </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php _e('This notice is displayed on the booking confirmation page and inside event booking confirmation email. You can use it to add payment instructions or other details about their payment status.', 'eventprime-offline'); ?>
                        </div>
                    </div>

                    <div class="emrow">
                        <div class="dbfl kf-buttonarea">
                            <button type="button" class="btn btn-primary" ng-click="saveSettings(optionForm.$valid)" ng-disabled="postForm.$invalid" ><?php _e('Save','eventprime-offline'); ?></button>  
                        </div>
                    </div>
                </div> 
            </div>
        </div><?php
    }
    
    // Saving Global Setting Options
    public function save_options($model) {
        $request= stripslashes_deep($this->request->get_data());
        $offline_enabled = !empty($request['offline_processor']) ? 1 : 0;
        if(empty($offline_enabled)) {
            return $model;
        }
        $model->offline_processor = 1;
        $model->send_ticket_on_payment_received = !empty($request['send_ticket_on_payment_received']) ? 1 : 0;
        $model->custom_note_ticket_print_area = !empty($request['custom_note_ticket_print_area']) ? $request['custom_note_ticket_print_area'] : 'You can download your tickets after payment is received.';
        $model->offline_payment_note = !empty($request['offline_payment_note']) ? $request['offline_payment_note'] : ' Congratulations, you booking is confirmed! Please note, your payment status is still incomplete. Failure to complete payment before the due date will result in booking cancellation.';
        return $model;
    }
    
    // Offline Handle on Single Bookings page
    public function offline_handle($html) {
        include_once(EM_OFFLINE_PLUGIN_DIR."/includes/html/admin/offline_status_handle.php");
    }
    
    public function get_options_from_db($options) {
        if (!isset($options->offline_processor) || empty($options->offline_processor)) {
            $options->offline_processor = 0;
        }
        return $options;
    }
    
    public function save_offline_booking_status() {
        $booking_id = absint($this->request->get_param('id'));
        $payment_log = (array) $_POST['payment_log'];
        $send_ticket = em_global_settings('send_ticket_on_payment_received');
        if( $payment_log['offline_status'] == 'Received' && $send_ticket == 1 ){
            $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
            $gs= $setting_service->load_model_from_db();
            $booking_service = EventM_Factory::get_service('EventM_Booking_Service');
            $booking= $booking_service->load_model_from_db($booking_id);
            $event_service = EventM_Factory::get_service('EventM_Service');
            $event = $event_service->load_model_from_db($booking->event);
            $attachments = array();
            $attachments = apply_filters( 'event_magic_booking_confirmed_notification_attachments', $attachments, $booking );
            /* get user or guest user info */
            $user= get_user_by('ID',$booking->user);
            $booking_user_email = $user->user_email;
            $booking_user_name = ( ! empty( $user->display_name) ) ? $user->display_name : $user->user_nicename;
            $booking_user_phone = get_user_meta($user->ID, 'phone', true);
            if(empty($user) && em_show_book_now_for_guest_users()){
                $booking_user_email = $booking->order_info['user_email'];
                $booking_user_name = $booking->order_info['user_name'];
                $booking_user_phone = (isset($booking->order_info['user_phone']) && !empty($booking->order_info['user_phone']) ? $booking->order_info['user_phone'] : '');
            }
            // sub total
            $order_sub_total = isset($booking->order_info['subtotal']) ? $booking->order_info['subtotal'] : 0;
            // total payment
            $total_payment = $order_sub_total; 
            // fixed event price
            $fixed_event_price = 0;
            if(isset($booking->order_info['fixed_event_price']) && !empty($booking->order_info['fixed_event_price'])){
                $fixed_event_price = $booking->order_info['fixed_event_price'];
                $total_payment += $fixed_event_price;
            }
            // discounts
            $total_discount = 0;
            if(isset($booking->order_info['discount']) && !empty($booking->order_info['discount'])){
                $total_discount += $booking->order_info['discount'];
            }
            if(isset($booking->order_info['coupon_discount']) && !empty($booking->order_info['coupon_discount'])){
                $total_discount += $booking->order_info['coupon_discount'];
            }
            if(isset($booking->order_info['ebd_discount_amount']) && !empty($booking->order_info['ebd_discount_amount'])){
                $total_discount += $booking->order_info['ebd_discount_amount'];
            }
            // deduct total discount from total payment
            if(!empty($total_discount)){
                $total_payment -= $total_discount;
            }
            // final order total
            $order_total = (!empty($booking->payment_log) && isset($booking->payment_log['total_amount']) ? $booking->payment_log['total_amount'] : $total_payment );
            $booking_item_price = em_price_with_position($booking->order_info['item_price']);
            if(isset($booking->multi_price_id) && !empty($booking->multi_price_id) && isset($booking->payment_log['multi_price_option_data']) && !empty($booking->payment_log['multi_price_option_data']->name)){
                $booking_item_price .= ' (' . $booking->payment_log['multi_price_option_data']->name . ')';
            }
            $event_time_str = date_i18n(get_option('date_format').' '.get_option('time_format'), $event->start_date);
            /* send Mail to User on Payment received*/
            $to = $booking_user_email;
            $subject = __('Payment Confirmation', 'eventprime-offline');
            $mail_body =  em_global_settings('payment_confirmed_email');
            $mail_body = str_replace("$(User Name)", $booking_user_name, $mail_body);
            $mail_body = str_replace("$(Event Name)", $event->name, $mail_body);
            $mail_body = str_replace("$(Event Time)", $event_time_str, $mail_body);
            $mail_body = str_replace("$(Booking ID)", '#'.$booking->id, $mail_body);
            $mail_body = str_replace("$(Total Amount)", em_price_with_position($order_total, $booking->order_info['currency']), $mail_body);
            $from = get_bloginfo('name') . '<' . get_bloginfo('admin_email') . '>';
            $headers = array( 'From: ' . $from . "\r\n",'Content-Type: text/html; charset=UTF-8' );
            if(empty($gs->disable_frontend_email)){
                wp_mail( $to, $subject, $mail_body, $headers, $attachments);
            }
        }
        $result = em_update_post_meta($booking_id,'payment_log',$payment_log);
        if($result==true)
            wp_send_json_success();
    }
    
    public function cancel_offline_booking() {
        $post_id = event_m_get_param('id');
        $this->payment_service->cancel($post_id);
        wp_send_json_success();
    }

}

EventM_Offline_Admin::get_instance();