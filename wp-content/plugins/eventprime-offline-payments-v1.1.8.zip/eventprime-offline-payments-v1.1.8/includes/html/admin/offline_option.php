<li>
    <input type="checkbox" name="offline_processor" ng-true-value="1" ng-fale-value="0" ng-model="data.options.offline_processor" />
    <span class="payment_processor_offiline"> <strong><?php _e("OFFLINE", 'eventprime-offline'); ?></strong></span>
    <div class="emrow"><div class="rminput" ><a ng-class="{'disable-Stripe-Config': !data.options.offline_processor}"  ng-click="configure_offline = true"><?php _e('Configure', 'eventprime-offline'); ?></a></div></div>
    <div class="kf-payment_offiline-info">
        <?php _e("Collect payments offline and manually update booking status within EventPrime's dashboard.", 'eventprime-offline'); ?>
    </div>
</li>