<?php
    wp_enqueue_script( 'em-offline-controller', plugin_dir_url(__DIR__) . 'js/em-offline-controller.js', array('em-angular', 'em-angular-module'), false );
?>
<div ng-show="data.post.payment_log.payment_gateway=='offline' && data.post.status != 'refunded'" class="em-booking-row" ng-controller="emOfflineCtrl" >
    <span class="em-booking-label"><?php _e('Payment Status:', 'eventprime-offline'); ?></span>

    <span ng-show="data.post.status != 'cancelled' && data.post.payment_log.offline_status != 'Cancelled'" class="em-booking-detail">
        <select class="dbfl" id="offline_status" ng-model="data.post.payment_log.offline_status" ng-change="saveStatus()" name="offline_status" ng-options="key as value for (key , value) in data.post.offline_options">
        </select>
    </span>
    <!--
    <span ng-show="data.post.payment_log.offline_status=='Received'" class="em-booking-detail" >
       {{ data.post.payment_log.offline_status }}
    </span>
    -->
    <span ng-show="data.post.status=='cancelled' && data.post.payment_log.offline_status == 'Pending'" class="em-booking-detail" >
       <?php _e('Booking has been cancelled by Attendee.', 'eventprime-offline'); ?>
    </span>
    
    <span ng-show="data.post.status=='cancelled' && data.post.payment_log.offline_status == 'Cancelled'" class="em-booking-detail" >
       <?php _e('Booking has been cancelled.', 'eventprime-offline'); ?>
    </span>
    
    <span ng-show="data.post.status=='completed' && data.post.payment_log.offline_status == 'Cancelled'" class="em-booking-detail" >
       <?php _e('Booking has been cancelled.', 'eventprime-offline'); ?>
    </span>
    
    <span ng-show="(data.post.status=='cancelled') && data.post.payment_log.offline_status=='Cancelled'" class="em-booking-label ep-refund-label"> 
        <input type="button" class="kf-upload" value="<?php _e('Mark as Refund', 'eventprime-offline'); ?>" ng-click="markRefund()">
    </span>
</div>