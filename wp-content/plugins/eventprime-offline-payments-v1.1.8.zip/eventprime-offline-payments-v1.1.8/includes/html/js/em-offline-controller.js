eventMagicApp.controller('emOfflineCtrl',function($scope, $http, EMRequest) {
    
    // Admin Offline Methods 
    $scope.saveStatus = function() {
        var add_msg='';
        if($scope.data.post.payment_log.offline_status == 'Received'){
            add_msg = 'This will send payment confirmation email to the user.';
        }
        var flag = confirm("You are about to change payment status of this booking to '"+ $scope.data.post.payment_log.offline_status +"'. "+ add_msg + " Do you wish to continue ?");
        if(flag) {
            $scope.progressStart();
            if ($scope.data.post.payment_log.offline_status == 'Cancelled') 
                EMRequest.send('em_cancel_offline_booking',$scope.data.post).then(function(response) {});
            EMRequest.send('em_save_offline_booking_status',$scope.data.post).then(function(response) {
                $scope.progressStop();
                if(response.data.success) {
                    alert("Payment status has been updated.");
                    $scope.preparePageData();
                } else {
                    alert("An error occurred while saving the changes. Please try again.");
                    location.reload(); 
                }
            });
        } else {
            location.reload();
        }
    }
 
    // Just to make Booking as Refunded, if admin does the refund
    $scope.markRefund = function(){
         var flag = confirm("Are you sure you want to mark this Booking as Refund?");
            if(flag) {
                $scope.progressStart();
                EMRequest.send('em_cancel_booking',$scope.data.post).then(function(response){
                    $scope.progressStop();
                    $scope.preparePageData();
                    $scope.refund_status= response.data.msg;
                }); 
            } else {
                location.reload(); 
            }
    }

    // Front End Offline Methods 
    $scope.proceedOffline=  function() {
        if ($scope.orders.length > 0) {
            var booking = {};
            booking.booking_id = $scope.order.order_id;
            $scope.progressStart();
            EMRequest.send('em_verify_booking', booking).then(function (response) {
                $scope.progressStop();
                if (response.data.success) {
                    if($scope.price==0) {
                        $scope.proceedWithoutPayment();
                    } else {
                        $scope.progressStart();
                        $scope.offlineResponseHandler();
                    }                   
                } else {
                    alert("There seems to be a problem. Please refresh the page and try again");
                }
            });
        }
    }
    
    $scope.offlineResponseHandler= function(response) {
        var order= {};
        var list= [];
        for(var i=0;i<$scope.orders.length;i++) {
            list[i]= {
                'single_price': $scope.orders[i].single_price,
                'quantity': $scope.orders[i].quantity,
                'discount': $scope.orders[i].discount,
                'order_id': $scope.orders[i].order_id,
                'item_number': $scope.orders[i].item_number,
                'coupon_code': $scope.orders[i].coupon_code,
                'coupon_discount': $scope.orders[i].coupon_discount,
                'coupon_amount': $scope.orders[i].coupon_amount,
                'coupon_type': $scope.orders[i].coupon_type,
                'woocommerce_products': $scope.orders[i].woocommerce_products,
                'billing_address': $scope.orders[i].billing_address,
                'shipping_address': $scope.orders[i].shipping_address
            }
        }
        order.list= list;
        order.amount= $scope.price;
        order.all_order_data = $scope.orders;
        EMRequest.send('em_charge_offline', order).then(function (res) {
            if(res.data.guest_booking && res.data.guest_booking == 1){
                $scope.data.gbid = $scope.orders[0].order_id;
                $scope.data.redirect_url = res.data.redirect;
                /*EMRequest.send('em_guest_booking_show_order_detail', $scope.data).then(function (response) {
                    jQuery("#booking_dialog").append(response.data);
                    $scope.progressStop();
                });*/
                $scope.progressStop();
                location.href = res.data.redirect;
            }
            else{
                $scope.progressStop();
                location.href= res.data.redirect;
            }
        }); 
    }
    
    $scope.offlineRefund= function() {
        var flag= confirm("Are you sure you want to mark this transaction as Refunded?");
        if(flag) {
            $scope.progressStart();
            EMRequest.send('em_cancel_booking',$scope.data.post).then(function(response) {
                $scope.progressStop();
                $scope.preparePageData();
                $scope.refund_status= response.data.msg;
            }); 
        } else {
            location.reload(); 
        }
    }
    
    // woocommerce billing / shipping validation
    $scope.validateBillingShipping = function(){
        $scope.$parent.billingErrors = [];
        $scope.$parent.shippingErrors = [];
        var setFocus = 0;
        angular.forEach($scope.order.billing_address, function(item, index){
            if(!item){
                var itemElem = angular.element("#"+index);
                if(itemElem){
                    var itemReq = itemElem.data('field_required');
                    if(itemReq){
                        $scope.$parent.billingErrors.push(itemReq);
                        if(setFocus == 0){
                            itemElem.focus();
                            setFocus = 1;
                        }
                        return false;
                    }
                }
            }
        });
        if($scope.order.shipping_address.address_option == 'same'){
            var shiAdd = {};
            angular.forEach($scope.order.shipping_address, function(item, index){
                if(index && index !== 'address_option'){
                    shiAdd[index] = '';
                    var sapItem = index.replace('shipping_', '');
                    shiAdd[index] = $scope.order.billing_address['billing_'+sapItem];
                }
            });
            $scope.order.shipping_address = shiAdd;
        }
        angular.forEach($scope.order.shipping_address, function(item, index){
            if($scope.order.shipping_address.address_option == 'same'){
                if(index !== 'address_option'){
                    var sapItem = index.replace('shipping_', '');
                    $scope.order.shipping_address.index = $scope.order.billing_address['billing_'+sapItem];
                }
            }
            if(!item){
                var itemElem = angular.element("#"+index);
                if(itemElem){
                    var itemReq = itemElem.data('field_required');
                    if(itemReq){
                        $scope.$parent.shippingErrors.push(itemReq);
                        if(setFocus == 0){
                            itemElem.focus();
                            setFocus = 1;
                        }
                        return false;
                    }
                }
            }
        });
        
        if(setFocus == 0){
            $scope.proceedOffline();
        }
    }
});