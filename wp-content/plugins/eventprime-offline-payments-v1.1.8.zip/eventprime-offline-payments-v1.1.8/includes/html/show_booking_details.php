<?php if(isset($offline_status) && $offline_status != null) { ?>
<tr>
    <td><?php _e('Payment Status', 'eventprime-offline'); ?></td>
    <td id="em_booking_status"><?php echo $offline_status; ?></td>
</tr>
<?php } ?>
