<?php wp_enqueue_script( 'em-offline-controller', EM_OFFLINE_BASE_URL. 'includes/html/js/em-offline-controller.js', array('em-angular', 'em-angular-module'), false );?>
<div class="kf-payment-mode-select" ng-controller="emOfflineCtrl" ng-show="price &gt; 0 && bookable && payment_processors.hasOwnProperty('offline') && payment_processors.offline==1">
    <div class="em_checkout_input_radio">
        <input type="radio" name="offline" value="offline" ng-model="data.payment_processor" id="ep-offline-payment" /><label for="ep-offline-payment" class="ep-payment-checkout-btn-wrap ep-payment-checkout-offline"><?php _e("Offline", 'eventprime-offline'); ?></label>
    </div>
</div>
<div class="ep-payment-checkout-btn em_bg_lt dbfl" ng-controller="emOfflineCtrl" ng-show="data.payment_processor=='offline'">
    <div class="em_checkout_btn" ng-show="data.payment_processor=='offline' && bookable && applyWoocommerce == 0">
        <button  class="ep-payment-button" ng-click="proceedOffline()"><?php echo em_global_settings_button_title('Checkout'); ?></button>
    </div>
    <div class="em_checkout_btn" ng-show="data.payment_processor=='offline' && bookable && applyWoocommerce == 1">
        <button  class="ep-checkout-btn" ng-click="validateBillingShipping()"><?php echo em_global_settings_button_title('Checkout'); ?></button>
    </div>
</div>
<!-- Offline Proceed Button -->
