<?php

class EventM_Offline_Payment_Service extends EventM_Payment_Service {
    
    function __construct() {
        parent::__construct("offline");
    }
    
    public function cancel($post_id) {
        $booking_id = $post_id;
        $service = EventM_Factory::get_service('EventM_Booking_Service');
        $service->revoke_seats($booking_id);
        $booking = $service->load_model_from_db($booking_id);
        
        // Changing booking status
        $booking->status = 'cancelled';
        $booking->payment_log['payment_status'] = 'cancelled';
        $booking->payment_log['offline_status'] = 'Cancelled';
        $service->save($booking);

        // cancel the recurring events automatic bookings
        do_action('event_magic_automatic_recurrence_booking_cancel', $booking);
    }
    
    public function refund($order_id, $info = array()) {}
    
    public function charge($order=array()) {
        $data = array();
        $order_id = $order['order_id'];
        
        if(empty($order['amount']))
            return false;
 
        $data = array(
            'payment_status' => 'completed',
            'offline_status' => EventM_Constants::$offline_status['Pending'],
            'total_amount' => $order['amount'],
            'currency' => $order['currency'],
            'payment_gateway' => 'offline'
        );
        
        return $data;
    }
}