<?php

class EventM_Offline_Service {
    
    protected $settings;
    protected $op_service;
    protected $payment_service;
    private static $instance = null;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        $gs_service = EventM_Factory::get_service('EventM_Setting_Service');
        $this->settings = $gs_service->load_model_from_db();
        $this->payment_service = new EventM_Offline_Payment_Service();
        $this->actions();
    }
    
    public function charge() {
        
        if ($_SERVER['REQUEST_METHOD']!=='POST') {
            wp_send_json_error(array('msg'=>__('Invalid access')));
        }
        
        $request= EventM_Raw_Request::get_instance();
        $gs_service = EventM_Factory::get_service('EventM_Setting_Service');
        $gs = $gs_service->load_model_from_db();

        $amount = $request->get_param('amount',true);
        $list = $request->get_param('list',true);
        $all_order_data = $request->get_param('all_order_data',true);
        if($amount>0)
            $offline_response = $this->payment_service->charge(
            array(
                'amount' => $amount,
                'currency' => $gs->currency, 
                'order_id'=> (isset($list['order_id']) ? $list['order_id'] : ''),
            )
         );
        
        $booking_service = EventM_Factory::get_service('EventM_Booking_Service');
        $order_ids = array();
        
        if(!empty($list)) {
            foreach($list as $key=>$val) {
                $par_amt = $val->single_price * (int) $val->quantity;
                if(isset($val->discount) && !empty($val->discount)){
                    $par_amt -= $val->discount;
                }
                $offline_response['partial_amount'] = $par_amt;
                //$offline_response['item_price'] = $val->single_price;
                $offline_response['coupon_code'] = $val->coupon_code;
                $offline_response['coupon_discount'] = $val->coupon_discount;
                $offline_response['coupon_amount'] = $val->coupon_amount;
                $offline_response['coupon_type'] = $val->coupon_type;
                $offline_response = apply_filters('event_magic_add_offline_payment_response', $offline_response, $all_order_data);
                $booking_service->confirm_booking($val->order_id, $offline_response);
                $order_ids[] = $val->order_id;
            }
        }
        
        $response = new stdClass();
        $response->error = false;

        $response->redirect = add_query_arg(array('em_bookings' => implode(',',$order_ids) ), get_permalink($gs->profile_page));
        if(!is_user_logged_in()){
            $showBookNowForGuestUsers = em_show_book_now_for_guest_users();
            if(!empty($showBookNowForGuestUsers)){
                /*$response->guest_booking = 1;
                if(!empty($gs->guest_booking_page_redirect)){
                    $response->redirect = get_permalink($gs->guest_booking_page_redirect);
                }*/

                $response->redirect = add_query_arg(array('id' => $order_ids[0], 'is_guest' => 1), get_permalink(em_global_settings('booking_details_page')));
                if(!empty($gs->guest_booking_page_redirect)){
                    $redirect_url = get_permalink($gs->guest_booking_page_redirect);
                    $response->redirect = add_query_arg(array('redirect_url' => esc_url($redirect_url)), $response->redirect);
                }
            }



            

        }
        echo json_encode($response);
        die;
    }
    
    public function refund($booking) {
        if(!em_is_admin()){
            return $booking;
        }
        if($booking->order_info['payment_gateway']=='offline') {
            $booking->status = 'refunded';
            $booking->payment_log['payment_status'] = 'refunded';
            $booking->payment_log['offline_status'] = 'Refunded';
        }
        return $booking;
    }
    
    public function actions() {
        add_action('event_magic_front_payment_processors', array($this,'front_processor_option'));
        add_action('event_magic_front_user_booking_details', array($this,'user_booking_details'));
        add_action('event_magic_load_payment_configuration', array($this,'load_configuration'));
        add_action('wp_ajax_em_charge_offline', array($this,'charge'));
        add_action('wp_ajax_nopriv_em_charge_offline', array($this,'charge'));
        add_filter('event_magic_refund_booking', array($this,'refund'));
    }

    /* Front end related functions */
    public function front_processor_option() {
        if($this->settings->offline_processor==1)
            include_once(EM_OFFLINE_PLUGIN_DIR."/includes/html/show_offline.php");
    }
    
    // Payment Details on User Bookings page
    public function user_booking_details($offline_status) {
        include(EM_OFFLINE_PLUGIN_DIR."/includes/html/show_booking_details.php");
    }
    
    public function load_configuration($response) {
        if(isset($this->settings->offline_processor)&&$this->settings->offline_processor==1) {   
            $response->payment_prcoessor['offline'] = 1;
        }
        return $response;
    }
    
}
EventM_Offline_Service::get_instance();