<?php
/**
 * Plugin Name:       EventPrime Recurring Events
 * Plugin URI:        http://eventprime.net
 * Description:       Enable event recurrence from Event Dashboard for daily, weekly, monthly, yearly, advanced and custom dates intervals.
 * Version:           1.0.6
 * Author:            EventPrime
 * Author URI:        http://eventprime.net
 * Text Domain:       eventprime-recurring-events
 * Domain Path:       /languages
 * Requires at least: 4.8
 * Tested up to:      6.0.1
 * Requires PHP:      5.6
 */
// Exit if accessed directly
if (!defined('ABSPATH'))
	exit;

// Check if plugin is active and class not already loaded
if (!class_exists('EventPrime_Recurring_Events')) {

    final class EventPrime_Recurring_Events {

        public $version = '1.0.6';
        private static $instance = null;

        public static function instance() {
            if (is_null(self::$instance)) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        private function __construct() {
            $this->load_plugin_textdomain();
            $this->define_constants();
            $this->global_actions();
            $this->includes();
            $em = event_magic_instance();
            array_push($em->extensions, 'recurring_events');
        }

        public function global_actions() {
            //add_filter('loading_event_from_db', array($this,'load_into_event_model'),10,2);
            add_action('event_magic_gs_settings',array($this,'event_recurring_events_gs_settings'));
            add_filter('eventprime_load_post_response', array($this,'load_into_post_response_model'),10,2);
            add_filter('eventprime_load_into_event_model', array($this,'load_event_recurrence_parameters'),10,2);
            add_filter('eventprime_save_into_post_model', array($this,'save_event_parent_id'),10,2);
            add_action('event_magic_automatic_recurrence_tmp_booking',array($this,'save_automatic_recurrence_tmp_booking'));
            add_action('event_magic_automatic_recurrence_booking',array($this,'save_automatic_recurrence_booking'));
            add_action('event_magic_automatic_recurrence_booking_refund',array($this,'refund_automatic_recurrence_booking'));
            add_action('event_magic_automatic_recurrence_booking_cancel',array($this,'cancel_automatic_recurrence_booking'));
            add_action('event_magic_booking_cancelled', array($this,'cancel_automatic_recurrence_booking'), 10, 1);
        }

        public function define_constants() {
            if (!defined('EVENTPRIME_RECURRING_BASE_URL')) {
                define('EVENTPRIME_RECURRING_BASE_URL', plugin_dir_url(__FILE__));
            }
            if (!defined('EVENTPRIME_RECURRING_PLUGIN_DIR')) {
                define('EVENTPRIME_RECURRING_PLUGIN_DIR', plugin_dir_path(__FILE__));
            }
            if (!defined('EVENTPRIME_RECURRING_INTERVALS')) {
                define('EVENTPRIME_RECURRING_INTERVALS', array(
                    'daily' => __('Day(s)', 'eventprime-recurring-events'),
                    'weekly' => __('Week(s)', 'eventprime-recurring-events'),
                    'monthly' => __('Month(s)', 'eventprime-recurring-events'),
                    'yearly' => __('Year(s)', 'eventprime-recurring-events'),
                    'advanced' => __('Advanced', 'eventprime-recurring-events'),
                    'custom_dates' => __('Custom Dates', 'eventprime-recurring-events')
                ));
            }
            if (!defined('EVENTPRIME_WEEK_DAYS')) {
                define('EVENTPRIME_WEEK_DAYS', array(
                    ["key" => 0, "value" => __('S', 'eventprime-recurring-events')],
                    ["key" => 1, "value" => __('M', 'eventprime-recurring-events')],
                    ["key" => 2, "value" => __('T', 'eventprime-recurring-events')],
                    ["key" => 3, "value" => __('W', 'eventprime-recurring-events')],
                    ["key" => 4, "value" => __('T', 'eventprime-recurring-events')],
                    ["key" => 5, "value" => __('F', 'eventprime-recurring-events')],
                    ["key" => 6, "value" => __('S', 'eventprime-recurring-events')],
                ));
            }
            if (!defined('EVENTPRIME_FULL_WEEK_DAYS')) {
                define('EVENTPRIME_FULL_WEEK_DAYS', array(
                    '0' => __('Sunday', 'eventprime-recurring-events'),
                    '1' => __('Monday', 'eventprime-recurring-events'),
                    '2' => __('Tuesday', 'eventprime-recurring-events'),
                    '3' => __('Wednesday', 'eventprime-recurring-events'),
                    '4' => __('Thursday', 'eventprime-recurring-events'),
                    '5' => __('Friday', 'eventprime-recurring-events'),
                    '6' => __('Saturday', 'eventprime-recurring-events'),
                ));
            }
            if (!defined('EVENTPRIME_WEEK_NUMBER')) {
                define('EVENTPRIME_WEEK_NUMBER', array(
                    '1' => __('first', 'eventprime-recurring-events'),
                    '2' => __('second', 'eventprime-recurring-events'),
                    '3' => __('third', 'eventprime-recurring-events'),
                    '4' => __('fourth', 'eventprime-recurring-events'),
                    '5' => __('last', 'eventprime-recurring-events'),
                ));
            }
            if (!defined('EVENTPRIME_FULL_MONTH_DAYS')) {
                define('EVENTPRIME_FULL_MONTH_DAYS', array(
                    '1' => __('January', 'eventprime-recurring-events'),
                    '2' => __('February', 'eventprime-recurring-events'),
                    '3' => __('March', 'eventprime-recurring-events'),
                    '4' => __('April', 'eventprime-recurring-events'),
                    '5' => __('May', 'eventprime-recurring-events'),
                    '6' => __('June', 'eventprime-recurring-events'),
                    '7' => __('July', 'eventprime-recurring-events'),
                    '8' => __('August', 'eventprime-recurring-events'),
                    '9' => __('September', 'eventprime-recurring-events'),
                    '10' => __('October', 'eventprime-recurring-events'),
                    '11' => __('November', 'eventprime-recurring-events'),
                    '12' => __('December', 'eventprime-recurring-events'),
                ));
            }
            if (!defined('EVENTPRIME_ADVANCED_WEEK')) {
                define('EVENTPRIME_ADVANCED_WEEK', array(
                    'first' => __('First', 'eventprime-recurring-events'),
                    'second' => __('Second', 'eventprime-recurring-events'),
                    'third' => __('Third', 'eventprime-recurring-events'),
                    'fourth' => __('Fourth', 'eventprime-recurring-events'),
                    'last' => __('Last', 'eventprime-recurring-events')
                ));
            }
            if (!defined('EVENTPRIME_ADVANCED_WEEK_DAYS')) {
                define('EVENTPRIME_ADVANCED_WEEK_DAYS', array(
                    'mon' => __('Mon', 'eventprime-recurring-events'),
                    'tue' => __('Tue', 'eventprime-recurring-events'),
                    'wed' => __('Wed', 'eventprime-recurring-events'),
                    'thu' => __('Thu', 'eventprime-recurring-events'),
                    'fri' => __('Fri', 'eventprime-recurring-events'),
                    'sat' => __('Sat', 'eventprime-recurring-events'),
                    'sun' => __('Sun', 'eventprime-recurring-events')
                ));
            }
        }

        private function includes() {
            include('includes/service/class-em-recurring-events.php');
            if(is_admin()){
                include('includes/admin/class-admin.php');
            }
        }

        public function load_plugin_textdomain() {
                load_plugin_textdomain('eventprime-recurring-events', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        public function event_recurring_events_gs_settings(){?>
            <a href='javascript:void(0)'>
                <div class="em-settings-box ep-active-extension ep-no-global-settings-model" data-popup="ep-recurring-events-ext" onclick="CallEPExtensionModal(this)">
                    <img class="em-settings-icon" ng-src="<?php echo EM_BASE_URL; ?>includes/admin/template/images/ep-recurring-events-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Recurring Event', 'eventprime-recurring-events'); ?></div>
                    <span><?php _e('Create recurring events.', 'eventprime-recurring-events'); ?></span>
                </div>
            </a>
            <?php
        }

        public function load_into_post_response_model($response) {
            $response->post['recurrence_intervals'] = EVENTPRIME_RECURRING_INTERVALS;
            $response->post['recurrence_weekdays'] = EVENTPRIME_WEEK_DAYS;
            $response->post['recurrence_fullweekdays'] = EVENTPRIME_FULL_WEEK_DAYS;
            $response->post['recurrence_weeknos'] = EVENTPRIME_WEEK_NUMBER;
            $response->post['recurrence_monthdays'] = EVENTPRIME_FULL_MONTH_DAYS;
            $response->post['recurrence_advanced_week'] = EVENTPRIME_ADVANCED_WEEK;
            $response->post['recurrence_advanced_week_days'] = EVENTPRIME_ADVANCED_WEEK_DAYS;
            // weekly interval setup
            $weekly_day = array(date('w') => true);
            if(!empty($response->post['is_weekly_recurrence'])){
                $weekly_day = array();
                foreach ($response->post['selected_weekly_day'] as $key => $value) {
                    $weekly_day[$key] = true;
                }
            }
            $response->post['selected_weekly_day'] = $weekly_day;
            $date = date("Y-m-d");
            $firstOfMonth = date("Y-m-01", strtotime($date));
            $currentWeekNo = intval(date("W", strtotime($date))) - intval(date("W", strtotime($firstOfMonth))) + 1;

            // monthly interval setup
            $month_week_no = EVENTPRIME_WEEK_NUMBER[$currentWeekNo];
            $month_week_day = EVENTPRIME_FULL_WEEK_DAYS[$currentWeekNo];
            $month_no = 1;
            if(!empty($response->post['is_monthly_recurrence'])){
                $month_week_no = (!empty($response->post['monthly_weekno'])) ? $response->post['monthly_weekno'] : $month_week_no; 
                $month_week_day = (!empty($response->post['monthly_fullweekday'])) ? $response->post['monthly_fullweekday'] : $month_week_day;
                $month_no = (!empty($response->post['monthly_month'])) ? $response->post['monthly_month'] : $month_no;
            }
            $response->post['monthly_weekno'] = $month_week_no;
            $response->post['monthly_fullweekday'] = $month_week_day;
            $response->post['monthly_month'] = $month_no;

            // yearly interval setup
            $yearly_week_no = EVENTPRIME_WEEK_NUMBER[$currentWeekNo];
            $yearly_week_day = EVENTPRIME_FULL_WEEK_DAYS[date('w')];
            $yearly_no = EVENTPRIME_FULL_MONTH_DAYS[date('n')];
            if(!empty($response->post['is_yearly_recurrence'])){
                $yearly_week_no = (!empty($response->post['yearly_weekno'])) ? $response->post['yearly_weekno'] : $yearly_week_no; 
                $yearly_week_day = (!empty($response->post['yearly_fullweekday'])) ? $response->post['yearly_fullweekday'] : $yearly_week_day;
                $yearly_no = (!empty($response->post['yearly_monthday'])) ? $response->post['yearly_monthday'] : $yearly_no;
            }

            $response->post['yearly_weekno'] = $yearly_week_no;
            $response->post['yearly_fullweekday'] = $yearly_week_day;
            $response->post['yearly_monthday'] = $yearly_no;
            
            // advanced interval setup
            $admonth_no = 1;$ad_recurr = [];
            if(!empty($response->post['is_advanced_recurrence'])){
                $admonth_no = (!empty($response->post['advanced_month'])) ? $response->post['advanced_month'] : $admonth_no;
                $ad_recurr = (!empty($response->post['advanced_recurr'])) ? $response->post['advanced_recurr'] : $ad_recurr;
            }
            $response->post['advanced_month'] = $admonth_no;
            $response->post['advanced_recurr'] = maybe_unserialize($ad_recurr);
            
            // custom dates interval setup
            $custom_dates_field = '';
            if(!empty($response->post['is_custom_dates_recurrence'])){
                $custom_dates_field = (!empty($response->post['recurrence_custom_dates'])) ? $response->post['recurrence_custom_dates'] : $custom_dates_field;
            }
            $response->post['recurrence_custom_dates'] = maybe_unserialize($custom_dates_field);
            
            // set recurrence limit to event start date
            $set_recurrent_limit = $response->post['recurrence_limit'];
            $event_start_date = strtotime($response->post['start_date']);
            if($set_recurrent_limit < $event_start_date){
                $set_recurrent_limit = $event_start_date;
            }
            $response->post['recurrence_limit'] = em_showDateTime($set_recurrent_limit,false,"m/d/Y");
            $response->post['is_weekly_recurrence'] = (!empty($response->post['is_weekly_recurrence'])) ? absint($response->post['is_weekly_recurrence']) : 0;
            $response->post['is_monthly_recurrence'] = (!empty($response->post['is_monthly_recurrence'])) ? absint($response->post['is_monthly_recurrence']) : 0;
            $response->post['is_yearly_recurrence'] = (!empty($response->post['is_yearly_recurrence'])) ? absint($response->post['is_yearly_recurrence']) : 0;
            $response->post['is_advanced_recurrence'] = (!empty($response->post['is_advanced_recurrence'])) ? absint($response->post['is_advanced_recurrence']) : 0;

            if(empty($response->post['is_weekly_recurrence']) && empty($response->post['is_monthly_recurrence']) && empty($response->post['is_yearly_recurrence']) && empty($response->post['is_advanced_recurrence'])){
                $response->post['is_default_recurrence'] = 1;
            }

            return $response;
        }

        public function load_event_recurrence_parameters($event,$post) {
            $event->parent = absint($post->post_parent);
            $event->enable_recurrence = metadata_exists('post',$post->ID,'em_enable_recurrence') ? absint(em_get_post_meta($post->ID,'enable_recurrence',true)) : 0;
            $event->recurrence_interval = metadata_exists('post',$post->ID,'em_recurrence_interval') ? em_get_post_meta($post->ID,'recurrence_interval',true) : 'daily';
            $event->recurrence_step = metadata_exists('post',$post->ID,'em_recurrence_step') ? absint(em_get_post_meta($post->ID,'recurrence_step',true)) : 1;
            $event->recurrence_limit = metadata_exists('post',$post->ID,'em_recurrence_limit') ? absint(em_get_post_meta($post->ID,'recurrence_limit',true)) : current_time('timestamp');

            $event->selected_weekly_day = metadata_exists('post',$post->ID,'em_selected_weekly_day') ? em_get_post_meta($post->ID,'selected_weekly_day',true) : '';

            $event->monthly_weekno = metadata_exists('post',$post->ID,'em_monthly_weekno') ? em_get_post_meta($post->ID,'monthly_weekno',true) : '';

            $event->monthly_fullweekday = metadata_exists('post',$post->ID,'em_monthly_fullweekday') ? em_get_post_meta($post->ID,'monthly_fullweekday',true) : '';

            $event->monthly_month = metadata_exists('post',$post->ID,'em_monthly_month') ? absint(em_get_post_meta($post->ID,'monthly_month',true)) : '';

            $event->yearly_weekno = metadata_exists('post',$post->ID,'em_yearly_weekno') ? em_get_post_meta($post->ID,'yearly_weekno',true) : '';

            $event->yearly_fullweekday = metadata_exists('post',$post->ID,'em_yearly_fullweekday') ? em_get_post_meta($post->ID,'yearly_fullweekday',true) : '';

            $event->yearly_monthday = metadata_exists('post',$post->ID,'em_yearly_monthday') ? em_get_post_meta($post->ID,'yearly_monthday',true) : '';

            $event->is_weekly_recurrence = metadata_exists('post',$post->ID,'em_is_weekly_recurrence') ? absint(em_get_post_meta($post->ID,'is_weekly_recurrence',true)) : '';

            $event->is_monthly_recurrence = metadata_exists('post',$post->ID,'em_is_monthly_recurrence') ? absint(em_get_post_meta($post->ID,'is_monthly_recurrence',true)) : '';
            
            $event->is_advanced_recurrence = metadata_exists('post',$post->ID,'em_is_advanced_recurrence') ? absint(em_get_post_meta($post->ID,'is_advanced_recurrence',true)) : '';

            $event->advanced_month = metadata_exists('post',$post->ID,'em_advanced_month') ? absint(em_get_post_meta($post->ID,'advanced_month',true)) : '';
            
            $event->advanced_recurr = metadata_exists('post',$post->ID,'em_advanced_recurr') ? maybe_unserialize(em_get_post_meta($post->ID,'advanced_recurr',true)) : [];
            
            $event->is_yearly_recurrence = metadata_exists('post',$post->ID,'em_is_yearly_recurrence') ? absint(em_get_post_meta($post->ID,'is_yearly_recurrence',true)) : '';
            
            $event->is_custom_dates_recurrence = metadata_exists('post',$post->ID,'em_is_custom_dates_recurrence') ? absint(em_get_post_meta($post->ID,'is_custom_dates_recurrence',true)) : '';

            $event->recurrence_custom_dates = metadata_exists('post',$post->ID,'em_recurrence_custom_dates') ? maybe_unserialize(em_get_post_meta($post->ID,'recurrence_custom_dates',true)) : [];

            $event->enable_recurrence_automatic_booking = metadata_exists('post',$post->ID,'em_enable_recurrence_automatic_booking') ? absint(em_get_post_meta($post->ID,'enable_recurrence_automatic_booking',true)) : 0;
            
            $event->add_slug_in_event_title = metadata_exists('post',$post->ID,'em_add_slug_in_event_title') ? absint(em_get_post_meta($post->ID,'add_slug_in_event_title',true)) : 0;
            
            $event->event_slug_type_options = metadata_exists('post',$post->ID,'em_event_slug_type_options') ? em_get_post_meta($post->ID,'event_slug_type_options',true) : '';

            $event->recurring_events_slug_format = metadata_exists('post',$post->ID,'em_recurring_events_slug_format') ? em_get_post_meta($post->ID,'recurring_events_slug_format',true) : 'Date';

            $event->enable_same_start_booking_date = metadata_exists('post',$post->ID,'em_enable_same_start_booking_date') ? absint(em_get_post_meta($post->ID,'enable_same_start_booking_date',true)) : 0;

            $event->child_exists = !empty(em_get_child_events($event->id)) ? true : false;
            return $event;
        }

        public function save_event_parent_id($args,$model) {
            if (isset($model->parent))
                $args = array_merge($args,array('post_parent'=>absint($model->parent)));
            return $args;
        }
        /**
         * Action to save automatic tmp booking into child recurring event
         */
        public function save_automatic_recurrence_tmp_booking($bookingData){
            if(!empty($bookingData) && !empty($bookingData->event)){
                $eventId = $bookingData->event;
                $event_service= EventM_Factory::get_service('EventM_Service');
                $event = $event_service->load_model_from_db($eventId);
                if(isset($event->enable_recurrence) && (!empty($event->enable_recurrence)) && isset($event->enable_recurrence_automatic_booking) && !empty($event->enable_recurrence_automatic_booking) && isset($event->child_exists) && !empty($event->child_exists)){
                    $recurring_service = EventM_Factory::get_service('EventM_Recurring_Events_Service');
                    $recurring_service->save_tmp_booking($eventId, $bookingData);
                }
            }
        }
        /**
         * Action to save automatic booking into child recurring event
         */
        public function save_automatic_recurrence_booking($bookingData){
            if(!empty($bookingData) && !empty($bookingData->event)){
                $eventId = $bookingData->event;
                $event_service= EventM_Factory::get_service('EventM_Service');
                $event = $event_service->load_model_from_db($eventId);
                if(isset($event->enable_recurrence) && (!empty($event->enable_recurrence)) && isset($event->enable_recurrence_automatic_booking) && !empty($event->enable_recurrence_automatic_booking) && isset($event->child_exists) && !empty($event->child_exists)){
                    $recurring_service = EventM_Factory::get_service('EventM_Recurring_Events_Service');
                    $recurring_service->save_booking($eventId, $bookingData);
                }
            }
        }
        /**
         * Action to refund automatic child booking
         */
        public function refund_automatic_recurrence_booking($bookingData){
            if(!empty($bookingData) && !empty($bookingData->event)){
                $eventId = $bookingData->event;
                $event_service= EventM_Factory::get_service('EventM_Service');
                $event = $event_service->load_model_from_db($eventId);
                if(isset($event->enable_recurrence) && (!empty($event->enable_recurrence)) && isset($event->enable_recurrence_automatic_booking) && !empty($event->enable_recurrence_automatic_booking) && isset($event->child_exists) && !empty($event->child_exists)){
                    $recurring_service = EventM_Factory::get_service('EventM_Recurring_Events_Service');
                    $recurring_service->refund_booking($eventId, $bookingData);
                }
            }
        }

        /**
         * Action to cancel automatic child booking
         */
        public function cancel_automatic_recurrence_booking($bookingData){
            if(!empty($bookingData) && !empty($bookingData->event)){
                $eventId = $bookingData->event;
                $event_service= EventM_Factory::get_service('EventM_Service');
                $event = $event_service->load_model_from_db($eventId);
                if(isset($event->enable_recurrence) && (!empty($event->enable_recurrence)) && isset($event->enable_recurrence_automatic_booking) && !empty($event->enable_recurrence_automatic_booking) && isset($event->child_exists) && !empty($event->child_exists)){
                    $recurring_service = EventM_Factory::get_service('EventM_Recurring_Events_Service');
                    $recurring_service->cancel_booking($eventId, $bookingData);
                }
            }
        }
    }
}

function eventprime_recurring_checks() { ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e("EventPrime Recurring Events extension won't work as EventPrime plugin is not installed or activated.", 'eventprime-recurring-events'); ?></p>
    </div>
<?php }

function eventprime_recurring_init() {
    return EventPrime_Recurring_Events::instance();
}

add_action('plugins_loaded', function() {
    if (!class_exists('Event_Magic')) {
        add_action('admin_notices', 'eventprime_recurring_checks');
    }
});
add_action('event_magic_loaded', 'eventprime_recurring_init');

require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/recurring_events_metadata.json',
    __FILE__,
    'eventprime-recurring_events'
);