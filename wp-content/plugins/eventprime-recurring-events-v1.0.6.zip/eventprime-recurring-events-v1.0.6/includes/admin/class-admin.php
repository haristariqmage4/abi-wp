<?php
class EventPrime_Recurring_Events_Admin {
    
    protected $request;
    protected $service;
    protected $dao;
    
    public function __construct() {
        $this->request = EventM_Raw_Request::get_instance();
        $this->service = EventM_Factory::get_service('EventM_Service');
        $this->dao = new EventM_Event_DAO();
        add_action('event_magic_dashboard_recurring_link',array($this,'dashboard_link'));
        add_action('event_magic_dashboard_recurring_tab',array($this,'dashboard_page'));
        //add_action('wp_ajax_em_delete_child_events',array($this,'delete_child_events'));
        //add_action('wp_ajax_em_create_child_events',array($this,'create_child_events'));
        add_action('wp_ajax_em_save_recurring_settings',array($this,'save_recurring_settings'));
        add_action('event_magic_update_child_events',array($this,'update_child_events'));
        add_action( 'insert_child_events_price_option_data', array( $this, 'insert_child_events_price_options' ) );
        add_action( 'update_child_events_price_option_data', array( $this, 'update_child_events_price_options' ) );
        add_action( 'delete_child_events_price_option_data', array( $this, 'delete_child_events_price_options' ) );
        add_action( 'update_child_events_woocommerce_products', array( $this, 'update_child_events_woocommerce_pro') );
        add_action( 'save_child_events_ebd' , array( $this, 'save_child_events_ebd_data' ) );
        add_action( 'delete_child_events_ebd' , array( $this, 'delete_child_events_ebd_data' ) );
        add_action( 'update_child_events_mailpoet_post_meta' , array( $this, 'update_child_events_mp_post_meta' ) );
    }
    
    public function dashboard_link($post_id) {
        include_once('template/dashboard_icon.php');
    }
    
    public function dashboard_page($post_id) {
        wp_enqueue_style('em_recurring', plugin_dir_url(__DIR__) . 'admin/template/css/em_recurring.css', false, EVENTPRIME_VERSION);
        wp_enqueue_script('em-recurring-controller',plugin_dir_url(__DIR__).'/admin/template/js/em-recurring-controller.js',array('em-event-controller', 'jquery-ui-datepicker'));
        wp_enqueue_script('jquery-ui-datepicker');
        include_once('template/settings.php');
    }
    
    public function delete_child_events($post_data) {
        $parent_id = absint($post_data['id']);
        $child_posts = em_get_child_events($parent_id);
        if(!empty($child_posts)) {
            foreach ($child_posts as $child_post) {
                wp_delete_object_term_relationships($child_post->ID, array(EM_EVENT_VENUE_TAX, EM_EVENT_TYPE_TAX));
                wp_delete_post($child_post->ID);
            }
        }
    }
    
    public function create_child_events($post_data) {
        $parent_post = $this->service->load_model_from_db(absint($post_data['id']));
        $child_post_model = new stdClass();
        foreach($parent_post as $key => $val) {
            if (in_array($key,array('id','slug','booked_seats','status')))
                continue;
            else if (in_array($key,array('start_date','end_date','start_booking_date','last_booking_date','recurrence_limit')))
                $child_post_model->$key = absint($val);
            else
                $child_post_model->$key = $val;
        }
        $child_post_model->id = 0;
        $child_post_model->status = 'publish';
        $child_post_model->parent = absint($parent_post->id);
        $child_post_model->booked_seats = 0;
        
        $child_start_date = date("Y-m-d", $child_post_model->start_date);
        $start_date_only = new DateTime('@' . strtotime($child_start_date));
        $start_date = new DateTime('@' . $child_post_model->start_date);
        $end_date = new DateTime('@' . $child_post_model->end_date);
        $start_booking_date = !empty($child_post_model->start_booking_date) ? new DateTime('@' . $child_post_model->start_booking_date) : new DateTime('@' . $child_post_model->start_date);
        $last_booking_date = !empty($child_post_model->last_booking_date) ? new DateTime('@' . $child_post_model->last_booking_date) : new DateTime('@' . $child_post_model->end_date);
        $recurrence_limit = new DateTime('@' . $child_post_model->recurrence_limit);
        $recurrence_limit->setTime(0,0,0,0);
        $recurrence_limit_timestamp = $recurrence_limit->getTimestamp();
        $weeknos_data = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];

        if(isset($parent_post->is_weekly_recurrence) && !empty($parent_post->is_weekly_recurrence)){
            $week_days = array_keys((array)$parent_post->selected_weekly_day);
            if(!empty($week_days)){
                $step = absint($parent_post->recurrence_step);
                $step_string = ($step > 1) ? ' weeks' : ' week';
                // start modify string
                $day_name = EVENTPRIME_FULL_WEEK_DAYS[$week_days[0]];
                $wk = 1;$wstart = 0;
                // setting weekly recurrence periods
                // $init_step = ($step==1)?'Next': ;
                 if($step == 1):
                    $modify_string = 'Next '.$day_name;
                  //  $modify_string = $day_name. ' +'. $step. ' '. $step_string; 
                 elseif($step==2):
                    $modify_string = 'Second '.$day_name;
                 elseif($step==3):
                    $modify_string = 'Third '.$day_name;   
                 elseif($step==4):
                    $modify_string = 'Fourth '.$day_name;
                 elseif($step==5):
                    $modify_string = 'Fifth '.$day_name;
                 elseif($step==6):
                     $modify_string = 'Sixth '.$day_name;   
                 elseif($step==7):
                     $modify_string = 'Seventh '.$day_name;
                 else:
                     $modify_string = $day_name. ' +'. $step. ' '. $step_string;            
                 endif;
                $counter = 1; 
                while ($start_date_only->modify($modify_string)->getTimestamp() <= $recurrence_limit_timestamp) {                    
                    // get date of next recure
                    $new_modify_string = $this->get_new_modify_string($start_date, $modify_string);
                    $start_date->modify($new_modify_string);
                    $end_date->modify($new_modify_string);
                    $start_booking_date->modify($new_modify_string);
                    $last_booking_date->modify($new_modify_string);
                    $child_post_model->start_date = $start_date->getTimestamp();
                    $child_post_model->start_booking_date = ($parent_post->enable_same_start_booking_date == 1) ? $parent_post->start_booking_date : $start_booking_date->getTimestamp();
                    $child_post_model->end_date = $end_date->getTimestamp();
                    $child_post_model->last_booking_date = $last_booking_date->getTimestamp();
                    $child_post_model->recurrence_limit = $recurrence_limit->getTimestamp();
                    $child_post_model->name = ($parent_post->add_slug_in_event_title == 1) ? $this->recurring_event_slug_format($parent_post,$counter,$child_post_model->start_date):$parent_post->name;
                    $child_event_id = $this->dao->save($child_post_model);
                    $this->update_featured_image_in_child_events($parent_post->cover_image_id, $child_event_id);
                    /* update price option data for child events */
                    $this->service->update_multi_price_option( $child_post_model, $child_event_id );
                    if(count($week_days) > 1){
                        foreach ($week_days as $key => $value) {
                            if($wstart == 0){
                                $wstart = 1;
                                continue;
                            }
                            $day_name = EVENTPRIME_FULL_WEEK_DAYS[$value];
                            $modify_string = 'next '.$day_name;
                            $wk++;
                            if($start_date_only->modify($modify_string)->getTimestamp() <= $recurrence_limit_timestamp){
                                // get date of next recure
                                $new_modify_string = $this->get_new_modify_string($start_date, $modify_string);
                                $start_date->modify($new_modify_string);
                                $end_date->modify($new_modify_string);
                                $start_booking_date->modify($new_modify_string);
                                $last_booking_date->modify($new_modify_string);
                                $child_post_model->start_date = $start_date->getTimestamp();
                                $child_post_model->start_booking_date = ($parent_post->enable_same_start_booking_date == 1) ? $parent_post->start_booking_date : $start_booking_date->getTimestamp();
                                $child_post_model->end_date = $end_date->getTimestamp();
                                $child_post_model->last_booking_date = $last_booking_date->getTimestamp();
                                $child_post_model->recurrence_limit = $recurrence_limit->getTimestamp();
                                $counter++;
                                $child_post_model->name = ($parent_post->add_slug_in_event_title == 1) ? $this->recurring_event_slug_format($parent_post,$counter,$child_post_model->start_date):$parent_post->name;
                                $child_event_id = $this->dao->save($child_post_model);
                                $this->update_featured_image_in_child_events($parent_post->cover_image_id, $child_event_id);
                                /* update price option data for child events */
                                $this->service->update_multi_price_option( $child_post_model, $child_event_id );
                            }
                            if($wk == count($week_days)){
                                // move to start condition
                                $wk = 1;$wstart = 0;
                                $day_name = EVENTPRIME_FULL_WEEK_DAYS[$week_days[0]];
                                $newstep = $step - 1;
                                $modify_string = $day_name. ' +'. $newstep. ' '. $step_string;
                                break;
                            }
                        }
                    }
                  $counter++;  
                }
            }
        }
        else if(isset($parent_post->is_monthly_recurrence) && !empty($parent_post->is_monthly_recurrence)){
            $modify_string = $this->get_date_modification_string($parent_post);
            // get date of next recure
            $new_modify_string = $this->get_new_modify_string($start_date, $modify_string);
            $counter =1;
            while ($start_date_only->modify($new_modify_string)->getTimestamp() <= $recurrence_limit_timestamp) {
                $start_date_only->getTimestamp();
                $recurrence_limit_timestamp;
                $start_date->modify($new_modify_string);
                $end_date->modify($new_modify_string);
                $start_booking_date->modify($new_modify_string);
                $last_booking_date->modify($new_modify_string);
                $child_post_model->start_date = $start_date->getTimestamp();
                $child_post_model->start_booking_date = ($parent_post->enable_same_start_booking_date == 1) ? $parent_post->start_booking_date : $start_booking_date->getTimestamp();
                $child_post_model->end_date = $end_date->getTimestamp();
                $child_post_model->last_booking_date = $last_booking_date->getTimestamp();
                $child_post_model->recurrence_limit = $recurrence_limit->getTimestamp();
                $child_post_model->name = ($parent_post->add_slug_in_event_title == 1) ? $this->recurring_event_slug_format($parent_post,$counter,$child_post_model->start_date):$parent_post->name;
                $child_event_id = $this->dao->save($child_post_model);
                $this->update_featured_image_in_child_events($parent_post->cover_image_id, $child_event_id);
                /* update price option data for child events */
                $this->service->update_multi_price_option( $child_post_model, $child_event_id );
                $counter++;
                // get date of next recure
                $new_modify_string = $this->get_new_modify_string($start_date, $modify_string);
            }
        }
        else if(isset($parent_post->is_yearly_recurrence) && !empty($parent_post->is_yearly_recurrence)){
            /**
             * In the case of custom yearly recurrenc we need to increase year till end date
             */
            $recur_limit = new DateTime('@' . $child_post_model->recurrence_limit);
            $recur_last_year = $recur_limit->format('Y');
            $recur_limit_timestamp = $recur_limit->getTimestamp();
            $recur_year = date("Y");
            $counter=1;
            for ($i = $recur_year; $i <= $recur_last_year; $i++) { 
                $modify_string = $parent_post->yearly_weekno. ' '. $parent_post->yearly_fullweekday . ' of '. $parent_post->yearly_monthday .' '. $i;
                // get date of next recure
                $new_modify_string = $this->get_new_modify_string($start_date, $modify_string);
                $first_start_time = $start_date_only->modify($new_modify_string)->getTimestamp();
                /*if($start_date_only->modify($new_modify_string)->getTimestamp() > $start_date->getTimestamp()){
                    // It means we get back time from today of current year, move to next year.
                    $i++;
                    $modify_string = $parent_post->yearly_weekno. ' '. $parent_post->yearly_fullweekday . ' of '. $parent_post->yearly_monthday .' '. $i;
                    // get date of next recure
                    $new_modify_string = $this->get_new_modify_string($start_date, $modify_string);
                }*/
                if($first_start_time > $start_date->getTimestamp() && $first_start_time <= $recurrence_limit_timestamp){
                    $start_date->modify($new_modify_string);
                    $end_date->modify($new_modify_string);
                    $start_booking_date->modify($new_modify_string);
                    $last_booking_date->modify($new_modify_string);
                    $child_post_model->start_date = $start_date->getTimestamp();
                    $child_post_model->start_booking_date = ($parent_post->enable_same_start_booking_date == 1) ? $parent_post->start_booking_date : $start_booking_date->getTimestamp();
                    $child_post_model->end_date = $end_date->getTimestamp();
                    $child_post_model->last_booking_date = $last_booking_date->getTimestamp();
                    $child_post_model->recurrence_limit = $recurrence_limit->getTimestamp();
                    $child_post_model->name = ($parent_post->add_slug_in_event_title == 1) ? $this->recurring_event_slug_format($parent_post,$counter,$child_post_model->start_date):$parent_post->name;
                    $child_event_id = $this->dao->save($child_post_model);
                    $this->update_featured_image_in_child_events($parent_post->cover_image_id, $child_event_id);
                    /* update price option data for child events */
                    $this->service->update_multi_price_option( $child_post_model, $child_event_id );
                    $counter++;
                }
            }
        }
        else if(isset($parent_post->is_advanced_recurrence) && !empty($parent_post->is_advanced_recurrence)){
            // this is advanced recurring option. In which we can recurre event on selected days
            $adv_recurr = $child_post_model->advanced_recurr;

            if(!empty($adv_recurr)){
                $m = date('m');
                $y = date('Y');
                $i = 0;
                $step = absint($parent_post->advanced_month);
              /*  echo $step;die; 1*/
                $stop_recurr = 0;
                $recurr_limit_month = date('m', $child_post_model->recurrence_limit);
                $recurr_limit_year = date('Y', $child_post_model->recurrence_limit);
              
                 $items=array();
                $counter =1; 
                while($stop_recurr == 0){
                    if($i > 0){
                        $m += $step;
                        if($m > 12){
                            $y++;
                            $monDiff = $m - 12;
                            $m = $monDiff;
                        }
                        if($y == $recurr_limit_year){
                            if($m > $recurr_limit_month){
                                $stop_recurr = 1;
                                break;
                            }
                        }
                    }
                    foreach($adv_recurr as $adv){
                       
                        $advs = explode("-", $adv);
                       /*checking whether a day name occurs in the given week no of the month or not */
                        $dates = $this->nthDayInMonth($advs[1], array_search($advs[0], $weeknos_data), $m, $y);
                        /*echo $dates;die;*/
                        $child_start_date1 = date("Y-m-d", $parent_post->start_date);


                        if(!empty($dates) && strtotime($dates) > strtotime($child_start_date1)){
                            $newdates = date_create($dates);
                            $child_start_date1 = date_create($child_start_date1);
                            $start_date_diff = date_diff($child_start_date1,$newdates);
                            $modify_string = $start_date_diff->days > 1 ? '+'.$start_date_diff->days.' days' : '+'.$start_date_diff->days.' day';
                            $start_date->modify($modify_string);
                            if($start_date->getTimestamp() > $recurrence_limit_timestamp){
                                $stop_recurr = 1;
                                break;
                            }
                            $end_date->modify($modify_string);
                            $start_booking_date->modify($modify_string);
                            $last_booking_date->modify($modify_string);
                            $child_post_model->start_date = $start_date->getTimestamp();
                            $child_post_model->start_booking_date = ($parent_post->enable_same_start_booking_date == 1) ? $parent_post->start_booking_date : $start_booking_date->getTimestamp();
                            $child_post_model->end_date = $end_date->getTimestamp();
                            $child_post_model->last_booking_date = $last_booking_date->getTimestamp();
                            $child_post_model->recurrence_limit = $recurrence_limit->getTimestamp();
                            $child_post_model->name = ($parent_post->add_slug_in_event_title == 1) ? $this->recurring_event_slug_format($parent_post,$counter,$child_post_model->start_date):$parent_post->name;
                            $child_event_id = $this->dao->save($child_post_model);
                            $this->update_featured_image_in_child_events($parent_post->cover_image_id, $child_event_id);
                            /* update price option data for child events */
                            $this->service->update_multi_price_option( $child_post_model, $child_event_id );
                            $counter++;
                            // reset the variable so we can start from the actual booking dates
                            $start_date = new DateTime('@' . $parent_post->start_date);
                            $end_date = new DateTime('@' . $parent_post->end_date);
                            $start_booking_date = !empty($parent_post->start_booking_date) ? new DateTime('@' . $parent_post->start_booking_date) : new DateTime('@' . $parent_post->start_date);
                            $last_booking_date = !empty($parent_post->last_booking_date) ? new DateTime('@' . $parent_post->last_booking_date) : new DateTime('@' . $parent_post->end_date);
                        }
                    }
                    $i++;
                }
              
            }
        }
        else if(isset($parent_post->is_custom_dates_recurrence) && !empty($parent_post->is_custom_dates_recurrence)){
            // this is advanced recurring option. In which we can recurre event on selected days
            $recurrence_custom_dates = maybe_unserialize($child_post_model->recurrence_custom_dates);
            if(!empty($recurrence_custom_dates)){
                $counter = 1;
                foreach($recurrence_custom_dates as $cdates){
                    $dates = date("Y-m-d", strtotime($cdates));
                    $child_start_date1 = date("Y-m-d", $parent_post->start_date);
                    if(!empty($dates) && strtotime($dates) > strtotime($child_start_date1)){
                        $newdates = date_create($dates);
                        $child_start_date1 = date_create($child_start_date1);
                        $start_date_diff = date_diff($child_start_date1,$newdates);
                        $modify_string = $start_date_diff->days > 1 ? '+'.$start_date_diff->days.' days' : '+'.$start_date_diff->days.' day';
                        $start_date->modify($modify_string);
                        if($start_date->getTimestamp() > $recurrence_limit_timestamp){
                            $stop_recurr = 1;
                            break;
                        }
                        $end_date->modify($modify_string);
                        $start_booking_date->modify($modify_string);
                        $last_booking_date->modify($modify_string);
                        $child_post_model->start_date = $start_date->getTimestamp();
                        $child_post_model->start_booking_date = ($parent_post->enable_same_start_booking_date == 1) ? $parent_post->start_booking_date : $start_booking_date->getTimestamp();
                        $child_post_model->end_date = $end_date->getTimestamp();
                        $child_post_model->last_booking_date = $last_booking_date->getTimestamp();
                        $child_post_model->recurrence_limit = $recurrence_limit->getTimestamp();
                        $child_post_model->name = ($parent_post->add_slug_in_event_title == 1) ? $this->recurring_event_slug_format($parent_post,$counter,$child_post_model->start_date):$parent_post->name;
                        $child_event_id = $this->dao->save($child_post_model);
                        $this->update_featured_image_in_child_events($parent_post->cover_image_id, $child_event_id);
                        /* update price option data for child events */
                        $this->service->update_multi_price_option( $child_post_model, $child_event_id );
                        $counter++;
                        // reset the variable so we can start from the actual booking dates
                        $start_date = new DateTime('@' . $parent_post->start_date);
                        $end_date = new DateTime('@' . $parent_post->end_date);
                        $start_booking_date = !empty($parent_post->start_booking_date) ? new DateTime('@' . $parent_post->start_booking_date) : new DateTime('@' . $parent_post->start_date);
                        $last_booking_date = !empty($parent_post->last_booking_date) ? new DateTime('@' . $parent_post->last_booking_date) : new DateTime('@' . $parent_post->end_date);
                    }
                }
            }
        }
        else{
            $modify_string = $this->get_date_modification_string($parent_post);
            $counter = 1;
            while ($start_date_only->modify($modify_string)->getTimestamp() <= $recurrence_limit_timestamp) {
                $start_date->modify($modify_string);
                $end_date->modify($modify_string);
                $start_booking_date->modify($modify_string);
                $last_booking_date->modify($modify_string);
                $child_post_model->start_date = $start_date->getTimestamp();
                $child_post_model->start_booking_date = ($parent_post->enable_same_start_booking_date == 1) ? $parent_post->start_booking_date : $start_booking_date->getTimestamp();
                $child_post_model->end_date = $end_date->getTimestamp();
                $child_post_model->last_booking_date = $last_booking_date->getTimestamp();
                $child_post_model->recurrence_limit = $recurrence_limit->getTimestamp();
                $child_post_model->name = ($parent_post->add_slug_in_event_title == 1) ? $this->recurring_event_slug_format($parent_post,$counter,$child_post_model->start_date):$parent_post->name;
                $child_event_id = $this->dao->save($child_post_model);
                $this->update_featured_image_in_child_events($parent_post->cover_image_id, $child_event_id);
                /* update price option data for child events */
                $this->service->update_multi_price_option( $child_post_model, $child_event_id );
                $counter++;
            }
        }
    }
    
    public function save_recurring_settings() {
        $this->check_permission();
        $post_data = $this->request->get_data();
        if (intval($post_data['recurrence_step']) < 1 || $post_data['recurrence_step'] == '-') {
            wp_send_json_error(array('errors'=>array(__('Recurrence interval cannot be 0 or a negative value','eventprime-recurring-events'))));
        }
        $event_id = absint($post_data['id']);
        foreach ($post_data as $key => $val) {
            if (in_array($key,array('enable_recurrence','recurrence_step','recurrence_interval','selected_weekly_day','monthly_weekno','monthly_fullweekday','monthly_month','yearly_weekno','yearly_fullweekday','yearly_monthday','is_weekly_recurrence','is_monthly_recurrence','is_yearly_recurrence','enable_recurrence_automatic_booking','is_advanced_recurrence','is_custom_dates_recurrence','advanced_month','add_slug_in_event_title','event_slug_type_options','recurring_events_slug_format', 'enable_same_start_booking_date'))) {
                em_update_post_meta($event_id, $key, $val);
            } else if (in_array($key,array('recurrence_limit'))) {
                $limit = DateTime::createFromFormat('m/d/Y',$val);
                $limit->setTime(0,0,0,0);
                em_update_post_meta($event_id, $key, $limit->getTimestamp());
            } 
            else if (in_array($key,array('advanced_recurr'))) {
                $val = maybe_serialize($val);
                em_update_post_meta($event_id, $key, $val);
            }
            else if (in_array($key,array('recurrence_custom_dates'))) {                
                $val = maybe_serialize($val);
                em_update_post_meta($event_id, $key, $val);
            }
            else {
                continue;
            }
        }
        $this->delete_child_events($post_data);
        if (absint($post_data['enable_recurrence']) == 1)
            $this->create_child_events($post_data);
        $redirect = admin_url('/admin.php?page=em_dashboard&post_id=' . $event_id);
        wp_send_json_success(array('redirect'=>$redirect));
    }
    
    public function update_child_events($event_id) {
        $event = $this->service->load_model_from_db($event_id);
        if (isset($event->enable_recurrence) && $event->enable_recurrence == 1 && $event->parent == 0) {
            $child_posts = em_get_child_events($event->id);
            if (!empty($child_posts)) {
                $iteration = 1;
                $modify_string = $this->get_date_modification_string($event);
                $counter = count($child_posts);
                foreach($child_posts as $child_post) {
                    /* Set Feature image For Child Event */
                    $cover_image_id = $event->cover_image_id;
                    if ($cover_image_id != null && (int) $cover_image_id > 0) {
                        $this->dao->set_thumbnail($child_post->ID, $cover_image_id);
                    }
                    $child_post = $this->service->load_model_from_db($child_post->ID);
                    foreach($event as $key => $val) {
                        if (in_array($key,array('id','slug','booked_seats','status','parent','start_date','end_date','start_booking_date','last_booking_date'))) {
                            continue;
                        } else if (in_array($key,array('recurrence_limit'))) {
                            if (empty($val) || $val == '') {
                                $child_post->$key = $val;
                                continue;
                            } else {
                                $date = new DateTime('@' . $val);
                                for($i=1;$i<=$iteration;$i++) {
                                    $date->modify($modify_string);
                                }
                                $child_post->$key = $date->getTimestamp();
                            }
                        } else {
                            $child_post->$key = $val;
                        }
                    }
                    $child_post->name = ($child_post->add_slug_in_event_title == 1) ? $this->recurring_event_slug_format($child_post,$counter,$child_post->start_date):$child_post->name;
                    $this->service->update_model($child_post);
                    $iteration++;
                    $counter--;
                }
            }
        }
    }
    
    public function get_date_modification_string($parent_post) {
        $step = absint($parent_post->recurrence_step);
        $interval = $parent_post->recurrence_interval;
        $modify_string = '+' . $step;
        switch ($interval) {
            case 'daily':
                $modify_string .= ($step > 1) ? ' days' : ' day';
                break;
            case 'weekly':
                $modify_string .= ($step > 1) ? ' weeks' : ' week';
                break;
            case 'monthly':
                if(isset($parent_post->is_monthly_recurrence)){
                    $step = absint($parent_post->monthly_month);
                    $step_string = ($step > 1) ? ' months' : ' month';
                    $modify_string = $parent_post->monthly_weekno. ' '. $parent_post->monthly_fullweekday . ' of +'. $step. ' '. $step_string;
                }
                else{
                    $modify_string .= ($step > 1) ? ' months' : ' month';
                }
                break;
            case 'yearly':
                $modify_string .= ($step > 1) ? ' years' : ' year';
                break;
        }
        return $modify_string;
    }
    
    public function check_permission() {
        if (!em_is_user_admin()) {
            $error_msg = __('User not allowed to perform this operation','eventprime-recurring-events');
            wp_send_json_error(array('errors'=>array($error_msg)));
        }
    }
    
    public function nthDayInMonth($n, $day, $m = '', $y = '') {
        // day is in range 0 Sunday to 6 Saturday
        $y = (!empty($y) ? $y : date('Y'));
        $m = (!empty($m) ? $m : date('m'));
        $d = $this->firstDayInMonth($day, $m, $y);

        $weeks = $this->getWeeksInMonth($y, $m, 7); //1 (for monday) to 7 (for sunday)

        $week_status= array();    
        foreach($weeks as $weekNumber => $week){
            $week_status[$weekNumber]= $week[0].'/'.$week[1];
        }
        $week_start_end = explode("/",$week_status[$n]);
        $start_date = $week_start_end[0];
        $end_date = $week_start_end[1];
        $week_w_count = array();
        $week_date_range = array();
        $w_loop_start = 1;
        while (strtotime($start_date) <= strtotime($end_date)) {
            $timestamp = strtotime($start_date);
            $day_w_count = date('w', $timestamp);
            $week_w_count[$w_loop_start] = $day_w_count;
            $week_date_range[$w_loop_start] = $start_date;
            $start_date = date ("Y-m-d", strtotime("+1 days", strtotime($start_date)));
            $w_loop_start++;
        }

        if(in_array($day,$week_w_count))
        {
            $key_value = array_search($day,$week_w_count);
            $newDate = $week_date_range[$key_value];
            unset($week_status);
            unset($week_start_end);
            unset($week_w_count);
            unset($week_date_range);
            return $newDate; 
        }

           unset($week_status);
           unset($week_start_end);
           unset($week_w_count);
           unset($week_date_range);
           return '';
    }
    
    public function firstDayInMonth($day, $m = '', $y = '') {
        // day is in range 0 Sunday to 6 Saturday
        $y = (!empty($y) ? $y : date('Y'));
        $m = (!empty($m) ? $m : date('m'));
        $fdate = date($y.'-'.$m.'-01');
        $fd = date('w', strtotime($fdate));
        $od = 1 + ($day - $fd + 7) % 7;
        $newDate = date($y.'-'.$m.'-'.$od);
        return $newDate;
    }

    public function get_new_modify_string($start_date, $modify_string){
        $child_start_date1 = date("Y-m-d", $start_date->getTimestamp());
        $tmp_date = new DateTime($child_start_date1);
        $tmp1_date = $tmp_date;
        $tmp2_date = $tmp1_date;
        $tmp1_date->modify($modify_string);
        $start_date_diff = date_diff(new DateTime($child_start_date1),$tmp1_date);
        $new_modify_string = $start_date_diff->days > 1 ? '+'.$start_date_diff->days.' days' : '+'.$start_date_diff->days.' day';
        return $new_modify_string;
    }

    public function getWeeksInMonth($year, $month, $lastDayOfWeek){
        $aWeeksOfMonth = [];
        $date = new DateTime("{$year}-{$month}-01");
        $iDaysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $aOneWeek = [$date->format('Y-m-d')];
        $weekNumber = 1;
        for ($i = 1; $i <= $iDaysInMonth; $i++)
        {
            if ($lastDayOfWeek == $date->format('N') || $i == $iDaysInMonth)
            {
                $aOneWeek[]      = $date->format('Y-m-d');
                $aWeeksOfMonth[$weekNumber++] = $aOneWeek;
                $date->add(new DateInterval('P1D'));
                $aOneWeek = [$date->format('Y-m-d')];
                $i++;

            }
            $date->add(new DateInterval('P1D'));
        }
        return $aWeeksOfMonth;
 
     }

     public function recurring_event_slug_format($parent_post,$counter,$booking_date){
        if($parent_post->event_slug_type_options=='Prefix'):
            if($parent_post->recurring_events_slug_format=='Occurrence number'):
                return $counter.' - '.$parent_post->name; 
            elseif($parent_post->recurring_events_slug_format=='Date'):
                $date_format = !empty(em_global_settings_date_format())?em_global_settings_date_format():'m/d/Y';
                return em_showDateTime($booking_date, false, $date_format).' - '.$parent_post->name; 
            endif;   
        elseif($parent_post->event_slug_type_options=='Suffix'):
            if($parent_post->recurring_events_slug_format=='Occurrence number'):
                return $parent_post->name.' - '.$counter; 
            elseif($parent_post->recurring_events_slug_format=='Date'):
                $date_format = !empty(em_global_settings_date_format())?em_global_settings_date_format():'m/d/Y';
                return $parent_post->name.' - '.em_showDateTime($booking_date, false, $date_format); 
            endif;  
        else:
            return $parent_post->name;
        endif;        
    } 

    public function update_featured_image_in_child_events($parent_cover_image_id, $child_event_id)
    {
        /* Set Feature image For Child Event */
        $cover_image_id = $parent_cover_image_id;
        if ($cover_image_id != null && (int) $cover_image_id > 0) {
            $this->dao->set_thumbnail($child_event_id, $cover_image_id);
        } 
    }

    public function insert_child_events_price_options( $child_events_data ){
        if( ! empty( $child_events_data ) ){
            $data = $child_events_data['data'];
            $parent_price_option_id = $child_events_data['option_id'];
            $event = $this->service->load_model_from_db( $data['event_id'] );
            global $wpdb;
            if ( isset( $event->enable_recurrence ) && $event->enable_recurrence == 1 && $event->parent == 0 ) {
                $child_posts = em_get_child_events( $event->id );
                if ( ! empty( $child_posts ) ) {
                    $table_name = $wpdb->prefix.'em_price_options';
                    foreach($child_posts as $child_post) {
                        $data['event_id'] = $child_post->ID;
                        $data['parent_price_option_id'] = $parent_price_option_id;
                        $result = $wpdb->insert($table_name, $data);
                        $option_id = $wpdb->insert_id;
                    }
                }    

            }
        }
        
    }

    public function update_child_events_price_options( $child_events_data ){
        if( ! empty( $child_events_data ) ){
            $data = $child_events_data['data'];
            $option_id = $child_events_data['option_id'];
            $event_id = $child_events_data['event_id'];
            $event = $this->service->load_model_from_db( $event_id );
            global $wpdb;
            if ( isset( $event->enable_recurrence ) && $event->enable_recurrence == 1 && $event->parent == 0 ) {
                $child_posts = em_get_child_events( $event->id );
                if ( ! empty( $child_posts ) ) {
                    $table_name = $wpdb->prefix.'em_price_options';
                    foreach($child_posts as $child_post) {
                        $data['event_id'] = $child_post->ID;
                        $result = $wpdb->update( $table_name, $data , array( 'event_id' => $child_post->ID, 'parent_price_option_id' => $option_id ) );
                    }
                }    

            }
        }
        
    }

    public function delete_child_events_price_options( $child_events_data ){
        if( ! empty( $child_events_data ) ){
            $event_id = $child_events_data['event_id'];
            $option_id = $child_events_data['option_id'];
            $event = $this->service->load_model_from_db( $event_id );
            global $wpdb;
            if ( isset( $event->enable_recurrence ) && $event->enable_recurrence == 1 && $event->parent == 0 ) {
                $child_posts = em_get_child_events( $event->id );
                if ( ! empty( $child_posts ) ) {
                    $table_name = $wpdb->prefix.'em_price_options';
                    foreach($child_posts as $child_post) {
                        $wpdb->delete( $table_name, array( 'event_id' => $child_post->ID, 'parent_price_option_id' => $option_id ) );
                    }
                }    

            }
        }
    }

    public function update_child_events_woocommerce_pro( $child_events_data ){
        if( ! empty( $child_events_data ) ){
            if( $child_events_data['is_product_selected'] == 1 ){
                $selectedProducts = $child_events_data['selectedProducts'];
                $event_id = $child_events_data['event_id'];
                $event = $this->service->load_model_from_db( $event_id );
                global $wpdb;
                if ( isset( $event->enable_recurrence ) && $event->enable_recurrence == 1 && $event->parent == 0 ) {
                    $child_posts = em_get_child_events( $event->id );
                    if ( ! empty( $child_posts ) ) {
                        foreach($child_posts as $child_post) {
                            em_update_post_meta( $child_post->ID, 'selectd_products', $selectedProducts);
                        }
                    }    
    
                }
            }else{
                $event_id = $child_events_data['event_id'];
                $key = $child_events_data['key'];
                $val = $child_events_data['val'];
                $event = $this->service->load_model_from_db( $event_id );
                global $wpdb;
                if ( isset( $event->enable_recurrence ) && $event->enable_recurrence == 1 && $event->parent == 0 ) {
                    $child_posts = em_get_child_events( $event->id );
                    if ( ! empty( $child_posts ) ) {
                        foreach($child_posts as $child_post) {
                            em_update_post_meta( $child_post->ID, $key, $val );
                        }
                    }    
    
                }
            }
        }
    }

    public function save_child_events_ebd_data( $child_events_data ){
        if( !empty( $child_events_data ) ){
            $model = $child_events_data['model'];
            $rule_id = $child_events_data['post_id'];
            $event_id = $model->event_id;
            $ebd_service = EventM_Factory::get_service('EventM_Early_Bird_Discount_Service');
            $event = $this->service->load_model_from_db( $event_id );
            global $wpdb;
            if ( isset( $event->enable_recurrence ) && $event->enable_recurrence == 1 && $event->parent == 0 ) {
                $child_posts = em_get_child_events( $event->id );
                if ( ! empty( $child_posts ) ) {
                    foreach( $child_posts as $child_post ) {
                        $model->post_id = $child_post->ID;
                        $model->event_id = $child_post->ID;
                        $model->parent_rule_id = $rule_id;
                        if(!empty($model->ebd_start_date)){
                            $model->ebd_start_date = date("m/d/Y H:i", $model->ebd_start_date);
                        }
                        if(!empty($model->ebd_end_date)){
                            $model->ebd_end_date = date("m/d/Y H:i", $model->ebd_end_date);
                        }
    
                        $template = $ebd_service->save( $model );
                    }
                }    

            }
        }
    }

    public function delete_child_events_ebd_data( $child_events_data ){
        if( !empty( $child_events_data ) ){
            $ebd_dao = new EventM_Early_Bird_Discount_DAO;
            $rules = $child_events_data['rules'];
            $rule_id = $child_events_data['post_id'];
    
            if ( isset( $rules ) && !empty( $rules ) && !empty( $rule_id ) ) {
                /* $child_posts = em_get_child_events( $event->id ); */
                /* get child posts discount rule based on parent post id */
                $args = array( 
                    'post_type' => 'any',
                    'meta_query'       => array(
                        array(
                            'key'   => em_append_meta_key('parent_rule_id'),
                            'value' => $rule_id,
                        ),
                    ),
                );
                $child_posts_ebd_rules = get_posts( $args );
                if ( ! empty( $child_posts_ebd_rules ) ) {
                    foreach( $child_posts_ebd_rules as $rule ) {
                        /* $ebd_dao->deleteRule( $rules, $child_post->ID ); */
                        wp_delete_post( $rule->ID, true );
                    }
                }    
            }
        }
    }

    public function update_child_events_mp_post_meta( $child_events_data ){
        if( ! empty( $child_events_data ) ){
            $em_enable_mailpoet_value = $child_events_data['enable_mailpoet'];
            $em_mailpoet_lists_value = $child_events_data['mailpoet_lists'];
            $parent_post_id = $child_events_data['parent_post_id'];
            $event = $this->service->load_model_from_db( $parent_post_id );
            global $wpdb;
            if ( isset( $event->enable_recurrence ) && $event->enable_recurrence == 1 && $event->parent == 0 ) {
                $child_posts = em_get_child_events( $event->id );
                if ( ! empty( $child_posts ) ) {
                    foreach($child_posts as $child_post) {
                        update_post_meta($child_post->ID,'em_enable_mailpoet',$em_enable_mailpoet_value);
	                    update_post_meta($child_post->ID,'em_mailpoet_lists',$em_mailpoet_lists_value);
                    }
                }    

            }
        }
        
    }
}
new EventPrime_Recurring_Events_Admin;