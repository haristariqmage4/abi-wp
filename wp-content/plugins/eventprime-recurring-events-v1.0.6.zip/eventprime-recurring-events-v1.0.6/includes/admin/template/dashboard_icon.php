<div class="ep-grid-icon difl" id="ep-event-recurring">
    <a href="<?php echo admin_url("/admin.php?page=em_dashboard&tab=recurring&post_id=$post_id"); ?>" class="ep-dash-link">
        <div class="ep-grid-icon-area dbfl">
            <img class="ep-grid-icon dibfl" src="<?php echo EM_BASE_URL.'includes/admin/template/images/ep-recurring-events-icon.png'; ?>">
        </div>
        <div class="ep-grid-icon-label dbfl"><?php _e('Recurrence', 'eventprime-recurring-events'); ?></div>
    </a>
</div>