eventMagicApp.controller('recurringCtrl', function ($scope, $http, TermUtility, EMRequest, PostUtility) {
    $scope.advanced_recurr = [];
    $scope.total_adv_recur = 0;
    $scope.wadvDate = [];
    $scope.weeknos_data = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
    $scope.cdates = [];
    $scope.show_date_picker = 0;
    /* Show/Hide element while performing HTTP request */
    $scope.progressStart= function()
    {
        $scope.requestInProgress = true;
    }
    
    $scope.progressStop= function()
    {
        $scope.requestInProgress = false;
    }    

    /*
     * Controller initialization for data load 
     */
    $scope.initialize = function () {
        jQuery('input[name="recurrence_limit"]').datepicker({controlType: 'select',oneLine: true,changeYear: true,minDate: new Date()});
        jQuery('#recurrence_custom_dates').datepicker({
            controlType: 'select',
            oneLine: true,
            changeYear: true,
            minDate: new Date(),
            autoClose: false,
            onSelect: function (dateText, inst) {
                $scope.addOrRemoveDate(dateText);                
                setTimeout(function(){
                    jQuery( "#recurrence_custom_dates" ).datepicker( "refresh" );
                    jQuery('#ui-datepicker-div').show();
                    jQuery("#hide_date_picker").show();
                }, 300);
            },
            beforeShowDay: function (date) {
                var year = date.getFullYear();
                // months and days are inserted into the array in the form, e.g "01/01/2009", but here the format is "1/1/2009"
                var month = $scope.padNumber(date.getMonth() + 1);
                var day = $scope.padNumber(date.getDate());
                // This depends on the datepicker's date format
                var dateString = month + "/" + day + "/" + year;
                var gotDate = jQuery.inArray(dateString, $scope.cdates);
                if (gotDate >= 0) {
                    // Enable date so it can be deselected. Set style to be highlighted
                    return [true, "ui-state-highlight ep-active-dates"];
                }
                // Dates not in the array are left enabled, but with no extra style
                return [true, ""];
            }
        });
        
        setTimeout(function(){
            $scope.check_recurrence();
        }, 5000);
    }   
    
    $scope.create_recurring_events = function (event) {
        if ($scope.data.post.child_exists == true) {
            if ($scope.data.post.enable_recurrence == 0) {
                var feedback = confirm('You have disabled recurrence for this event. This action will delete all recurring events this event already has. Are you sure you want to continue?');
            } else if ($scope.data.post.enable_recurrence == 1) {
                var feedback = confirm('This event already has a series of recurring events. Saving the changes again will delete those events and create new recurring ones.');
            } else {
                var feedback = true;
            }
            if (!feedback) {
                $scope.data.post.enable_recurrence = 1;
                $scope.requestInProgress = false;
                event.preventDefault();
            }
        }
        // set weekly recurrence
        if($scope.data.post.is_weekly_recurrence == 1){
            var chk_week = $scope.data.post.selected_weekly_day;
            angular.forEach(chk_week, function(key, val){
                if(key == false){
                    delete chk_week[val];
                }
            });
        }
        // for advanced recurrence
        if($scope.data.post.is_advanced_recurrence == 1){
            $scope.data.post.advanced_recurr = $scope.advanced_recurr;
        }
        // for custom dates recurrence
        if($scope.data.post.is_custom_dates_recurrence == 1){
            $scope.data.post.recurrence_custom_dates = $scope.cdates;
        }

        $scope.progressStart();
        EMRequest.send('em_save_recurring_settings',$scope.data.post).then(function(response) {
            var responseBody = response.data;
            if (responseBody.success) {
                if(responseBody.data.hasOwnProperty('redirect')) {
                    $scope.requestInProgress = false;
                    location.href = responseBody.data.redirect;
                }
            } else {
                if (responseBody.data.hasOwnProperty('errors')) {
                    $scope.formErrors = responseBody.data.errors;
                    $scope.requestInProgress = false;
                    jQuery('html, body').animate({ scrollTop: 0 }, 'slow');
                }
            }
            $scope.progressStop();
        });
    }

    $scope.change_recur = function(model, curr = ''){
        var recur_name = ['is_weekly_recurrence', 'is_monthly_recurrence', 'is_yearly_recurrence', 'is_advanced_recurrence', 'is_custom_dates_recurrence'];
        angular.forEach(recur_name, function(key, val){
            if(model != key && model == 'is_default_recurrence'){
                $scope.data.post[key] = 0;
                if(key == 'is_advanced_recurrence' && curr && curr == 'advanced'){
                    $scope.data.post.is_default_recurrence = 0;
                    $scope.data.post[key] = 1;
                }
                else if(key == 'is_custom_dates_recurrence' && curr && curr == 'custom_dates'){
                    $scope.data.post.is_default_recurrence = 0;
                    $scope.data.post[key] = 1;  
                }
                else{
                    $scope.data.post.is_default_recurrence = 1;
                }
            }
            else{                
                $scope.data.post.is_default_recurrence = 0;
            }
        });
        $scope.check_recurrence();
    }

    $scope.check_recurrence = function(){
        if($scope.data.post){
            var event_start_date = $scope.data.post.start_date;
            var recurr_limit = $scope.data.post.recurrence_limit;
            var recurr_step = $scope.data.post.recurrence_step;
            if($scope.data.post.is_monthly_recurrence == 1){
                var recurr_step = $scope.data.post.monthly_month;
            }
            $scope.notice_msg = 'This event will recur every '+ recurr_step + ' ' + $scope.data.post.recurrence_intervals[$scope.data.post.recurrence_interval] + ' till '+ $scope.data.post.recurrence_limit +'.';
            // check for recurring possible or not
            var esd = new Date(event_start_date);
            var esd_format = (esd.getFullYear()) + '/' + (esd.getMonth() + 1) + '/' + (esd.getDate());
            var rld = new Date(recurr_limit);
            var rld_time = rld.getTime();
            var rld_format = (rld.getFullYear()) + '/' + (rld.getMonth() + 1) + '/' + (rld.getDate());
            if($scope.data.post.recurrence_interval == 'daily'){
                var esd_with_step = new Date(new Date(esd_format).getTime()+(recurr_step * 24 * 60 * 60 * 1000)).getTime();
            }
            if($scope.data.post.recurrence_interval == 'weekly'){
                var esd_with_step = new Date(new Date(esd_format).getTime()+(recurr_step * 24 * 60 * 60 * 1000 * 7)).getTime();
            }
            if($scope.data.post.recurrence_interval == 'monthly'){
                var esd_with_step = new Date(new Date(esd_format).getTime()+(recurr_step * 24 * 60 * 60 * 1000 * 30)).getTime();
            }
            if($scope.data.post.recurrence_interval == 'yearly'){
                var esd_with_step = new Date(new Date(esd_format).getTime()+(recurr_step * 24 * 60 * 60 * 1000 * 365)).getTime();
            }
            if($scope.data.post.recurrence_interval == 'advanced'){
                var recurTimes = 0;
                var recurr_step = $scope.data.post.advanced_month;
                var advrecurr = $scope.data.post.advanced_recurr;
                var esd_with_step = new Date(new Date(esd_format).getTime()+(recurr_step * 24 * 60 * 60 * 1000)).getTime();
                var startDateTime = esd.getTime();
                var currDate = new Date();
                var currMonth = currDate.getMonth();
                var currYear = currDate.getFullYear();
                if(advrecurr){
                    angular.forEach(advrecurr, function(item, index){
                        var currMonth = currDate.getMonth();
                        var currYear = currDate.getFullYear();
                        var weekitem = item.split('-');
                        var wdate = $scope.nthDayInMonth(weekitem[1], $scope.weeknos_data.indexOf(weekitem[0]), currMonth, currYear);
                        console.log(wdate);
                        esd_with_step = wdate.getTime();
                        if(esd_with_step > startDateTime && esd_with_step <= rld_time){
                            recurTimes++;
                        }
                        while(esd_with_step <= rld_time){
                            currMonth = parseInt(currMonth + recurr_step);
                            if(currMonth >= 12){
                                currMonth -= 12;
                                currYear++;
                            }
                            var wdate = $scope.nthDayInMonth(weekitem[1], $scope.weeknos_data.indexOf(weekitem[0]), currMonth, currYear);
                            console.log(wdate);
                            esd_with_step = wdate.getTime();
                            if(esd_with_step > startDateTime && esd_with_step <= rld_time){
                                recurTimes++;
                            }
                        }
                    });
                }
                if(recurTimes > 0){
                    $scope.notice_msg = 'This event will recur '+ recurTimes + ' times ' + ' till '+ $scope.data.post.recurrence_limit +'.';
                }
                else{
                    $scope.notice_msg = 'This event will not recur. Please increase recurrence limit.';
                }
            }
            if($scope.data.post.recurrence_interval == 'custom_dates'){
                if($scope.data.post.recurrence_custom_dates){
                    $scope.cdates = $scope.data.post.recurrence_custom_dates;
                }
                if($scope.cdates.length > 0){
                    var recurTimes = 0;
                    var esd_with_step = '';
                    var startDateTime = esd.getTime();
                    angular.forEach($scope.cdates, function(item, index){
                        var wdate = new Date(item);
                        esd_with_step = wdate.getTime();
                        if(esd_with_step > startDateTime && esd_with_step <= rld_time){
                            recurTimes++;
                        }
                    });
                    if(recurTimes > 0){
                        $scope.notice_msg = 'This event will recur '+ recurTimes + ' times ' + ' till '+ $scope.data.post.recurrence_limit +'.';
                    }
                    else{
                        $scope.notice_msg = 'This event will not recur. Please increase recurrence limit.';
                    }
                }
                else{
                    $scope.notice_msg = 'This event will not recur. Please select dates from calendar.';
                }
            }
            if($scope.data.post.recurrence_interval != 'advanced' && $scope.data.post.recurrence_interval != 'custom_dates'){
                if(rld_time < esd_with_step){
                    $scope.notice_msg = 'This event will not recur. Please increase recurrence limit.';
                }
            }
        }
    }
    
    $scope.setAdvancedRecurrence = function(week, day){
        if($scope.advanced_recurr.length == 0){
            $scope.advanced_recurr = $scope.data.post.advanced_recurr;
        }
        var wid = week+"-"+day;
        var weekindex = $scope.weeknos_data.indexOf(week);
        var windex = $scope.advanced_recurr.indexOf(wid);
        if(jQuery("#"+wid).hasClass('active')){
            jQuery("#"+wid).removeClass('active');
            $scope.advanced_recurr.splice(windex, 1);
        }
        else{
            jQuery("#"+wid).addClass('active');
            if(windex < 0){
                $scope.advanced_recurr.push(wid);
            }            
        }
        // get date of clicked day
        var wdate = $scope.nthDayInMonth(day, weekindex);
        var wtime = wdate.getTime();
        if($scope.wadvDate.indexOf(wtime) > -1){
            var wtimeIndex = $scope.wadvDate.indexOf(wtime);
            $scope.wadvDate.splice(wtimeIndex, 1);
        }
        else{
            $scope.wadvDate.push(wtime);
        }
        $scope.check_recurrence();
    }
    
    $scope.nthDayInMonth = function(n, day, m, y) {
        // day is in range 0 Sunday to 6 Saturday
        var y = y || new Date(Date.now()).getFullYear();
        var m = m || new Date(Date.now()).getMonth();
        var d = $scope.firstDayInMonth(day, m, y);
        return new Date(d.getFullYear(), d.getMonth(), d.getDate() + (n - 1) * 7);
    }
    
    $scope.firstDayInMonth = function(day, m, y) {
        // day is in range 0 Sunday to 6 Saturday
        var y = y || new Date(Date.now()).getFullYear();
        var m = m || new Date(Date.now()).getMonth();
        return new Date(y, m, 1 + (day - new Date(y, m, 1).getDay() + 7) % 7);
    }
    
    $scope.setAdvancedClass = function(i, ind){
        var activeClass = '';
        if($scope.data.post.recurrence_interval == 'advanced'){
            var newind = i + '-' + ind;
            if($scope.data.post.advanced_recurr.indexOf(newind) > -1){
                activeClass = 'active';
            }            
        }
        return activeClass;
    }
    
    $scope.padNumber = function(number) {
        var ret = new String(number);
        if (ret.length == 1) ret = "0" + ret;
        return ret;
    }
    
    $scope.addDate = function(date) {
        if (jQuery.inArray(date, $scope.cdates) < 0) $scope.cdates.push(date);
    }

    $scope.removeDate = function (index) {
        $scope.cdates.splice(index, 1);
    }
    // Adds a date if we don't have it yet, else remove it
    $scope.addOrRemoveDate = function(date){
        var index = jQuery.inArray(date, $scope.cdates);
        if (index >= 0) 
            $scope.removeDate(index);
        else 
            $scope.addDate(date);
        
        jQuery(".ep_selected_dates_data").html($scope.cdates.toString());
    }
    
    $scope.hide_date_picker = function(){
        jQuery('#ui-datepicker-div').hide();
        jQuery('#hide_date_picker').hide();
        $scope.check_recurrence();
    }
});