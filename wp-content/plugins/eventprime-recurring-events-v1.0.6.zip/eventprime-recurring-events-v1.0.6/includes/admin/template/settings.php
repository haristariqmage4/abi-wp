<div ng-controller="eventCtrl" ng-app="eventMagicApp" ng-cloak ng-init="initialize('event_recurring')">
    <div class="kikfyre kf-container" ng-controller="recurringCtrl" ng-init="initialize()" ng-cloak>
        <div class="kf_progress_screen" ng-show="requestInProgress"></div>
        <div class="kf-db-content" ng-hide="requestInProgress">
            <div class="kf-db-title">
                <?php _e('Recurrence', 'eventprime-recurring-events'); ?>
            </div>
            <div class="form_errors">
                <ul>
                    <li class="emfield_error" ng-repeat="error in formErrors">
                        <span>{{error}}</span>
                    </li>
                </ul>  
            </div>
            <!-- FORM -->
            <form name="recurring_events_form" novalidate ng-submit="create_recurring_events()" ng-show="data.post.parent <= 0">
                <div class="emrow">
                    <div class="emfield"><?php _e('Enable Event Recurrence', 'eventprime-recurring-events'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" name="enable_recurrence" ng-model="data.post.enable_recurrence" ng-true-value="1" ng-false-value="0">
                    </div>
                </div>
                <div class="emrow ep-recurrence-wrap" ng-show="data.post.enable_recurrence == 1">
                    <div class="emfield"><?php _e('Recurrence Interval', 'eventprime-recurring-events'); ?></div>
                    <div class="eminput ep-recurring-event-head">
                        <span class="ep-recurrence-selector" ng-hide="data.post.recurrence_interval == 'advanced' || data.post.recurrence_interval == 'custom_dates'">
                            <input type="radio" name="is_default_recurrence" ng-model="data.post.is_default_recurrence" ng-value="true" ng-change="change_recur('is_default_recurrence')">
                        </span>
                        <span class="ep-recurrence-step" ng-hide="data.post.recurrence_interval == 'advanced' || data.post.recurrence_interval == 'custom_dates'">
                            <input type="number" name="recurrence_step" ng-model="data.post.recurrence_step" min="0" ng-change="check_recurrence()">
                        </span>
                        <!-- radio button if advanced and custom dates recurrence option -->
                        <span class="ep-recurrence-selector" ng-if="data.post.recurrence_interval == 'advanced'">
                            <input type="radio" name="is_advanced_recurrence" ng-model="data.post.is_advanced_recurrence" ng-value="true">
                        </span>
                        <span class="ep-recurrence-selector" ng-if="data.post.recurrence_interval == 'custom_dates'">
                            <input type="radio" name="is_custom_dates_recurrence" ng-model="data.post.is_custom_dates_recurrence" ng-value="true">
                        </span>
                        <span class="ep-recurrence-interval">
                            <select name="recurrence_interval" ng-model="data.post.recurrence_interval" ng-options="key as value for (key, value) in data.post.recurrence_intervals" ng-change="change_recur('is_default_recurrence', data.post.recurrence_interval)"></select>
                        </span>
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Set recurrence pattern for this event', 'eventprime-recurring-events'); ?>
                    </div>
                </div>
                <!-- Weekly recurrence option -->
                <div class="emrow ep-recurrence-wrap" ng-show="data.post.enable_recurrence == 1" ng-if="data.post.recurrence_interval == 'weekly'">
                    <div class="emfield">&nbsp;</div>
                    <div class="eminput">
                        <label><input type="radio" name="is_weekly_recurrence" ng-model="data.post.is_weekly_recurrence" ng-value="true" ng-change="change_recur('is_weekly_recurrence')"></label>
                        <label ng-repeat="weekday in data.post.recurrence_weekdays">
                            <input type="checkbox" name="selected_weekly_day" ng-model="data.post.selected_weekly_day[weekday.key]" ng-disabled="!data.post.is_weekly_recurrence">{{ weekday.value }}&nbsp;
                        </label>
                    </div>
                </div>
                <!-- Monthly recurrence option -->
                <div class="emrow ep-recurrence-wrap" ng-show="data.post.enable_recurrence == 1" ng-if="data.post.recurrence_interval == 'monthly'">
                    <div class="emfield">&nbsp;</div>
                    <div class="eminput ep-recurring-event-head">
                        <div class="ep-recurrence-row">
                            <span class="ep-recurrence-selector"><input type="radio" name="is_monthly_recurrence" ng-model="data.post.is_monthly_recurrence" ng-value="true" ng-change="change_recur('is_monthly_recurrence')"></span>
                            <span class="ep-recurrence-interval"><span class="ep-recurrence-helper">The</span>
                                <select name="recurrence_weekno" ng-model="data.post.monthly_weekno" ng-options="value for (key, value) in data.post.recurrence_weeknos" ng-disabled="!data.post.is_monthly_recurrence"></select>
                            </span>
                            <span class="ep-recurrence-interval"><span>	&nbsp;</span>
                                <select name="recurrence_fullweekday" ng-model="data.post.monthly_fullweekday" ng-options="value for (key, value) in data.post.recurrence_fullweekdays" ng-disabled="!data.post.is_monthly_recurrence"></select>
                            </span>
                        </div>
                        <div class="ep-recurrence-row">
                            <span class="ep-recurrence-label">of every </span>
                            <span class="ep-recurrence-month-selector"> 
                                <input type="number" name="monthly_month" ng-model="data.post.monthly_month" ng-disabled="!data.post.is_monthly_recurrence" min="0" ng-change="check_recurrence()"> 
                            </span><span class="ep-recurrence-month-label">month(s)</span>
                        </div>
                    </div>
                </div>

                <!-- Yearly recurrence option -->
                <div class="emrow" ng-show="data.post.enable_recurrence == 1" ng-if="data.post.recurrence_interval == 'yearly'">
                    <div class="emfield">&nbsp;</div>
                    <div class="eminput ep-recurring-event-head">
                        <div class="ep-recurrence-row">
                            <span class="ep-recurrence-selector"><input type="radio" name="is_yearly_recurrence" ng-model="data.post.is_yearly_recurrence" ng-value="true" ng-change="change_recur('is_yearly_recurrence')"></span>
                  
                            <span class="ep-recurrence-interval"><span>The</span>
                                <select name="recurrence_weekno" ng-disabled="!data.post.is_yearly_recurrence" ng-model="data.post.yearly_weekno" ng-options="value for (key, value) in data.post.recurrence_weeknos"></select>
                            </span>
                            <span class="ep-recurrence-interval"><span>	&nbsp;</span>
                                <select name="recurrence_fullweekday" ng-disabled="!data.post.is_yearly_recurrence" ng-model="data.post.yearly_fullweekday" ng-options="value for (key, value) in data.post.recurrence_fullweekdays"></select>
                            </span>
                        </div>
                        
                        <div class="ep-recurrence-row ep-recurrence_monthday">
                            <span class="ep-recurrence-interval"> of 
                                <select name="recurrence_monthday" ng-disabled="!data.post.is_yearly_recurrence" ng-model="data.post.yearly_monthday" ng-options="value for (key, value) in data.post.recurrence_monthdays"></select>
                            </span>                                
                        </div>
                    </div>
                </div>
                
                <!-- Advanced recurrence option -->
                <div class="emrow" ng-show="data.post.enable_recurrence == 1" ng-if="data.post.recurrence_interval == 'advanced'">
                    <div class="emfield">&nbsp;</div>
                    <div class="eminput ep-recurring-event-head">
                        <div class="ep-recurrence-row">
                            <div id="ep-recurrence-advanced-wraper">
                                <ul ng-repeat="(key, value) in data.post.recurrence_advanced_week">
                                    <li class="ep-recurrence-week">{{value}}</li>
                                    <li ng-repeat="(i, val) in data.post.recurrence_advanced_week_days" ng-class="setAdvancedClass(i, $parent.$index+1)" id="{{i}}-{{$parent.$index+1}}" ng-click="setAdvancedRecurrence(i, $parent.$index+1)"> {{val}}</li>
                                </ul>
                            </div>
                        </div>
                        <div class="ep-recurrence-row">
                            <span class="ep-recurrence-label">of every </span>
                            <span class="ep-recurrence-month-selector"> 
                                <input type="number" name="advanced_month" ng-model="data.post.advanced_month" ng-disabled="!data.post.is_advanced_recurrence" min="0" ng-change="check_recurrence()"> 
                            </span><span class="ep-recurrence-month-label">month(s)</span>
                        </div>
                    </div>
                </div>
                
                <!-- Custom days option -->
                <div class="emrow" ng-show="data.post.enable_recurrence == 1 && data.post.recurrence_interval == 'custom_dates'">
                    <div class="emfield">&nbsp;</div>
                    <div class="eminput">
                         <div class="ep_selected_dates_data-wrap">
                        <div class="ep_selected_dates_data"></div>
                        <button class="btn btn-primary ep_recurrence_custom_dates-button" id="hide_date_picker" ng-click="hide_date_picker()" type="button" style="display:none;"><?php _e('Done', 'eventprime-recurring-events'); ?></button>
                        </div>
                        <input type="text" id="recurrence_custom_dates" name="recurrence_custom_dates" ng-model="data.post.recurrence_custom_dates" placeholder="<?php _e('Select dates', 'eventprime-recurring-events'); ?>" autocomplete="off">
                       
                        </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Select the individual dates on which this event will repeat', 'eventprime-recurring-events'); ?>
                    </div>
                </div>

                <div class="emrow" ng-show="data.post.enable_recurrence == 1">
                    <div class="emfield"><?php _e('End Date', 'eventprime-recurring-events'); ?></div>
                    <div class="eminput">
                        <input required readonly="readonly" type="text" id="recurrence_end_date" name="recurrence_limit" ng-model="data.post.recurrence_limit" ng-change="check_recurrence()">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Event will stop recurring after this date.', 'eventprime-recurring-events'); ?>
                    </div>
                </div>
                <div class="epnotice" ng-show="data.post.enable_recurrence == 1 && notice_msg">
                    {{ notice_msg }}
                    <!--<span ng-if="!notice_msg">
                        <?php //_e('This event will recur every', 'eventprime-recurring-events');?> {{data.post.recurrence_step}} {{data.post.recurrence_intervals[data.post.recurrence_interval]}} <?php _e('till', 'eventprime-recurring-events');?> {{data.post.recurrence_limit}}.
                    </span>-->
                </div>

                <div class="emrow" ng-show="data.post.enable_recurrence == 1">
                    <div class="emfield"><?php _e('Open Bookings for all Future Instances', 'eventprime-recurring-events'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" name="enable_same_start_booking_date" ng-model="data.post.enable_same_start_booking_date" ng-true-value="1" ng-false-value="0">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Enable to allow users to book for any future recurring instance of this event. If disabled, a future instance will only become available for booking once the previous event instance is complete.', 'eventprime-recurring-events'); ?>
                    </div>
                </div>
                
                <div class="emrow" ng-show="data.post.enable_recurrence == 1">
                    <div class="emfield"><?php _e('Limit Bookings to First Event in Series', 'eventprime-recurring-events'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" name="enable_recurrence_automatic_booking" ng-model="data.post.enable_recurrence_automatic_booking" ng-true-value="1" ng-false-value="0">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Users who book first event in the series, will automatically receive booking for all future recurrences of the event. Separate bookings for future events will be disabled.', 'eventprime-recurring-events'); ?>
                    </div>
                </div>

                <div class="emrow" ng-show="data.post.enable_recurrence == 1">
                    <div class="emfield"><?php _e('Auto-Format Event Titles', 'eventprime-recurring-events'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" name="add_slug_in_event_title" ng-model="data.post.add_slug_in_event_title" ng-true-value="1" ng-false-value="0">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Modify titles of the future recurrences of the event using an automatic prefix or suffix. Enabling will display formatting options.', 'eventprime-recurring-events'); ?>
                    </div>
                </div>

                <div class="emrow" ng-show="data.post.add_slug_in_event_title == 1 && data.post.enable_recurrence == 1">
                    <div class="emrow">
                        <div class="emfield"><?php _e('Modify Title Using', 'eventprime-event-calendar-management'); ?></div>
                        <div class="eminput">
                            <select name="event_slug_type_options" id="event_slug_type_options" ng-model="data.post.event_slug_type_options" >
                            </select>
                        </div>                   
                        <div class="emfield_error">
                        </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php _e('Select where you wish to place the title modifier. Prefix will place it before the event title. Suffix will place it after the event title.', 'eventprime-event-calendar-management'); ?>
                        </div>
                    </div> 
                </div>

                <div class="emrow" ng-show="(data.post.event_slug_type_options == 'Prefix' || data.post.event_slug_type_options == 'Suffix') && data.post.add_slug_in_event_title == 1 && data.post.enable_recurrence == 1">
                    <div class="emrow">
                        <div class="emfield"><?php _e('Select Title Modifier', 'eventprime-event-calendar-management'); ?></div>
                        <div class="eminput">
                            <div>
                                <input type="radio" ng-model="data.post.recurring_events_slug_format" name="recurring_events_slug_format" value="Date"><?php _e('Date (Using WordPress settings format)', 'eventprime-event-calendar-management'); ?>
                            </div><br/>
                            <div>
                                <input type="radio" ng-model="data.post.recurring_events_slug_format" name="recurring_events_slug_format" value="Occurrence number"><?php _e('Number (Recurrence number)', 'eventprime-event-calendar-management'); ?>
                            </div>
                        </div>                   
                        <div class="emfield_error">
                        </div>
                        <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php _e('Pick the modifier you wish to use.', 'eventprime-event-calendar-management'); ?>
                        </div>
                    </div> 
                </div>

                <div class="dbfl kf-buttonarea">
                    <div class="em_cancel">
                        <a class="kf-cancel" href="<?php echo admin_url('/admin.php?page=em_dashboard&post_id=' . $post_id); ?>">
                            <?php _e('Cancel', 'eventprime-recurring-events'); ?>
                        </a>
                    </div>
                    <button type="submit" class="btn btn-primary" ng-disabled="requestInProgress || data.post.recurrence_step < 1">
                        <?php _e('Save', 'eventprime-recurring-events'); ?>
                    </button>
                </div>
            </form>
            <div ng-show="data.post.parent > 0">
                <div class="epnotice">
                    <?php _e('This event is already part of a series of recurring events.', 'eventprime-recurring-events'); ?>
                </div>
                <div class="dbfl kf-buttonarea">
                    <div class="em_cancel">
                        <a class="kf-cancel" href="<?php echo admin_url('/admin.php?page=em_dashboard&post_id=' . $post_id); ?>">
                            <?php _e('Cancel', 'eventprime-recurring-events'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
(function($){    
    
         /*  slug position options*/
        let espo = {"Prefix": "Prefix", "Suffix": "Suffix"};
            $.each(espo, function(idx, val){
            let newOption = new Option(val);
            $("#event_slug_type_options").append( newOption );
        });
   
})(jQuery);  
</script>