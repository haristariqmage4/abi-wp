<?php
if (!defined( 'ABSPATH')){
  exit;
}

class EventM_Recurring_Events_Service {

  private static $instance = null;

  public static function get_instance() {
    if (self::$instance === null) {
      self::$instance = new self();
    }

    return self::$instance;
  }

  public function get_booking_by_eventid_status($eventid, $status){
    $args = array(
      'numberposts' => -1,
      'post_status'=> $status,
      'post_type'=> EM_BOOKING_POST_TYPE,
      'meta_key' => em_append_meta_key('event'),
      'meta_value' => $eventid,
    );
    $booking_posts = get_posts($args);
    return $booking_posts;
  }

  /**
   * save tmp recurring booking
   */
  public function save_tmp_booking($eventId, $bookingData){
    $child_posts = em_get_child_events($eventId);
    if(!empty($child_posts) && count($child_posts) > 0){
      foreach ($child_posts as $childPost) {
        $event_id = $childPost->ID;
        $event_service = EventM_Factory::get_service('EventM_Service');
        $venue_service = EventM_Factory::get_service('EventM_Venue_Service');

        $booked_seats = $event_service->booked_seats($event_id);
        $child_event = $event_service->load_model_from_db($event_id);
        $venue = $venue_service->load_model_from_db($child_event->venue);

        $event_dao = new EventM_Booking_DAO();
        $booking = $event_dao->get(0);

        $booking->name = $bookingData->name;
        $booking->status = 'pending';
        $booking->user = $bookingData->user;
        $booking->date = current_time('timestamp');
        $booking->event = $childPost->ID;
        $child_order_info = $bookingData->order_info;
        $child_order_info['parent_booking_id'] = $bookingData->id;
        $booking->order_info = $child_order_info;
        $booking->attendee_names = $bookingData->attendee_names;
        $booking->offline_options = $bookingData->offline_options;
        if(!empty($venue->id) && $venue->type=="seats"){
          $booking->booked_seats = $bookingData->booked_seats;
          $booking = $event_dao->save($booking);
          if (!empty($booking)) {
            $seats = event_m_get_param("seats", true);
            $event_service->update_booked_seats($event_id, $booking->order_info['quantity'] + $booked_seats);
            $event_dao->set_meta($event_id, 'seats', $seats);
          }
        }
        else{
          $booking = $event_dao->save($booking);
          if (!empty($booking)) {
            $event_service->update_booked_seats($event_id, $order_info['quantity'] + $booked_seats);
          }
        }
      }
    }
  }

  /**
   * save main recurring booking
   */
  public function save_booking($eventId, $bookingData){
    $parentBookingId = $bookingData->id;
    $child_posts = em_get_child_events($eventId);
    if(!empty($child_posts) && count($child_posts) > 0){
      foreach ($child_posts as $childPost) {
        // get child event bookings
        $childEventId = $childPost->ID;
        $args = array(
          'numberposts' => -1,
          'post_status'=> 'pending',
          'post_type'=> EM_BOOKING_POST_TYPE,
          'meta_key' => em_append_meta_key('event'),
          'meta_value' => $childEventId,
        );
        $booking_posts = get_posts($args);
        foreach ($booking_posts as $post) {
          $order_info = em_get_post_meta($post->ID, 'order_info');
          if(isset($order_info[0]['parent_booking_id']) && !empty($order_info[0]['parent_booking_id']) && $order_info[0]['parent_booking_id'] == $parentBookingId){
            $event_dao = new EventM_Booking_DAO();
            $booking = $event_dao->get($post->ID);
            $booking->order_info = $bookingData->order_info;
            $booking->order_info['parent_booking_id'] = $parentBookingId;
            $booking->payment_log = $bookingData->payment_log;
            $booking->booking_tmp_status = $bookingData->booking_tmp_status;
            $booking->status = $bookingData->status;
            $booking = $event_dao->save($booking);
          }
        }
      }
    }
  }

  /**
   * refund recurring booking
   */
  public function refund_booking($eventId, $bookingData){
    $parentBookingId = $bookingData->id;
    $child_posts = em_get_child_events($eventId);
    if(!empty($child_posts) && count($child_posts) > 0){
      foreach ($child_posts as $childPost) {
        // get child event bookings
        $childEventId = $childPost->ID;
        $args = array(
          'numberposts' => -1,
          'post_status'=> 'cancelled',
          'post_type'=> EM_BOOKING_POST_TYPE,
          'meta_key' => em_append_meta_key('event'),
          'meta_value' => $childEventId,
        );
        $booking_posts = get_posts($args);
        foreach ($booking_posts as $post) {
          $order_info = em_get_post_meta($post->ID, 'order_info');
          if(isset($order_info[0]['parent_booking_id']) && !empty($order_info[0]['parent_booking_id']) && $order_info[0]['parent_booking_id'] == $parentBookingId){
            $event_dao = new EventM_Booking_DAO();
            $booking = $event_dao->get($post->ID);
            $booking->order_info = $bookingData->order_info;
            $booking->order_info['parent_booking_id'] = $parentBookingId;
            $booking->payment_log = $bookingData->payment_log;
            $booking->status = $bookingData->status;
            $booking = $event_dao->save($booking);
          }
        }
      }
    }
  }

  /**
   * cancel recurring booking
   */
  public function cancel_booking($eventId, $bookingData){
    $parentBookingId = $bookingData->id;
    $child_posts = em_get_child_events($eventId);
    if(!empty($child_posts) && count($child_posts) > 0){
      foreach ($child_posts as $childPost) {
        // get child event bookings
        $childEventId = $childPost->ID;
        $args = array(
          'numberposts' => -1,
          'post_status'=> 'completed',
          'post_type'=> EM_BOOKING_POST_TYPE,
          'meta_key' => em_append_meta_key('event'),
          'meta_value' => $childEventId,
        );
        $booking_posts = get_posts($args);
        foreach ($booking_posts as $post) {
          $order_info = em_get_post_meta($post->ID, 'order_info');
          if(isset($order_info[0]['parent_booking_id']) && !empty($order_info[0]['parent_booking_id']) && $order_info[0]['parent_booking_id'] == $parentBookingId){
            $event_dao = new EventM_Booking_DAO();
            $booking = $event_dao->get($post->ID);
            $booking->order_info = $bookingData->order_info;
            $booking->order_info['parent_booking_id'] = $parentBookingId;
            $booking->payment_log = $bookingData->payment_log;
            $booking->status = $bookingData->status;
            $booking = $event_dao->save($booking);
          }
        }
      }
    }
  }

}
EventM_Recurring_Events_Service::get_instance();