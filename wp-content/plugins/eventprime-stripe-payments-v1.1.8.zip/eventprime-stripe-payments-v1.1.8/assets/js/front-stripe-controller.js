eventMagicApp.controller('kfStripeCtrl',function($scope, $http, EMRequest){
   $= jQuery;
   $scope.stripe=null;
   $scope.showCardElements= false;
   $scope.card= null;
   $scope.payButton=null;
   
   $scope.payProgress= function(state){
       if(state){
           $scope.payButton.addClass('request_in_progress');
           $scope.payButton.attr('disabled','disabled');
           $("#em_cancel_from_stripe,#em_pay_from_stripe").addClass('request_in_progress');
           return;
       }
       $scope.payButton.removeClass('request_in_progress');
       $("#em_cancel_from_stripe,#em_pay_from_stripe").removeClass('request_in_progress');
       $scope.payButton.removeAttr('disabled');
   }
   
   $scope.proceedToStripe = function (obj) {
       $scope.payButton= $(obj);
        if ($scope.orders.length > 0)
        {
            $scope.progressStart();
            var booking = {};
            booking.booking_id = $scope.order.order_id;
            EMRequest.send('em_verify_booking', booking).then(function (response) {
                $scope.progressStop();
                if (response.data)
                {
                    if($scope.price==0)
                    {
                       $scope.proceedWithoutPayment();
                    }
                    else
                    { 
                        $scope.showCardElements= true;
                        $scope.stripe= Stripe($scope.payment_processors.stripe.stripe_pub_key);
                        var elements = $scope.stripe.elements();
                        var style = {
                            base: {
                                color: '#32325d',
                                lineHeight: '18px',
                                fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
                                fontSmoothing: 'antialiased',
                                fontSize: '16px',
                                '::placeholder': {
                                    color: '#aab7c4'
                                }
                            },
                            invalid: {
                                color: '#fa755a',
                                iconColor: '#fa755a'
                            }
                        };
                        if($scope.payment_processors.stripe.stripe_hide_postal_code && $scope.payment_processors.stripe.stripe_hide_postal_code == 1){
                            $scope.card = elements.create('card', {
                                style: style,
                                hidePostalCode : true
                            });
                        } else{
                            $scope.card = elements.create('card', {style: style}); // We can place style here
                        }
                        $scope.card.mount('#em-stripe-card-element');
                    }
                }
                else{
                    alert("There seems to be a problem. Please refresh the page and try again");
                    $scope.progress(false);
                }
            });
        } 
    }
    
    $scope.sendCardInfo = function(){
        $scope.payProgress(true);
        $scope.stripe.createPaymentMethod('card',$scope.card).then(function (result) {
            if (result.error) {
                $scope.order.stripe_error= result.error.message;
                $scope.payProgress(false);
            } else {
              var order= {};
              var list= [];
              for(var i=0;i<$scope.orders.length;i++) {
                list[i]= {
                  'single_price': $scope.orders[i].single_price,
                  'quantity': $scope.orders[i].quantity,
                  'discount': $scope.orders[i].discount,
                  'order_id': $scope.orders[i].order_id,
                  'item_number': $scope.orders[i].item_number,
                  'coupon_code': $scope.orders[i].coupon_code,
                  'coupon_discount': $scope.orders[i].coupon_discount,
                  'coupon_amount': $scope.orders[i].coupon_amount,
                  'coupon_type': $scope.orders[i].coupon_type
                }
              }
              order.list = list;
              order.payment_method_id = result.paymentMethod.id;
              order.order_id = $scope.order.order_id;
              order.amount = $scope.price;
              order.all_order_data = $scope.orders;
              //var data= {payment_method_id: result.paymentMethod.id,order_id:$scope.order.order_id,amount: $scope.price};
              $scope.payProgress(true);
              EMRequest.send('em_charge_amount_from_stripe', order).then(function(response) {
                  $scope.chargeResponse(response.data);
              });
            }
        });
    }
    
    $scope.chargeResponse= function(response) {  
        if(!response.success){
            $scope.order.stripe_error= response.data.msg;
            $scope.payProgress(false);
        }
        else if(response.data.requires_action){
            $scope.handleCardAction(response);
        }
        else{
            $scope.payProgress(false);
            if(response.data.redirect){
                if(response.data.guest_booking && response.data.guest_booking == 1){
                    $scope.data.gbid = $scope.order.order_id;
                    $scope.data.redirect_url = response.data.redirect;
                    /*EMRequest.send('em_guest_booking_show_order_detail', $scope.data).then(function (response) {
                      jQuery("#booking_dialog").append(response.data);
                    });*/
                    location.href = response.data.redirect;
                }
                else{
                    location.href = response.data.redirect;
                }
            }
        }
    }
    
    $scope.handleCardAction = function(response){
        $scope.stripe.handleCardAction(response.data.payment_intent_client_secret)
          .then(function(result) {
            if (result.error) {
              $scope.order.stripe_error=result.error;
              $scope.payProgress(false);
            } 
            else{
              var order= {};
              var list= [];
              for(var i=0;i<$scope.orders.length;i++) {
                list[i]= {
                  'single_price': $scope.orders[i].single_price,
                  'quantity': $scope.orders[i].quantity,
                  'discount': $scope.orders[i].discount,
                  'order_id': $scope.orders[i].order_id,
                  'item_number': $scope.orders[i].item_number,
                  'coupon_code': $scope.orders[i].coupon_code,
                  'coupon_discount': $scope.orders[i].coupon_discount,
                  'coupon_amount': $scope.orders[i].coupon_amount,
                  'coupon_type': $scope.orders[i].coupon_type
                }
              }
              order.list = list;
              order.payment_method_id = result.paymentMethod.id;
              order.order_id = $scope.order.order_id;
              order.amount = $scope.price;
              order.all_order_data = $scope.orders;
              //var data= {payment_intent_id: result.paymentIntent.id,order_id:$scope.order.order_id,amount: $scope.price,order:$scope.order};
              EMRequest.send('em_charge_amount_from_stripe', order).then(function(response) {
                $scope.chargeResponse(response.data);
              });
            }
       });
    }
    
    // woocommerce billing / shipping validation
    $scope.validateBillingShipping = function(){
        $scope.$parent.billingErrors = [];
        $scope.$parent.shippingErrors = [];
        var setFocus = 0;
        angular.forEach($scope.order.billing_address, function(item, index){
            if(!item){
                var itemElem = angular.element("#"+index);
                if(itemElem){
                    var itemReq = itemElem.data('field_required');
                    if(itemReq){
                        $scope.$parent.billingErrors.push(itemReq);
                        if(setFocus == 0){
                            itemElem.focus();
                            setFocus = 1;
                        }
                        return false;
                    }
                }
            }
        });
        if($scope.order.shipping_address.address_option == 'same'){
            var shiAdd = {};
            angular.forEach($scope.order.shipping_address, function(item, index){
                if(index && index !== 'address_option'){
                    shiAdd[index] = '';
                    var sapItem = index.replace('shipping_', '');
                    shiAdd[index] = $scope.order.billing_address['billing_'+sapItem];
                }
            });
            $scope.order.shipping_address = shiAdd;
        }
        angular.forEach($scope.order.shipping_address, function(item, index){
            if(!item){
                var itemElem = angular.element("#"+index);
                if(itemElem){
                    var itemReq = itemElem.data('field_required');
                    if(itemReq){
                        $scope.$parent.shippingErrors.push(itemReq);
                        if(setFocus == 0){
                            itemElem.focus();
                            setFocus = 1;
                        }
                        return false;
                    }
                }
            }
        });
        
        if(setFocus == 0){
            $scope.proceedToStripe();
        }
    }
});