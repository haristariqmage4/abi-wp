<?php
/**
 * Plugin Name:       EventPrime Stripe Payments
 * Plugin URI:        http://eventprime.net
 * Description:       Start accepting credit cards on your site for Event bookings by integrating popular Stripe payment gateway.
 * Version:           1.1.8
 * Requires at least: 4.8
 * Tested up to:      6.1.1
 * Author:            EventPrime
 * Author URI:        http://eventprime.net
 * Text Domain:       eventprime-event-stripe
 * Domain Path:       /languages
 */
// Exit if accessed directly
if (!defined('ABSPATH'))
    exit;

// Check if plugin is active and class not already loaded
if (!class_exists('EM_Stripe')) {

    final class EM_Stripe {

        public $version = '1.1.8';
        private static $instance = null;

        public static function instance() {
            if (is_null(self::$instance)) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        private function __construct() {
            $this->load_plugin_textdomain();
            $this->define_constants();
            $this->global_actions();
            $this->includes();
            $em = event_magic_instance();
            array_push($em->extensions, 'stripe');
        }

        public function global_actions(){
            add_action('wp_enqueue_scripts',array($this,'event_magic_enqueue_style_and_scripts'));
            add_filter('event_magic_gs_get_model',array($this,'load_into_model'),10,2);
            add_action('event_magic_gs_settings',array($this,'event_stripe_gs_settings'));
        }
        
        public function define_constants() {
            if (!defined('EM_STRIPE_BASE_URL')) {
                define('EM_STRIPE_BASE_URL', plugin_dir_url(__FILE__));
            }
            if (!defined('EM_STRIPE_PLUGIN_DIR')) {
                define('EM_STRIPE_PLUGIN_DIR', plugin_dir_path(__FILE__));
            }
        }

        public function event_magic_enqueue_style_and_scripts() {
           
        }
        
        private function includes() {
            include_once('includes/class-em-stripe-payment.php');
            include_once('includes/class-em-stripe.php');
            if(is_admin()){
                include('includes/admin/class-admin.php');
            }
        }

        public function load_plugin_textdomain() {
            load_plugin_textdomain('eventprime-event-stripe', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }
        
        public function load_into_model($settings,$options){
            $settings->stripe_processor = !empty($options['stripe_processor']) ? 1: 0;
            $settings->stripe_api_key = !empty($options['stripe_api_key']) ? $options['stripe_api_key']: '';
            $settings->stripe_pub_key = !empty($options['stripe_pub_key']) ? $options['stripe_pub_key']: '';
            $settings->stripe_hide_postal_code = !empty($options['stripe_hide_postal_code']) ? $options['stripe_hide_postal_code']: '';
            $settings->stripe_add_card_holder_data = !empty($options['stripe_add_card_holder_data']) ? $options['stripe_add_card_holder_data']: '';
            return $settings;
        }

        public function event_stripe_gs_settings(){?>
            <a href='javascript:void(0)'>
                <div class="em-settings-box ep-active-extension ep-no-global-settings-model" data-popup="ep-stripe-payments-ext" onclick="CallEPExtensionModal(this)">
                    <img class="em-settings-icon" ng-src="<?php echo EM_BASE_URL; ?>includes/admin/template/images/ep-stripe-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Stripe Payments', 'eventprime-event-stripe'); ?></div>
                    <span><?php _e('Accept payments via Stripe.', 'eventprime-event-stripe'); ?></span>
                </div>
            </a>
            <?php
        }
    }

}

function em_stripe_checks() {
    ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e("EventPrime Stripe Extension won't work as EventPrime plugin is not active/installed.", 'eventprime-event-stripe'); ?></p>
    </div>
<?php
}

function em_stripe_init() {
    return EM_Stripe::instance();
}

add_action('plugins_loaded', function() {
    if (!class_exists('Event_Magic')) {
        add_action('admin_notices', 'em_stripe_checks');
    }
});
add_action('event_magic_loaded', 'em_stripe_init');
require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_stripe_metadata.json',
    __FILE__,
    'eventprime-event-stripe'
);