<?php

class EM_Stripe_Admin {

    public function __construct() {
        add_action('event_magic_gs_pp', array($this, 'global_settings'));
        add_action('event_magic_gs_pp_options', array($this, 'stripe_options'));
        add_filter('event_magic_gs_before_save',array($this,'save_options'));
    }

    public function global_settings() {
        ?>
        <li>
            <input type="checkbox" name="stripe_processor" ng-true-value="1" ng-fale-value="0"  ng-model="data.options.stripe_processor" />
            <span><img src="<?php echo EM_STRIPE_BASE_URL; ?>/assets/images/payment-stripe.png" alt=""></span>
            <div class="emrow"><div class="rminput" ><a ng-class="{'disable-Stripe-Config': !data.options.stripe_processor}"  ng-click="configure_stripe = true"><?php _e('Configure', 'eventprime-event-stripe'); ?></a></div></div>
        </li>
    <?php
    }

    public function stripe_options() {?>
        <div id="kf_pproc_config_parent_backdrop" class="pg_options kf_config_pop_wrap"  ng-show="configure_stripe">
            <div id="kf_pproc_config_parent" class="kf-stripe_settings kf_config_pop">
                <div  class="kf_pproc_config_single" id="kf_pproc_config_paypal">
                    <div class="kf_pproc_config_single_titlebar">
                        <div class="kf_pproc_title">
                            <img src="<?php echo EM_STRIPE_BASE_URL; ?>/assets/images/payment-stripe.png" alt=""></div>
                        <span ng-click="configure_stripe = false" class="kf-popup-close">×</span>
                    </div>
                </div>

                <div id="stripe_options">
                    <div class="emrow">
                        <div class="emfield"><?php _e('Secret Key', 'eventprime-event-stripe'); ?></div>
                        <div class="eminput">
                            <input ng-required="data.options.stripe_processor==1" type="text" name="stripe_api_key"  ng-model="data.options.stripe_api_key">
                            <div class="emfield_error" ng-show="optionForm.stripe_api_key.$dirty && optionForm.stripe_api_key.$invalid">
                                <span> <?php _e('API Key is required.', 'eventprime-event-stripe'); ?></span> 
                            </div>
                        </div>
                        <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php printf(__('Secret key to identify your Stripe account. You can grab the test and live API keys for your account under <a href="%s" target="blank">Your Account &gt; API Keys</a>', 'eventprime-event-stripe'),'https://dashboard.stripe.com/account/apikeys'); ?>
                        </div>
                    </div> 

                    <div class="emrow">
                        <div class="emfield"><?php _e('Publishable Key', 'eventprime-event-stripe'); ?></div>
                        <div class="eminput">
                            <input ng-required="data.options.stripe_processor==1" type="text" name="stripe_pub_key"  ng-model="data.options.stripe_pub_key">
                            <div class="emfield_error" ng-show="optionForm.stripe_pub_key.$dirty && optionForm.stripe_pub_key.$invalid">
                                <span> <?php _e('Publishable Key is required.', 'eventprime-event-stripe'); ?></span>  
                            </div>
                        </div>
                        <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php printf(__('Publishable key to identify your Stripe account. You can grab the test and live API keys for your account under <a href="%s" target="blank">Your Account &gt; API Keys</a>', 'eventprime-event-stripe'),'https://dashboard.stripe.com/account/apikeys'); ?>
                        </div>
                    </div>

                    <div class="emrow">
                        <div class="emfield"><?php _e('Hide Postal Code/ Zip Code', 'eventprime-event-stripe'); ?></div>
                        <div class="eminput">
                            <input type="checkbox" name="stripe_hide_postal_code"  ng-model="data.options.stripe_hide_postal_code" ng-true-value="1" ng-fale-value="0">
                        </div>
                        <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php esc_html_e('Do not display Postal or Zip code field in the payment form.', 'eventprime-event-stripe') ?>
                        </div>
                    </div>

                    <div class="emrow">
                        <div class="emfield"><?php _e('Show Customer Data', 'eventprime-event-stripe'); ?></div>
                        <div class="eminput">
                            <input type="checkbox" name="stripe_add_card_holder_data" ng-model="data.options.stripe_add_card_holder_data" ng-true-value="1" ng-fale-value="0">
                        </div>
                        <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php esc_html_e('Display customer\'s information in the admin area transaction details.', 'eventprime-event-stripe') ?>
                        </div>
                    </div>

                    <div class="emrow">
                        <div class="emfield"><?php _e('Stripe Option Label', 'eventprime-event-stripe'); ?></div>
                        <div class="eminput">
                            <input type="text" name="stripe_label"  ng-model="data.options.button_titles['Stripe']">
                        </div>
                        <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            <?php esc_html_e('Change the label of the Stripe option while user selects payment gateway on the booking checkout page.', 'eventprime-event-stripe') ?>
                        </div>
                    </div>

                    <div class="emrow">
                        <div class="dbfl kf-buttonarea">
                            <button type="button" class="btn btn-primary" ng-click="saveSettings(optionForm.$valid)" ng-disabled="postForm.$invalid" ><?php _e('Save','eventprime-event-stripe'); ?></button>  
                        </div>
                    </div>
                </div> 
            </div>
        </div><?php
    }
        
    public function save_options($model){
        $request = EventM_Raw_Request::get_instance();
        $request= stripslashes_deep($request->get_data());
        $stripe_enabled = !empty($request['stripe_processor']) ? 1 : 0;
        if(empty($stripe_enabled)){
            return $model;
        }
        $model->stripe_processor = 1;
        $model->stripe_api_key = sanitize_text_field($request['stripe_api_key']);
        $model->stripe_pub_key = sanitize_text_field($request['stripe_pub_key']);
        $model->stripe_hide_postal_code = absint(sanitize_text_field($request['stripe_hide_postal_code']));
        $model->stripe_add_card_holder_data = absint(sanitize_text_field($request['stripe_add_card_holder_data']));
        return $model;
    }

}

new EM_Stripe_Admin;
    