<?php
class EventM_Stripe_Payment_Service extends EventM_Payment_Service {

    function __construct() {
        parent::__construct("stripe");
    }
    
    public function cancel($order_id) {
        
    }

    public function charge($info=array()) {
        if (!class_exists('Stripe\Stripe')){
           require_once('lib/stripe/init.php');
        }
        
        \Stripe\Stripe::setApiKey($info['stripe_api_key']);
        $charge_response= array('error'=>true);
        
        try{
            if(!empty($info['pm_id'])){
                $charge_details= array('payment_method'=>$info['pm_id'],'confirmation_method'=>'manual','confirm'=>true, 
                                       'amount' => em_get_converted_price_in_cent($info['amount'], $info['currency']), 'currency' =>$info['currency']);
                $intent = \Stripe\PaymentIntent::create($charge_details);
            }
            if(!empty($info['pi_id'])){
                $intent = \Stripe\PaymentIntent::retrieve($info['pi_id']);
                $intent->confirm();
            }
            $charge_response['error']=false;
        }
        catch(\Stripe\Error\RateLimit $e){
            $charge_response['msg']=__('Stripe API request limit exceeded.','eventprime-event-stripe');
        }
        catch(\Stripe\Error\Card $e) {
            $charge_response['msg']=__('Card declined.','eventprime-event-stripe');
        }
        catch(\Stripe\Error\InvalidRequest $e){
            $charge_response['msg']=$e->getMessage();
        }
        catch(\Stripe\Error\Authentication $e){
            $charge_response['msg']=__('Authentication failed.','eventprime-event-stripe');
        }
        catch(\Stripe\Error\Base $e) {
            $charge_response['msg']=__('Unable to complete the payment process.','eventprime-event-stripe');
        }
        catch(Exception $e){
            $charge_response['msg']=$e->getMessage();
        }
        
        if(!empty($charge_response['error'])){
            return $charge_response;
        }
        
        if ($intent->status == 'requires_source_action' && $intent->next_action->type == 'use_stripe_sdk') {
            return array('requires_action' => true,'payment_intent_client_secret' => $intent->client_secret,'error'=>false);
        } 
        $payment_status = $intent->status=='succeeded' ? 'completed' : $intent->status;
        $stripe_add_card_holder_data = em_global_settings('stripe_add_card_holder_data');
        if($stripe_add_card_holder_data == 1){
            $pm_id = $intent->payment_method;
            $cus_email = $cus_name = NULL;
            if(!empty($pm_id)){
                $pm_method = \Stripe\PaymentMethod::retrieve(
                    $pm_id,
                    []
                );
                $finger_print = $pm_method->card->fingerprint;
                $customer = $pm_method->customer;
                if(!empty($customer)){
                    $customer_data = \Stripe\Customer::retrieve(
                        $customer,
                        []
                    );
                    if(!empty($customer_data)){
                        $cus_email = $customer_data->email;
                        $cus_name = $customer_data->name;
                    }
                } else{
                    $all_customer_data = \Stripe\Customer::all();
                    if(!empty($all_customer_data->data)){
                        foreach($all_customer_data->data as $all_cus){
                            if(isset($all_cus->sources)){
                                if(isset($all_cus->sources->data)){
                                    if(isset($all_cus->sources->data[0]->fingerprint)){
                                        $cus_finger_print = $all_cus->sources->data[0]->fingerprint;
                                        if($cus_finger_print == $finger_print){
                                            $customer_id = $all_cus->id;
                                            if(!empty($customer_id)){
                                                $customer_data = \Stripe\Customer::retrieve(
                                                    $customer_id,
                                                    []
                                                );
                                                if(!empty($customer_data)){
                                                    $cus_email = $customer_data->email;
                                                    $cus_name = $customer_data->name;
                                                }
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                $intent->cus_email = $cus_email;
                $intent->cus_name = $cus_name;
            }
        }
        return array('payment_gateway'=>'stripe','payment_status' => $payment_status,'total_amount' => $info['amount'],'currency' => $info['currency'],'error'=>false,'log'=>$intent->jsonSerialize());
    }

    public function refund($order_id, $info = array()) {
        $stripe_api_key = em_global_settings('stripe_api_key');
        \Stripe\Stripe::setApiKey($stripe_api_key);

        $payment_log = em_get_post_meta($order_id, 'payment_log', true);
        $return_amount = 0;
        if (isset($payment_log['partial_amount']))
            $return_amount = em_get_converted_price_in_cent($payment_log['partial_amount'], $payment_log['currency']);
        else
            $return_amount = em_get_converted_price_in_cent($payment_log['total_amount'], $payment_log['currency']);

        
        if(!empty($payment_log['log']) && !empty($payment_log['log']['charges']) && !empty($payment_log['log']['charges']['data'])){
            foreach($payment_log['log']['charges']['data'] as $single_charge){
                try {
                $re = \Stripe\Refund::create(array(
                            "charge" => $single_charge['id'],
                            "amount" => $return_amount
                ));
                } catch (Exception $e) {
                    $re = array(
                        'error' => true,
                        'reason' => $e->getMessage()
                    );
                    return $re;
                }
                break;
            }
            
        }
        return $re->__toArray(true);
    }

}