<?php

class EventM_Stripe_Service{
    
    protected $settings;
    protected $payment_service;
    private static $instance = null;
    
    public static function get_instance()
    {   
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $gs_service = EventM_Factory::get_service('EventM_Setting_Service');
        $this->settings = $gs_service->load_model_from_db();
        $this->payment_service= new EventM_Stripe_Payment_Service();
        add_action('wp_ajax_em_charge_amount_from_stripe',array($this,'charge'));
        add_action('wp_ajax_nopriv_em_charge_amount_from_stripe',array($this,'charge'));
        $this->actions();
    }



    public function charge()
    {   
        if ($_SERVER['REQUEST_METHOD']!=='POST') {
            wp_send_json_error(array('msg'=>__('Invalid access')));
        }
        
        $request=  EventM_Raw_Request::get_instance();
        $gs_service = EventM_Factory::get_service('EventM_Setting_Service');
        $gs = $gs_service->load_model_from_db();
        
        $amount = $request->get_param('amount',true);
        $list = $request->get_param('list',true);
        $pm_id = $request->get_param('payment_method_id',true);
        $pi_id = $request->get_param('payment_intent_id',true);
        $all_order_data = $request->get_param('all_order_data',true);
        $booking_id = $list[0]->order_id;
        if($amount>0){
            $stripe_response=   $this->payment_service->charge(array(
                                    'amount'=>$amount,
                                    'currency'=> $gs->currency,
                                    'stripe_api_key'=> $gs->stripe_api_key,
                                    'pm_id'=>$pm_id,
                                    'pi_id'=>$pi_id
                                ));
        }
            
        if(!empty($stripe_response['error']))
        {
            wp_send_json_error($stripe_response);
        }
        unset($stripe_response['error']);
        if(!empty($stripe_response['requires_action'])){
             wp_send_json_success($stripe_response);
        }
        
        $booking_service= EventM_Factory::get_service('EventM_Booking_Service');
        $stripe_response['coupon_code'] = $list[0]->coupon_code;
        $stripe_response['coupon_discount'] = $list[0]->coupon_discount;
        $stripe_response['coupon_amount'] = $list[0]->coupon_amount;
        $stripe_response['coupon_type'] = $list[0]->coupon_type;
        $stripe_response = apply_filters('event_magic_add_stripe_payment_response', $stripe_response, $all_order_data);
        $booking_service->confirm_booking($booking_id,$stripe_response);
        
        $redirect_url= add_query_arg(array('em_bookings' =>$booking_id),get_permalink($gs->profile_page));
        if(!is_user_logged_in()){
            $showBookNowForGuestUsers = em_show_book_now_for_guest_users();
            if(!empty($showBookNowForGuestUsers)){
                $booking_redirect = add_query_arg(array('id' => $booking_id, 'is_guest' => 1), get_permalink(em_global_settings('booking_details_page')));
                if(!empty($gs->guest_booking_page_redirect)){
                    $redirect_url = get_permalink($gs->guest_booking_page_redirect);
                    $booking_redirect = add_query_arg(array('redirect_url' => esc_url($redirect_url)), $booking_redirect);
                }

                wp_send_json_success(array('redirect' => $booking_redirect, 'guest_booking' => 1));
            }
        }
        wp_send_json_success(array('redirect'=>$redirect_url));
    }

    public function refund($booking)
    {
        if(!em_is_admin()){
            return $data;
        }
        if (!class_exists('Stripe\Stripe')){
            require_once('lib/stripe/init.php');
        }
        $order_info= $booking->order_info;
        if($order_info['payment_gateway']=="stripe")
        {
            $payment_response= $this->payment_service->refund($booking->id);
            if(isset($payment_response['status']) && $payment_response['status']=="succeeded")
            {
                $booking->status = 'refunded';
            }
            $booking->payment_log=$payment_response;
        }

        return $booking;
    }
    
    public function actions(){
        add_action('event_magic_front_payment_processors',array($this,'show_on_front'));
        add_action('event_magic_load_payment_configuration',array($this,'load_payment_processor'));
        add_action('wp_ajax_em_charge_from_stripe', array($this,'charge'));
        add_filter('event_magic_refund_booking',array($this,'refund'));
    }
    
    public function show_on_front()
    {  
        if(empty($this->settings->stripe_processor))
            return;
        include_once(EM_STRIPE_PLUGIN_DIR."/includes/html/show_stripe.php");
    }
    
    function load_payment_processor($response){
        if($this->settings->stripe_processor == 1){
            $response->payment_prcoessor['stripe'] = array('stripe_pub_key'=> $this->settings->stripe_pub_key, 'stripe_hide_postal_code' => $this->settings->stripe_hide_postal_code);
        }
        return $response;
    }
}
EventM_Stripe_Service::get_instance();