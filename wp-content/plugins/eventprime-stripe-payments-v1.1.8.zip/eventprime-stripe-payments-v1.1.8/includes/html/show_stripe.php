<?php  wp_enqueue_script('stripe_script', esc_url_raw('https://js.stripe.com/v3/'), array());
    wp_enqueue_script('kf-stripe-controller', EM_STRIPE_BASE_URL . '/assets/js/front-stripe-controller.js', array('em-angular', 'em-angular-module'), false);
    wp_enqueue_style('kf-stripe-css', EM_STRIPE_BASE_URL . '/assets/css/ep_stripe_public.css', false);
?>
<div class="kf-payment-mode-select" ng-controller="kfStripeCtrl" ng-show="price &gt; 0 && payment_processors.hasOwnProperty('stripe') && bookable">
    <div class="em_checkout_input_radio">
        <input type="radio" name="stripe" value="stripe" ng-model="data.payment_processor" />
        <label ng-click="data.payment_processor='stripe'" class="ep-payment-checkout-btn-wrap ep-payment-checkout-stripe"><?php echo em_global_settings_button_title('Stripe', 'eventprime-event-stripe'); ?><span><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 468 222.5" style="enable-background:new 0 0 468 222.5;" xml:space="preserve">
<style type="text/css">
	.st0{fill-rule:evenodd;clip-rule:evenodd;fill:#635BFF;}
</style>
<g>
	<path class="st0" d="M414,113.4c0-25.6-12.4-45.8-36.1-45.8c-23.8,0-38.2,20.2-38.2,45.6c0,30.1,17,45.3,41.4,45.3
		c11.9,0,20.9-2.7,27.7-6.5v-20c-6.8,3.4-14.6,5.5-24.5,5.5c-9.7,0-18.3-3.4-19.4-15.2h48.9C413.8,121,414,115.8,414,113.4z
		 M364.6,103.9c0-11.3,6.9-16,13.2-16c6.1,0,12.6,4.7,12.6,16H364.6z"/>
	<path class="st0" d="M301.1,67.6c-9.8,0-16.1,4.6-19.6,7.8l-1.3-6.2h-22v116.6l25-5.3l0.1-28.3c3.6,2.6,8.9,6.3,17.7,6.3
		c17.9,0,34.2-14.4,34.2-46.1C335.1,83.4,318.6,67.6,301.1,67.6z M295.1,136.5c-5.9,0-9.4-2.1-11.8-4.7l-0.1-37.1
		c2.6-2.9,6.2-4.9,11.9-4.9c9.1,0,15.4,10.2,15.4,23.3C310.5,126.5,304.3,136.5,295.1,136.5z"/>
	<polygon class="st0" points="223.8,61.7 248.9,56.3 248.9,36 223.8,41.3 	"/>
	<rect x="223.8" y="69.3" class="st0" width="25.1" height="87.5"/>
	<path class="st0" d="M196.9,76.7l-1.6-7.4h-21.6v87.5h25V97.5c5.9-7.7,15.9-6.3,19-5.2v-23C214.5,68.1,202.8,65.9,196.9,76.7z"/>
	<path class="st0" d="M146.9,47.6l-24.4,5.2l-0.1,80.1c0,14.8,11.1,25.7,25.9,25.7c8.2,0,14.2-1.5,17.5-3.3V135
		c-3.2,1.3-19,5.9-19-8.9V90.6h19V69.3h-19L146.9,47.6z"/>
	<path class="st0" d="M79.3,94.7c0-3.9,3.2-5.4,8.5-5.4c7.6,0,17.2,2.3,24.8,6.4V72.2c-8.3-3.3-16.5-4.6-24.8-4.6
		C67.5,67.6,54,78.2,54,95.9c0,27.6,38,23.2,38,35.1c0,4.6-4,6.1-9.6,6.1c-8.3,0-18.9-3.4-27.3-8v23.8c9.3,4,18.7,5.7,27.3,5.7
		c20.8,0,35.1-10.3,35.1-28.2C117.4,100.6,79.3,105.9,79.3,94.7z"/>
</g>
</svg>
</span></label> 
    </div> 
</div>
<div class="ep-payment-checkout-btn em_bg_lt dbfl" ng-controller="kfStripeCtrl" ng-show="data.payment_processor == 'stripe' && bookable">
    <div id="kf-stripe-purchase-form-wrap" class="dbfl" ng-show="data.payment_processor == 'stripe' && bookable && applyWoocommerce == 0">
        <div class="em_checkout_btn">
            <button class="ep-checkout-btn" ng-click="proceedToStripe(this)"><?php echo em_global_settings_button_title('Checkout'); ?></button>
        </div>
    </div>
    <!-- this button will show if woocommerce products added to cart. This is for validate address -->
    <div id="kf-stripe-purchase-form-wrap" class="dbfl" ng-show="data.payment_processor == 'stripe' && bookable && applyWoocommerce == 1">
        <div class="em_checkout_btn">
            <button class="ep-checkout-btn" ng-click="validateBillingShipping(this)"><?php echo em_global_settings_button_title('Checkout'); ?></button>
        </div>
    </div>
    
    <div id="kf-reconfirm-popup" class="dbfl" ng-show="showCardElements">
        <div class="dbfl em_block kf-reconfirm-popup-content">
           <div class="ep_stripe_fields">
                <div class="ep-stripe-card-row">
                    <div id="em-stripe-card-element"></div>
                    <div class="payment-errors" id="ep_stripe_payment_errors">
                        {{order.stripe_error}}
                    </div>
                </div>
                <button id="em_pay_from_stripe" ng-click="sendCardInfo()" class="ep-stripe-pay-btn"><?php _e('Submit','eventprime-event-stripe'); ?></button>
                <button id="em_cancel_from_stripe" ng-click="showCardElements=false" class="ep-stripe-cancel-btn"><?php _e('Cancel','eventprime-event-stripe'); ?></button>
            </div>
        </div>
    </div>
</div>