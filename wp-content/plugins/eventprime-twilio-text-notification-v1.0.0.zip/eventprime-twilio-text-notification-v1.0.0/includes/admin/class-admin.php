<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class EM_SMS_Integration_Admin {
	
    public function __construct() { 
        add_action('event_magic_menus', array($this, 'menus'));
        add_action('admin_enqueue_scripts', array($this,'enqueue'));
        $this->current_page = isset($_GET['page']) ? $_GET['page'] : '';
    }
    
    public function menus(){
        add_submenu_page("event_magic", __('Twilio', 'eventprime-twilio-text-notification'), __('Twilio', 'eventprime-twilio-text-notification'), "manage_options", "em_sms_settings", array($this, 'sms_settings'));
    }
    
    public function sms_settings() {
        wp_enqueue_style('em_admin_sms_settings', EMSS_BASE_URL.'includes/admin/template/css/em_admin_sms_settings.css', false, EVENTPRIME_VERSION );
        /* intl input phone numbers with country code dropdown css and js files */
        wp_enqueue_style('em-intlTelInput-css', EMSS_BASE_URL.'includes/admin/template/css/intlTelInput.css', false, EVENTPRIME_VERSION, true );
        wp_enqueue_script('em-intlTelInput-jquery-min', EMSS_BASE_URL.'includes/admin/template/js/jquery.min.js', false, EVENTPRIME_VERSION, true );
        wp_enqueue_script('em-intlTelInput', EMSS_BASE_URL.'includes/admin/template/js/intlTelInput.js', array(), EVENTPRIME_VERSION, true );
        wp_enqueue_script('em-intlTelInput-min', EMSS_BASE_URL.'includes/admin/template/js/intlTelInput.min.js', array(), EVENTPRIME_VERSION, true );
        wp_enqueue_script( 'em-utils', EMSS_BASE_URL . 'includes/admin/template/js/utils.js', array(), EVENTPRIME_VERSION, true );
        wp_enqueue_script( 'em-sms-custom-js', EMSS_BASE_URL . 'includes/admin/template/js/em-sms-custom.js', array(), EVENTPRIME_VERSION, true );
       
        wp_enqueue_script('em-sms-settings-controller');
        wp_enqueue_script('em-sms-multi-select-dropdown');
        if($this->current_page == 'em_sms_settings'){
            include_once('template/sms_settings.php' );
        }
    }
    
    public function enqueue(){
        wp_register_script('em-sms-settings-controller', EMSS_BASE_URL.'includes/admin/template/js/em-sms-settings-controller.js',array('em-angular-module'),EVENTPRIME_VERSION);
        wp_register_script('em-sms-multi-select-dropdown', EMSS_BASE_URL.'includes/admin/template/js/multi-select-dropdown.js', array(),EVENTPRIME_VERSION );
    }
}
new EM_SMS_Integration_Admin;