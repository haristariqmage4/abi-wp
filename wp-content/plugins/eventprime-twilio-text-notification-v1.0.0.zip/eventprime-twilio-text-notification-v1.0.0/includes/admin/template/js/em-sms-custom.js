$(document).ready(function(){
    var telInput = $("#admin_mobile_number"),
    errorMsg = $("#error-msg"),
    validMsg = $("#valid-msg");
    subSMS = $("#submitSmsSettings");

    // initialise plugin
    telInput.intlTelInput({
        allowExtensions: true,
        formatOnDisplay: true,
        autoFormat: true,
        autoHideDialCode: true,
        autoPlaceholder: true,
        defaultCountry: "auto",
        ipinfoToken: "yolo",

        nationalMode: false,
        numberType: "MOBILE",
        //onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
        preferredCountries: ['sa', 'ae', 'qa','om','bh','kw','ma'],
        preventInvalidNumbers: true,
        separateDialCode: false,
        /* initialCountry: "in", */
        initialCountry : "auto",
        geoIpLookup: function(callback) {
            $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
                var countryCode = (resp && resp.country) ? resp.country : "";
                callback(countryCode);
            });
        },
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/utils.js"
    });

    var reset = function() {
        telInput.removeClass("error");
        errorMsg.addClass("hide");
        validMsg.addClass("hide");
        subSMS.addClass("hide");
    };

    // on blur: validate
    telInput.blur(function() {
        reset();
        if ($.trim(telInput.val())) {
            var ccode = $(".country[class*='active']").attr("data-country-code");
            var myInput = $("#country_code");
            myInput.val(ccode);
            myInput.trigger('input');
            /* get code here*/
            var getCode = $(".country[class*='active']").attr("data-dial-code");
            var myDialInput = $("#country_code_numeric");
            var getCodecmplt = '+'+getCode;
            myDialInput.val(getCodecmplt);
    		myDialInput.trigger('input');
            if (telInput.intlTelInput("isValidNumber")) {
                validMsg.removeClass("hide");
                errorMsg.addClass("hide");
                $('#submitSmsSettings').removeAttr('disabled');
            } else {
                telInput.addClass("error");
                errorMsg.removeClass("hide");
                $('#submitSmsSettings').attr('disabled', 'disabled');
            }
        }
    });

    // on keyup / change flag: reset
    telInput.on("keyup change", reset);
    /* scc = $("#code").val(($("#admin_mobile_number").telInput("getSelectedCountryData").dialCode));
    alert(scc); */
});