eventMagicApp.controller('smsSettingsCtrl', function($scope, $http, EMRequest){
  $scope.data = {};
  $scope.ixdata = {};
  $scope.requestInProgress = false;
  $scope.formErrors = [];
  $scope.formSuccess = [];
  $scope.formiErrors = [];
  $scope.formiSuccess = [];
  $scope.showNotificationsTab = false;
  $scope.showSmsTestingTab = false;
  $scope.sms_testing_mobile_number;
  $scope.sms_testing_message;
  $ = jQuery;

  $scope.progressStart = function()
  {
    $scope.requestInProgress = true;
  }

  $scope.progressStop = function()
  {
    $scope.requestInProgress = false;
  }
  
  $scope.initialize = function ( tab ) {
    // Loading all the required data before form load
    if(tab == 'settings'){
      $scope.showNotificationsTab = false;
      $scope.showSettingsTab = true;
    }
    $scope.preparePageData();
  };

   //Loads Pre saved setting data
  $scope.preparePageData = function () {
     /*  $scope.data.em_request_context='admin_sms_settings'; */
    $scope.progressStart();
    EMRequest.send('em_admin_sms_settings', $scope.data).then(function(response){
      $scope.progressStop();
      var responseBody= response.data;
      if(!responseBody.success)
        return;
      $scope.data= responseBody.data;
      var myEl = angular.element( document.querySelector( '.iti-flag' ) );
      myEl.addClass($scope.data.options.country_code);
    });
  }

   /*
   * Save Settings
   */
   $scope.saveSmsSettings = function (isValid) {
    $scope.formErrors='';
      // If form is valid against all the angular validations
      if (isValid) {
        $scope.progressStart();
        EMRequest.send('em_save_sms_settings',$scope.data.options).then(function(response){
          $scope.progressStop();
          var responseBody= response.data;
          if(responseBody.success){
            $scope.preparePageData();
          }
          else
          {
            if(responseBody.data.hasOwnProperty('errors')){
              $scope.formErrors= responseBody.data.errors;
              jQuery('html, body').animate({ scrollTop: 0 }, 'slow');
            }
          }
        });        
      }
    }

    $scope.showMainTab = function(type){
      $scope.showNotificationsTab = false;
      $scope.showSettingsTab = false;
      $scope.showSmsTestingTab = false;
      $scope.showSmsLogsTab = false;
      if(type == 'showNotificationsTab'){
        $scope.progressStop();
        var page_location = window.location;
        var params = new URLSearchParams(window.location.search);
        if(params.get('code')){
          var next_location = page_location.origin + page_location.pathname + '?page=em_sms_settings';
          if(next_location){
            location.href = next_location;
          }
        }
      }
      if(type == 'showSmsTestingTab'){
        $scope.progressStop();
        var page_location = window.location;
        var params = new URLSearchParams(window.location.search);
        if(params.get('code')){
          var next_location = page_location.origin + page_location.pathname + '?page=em_sms_settings';
          if(next_location){
            location.href = next_location;
          }
        }
      }
      if(type == 'showSmsLogsTab'){
        $scope.progressStop();
        var page_location = window.location;
        var params = new URLSearchParams(window.location.search);
        if(params.get('code')){
          var next_location = page_location.origin + page_location.pathname + '?page=em_sms_settings';
          if(next_location){
            location.href = next_location;
          }
        }
      }
      $scope[type] = true;
    }

    $scope.scroll_top = function(selector){
      setTimeout(function(){
        $('html, body').animate({
          scrollTop: $('div'+selector).offset().top
        }, 1000);
      }, 500);
    }

    /*
   * Save Settings
   */
   $scope.sendTestingSms = function (isValid) {
    $scope.formErrors='';
      // If form is valid against all the angular validations
      if (isValid) {
        $scope.progressStart();
        $scope.data.sms_testing_mobile_number = $scope.sms_testing_mobile_number;
        $scope.data.sms_testing_message = $scope.sms_testing_message
        EMRequest.send('em_send_testing_sms',$scope.data).then(function(response){
          $scope.progressStop();
          var responseBody= response.data;
          if(responseBody.success){
            $scope.preparePageData();
          }
          else
          {
            if(responseBody.data.hasOwnProperty('errors')){
              $scope.formErrors= responseBody.data.errors;
              jQuery('html, body').animate({ scrollTop: 0 }, 'slow');
            }
          }
        });        
      }
    }

   /*
   * Delete twilio sms error logs
   */
   $scope.delTwlSmsErrLogs = function (isValid) {
    $scope.formErrors='';
    // If form is valid against all the angular validations
    if (isValid) {
      $scope.progressStart();
      EMRequest.send('em_delete_twilio_sms_error_logs',$scope.data).then(function(response){
        $scope.progressStop();
        var responseBody= response.data;
        if(responseBody.success){
          $scope.preparePageData();
        }
        else
        {
          if(responseBody.data.hasOwnProperty('errors')){
            $scope.formErrors= responseBody.data.errors;
            jQuery('html, body').animate({ scrollTop: 0 }, 'slow');
          }
        }
      });        
    }
  }
});

eventMagicApp.filter('unsafe', function($sce) {
  return function(val) {
    return $sce.trustAsHtml(val);
  };
});

/* eventMagicApp.filter('logsTextFormat', function() {
    return function (x) {
      return x.replace(new RegExp('\/n', 'g'), '<br/>');
    };
 }); */