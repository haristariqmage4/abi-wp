<?php
$sms_tab = isset($_GET['ep-ix-tab']) ? sanitize_text_field($_GET['ep-ix-tab']) : 'settings';
?>
<div class="kikfyre" ng-app="eventMagicApp" ng-controller="smsSettingsCtrl" ng-init="initialize('<?php echo $sms_tab;?>')" ng-cloak="">
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>
    <div class="kf-hidden" style="{{requestInProgress ?'display:none':'display:block'}}">
        <!-- Operations bar Starts --> 
        <div class="kf-operationsbar dbfl">
            <div class="kf-titlebar_dark dbfl">
                <div class="kf-title kf-title-1 difl"><?php _e('Twilio Configuration', 'eventprime-twilio-text-notification'); ?></div>
            </div>
            <div class="kf-nav dbfl">
                <ul class="em-ie-headers">
                    <li><a href="javascript:void(0)" ng-click="showMainTab('showSettingsTab')" ng-class="{'active': showSettingsTab}"><?php _e('Settings', 'eventprime-twilio-text-notification'); ?></a></li>
                    <li><a href="javascript:void(0)" ng-click="showMainTab('showNotificationsTab')" ng-class="{'active': showNotificationsTab}"><?php _e('Notifications', 'eventprime-twilio-text-notification'); ?></a></li>
                    <li ng-show="data.options.enable_twilio_sms_service==1"><a href="javascript:void(0)" ng-click="showMainTab('showSmsTestingTab')" ng-class="{'active': showSmsTestingTab}"><?php _e('SMS Testing', 'eventprime-twilio-text-notification'); ?></a></li>
                    <li ng-show="data.options.enable_twilio_sms_service==1 && data.options.show_twilio_sms_error_logs==1"><a href="javascript:void(0)" ng-click="showMainTab('showSmsLogsTab')" ng-class="{'active': showSmsLogsTab}"><?php _e('Twilio SMS Error Logs', 'eventprime-twilio-text-notification'); ?></a></li>
                </ul>
            </div>
        </div>
    <div class="form_errors">
        <ul>
            <li class="emfield_error" ng-repeat="error in  formErrors">
                <span>{{error}}</span>
            </li>
        </ul>  
    </div>
        <!--  Operations bar Ends -->
     <form name="optionForm" ng-submit="saveSmsSettings(optionForm.$valid)" novalidate  class="em-email-settings-form">        
        <div class="emagic-table dbfl" ng-show="showSettingsTab == true || showNotificationsTab == true">
            <div class="em-twilio-tab" ng-show="showSettingsTab == true">
                <div class="em-twilio-contant">
                    <div class="em-twilio-section em-twilio-contant">
                        <div class="emrow ep-subhead-wrap">
                            <div class="ep-subhead-title"><?php _e('Setup the credentials of Twilio!', 'eventprime-twilio-text-notification'); ?></div>
                            <div class="ep-subhead-info epnotice"><?php _e('Here you can fill up credentials for sms settings to EventPrime.', 'eventprime-twilio-text-notification'); ?></div>
                        </div>
                        <div class="em-twilio-integration" >
                            <div class="emrow">
                                <div class="emfield"><?php _e('Admin Notifications Number', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                <input type="text" name="country_code" id="country_code" ng-model="data.options.country_code" value="data.options.country_code" style="display:none;">
                                <input type="text" name="country_code_numeric" id="country_code_numeric" ng-model="data.options.country_code_numeric" value="data.options.country_code_numeric" style="display:none;">
                                <input type="tel" name="admin_mobile_number" id="admin_mobile_number"  ng-model="data.options.admin_mobile_number" ng-required="true" ng-pattern="/^\+?\d{2}[- ]?\d{3}[- ]?\d{5,10}$/">
                                    <div class="emfield_error">
                                        <span ng-show="optionForm.admin_mobile_number.$error.required && !optionForm.admin_mobile_number.$pristine"><?php _e('Please enter mobile number with country code.', 'eventprime-twilio-text-notification'); ?></span>
                                        <!-- <span ng-show="optionForm.admin_mobile_number.$error.pattern && !optionForm.admin_mobile_number.$pristine"><?php _e('Please enter valid mobile number with country code.', 'eventprime-twilio-text-notification'); ?></span> -->
                                        <span name="valid-msg" id="valid-msg" class="hide" style="color:green;">✓ Valid</span>
                                        <span name="error-msg" id="error-msg" class="hide">Invalid number</span>
                                    </div>
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Mobile number on which you wish to receive admin alerts. Enter mobile number with a "+" and country code ( +1, +44 ).', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                            <div class="emrow">
                                <div class="emfield"><?php _e('Enable Twilio Text Services', 'eventprime-twilio-text-notification'); ?></div>
                                <div class="eminput">
                                    <input type="checkbox" name="enable_twilio_sms_service"  ng-model="data.options.enable_twilio_sms_service" ng-true-value="1" ng-false-value="0">
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Enable to connect to your Twilio account to deliver text messages.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                            <div class="emrow" ng-show="data.options.enable_twilio_sms_service==1">
                                <div class="emfield"><?php _e('Account SID', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                    <input type="text" name="twilio_account_sid" ng-model="data.options.twilio_account_sid" ng-required="data.options.enable_twilio_sms_service==1" >
                                    <div class="emfield_error">
                                        <span ng-show="optionForm.twilio_account_sid.$error.required && !optionForm.twilio_account_sid.$pristine"><?php _e('This is a required field.', 'eventprime-twilio-text-notification'); ?></span>
                                    </div>
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('To view API credentials visit <a href="https://www.twilio.com/user/account/voice-sms-mms" target="_blank">https://www.twilio.com/user/account/voice-sms-mms</a>.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                            <div class="emrow" ng-show="data.options.enable_twilio_sms_service==1">
                                <div class="emfield"><?php _e('Auth Token', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                    <input type="text" name="twilio_auth_token"  ng-model="data.options.twilio_auth_token" ng-required="data.options.enable_twilio_sms_service==1">
                                    <div class="emfield_error">
                                        <span ng-show="optionForm.twilio_auth_token.$error.required && !optionForm.twilio_auth_token.$pristine"><?php _e('This is a required field.', 'eventprime-twilio-text-notification'); ?></span>
                                    </div>
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('To view API credentials visit <a href="https://www.twilio.com/user/account/voice-sms-mms" target="_blank">https://www.twilio.com/user/account/voice-sms-mms</a>.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                            <div class="emrow" ng-show="data.options.enable_twilio_sms_service==1">
                                <div class="emfield"><?php _e('Service ID', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                    <input type="text" name="twilio_service_id"  ng-model="data.options.twilio_service_id" ng-required="data.options.enable_twilio_sms_service==1">
                                    <div class="emfield_error">
                                        <span ng-show="optionForm.twilio_service_id.$error.required && !optionForm.twilio_service_id.$pristine"><?php _e('This is a required field.', 'eventprime-twilio-text-notification'); ?></span>
                                    </div>
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('To view or create Notify Service ID visit <a href="https://www.twilio.com/console/notify/services" target="_blank">https://www.twilio.com/console/notify/services</a>.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                            <div class="emrow" ng-show="data.options.enable_twilio_sms_service==1">
                                <div class="emfield"><?php _e('Twilio Number', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                    <input type="text" name="twilio_number"  ng-model="data.options.twilio_number" ng-required="data.options.enable_twilio_sms_service==1" ng-pattern="/^\+?\d{2}[- ]?\d{3}[- ]?\d{5,10}$/">
                                    <div class="emfield_error">
                                        <span ng-show="optionForm.twilio_number.$error.required && !optionForm.twilio_number.$pristine"><?php _e('This is a required field.', 'eventprime-twilio-text-notification'); ?></span>
                                        <span ng-show="optionForm.twilio_number.$error.pattern && !optionForm.twilio_number.$pristine"><?php _e('Please enter valid twilio mobile number.', 'eventprime-twilio-text-notification'); ?></span>
                                    </div>
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Twilio mobile number with your country code ( i.e. +1 123 456 7890 ).', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>

                            <div class="emrow" ng-show="data.options.enable_twilio_sms_service==1">
                                <div class="emfield"><?php _e('Show Twilio SMS Error Logs', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                    <input type="checkbox" name="show_twilio_sms_error_logs"  ng-model="data.options.show_twilio_sms_error_logs" ng-true-value="1" ng-false-value="0">
                                    <div class="emfield_error">
                                        <span ng-show="optionForm.show_twilio_sms_error_logs.$error.required && !optionForm.show_twilio_sms_error_logs.$pristine"><?php _e('This is a required field.', 'eventprime-twilio-text-notification'); ?></span>
                                    </div>
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Enable to show twilio sms error logs.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
            <div class="em-export-tab" ng-show="showNotificationsTab == true">
                <div class="em-export-contant">
                    <div class="em-export-section em-export-gcal-contant">
                        <div class="emrow ep-subhead-wrap">
                        <div class="ep-subhead-title"><?php _e('Setup the notifications settings for sms! ', 'eventprime-twilio-text-notification'); ?></div>
                        <div class="ep-subhead-info epnotice">
                            <?php 
                            $url = admin_url().'admin.php?page=em_sms_settings';
                            $redirect = esc_url( add_query_arg( array( 'ep-ix-tab' => 'showNotificationsTab' ), $url ) );
                            _e("Manage the options to set enable/disable the actions and their message.", 'eventprime-twilio-text-notification'); ?></div>
                        </div>
                        <div class="em-export-gcal-integration" >
                            <div class="kf-db-title dbfl"><?php _e('On Event Bookings', 'eventprime-twilio-text-notification'); ?></div>
                            <div class="emrow">
                                <div class="emfield"><?php _e('Notify Admin', 'eventprime-twilio-text-notification'); ?></div>
                                <div class="eminput">
                                    <input type="checkbox" name="send_booking_msg_to_admin"  ng-model="data.options.send_booking_msg_to_admin" ng-true-value="1" ng-false-value="0">
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Send a text message to admin number on new bookings.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                            <div class="emrow" ng-show="data.options.send_booking_msg_to_admin==1">
                                <div class="emfield"><?php _e('Notification Message', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                    <textarea name="booking_msg_to_admin" ng-model="data.options.booking_msg_to_admin" ng-required="data.options.send_booking_msg_to_admin==1"></textarea>
                                    <div class="emfield_error">
                                        <span ng-show="optionForm.booking_msg_to_admin.$error.required && !optionForm.booking_msg_to_admin.$pristine"><?php _e('This is a required field.', 'eventprime-twilio-text-notification'); ?></span>
                                    </div>
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Contents of the text message which will be sent to the admin number on new bookings.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                            <div class="emrow">
                                <div class="emfield"><?php _e('Notify Users', 'eventprime-twilio-text-notification'); ?></div>
                                <div class="eminput">
                                    <input type="checkbox" name="send_booking_msg_to_users"  ng-model="data.options.send_booking_msg_to_users" ng-true-value="1" ng-false-value="0">
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Send a text message to the users who have just completed an event booking on your site. The user must have entered his/ her mobile number in user profile field.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                            <div class="emrow" ng-show="data.options.send_booking_msg_to_users==1">
                                <div class="emfield"><?php _e('Notification Message', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                    <textarea name="booking_msg_to_users" ng-model="data.options.booking_msg_to_users" ng-required="data.options.send_booking_msg_to_users==1"></textarea>
                                    <div class="emfield_error">
                                        <span ng-show="optionForm.booking_msg_to_users.$error.required && !optionForm.booking_msg_to_users.$pristine"><?php _e('This is a required field.', 'eventprime-twilio-text-notification'); ?></span>
                                    </div>    
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Contents of the text message which will be sent to the users who have just completed an event booking on your site.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                            <div class="kf-db-title dbfl"><?php _e('Frontend Event Submission', 'eventprime-twilio-text-notification'); ?></div>
                            <div class="emrow">
                                <div class="emfield"><?php _e('Notify Admin', 'eventprime-twilio-text-notification'); ?></div>
                                <div class="eminput">
                                    <input type="checkbox" name="send_fes_msg_to_admin"  ng-model="data.options.send_fes_msg_to_admin" ng-true-value="1" ng-false-value="0">
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Send a text message to the admin number when a new event is submitted by a user on your website.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                            <div class="emrow" ng-show="data.options.send_fes_msg_to_admin==1">
                                <div class="emfield"><?php _e('Notification Message', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                    <textarea name="fes_msg_to_admin" ng-model="data.options.fes_msg_to_admin" ng-required="data.options.send_fes_msg_to_admin==1"></textarea>
                                    <div class="emfield_error">
                                        <span ng-show="optionForm.fes_msg_to_admin.$error.required && !optionForm.fes_msg_to_admin.$pristine"><?php _e('This is a required field.', 'eventprime-twilio-text-notification'); ?></span>
                                    </div>   
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e(' Contents of the text message which will be sent to the admin number when a new event is submitted by a user on your website.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>

                            <div class="emrow">
                                <div class="emfield"><?php _e('Notify Users', 'eventprime-twilio-text-notification'); ?></div>
                                <div class="eminput">
                                    <input type="checkbox" name="send_fes_msg_to_users"  ng-model="data.options.send_fes_msg_to_users" ng-true-value="1" ng-false-value="0">
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Send a text message to the users who have just submitted a new event on your site. The user must have entered his/ her mobile number in user profile field.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                            <div class="emrow" ng-show="data.options.send_fes_msg_to_users==1">
                                <div class="emfield"><?php _e('Notification Message', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                    <textarea name="fes_msg_to_users" ng-model="data.options.fes_msg_to_users" ng-required="data.options.send_fes_msg_to_users==1"></textarea>
                                    <div class="emfield_error">
                                        <span ng-show="optionForm.fes_msg_to_users.$error.required && !optionForm.fes_msg_to_users.$pristine"><?php _e('This is a required field.', 'eventprime-twilio-text-notification'); ?></span>
                                    </div>    
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Contents of the text message which will be sent to the users who have just submitted a new event on your site.', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="emrow">
                <div class="eminput">
                    <button type="submit" class="btn btn-primary ep-authentication-button" id="submitSmsSettings" ng-disabled="optionForm.$invalid"><?php _e('Save', 'eventprime-twilio-text-notification'); ?></button>
                </div>
            </div> 
        </div>
     </form>
     <form ng-show="data.options.enable_twilio_sms_service==1" name="smsTestingForm" ng-submit="sendTestingSms(smsTestingForm.$valid)" novalidate  class="em-email-settings-form">        
        <div class="emagic-table dbfl" ng-show="showSmsTestingTab == true">
            <div class="em-export-tab" ng-show="showSmsTestingTab == true">
                <div class="em-export-contant">
                    <div class="em-export-section em-export-gcal-contant">
                        <div class="emrow ep-subhead-wrap">
                        <div class="ep-subhead-title"><?php _e('Send Testing SMS! ', 'eventprime-twilio-text-notification'); ?></div>
                        <div class="ep-subhead-info epnotice">
                            <?php 
                            $url = admin_url().'admin.php?page=em_sms_settings';
                            $redirect = esc_url( add_query_arg( array( 'ep-ix-tab' => 'showSmsTestingTab' ), $url ) );
                            _e("You can send testing sms here.", 'eventprime-twilio-text-notification'); ?></div>
                        </div>
                        <div class="em-export-gcal-integration" >
                             <div class="emrow">
                                    <?php _e('If you are sending messages while in trial mode, the recipient mobile number must be verified with Twilio.', 'eventprime-twilio-text-notification'); ?>
                            </div>
                            <div class="emrow">
                                <div class="emfield"><?php _e('Enter mobile number', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                    <input type="text" name="sms_testing_mobile_number"  ng-model="sms_testing_mobile_number" ng-required="true" ng-pattern="/^\+?\d{2}[- ]?\d{3}[- ]?\d{5,10}$/">
                                    <div class="emfield_error">
                                        <span ng-show="smsTestingForm.sms_testing_mobile_number.$error.required && smsTestingForm.$submitted"><?php _e('This is a required field.','eventprime-twilio-text-notification'); ?></span>
                                        <span ng-show="smsTestingForm.sms_testing_mobile_number.$error.pattern && smsTestingForm.$submitted"><?php _e('Please enter valid mobile number.','eventprime-twilio-text-notification'); ?></span>
                                    </div>
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Enter mobile number to which you want to send testing sms with a "+" and country code e.g., +1 123 456 7890', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>  
                            <div class="emrow" >
                                <div class="emfield"><?php _e('Message', 'eventprime-twilio-text-notification'); ?><sup>*</sup></div>
                                <div class="eminput">
                                    <textarea name="sms_testing_message" ng-model="sms_testing_message" ng-required="true"></textarea>
                                    <div class="emfield_error">
                                        <span ng-show="smsTestingForm.sms_testing_message.$error.required && smsTestingForm.$submitted"><?php _e('This is a required field.','eventprime-twilio-text-notification'); ?></span>
                                    </div>
                                </div>
                                <div class="emnote GSnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                                    <?php _e('Enter testing message, limited to 1600 characters', 'eventprime-twilio-text-notification'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           
            <div class="emrow">
                <div class="eminput">
                    <button type="submit" class="btn btn-primary ep-authentication-button" ng-disabled="postForm.$invalid"><?php _e('Send', 'eventprime-twilio-text-notification'); ?></button>
                </div>
            </div> 
        </div>
     </form>
     <form ng-show="data.options.enable_twilio_sms_service==1 && data.options.show_twilio_sms_error_logs==1" name="SmsLogsForm" ng-submit="delTwlSmsErrLogs(SmsLogsForm.$valid)" novalidate  class="em-email-settings-form">        
        <div class="emagic-table dbfl" ng-show="showSmsLogsTab == true">
            <div class="em-export-tab" ng-show="showSmsLogsTab == true">
                <div class="em-export-contant">
                    <div class="em-export-section em-export-gcal-contant">
                        <div class="emrow ep-subhead-wrap">
                        <div class="ep-subhead-title"><?php _e('Twilio SMS Error Logs Collections! ', 'eventprime-twilio-text-notification'); ?></div>
                        <div class="ep-subhead-info epnotice">
                            <?php 
                            $url = admin_url().'admin.php?page=em_sms_settings';
                            $redirect = esc_url( add_query_arg( array( 'ep-ix-tab' => 'showSmsLogsTab' ), $url ) );
                            _e("You can check twilio sms error logs here.", 'eventprime-twilio-text-notification'); ?></div>
                        </div>
                        <div class="em-export-gcal-integration" >
                             <div class="emrow">
                                    <?php _e('Here you can check out twilio sms error logs.', 'eventprime-twilio-text-notification'); ?>
                            </div>
                            <div class="emrow" style="white-space: pre-line;">
                                {{data.options.twilio_sms_error_logs_collections}}
                            </div>  
                        </div>
                    </div>
                </div>
            </div>
           
            <div class="emrow">
                <div class="eminput">
                    <button type="submit" class="btn btn-primary ep-authentication-button" ng-disabled="data.options.twilio_sms_error_logs_collections=='No logs are available'"><?php _e('Delete All Logs', 'eventprime-twilio-text-notification'); ?></button>
                </div>
            </div> 
        </div>
     </form>
    </div>
</div>