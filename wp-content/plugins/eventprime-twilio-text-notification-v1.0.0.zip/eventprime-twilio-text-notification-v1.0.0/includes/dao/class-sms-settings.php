<?php
if (!defined( 'ABSPATH')){
    exit; // Exit if accessed directly
}

class EventM_SMS_Settings_DAO 
{
    public function save($model)
    {   
        $options= get_option( EM_SMS_SETTINGS );
        foreach($model as $key=>$val){
            $options[$key]= $val;
        }
        update_option( EM_SMS_SETTINGS, $options );
    }
    
    public function get() { 
        $options = get_option( EM_SMS_SETTINGS );
        $sms_settings = new EventM_SMS_Settings_Model();
        foreach ($options as $key=>$val) {
            $key= str_replace('em_','',$key);
            if ( property_exists( $sms_settings, $key ) ) {
               $sms_settings->{$key}= maybe_unserialize( $val );
            }
        }

        return $sms_settings;
    }
}
