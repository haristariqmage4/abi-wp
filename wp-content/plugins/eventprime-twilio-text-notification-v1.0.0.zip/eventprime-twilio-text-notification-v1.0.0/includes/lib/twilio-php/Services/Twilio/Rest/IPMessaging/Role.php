<?php

class Services_Twilio_Rest_IPMessaging_Role extends Services_Twilio_IPMessagingInstanceResource {

}
