<?php

class Services_Twilio_Rest_Trunking_OriginationUrl extends Services_Twilio_TrunkingInstanceResource {

}
