<?php
class EventPrime_Woocommerce_Integration_Admin {
    
    protected $request;
    protected $service;
    protected $dao;
    
    public function __construct() {
        $this->request = EventM_Raw_Request::get_instance();
        $this->service = EventM_Factory::get_service('EventM_Service');
        $this->dao = new EventM_Event_DAO();
        add_action('event_magic_custom_extensions_link',array($this,'dashboard_link'));
        add_action('event_magic_dashboard_woocommerce_tab',array($this,'dashboard_page'));
        add_action('event_magic_load_strings',array($this,'load_screen_data'));
        add_action('wp_ajax_em_save_woocommerce_products',array($this,'save_woocommerce_products'));
    }
    
    public function dashboard_link($post_id) {
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            include_once('template/dashboard_icon.php');
        }
    }
    
    public function dashboard_page($post_id) {
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            wp_enqueue_style('em_woocommerce_integration', plugin_dir_url(__DIR__) . 'admin/template/css/em_woocommerce_integration.css', false, EVENTPRIME_VERSION);
            wp_enqueue_style('em_woocommerce_integration_select2', plugin_dir_url(__DIR__) . 'admin/template/css/select2.min.css', false, EVENTPRIME_VERSION);
            wp_enqueue_script('em-woocommerce-integration',plugin_dir_url(__DIR__).'/admin/template/js/em-woocommerce-integration.js',array('em-event-controller'));
            wp_enqueue_script('em-woocommerce-integration-select2',plugin_dir_url(__DIR__).'/admin/template/js/select2.min.js',array('em-event-controller'));
            include_once('template/settings.php');
        }
    }

    public function load_screen_data($context){
        $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
        if($context == 'admin_woocommerce_product_tags'){
            $response = $service->load_products_by_tags();
            wp_send_json_success($response);
        }
        elseif($context == 'admin_woocommerce_product_categories'){
            $response = $service->load_products_by_categories();
            wp_send_json_success($response);
        }
    }
    
    public function check_permission() {
        if (!em_is_user_admin()) {
            $error_msg = __('User not allowed to perform this operation','eventprime-recurring-events');
            wp_send_json_error(array('errors'=>array($error_msg)));
        }
    }

    public function save_woocommerce_products() {
        $this->check_permission();
        $post_data = $this->request->get_data();
        $event_id = absint($post_data['id']);
        foreach ($post_data as $key => $val) {
            if($key == 'selectd_products'){
                $is_all_empty = 0;$selectedProducts = array();
                foreach ($post_data['selectd_products'] as $pkey => $pvalue) {
                    if(empty($post_data['selectd_products'][$pkey]->product)){
                        $is_all_empty++;
                    }
                    else{
                        $selectedProducts[] = $post_data['selectd_products'][$pkey];
                    }
                }
                if($is_all_empty == count($post_data['selectd_products'])){
                    // no product selected
                    wp_send_json_error(array('errors'=>array(__('Please add alteast one product','eventprime-recurring-events'))));
                }
                else{
                    em_update_post_meta($event_id, 'selectd_products', $selectedProducts);
                    /* woo commerce products updates for child events */
                    $child_events_data = array( 'event_id' => $event_id, 'selectedProducts' => $selectedProducts , 'is_product_selected' => 1 );
                    do_action( 'update_child_events_woocommerce_products', $child_events_data );
                    // update event product session
                    foreach ($selectedProducts as $value) {
                        $productData = array();
                        $productid = $value->product;
                        $product = wc_get_product($productid);
                        $productData['image'] = $product->get_image(array(100, 100));
                        $productData['name'] = $product->get_name();
                        $productData['price'] = $product->get_price();
                        $productData['type'] = $product->get_type();
                        $productData['purchase_mendatory'] = $value->purchase_mendatory;
                        $_SESSION['event_products'][$event_id][$productid] = $productData;
                    }
                }
            }
            else if (in_array($key,array('enable_product','allow_update_quantity','multiply_product_quantity','display_combined_cost'))) {
                em_update_post_meta($event_id, $key, $val);
                /* woo commerce products updates for child events */
                $child_events_data = array( 'event_id' => $event_id, 'key' => $key, 'val' => $val, 'is_product_selected' => 0  );
                do_action( 'update_child_events_woocommerce_products', $child_events_data );
            } 
            else {
                continue;
            }
        }
        $redirect = admin_url('/admin.php?page=em_dashboard&post_id=' . $event_id);
        wp_send_json_success(array('redirect'=>$redirect));
    }
}
new EventPrime_Woocommerce_Integration_Admin;