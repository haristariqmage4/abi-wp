eventMagicApp.controller('woocommerceIntegrationCtrl', function ($scope, $http, TermUtility, EMRequest, PostUtility) {

    $scope.formErrors = [];
    $scope.progressStart= function(){
        $scope.requestInProgress = true;
    }
    $scope.progressStop= function(){
        $scope.requestInProgress = false;
    }
    /*
     * Controller initialization for data load 
     */
    $scope.initialize = function () {

    }
    $scope.addSelect = function () {
        if($scope.addCountWoo == undefined){
            if($scope.data.post.selectd_products.length > 0){
                $scope.addCountWoo = $scope.data.post.selectd_products.length;
            }
            else{
                $scope.addCountWoo = 0;
                $scope.data.post.selectd_products = [];
                if($scope.data.post.woocommerce_products.length > 0){
                    $scope.addCountWoo = $scope.data.post.woocommerce_products.length;
                }
            }
        }
        else{
            $scope.addCountWoo++;
        }
        $scope.data.post.selectd_products.push({
            'product' : '',
            'purchase_mendatory' : ''
        });
        if($scope.addCountWoo > 0){
            $scope.data.post.woocommerce_products[$scope.addCountWoo] = {};
            $scope.data.post.woocommerce_products[$scope.addCountWoo].data = $scope.data.post.all_woocommerce_products;
        }
    };

    $scope.removeSelect = function (index) {
        $scope.data.post.selectd_products.splice(index, 1);
    };
    
    $scope.changeCategory = function(index){
        var categories = $scope.data.post.search_category[index];
        $scope.data.selected_categories = [];
        $scope.data.selected_categories[index] = categories;
        $scope.data.selected_index = index;
        if($scope.data.post.search_tags && $scope.data.post.search_tags[index]){
            var tags = $scope.data.post.search_tags[index];
            $scope.data.selected_tags = [];
            if(tags.length > 0){
                $scope.data.selected_tags[index] = tags;
            }
        }
        $scope.data.em_request_context = 'admin_woocommerce_product_categories';
        $scope.progressStart();
        EMRequest.send('em_load_strings',$scope.data).then(function(response){
            var responseBody = response.data;
            if(responseBody.success){
                $scope.data.post.woocommerce_products[index].data = responseBody.data.products;
            }
            $scope.progressStop();
        });
    };
    
    $scope.changeTag = function(index){
        var tags = $scope.data.post.search_tags[index];
        $scope.data.selected_tags = [];
        $scope.data.selected_tags[index] = tags;
        $scope.data.selected_index = index;
        if($scope.data.post.search_category && $scope.data.post.search_category[index]){
            var categories = $scope.data.post.search_category[index];
            $scope.data.selected_categories = [];
            if(categories.length > 0){
                $scope.data.selected_categories[index] = categories;
            }
        }
        $scope.data.em_request_context = 'admin_woocommerce_product_tags';
        $scope.progressStart();
        EMRequest.send('em_load_strings',$scope.data).then(function(response){
            var responseBody = response.data;
            if(responseBody.success){
                $scope.data.post.woocommerce_products[index].data = responseBody.data.products;
            }
            $scope.progressStop();
        });
    };

    $scope.save_event_products = function () {
        if ($scope.data.post.selectd_products.length > 0) {
            $scope.progressStart();
            EMRequest.send('em_save_woocommerce_products',$scope.data.post).then(function(response) {
                var responseBody = response.data;
                if (responseBody.success) {
                    if(responseBody.data.hasOwnProperty('redirect')) {
                        $scope.requestInProgress = false;
                        location.href = responseBody.data.redirect;
                    }
                } else {
                    if (responseBody.data.hasOwnProperty('errors')) {
                        $scope.formErrors = responseBody.data.errors;
                        $scope.requestInProgress = false;
                        jQuery('html, body').animate({ scrollTop: 0 }, 'slow');
                    }
                }
                $scope.progressStop();
            });
        }
    }

    $scope.enable_woo_products = function() {
        if($scope.data.post.enable_product == 1){
            if($scope.data.post.selectd_products == ''){
                $scope.addSelect();
            }
        }
    }
});