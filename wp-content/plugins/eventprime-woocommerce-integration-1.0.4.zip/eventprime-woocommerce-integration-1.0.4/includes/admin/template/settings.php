<div ng-controller="eventCtrl" ng-app="eventMagicApp" ng-cloak ng-init="initialize('event_woocommerce_integration')">
    <div class="kikfyre kf-container" ng-controller="woocommerceIntegrationCtrl" ng-init="initialize()" ng-cloak>
        <div class="kf_progress_screen" ng-show="requestInProgress"></div>
        <div class="kf-db-content" ng-hide="requestInProgress">
            <div class="kf-db-title">
                <?php _e('Woocommerce Products', 'eventprime-woocommerce-integration'); ?>
            </div>
            <div class="form_errors">
                <ul>
                    <li class="emfield_error" ng-repeat="error in formErrors">
                        <span>{{error}}</span>
                    </li>
                </ul>  
            </div>
            
            <div class="emrow">
                <div class="emfield"><?php _e('Enable product', 'eventprime-woocommerce-integration'); ?></div>
                <div class="eminput">
                    <input type="checkbox" name="enable_product" ng-model="data.post.enable_product" ng-true-value="1" ng-false-value="0" ng-click="enable_woo_products()">
                </div>
            </div>
            
            <!-- FORM -->
            <form name="event_products_form" novalidate ng-submit="save_event_products()" ng-show="data.post.enable_product == 1">
                <div class="emrow ep-childfieldsrow ep-woo-product-block" ng-repeat="(tindex, wp) in data.post.selectd_products">
                    <div class="emrow">
                        <div class="emfield"><?php _e('Select Category', 'eventprime-woocommerce-integration'); ?></div>
                        <div class="eminput">
                            <span class="ep-wi-category">
                                <select multiple name="search_category_{{tindex}}[]" ng-model="data.post.search_category[tindex]" class="search_category" ng-change="changeCategory({{tindex}})">
                                    <option ng-repeat="category in data.post.woocommerce_categories" value="{{category.slug}}">{{category.name}}</option>
                                </select>
                            </span>
                            <!-- <span class="ep-wi-tags">
                                <select multiple name="search_tags_{{tindex}}[]" ng-model="data.post.search_tags[tindex]" class="search_tags" ng-change="changeTag({{tindex}})">
                                    <option ng-repeat="tag in data.post.woocommerce_tags" value="{{tag.slug}}">{{tag.name}}</option>
                                </select>
                            </span> -->
                        </div>
                    </div>
                    <script>
                        setTimeout(() => {
                            jQuery(".search_category").select2({
                                placeholder: "Select Category",
                                tags: true,
                                width: '80%'
                            });
                            /*jQuery(".search_tags").select2({
                                placeholder: "Select Tags",
                                tags: true,
                                width: '80%'
                            });*/
                        }, 300);
                    </script>
                    
                    <div class="emrow">
                        <div class="emfield"><?php _e('Select Product', 'eventprime-woocommerce-integration'); ?></div>
                        <div class="eminput">
                            <span class="ep-wi-product">
                                <select name="woocommerce_product[tindex]" ng-model="data.post.selectd_products[tindex].product">
                                    <option data-index="{{tindex}}" value="">-- <?php _e('Select Product', 'eventprime-woocommerce-integration'); ?> --</option>
                                    <option ng-selected="{{product.id == data.post.selectd_products[tindex].product}}" ng-repeat="product in data.post.woocommerce_products[tindex].data" value="{{product.id}}" data-index="{{tindex}}" data-product="{{data.post.selectd_products[tindex].product}}">{{product.name}}</option>
                                </select>
                            </span>
                        </div>
                    </div>
                    <div class="emrow">
                        <div class="emfield"><?php _e('Is Purchase Mandatory', 'eventprime-recurring-events'); ?></div>
                        <div class="eminput">
                            <span class="ep-wi-remove">
                                <input type="checkbox" name="purchase_mendatory[tindex]" ng-model="data.post.selectd_products[tindex].purchase_mendatory" ng-true-value="1" ng-false-value="0">
                            </span>
                        </div>
                    </div>
                    <div class="ep-woo-product-btn">
                        <button ng-click="removeSelect(tindex)" class="ep-remove-product"> <?php _e('Remove', 'eventprime-woocommerce-integration'); ?> </button>
                        <button ng-show="$last" type="button" class="ep-add-product" ng-click="addSelect()"><?php _e('Add Product', 'eventprime-woocommerce-integration'); ?></button>
                    </div>
                </div>
                
                <!--<div class="emrow" ng-show="data.post.selectd_products.length > 0">
                    <div class="emfield"><?php //_e('Allow update product quantity', 'eventprime-recurring-events'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" name="allow_update_quantity" ng-model="data.post.allow_update_quantity" ng-true-value="1" ng-false-value="0">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php //_e('Choose to allow user to update product quantity on cart page', 'eventprime-recurring-events'); ?>
                    </div>
                </div>
                 <div class="emrow" ng-show="data.post.selectd_products.length > 0">
                    <div class="emfield"><?php //_e('Multiply product quantity with no. of seat', 'eventprime-recurring-events'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" name="multiply_product_quantity" ng-model="data.post.multiply_product_quantity" ng-true-value="1" ng-false-value="0">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php //_e('Choose whether to multiply product quantity with no. of seats on cart page', 'eventprime-recurring-events'); ?>
                    </div>
                </div> -->
                <div class="emrow" ng-show="data.post.selectd_products.length > 0">
                    <div class="emfield"><?php _e('Display event and product combined cost', 'eventprime-recurring-events'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" name="display_combined_cost" ng-model="data.post.display_combined_cost" ng-true-value="1" ng-false-value="0">
                    </div>
                    <div class="emnote">
                        <i class="fa fa-info-circle" aria-hidden="true"></i> <?php _e('Choose to display event and product combined cost on event detail page', 'eventprime-recurring-events'); ?>
                    </div>
                </div>
                <div class="dbfl kf-buttonarea">
                    <div class="em_cancel">
                        <a class="kf-cancel" href="<?php echo admin_url('/admin.php?page=em_dashboard&post_id=' . $post_id); ?>">
                            <?php _e('Cancel', 'eventprime-woocommerce-integration'); ?>
                        </a>
                    </div>
                    <button type="submit" class="btn btn-primary" ng-disabled="requestInProgress || data.post.selectd_products.length < 1">
                        <?php _e('Save', 'eventprime-woocommerce-integration'); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>