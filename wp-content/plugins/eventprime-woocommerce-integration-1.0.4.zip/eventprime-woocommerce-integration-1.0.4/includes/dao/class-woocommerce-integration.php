<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

class EventM_Woocommerce_Integration_DAO extends EventM_Post_Dao
{
  public function __construct() {
    $this->post_type = EM_COUPON_POST_TYPE;
  }
  
}