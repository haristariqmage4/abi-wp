<?php
class EventMWI_Global_Settings_Model extends EventM_Global_Settings_Model
{
  public $allow_woocommerce_integration;
}