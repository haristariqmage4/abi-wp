(function( $ ) {
    //'use strict';
    $(function() {
        $(".ep-choose-woo-btn").on("click", function() {
            var thisclicked = this;
            //$(thisclicked).hide();
            var em_event_id = $(thisclicked).data('event-id');
            var em_product_id = $(thisclicked).data('pid');
            var data = {
                action: 'em_woocommerce_select_option_popup',
                event_id: em_event_id,
                product_id: em_product_id,
            };
            $("#ep-woocommerce-product-loader-"+em_event_id).show();
            $.post(emwi_ajax_object.ajax_url, data, function(response) {
                $("#ep-woocommerce-booking-product-block").append(response);
                var modal = $("#ep-woocommerce-product-option-popup-model");
                modal.show();
                $("#ep-woocommerce-product-loader-"+em_event_id).hide();
            });
            return false;
        });
        
        $(".ep-product-popup-close").on("click", function() {
            var modal = $("#ep-woocommerce-product-option-popup-model"); 
            modal.hide();
        });

        $(".ep-view-woocommerce-product").on("click", function() {
            var thisclicked = this;
            //$(thisclicked).hide();
            var em_event_id = $(thisclicked).data('eventid');
            $("#ep-woocommerce-product-loader-"+em_event_id).show();
                var data = {
                action: "em_popup_view_woocommerce_products",
                event_id: em_event_id,
            };
            $.post(emwi_ajax_object.ajax_url, data, function(response) {
                $("#ep-woocommerce-product-popup-viewer-"+em_event_id).append(response);
                var modal = $("#ep-woocommerce-product-popup-model");
                modal.show();
                $(".ep-product-popup-close").click(function(){
                    modal.hide();
                    $("#ep-woocommerce-product-popup-model").remove();
                });
                $("#ep-woocommerce-product-loader-"+em_event_id).hide();
            });
        });
    });

})( jQuery );


var emColor = jQuery('.emagic').find('a').css('color');
jQuery(".emagic .ep-view-woocommerce-product svg").css('fill', emColor);

function ep_woo_select_option(thisclicked){
    jQuery(thisclicked).hide();
    var em_event_id = jQuery(thisclicked).data('event-id');
    var em_product_id = jQuery(thisclicked).data('pid');
    var data = {
        action: 'em_woocommerce_select_option_popup',
        event_id: em_event_id,
        product_id: em_product_id,
    };
    jQuery("#ep-woocommerce-product-loader-"+em_event_id).show();
    jQuery.post(emwi_ajax_object.ajax_url, data, function(response) {
        jQuery("#ep-woocommerce-booking-product-block").append(response);
        var modal = jQuery("#ep-woocommerce-product-option-popup-model");
        modal.show();
        jQuery("#ep-woocommerce-product-loader-"+em_event_id).hide();
    });
    return false;
}

function ep_woo_set_dominent_color(){ 
    $ = jQuery;
    $("#primary.content-area .entry-content").prepend("<a>");
    var epiconColor = $('.emagic, #primary.content-area .entry-content').find('a').css('color');
    $(".emagic .ep-view-woocommerce-product svg").css('fill', epiconColor); 
    //console.log(epiconColor);
}

jQuery(document).ready(function () {
    ep_woo_set_dominent_color();
});

function ep_show_woo_products(em_event_id) {
    $("#ep-woocommerce-product-loader-"+em_event_id).show();
    var data = {
        action: "em_popup_view_woocommerce_products",
        event_id: em_event_id,
    };
    $.post(emwi_ajax_object.ajax_url, data, function(response) {
        $("#ep-woocommerce-product-popup-viewer-"+em_event_id).append(response);
        var modal = $("#ep-woocommerce-product-popup-model");
        modal.show();
        $(".ep-product-popup-close").click(function(){
            modal.hide();
            $("#ep-woocommerce-product-popup-model").remove();
        });
        $("#ep-woocommerce-product-loader-"+em_event_id).hide();
    });
}