<?php
if (!defined( 'ABSPATH')){
    exit;
}

class EventM_Woocommerce_Integration_Service {
    
    private $dao;
    private static $instance = null;
    
    private function __construct() {
        //$this->dao = new EventM_Woocommerce_Integration_DAO();
    }
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function load_products_by_tags(){
        $response = new stdClass();
        $response->products = array();
        $tags = event_m_get_param('selected_tags');
        $selected_categories = event_m_get_param('selected_categories');
        $index = $_POST['selected_index'];
        $args = array(
            'numberposts' => -1,
            'post_status' => 'publish'
        );
        if(!empty($tags) && isset($tags[$index])){
            $args['tag'] = $tags[$index];
        }
        if(!empty($categories) && isset($categories[$index])){
            $args['category'] = $selected_categories;
        }
        $products = wc_get_products( $args );
        if(!empty($products)){
            foreach ($products as $key => $value) {
                $response->products[] = array('id' => $value->get_id(), 'name' => $value->get_name());
            }
        }
        return $response;
    }

    public function load_products_by_categories(){
        $response = new stdClass();
        $response->products = array();
        $categories = event_m_get_param('selected_categories');
        $index = $_POST['selected_index'];
        $args = array(
            'numberposts' => -1,
            'post_status' => 'publish'
        );
        if(!empty($categories) && isset($categories[$index])){
            $args['category'] = $categories[$index];
        }
        $products = wc_get_products($args);
        if(!empty($products)){
            foreach ($products as $key => $value) {
                $response->products[] = array('id' => $value->get_id(), 'name' => $value->get_name());
            }
        }
        return $response;
    }

    public function load_post_response_model($response){
        if(!isset($response->post['selectd_products'])){
            $response->post['selectd_products'] = array();
        }
        if(!isset($response->post['woocommerce_products'])){
            $response->post['woocommerce_products'] = array();
        }
        if(!isset($response->post['woocommerce_categories'])){
            $response->post['woocommerce_categories'] = array();
        }
        if(!isset($response->post['woocommerce_tags'])){
            $response->post['woocommerce_tags'] = array();
        }
        if(!isset($response->post['all_woocommerce_products'])){
            $response->post['all_woocommerce_products'] = array();
        }
        // products
        $args = array(
            'numberposts' => -1,
            'post_status' => 'publish'
        );
        $products = wc_get_products($args);
        if(!empty($products)){
            foreach ($products as $key => $value) {
                if(!empty($value->get_id())){
                    if(isset($response->post['selectd_products']) && !empty($response->post['selectd_products'])){
                        foreach ($response->post['selectd_products'] as $wkey => $wvalue) {
                            $response->post['woocommerce_products'][$wkey]['data'][] = array('id' => $value->get_id(), 'name' => $value->get_name());
                        }
                    }
                    else{
                        $response->post['woocommerce_products'][0]['data'][] = array('id' => $value->get_id(), 'name' => $value->get_name());
                    }
                    $response->post['all_woocommerce_products'][] = array('id' => $value->get_id(), 'name' => $value->get_name());
                }
            }
        }
        // categories
        $categories = get_terms( ['taxonomy' => 'product_cat', 'hide_empty' => false] );
        if(!empty($categories)){
            foreach ($categories as $key => $value) {
                $response->post['woocommerce_categories'][] = array("slug" => $value->slug, "name" => $value->name);
            }
        }
        // tags
        $tags = get_terms( ['taxonomy' => 'product_tag', 'hide_empty' => false] );
        if(!empty($tags)){
            foreach ($tags as $key => $value) {
                $response->post['woocommerce_tags'][] = array("slug" => $value->slug, "name" => $value->name);
            }
        }
        return $response;
    }

    public function load_event_product($event_id){
        if(!empty($event_id)){
            /*if(isset($_SESSION['event_products'][$event_id]) && !empty($_SESSION['event_products'][$event_id])){
                return $_SESSION['event_products'][$event_id];
            }
            else{*/
                $_SESSION['event_products'][$event_id] = [];
                $event_service = EventM_Factory::get_service('EventM_Service');
                $event = $event_service->load_model_from_db($event_id);
                if(!empty($event->selectd_products)){
                    foreach ($event->selectd_products as $value) {
                        $productData = array();
                        $productid = $value->product;
                        $product = wc_get_product($productid);
                        $productData['image'] = $product->get_image(array(100, 100));
                        $productData['name'] = $product->get_name();
                        $productData['price'] = $product->get_price();
                        $productData['type'] = $product->get_type();
                        $productData['purchase_mendatory'] = $value->purchase_mendatory;
                        $_SESSION['event_products'][$event_id][$productid] = $productData;
                    }
                }
                return $_SESSION['event_products'][$event_id];
            //}
        }
    }

    public function load_event_product_ids($event_id){
        $products = array();
        if(!empty($event_id)){
            $event_service = EventM_Factory::get_service('EventM_Service');
            $event = $event_service->load_model_from_db($event_id);
            if(!empty($event->selectd_products)){
                foreach ($event->selectd_products as $key => $value) {
                    $products[] = $value->product;
                }
            }
        }
        return $products;
    }

    public function get_event_product_popup_request(){
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            $event_id = event_m_get_param('event_id');
            if(empty($event_id))
                return;
            $products = $this->load_event_product($event_id);
            $content = '';
            if(!empty($products)){
                $currency_symbol = em_currency_symbol();
                $content .= '<div class="ep-woocommerce-product-popup" id="ep-woocommerce-product-popup-model">';
                    $content .= '<div class="ep-product-popup-content">';
                        $content .= '<div class="ep-product-popup-header">';
                        $content .= '<div class="ep-product-modal-title">'.__('Product Information', 'eventprime-event-woocommerce-integration').'</div>';
                            $content .= '<span class="ep-product-popup-close">&times;</span>';
                        $content .= '</div>';
                        $content .= '<div class="ep-product-popup-body">';
                            $content .= '<table class="ep-product-popup-table">';
                                $content .= '<tr>';
                                    $content .= '<th>'.__('Image', 'eventprime-event-woocommerce-integration').'</th>';
                                    $content .= '<th>'.__('Name', 'eventprime-event-woocommerce-integration').'</th>';
                                    $content .= '<th>'.__('Price', 'eventprime-event-woocommerce-integration').'</th>';
                                $content .= '</tr>';
                                $content .= '<tbody>';
                                    foreach ($products as $key => $value) {
                                        $content .= '<tr>';
                                            $content .= '<td>'.$value['image'].'</td>';
                                            $content .= '<td>'.$value['name'].'</td>';
                                            $content .= '<td>'.$currency_symbol.$value['price'].'</td>';
                                        $content .= '</tr>';
                                    }
                                $content .= '</tbody>';
                            $content .= '</table>';
                        $content .= '</div>';
                    $content .= '</div>';
                $content .= '</div>';
            }
            return $content;
        }
    }

    public function get_single_event_ticket_price($event_model, $ticket_price){
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration) && isset($event_model->selectd_products) && !empty($event_model->selectd_products) && isset($event_model->display_combined_cost) && !empty($event_model->display_combined_cost)){
            $selectd_products = $event_model->selectd_products;
            foreach ($selectd_products as $key => $value) {
                $productid = $value->product;
                $product = wc_get_product($productid);
                $ticket_price += $product->get_price();
            }
        }
        return $ticket_price;
    }

    public function get_booking_page_product_block(){
        $content = '';
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            $event_id = event_m_get_param('event_id');
            if(!empty($event_id)){
                $products = $this->load_event_product($event_id);
                if(!empty($products)){
                    $currency_symbol = em_currency_symbol();
                    $content .= '<div class="ep-woocommerce-product-wrap dbfl" id="ep-woocommerce-booking-product-block" ng-cloak>';
                        $content .= '<div class="ep-woocommerce-summary-head">'.__('Product Information','eventprime-event-woocommerce-integration').'</div>';
                        $content .= '<div class="em_progress_screen ep-progress-loader" id="ep-woocommerce-product-loader-'.$event_id.'" style="display:none;"></div>';
                        $content .= '<div class="ep-product-info-block">';
                            $content .= '<table class="ep-product-info-table">';
                                $content .= '<thead><tr>';
                                    $content .= '<th>'.__('Image', 'eventprime-event-woocommerce-integration').'</th>';
                                    $content .= '<th>'.__('Name', 'eventprime-event-woocommerce-integration').'</th>';
                                    $content .= '<th>'.__('Quantity', 'eventprime-event-woocommerce-integration').'</th>';
                                    $content .= '<th>'.__('Price', 'eventprime-event-woocommerce-integration').'</th>';
                                    $content .= '<th class="pmth"></th>';
                                $content .= '</tr></thead>';
                                $content .= '<tbody>';
                                    foreach ($products as $productid => $value) {
                                        $content .= '<tr class="ep-product-info-table-rows">';
                                            $content .= '<td>'.$value['image'].'</td>';
                                            $content .= '<td>'.$value['name'].'<br/>';
                                            if($value['type'] == 'variable'){
                                                $content .= '<a  class="ep-choose-woo-btn" data-pid="'.$productid.'" data-event-id="'.$event_id.'">'.__('Select Options', 'eventprime-event-woocommerce-integration').'</a>';
                                                $content .= '<div id="ep-woocommerce-option-popup-model"></div>';
                                                $content .= '<input type="text" id="ep_product_variation_id" ng-model="ep_product_variation_id['.$productid.']" name="ep_product_variation_id['.$productid.']" style="display:none;" />';
                                                $content .= '<input type="text" id="ep_product_variation_price" ng-model="ep_product_variation_price['.$productid.']" name="ep_product_variation_price['.$productid.']" style="display:none;" />';
                                            }
                                            $content .= '</td>';
                                            $content .= '<td>';
                                                if(!empty($value['purchase_mendatory'])){
                                                    $content .= '<input type="number" min="1" ng-init="ep_product_quantity['.$productid.']=1" name="ep_product_quantity['.$productid.']" ng-model="ep_product_quantity['.$productid.']" />';
                                                }
                                                else{
                                                    $content .= '<input type="number" min="0" ng-init="ep_product_quantity['.$productid.']=1" name="ep_product_quantity['.$productid.']" ng-model="ep_product_quantity['.$productid.']" />';
                                                }
                                            $content .= '</td>';
                                            $content .= '<td id="ep-woo-product-price-'.$productid.'">'.$currency_symbol.$value['price'].'</td>';
                                            if(empty($value['purchase_mendatory'])){
                                                $content .= '<script type="text/javascript">
                                                    jQuery(".pmth").show();
                                                </script>';
                                                
                                                $content .= '<td><a type="button" title="'.__('Remove', 'eventprime-event-woocommerce-integration').'" class="remove_product" data-pid="'.$productid.'" ng-click="removeBookingProduct('.$productid.')">X</a></td>';
                                            }else {$content .= '<td></td>';}
                                        $content .= '</tr>';
                                    }
                                $content .= '</tbody>';
                            $content .= '</table>';
                            $content .= '<div class="ep-woo-reset-button em_bg_lt"><button type="button" ng-click="reset_woo_products_on_booking_page()" >'.__('Reset', 'eventprime-event-woocommerce-integration').'</button></div>';
                        $content .= '</div>';
                    $content .= '</div>';
                }
            }
        }
        return $content;
    }

    public function update_event_order_info($order_info, $event_id){
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            if(!empty($event_id)){
                $productIds = $this->load_event_product_ids($event_id);
                $woocommerceProducts = event_m_get_param('woocommerce_products');
                if(!empty($woocommerceProducts) && count($woocommerceProducts) > 0){
                    $order_info['woocommerce_products_info'] = array();
                    foreach ($woocommerceProducts as $value) {
                        $pid = intval($value->id);
                        $qty = intval($value->qty);
                        WC()->cart->add_to_cart( $pid, $qty );
                        $order_info['woocommerce_products_info'][$pid] = $qty;
                    }
                }
            }
        }
        return $order_info;
    }

    public function remove_tmp_booking_products_from_cart($booking){
        /*$products = $booking->order_info['woocommerce_products_info'];
        if(!empty($products)){
            $products = array_keys($products);
            foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
                if (in_array($cart_item['product_id'], $products)) {
                    WC()->cart->remove_cart_item( $cart_item_key );
                }
            }
        }*/
    }

    public function get_event_cart_product(){
        $woocommerce_data['products'] = $woocommerce_data['billing_address'] = $woocommerce_data['shipping_address'] = array();
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            $event_id = event_m_get_param('event_id', true);
            if(!empty($event_id)){
                $products = $this->load_event_product($event_id);
                $cart_selected_product = event_m_get_param('cart_selected_product');
                $cart_selected_product_variation_id = event_m_get_param('cart_selected_product_variation_id');
                $cart_selected_product_variation_price = event_m_get_param('cart_selected_product_variation_price');
                if(!empty($cart_selected_product) && count($cart_selected_product) > 0){
                    foreach ($cart_selected_product as $value) {
                        if(isset($products[$value->id])){
                            $pdata = array();
                            $pdata = $products[$value->id];
                            $pdata['id'] = $value->id;
                            $pdata['qty'] = $value->qty;
                            $subtotal = $products[$value->id]['price'] * $value->qty;
                            $pdata['sub_total'] = number_format($subtotal, 2);
                            // check for variation
                            if(!empty($cart_selected_product_variation_id)){
                                foreach ($cart_selected_product_variation_id as $variation) {
                                    if($variation->id == $value->id){
                                        if(!empty($variation->variation)){
                                            $product_variation_data = json_decode($variation->variation);
                                            foreach ($product_variation_data as $var_value) {
                                                $pdata['variation'][] = $var_value;
                                            }
                                        }
                                        //$pdata['variation'] = $variation->variation;
                                    }
                                }
                            }
                            // check for variation price
                            if(!empty($cart_selected_product_variation_price)){
                                foreach ($cart_selected_product_variation_price as $variation) {
                                    if($variation->id == $value->id){
                                        $pdata['variation_price'] = $variation->variation_price;
                                        $pdata['price'] = $variation->variation_price;
                                        $subtotal = $pdata['price'] * $value->qty;
                                        $pdata['sub_total'] = number_format($subtotal, 2);
                                    }
                                }
                            }
                            $woocommerce_data['products'][] = $pdata;
                        }
                    }
                }
                $userMeta = get_user_meta(get_current_user_id());
                $current_user = wp_get_current_user();
                $countries = new WC_Countries();
                $billing_fields = $countries->get_address_fields( '', 'billing_' );
                foreach ( $billing_fields as $key => $field ){
                    $field_value = '';
                    if(isset($userMeta[$key])){
                        $field_value = $userMeta[$key][0];
                    }
                    else{
                        if($key == 'billing_first_name'){
                            $field_value = ( $current_user->user_firstname != '') ?  $current_user->user_firstname : '';
                        }
                        if($key == 'billing_last_name'){
                            $field_value = ( $current_user->user_lastname != '') ? $current_user->user_lastname : '';
                        }
                        if($key == 'billing_email'){
                            $field_value = ( $current_user->user_email != '') ? $current_user->user_email : '';
                        }
                    }
                    $woocommerce_data['billing_address'][$key] = $field_value;
                }
                $shipping_fields = $countries->get_address_fields( '', 'shipping_' );
                foreach ( $shipping_fields as $key => $field ){
                    $field_value = '';
                    if(isset($userMeta[$key])){
                        $field_value = $userMeta[$key][0];
                    }
                    else{
                        if($key == 'shipping_first_name'){
                            $field_value = ( $current_user->user_firstname != '' ) ? $current_user->user_firstname : '';
                        }
                        if($key == 'shipping_last_name'){
                            $field_value = ( $current_user->user_lastname != '' ) ? $current_user->user_lastname : '';
                        }
                        if($key == 'shipping_email'){
                            $field_value = $current_user->user_email;
                        }
                    }
                    $woocommerce_data['shipping_address'][$key] = $field_value;
                }
            }
        }
        return $woocommerce_data;
    }
    
    public function get_woocommerce_state_by_country_code() {
        $default_county_states = array();
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            $country_code = event_m_get_param('country_code', true);
            if(!empty($country_code)){
                global $woocommerce;
                $countries_obj = new WC_Countries();
                $countries = $countries_obj->__get('countries');
                $default_county_states = $countries_obj->get_states($country_code);
            }
        }
        return $default_county_states;
    }
    public function get_checkout_page_product_block(){
        $content = '';
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            $event_id = event_m_get_param('event_id');
            if(!empty($event_id)){
                $products = $this->load_event_product($event_id);
                if(!empty($products)){?>
                    <div class="ep-woo-product-wrap">
                        <!--<h2><?php //_e( 'Product Info', 'eventprime-event-woocommerce-integration' );?></h2>-->
                        <div class="em-checkout-order-wrap " ng-repeat="order in orders">
                            <div class="ep-cart-item" ng-repeat="products in order.woocommerce_products">
                                <div class="ep-woo-product-item">
                                    <div class="ep-woo-product-image" ng-bind-html="products.image | unsafe"></div>
                                    <div class="ep-woo-product-name">{{products.name}}</div>
                                    <div ng-if="products.variation" ng-repeat="pvalues in products.variation">
                                        <span>{{pvalues.attr_label}} : {{pvalues.attr_value}}</span>
                                    </div>
                                </div>
                                <div class="ep-woo-product-price">{{currency_symbol}}{{products.price}}</div>
                                <div class="ep-woo-product-qty">{{products.qty}}</div>
                                <div class="ep-woo-product-subtotal">{{currency_symbol}}{{products.sub_total}}</div>
                            </div>
                        </div>
                    </div><?php
                }
            }
        }
        return $content;
    }

    public function get_checkout_page_billing_block(){
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            $event_id = event_m_get_param('event_id');
            if(!empty($event_id)){
                $products = $this->load_event_product($event_id);
                if(!empty($products)){
                    // get the user meta
                    $userMeta = get_user_meta(get_current_user_id());
                    $current_user = wp_get_current_user();
                    // get the form fields
                    $countries = new WC_Countries();
                    $billing_fields = $countries->get_address_fields( '', 'billing_' );
                    $load_address = 'billing';
                    $page_title   = __( 'Billing Address', 'eventprime-event-woocommerce-integration' );?>
                    <div class="ep-woocommerce-checkout-forms dbfl">
                        <div class="ep-woocommerce-billing-address ep-woocommerce-address-form difl">
                            <form action="/my-account/edit-address/billing/" id="woocommerce-billing-address" class="edit-account" method="post">
                                <div class="ep-woocommerce_form_heading"><?php echo apply_filters( 'woocommerce_my_account_edit_address_title', $page_title ); ?></div>
                                <div class="ep-form_errors">
                                    <div class="emfield_error" ng-repeat="error in billingErrors">
                                        <span><span class="material-icons">error_outline</span>{{error}}</span>
                                    </div>
                                </div>
                                <?php do_action( "woocommerce_before_edit_address_form_{$load_address}" ); ?>
                                <?php
                                foreach ( $billing_fields as $key => $field ) : ?>
                                    <?php 
                                    $field['custom_attributes']['ng-model'] = 'order.billing_address.'.$key;
                                    if($key == 'billing_country'){
                                        $field['custom_attributes']['ng-change'] = 'getWoocommerceCountryState("billing_address", "billing_country", "billing_state")';
                                    }
                                    if($field['required'] == 1){
                                        $field['custom_attributes']['data-field_required'] = __($field['label'] . ' is required');
                                    }
                                    $field_value = '';
                                    if(isset($userMeta[$key])){
                                        $field_value = $userMeta[$key][0];
                                    }
                                    else{
                                        if($key == 'billing_first_name'){
                                            $field_value = ($current_user->user_firstname != '') ? $current_user->user_firstname : '';
                                        }
                                        if($key == 'billing_last_name'){
                                            $field_value = ($current_user->user_lastname != '') ? $current_user->user_lastname : '';
                                        }
                                        if($key == 'billing_email'){
                                            $field_value = ($current_user->user_email != '') ? $current_user->user_email : '';
                                            if(!empty($field_value)){
                                                $field['custom_attributes']['readonly'] = 'true';
                                            }
                                        }
                                    }
                                    woocommerce_form_field( $key, $field, $field_value );
                                endforeach; ?>
                                <?php do_action( "woocommerce_after_edit_address_form_{$load_address}" ); ?>
                            </form>
                        </div><?php
                }
            }
        }
    }

    public function get_checkout_page_shipping_block(){
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            $event_id = event_m_get_param('event_id');
            if(!empty($event_id)){
                $products = $this->load_event_product($event_id);
                if(!empty($products)){
                    // get the user meta
                    $userMeta = get_user_meta(get_current_user_id());
                    $current_user = wp_get_current_user();
                    // get the form fields
                    $countries = new WC_Countries();
                    $shipping_fields = $countries->get_address_fields( '', 'shipping_' );
                    $load_address = 'shipping';
                    $page_title   = __( 'Shipping Address', 'eventprime-event-woocommerce-integration' );?>
                    <div class="ep-woocommerce-shipping-address ep-woocommerce-address-form difl">
                        <form action="/my-account/edit-address/shipping/" id="woocommerce-shipping-address" class="edit-account" method="post">
                            <div class="ep-woocommerce_form_heading"><?php echo apply_filters( 'woocommerce_my_account_edit_address_title', $page_title ); ?></div>
                            <div class="em-pdate-shipping-address-block">
                                <div class="em-pdate-shipping-address-row dbfl">
                                    <label>
                                    <input type="radio" name="address_option" ng-model="order.shipping_address.address_option" value="same">
                                    <?php esc_html_e('Same as Billing Address', 'eventprime-event-woocommerce-integration');?>
                                    </label>
                                </div>
                                <div class="em-pdate-shipping-address-row dbfl">
                                   <label>
                                    <input type="radio" name="address_option" ng-model="order.shipping_address.address_option" value="diff">
                                    <?php esc_html_e('Different from Billing Address', 'eventprime-event-woocommerce-integration');?>
                                  </label>
                                </div>
                            </div>
                            <div class="em-order-shipping-address-block" ng-show="order.shipping_address.address_option == 'diff'">
                                <div class="ep-form_errors">
                                    <div class="emfield_error" ng-repeat="error in shippingErrors">
                                        <span><span class="material-icons">error_outline</span>{{error}}</span>
                                    </div>
                                </div>
                                <?php do_action( "woocommerce_before_edit_address_form_{$load_address}" ); ?>
                                <?php foreach ( $shipping_fields as $key => $field ) : ?>
                                    <?php 
                                    $field['custom_attributes']['ng-model'] = 'order.shipping_address.'.$key;
                                    if($key == 'shipping_country'){
                                        $field['custom_attributes']['ng-change'] = 'getWoocommerceCountryState("shipping_address", "shipping_country", "shipping_state")';
                                    }
                                    if($field['required'] == 1){
                                        $field['custom_attributes']['data-field_required'] = __($field['label'] . ' is required');
                                    }
                                    $field_value = '';
                                    if(isset($userMeta[$key])){
                                        $field_value = $userMeta[$key][0];
                                    }
                                    else{
                                        if($key == 'shipping_first_name'){
                                            $field_value = ( $current_user->user_firstname != '' ) ? $current_user->user_firstname : '';
                                        }
                                        if($key == 'shipping_last_name'){
                                            $field_value = ( $current_user->user_lastname != '' ) ? $current_user->user_lastname : '';
                                        }
                                        if($key == 'shipping_email'){
                                            $field_value = $current_user->user_email ;
                                            if(!empty($field_value)){
                                                $field['custom_attributes']['readonly'] = 'true';
                                            }
                                        }
                                    }
                                    woocommerce_form_field( $key, $field, $field_value );?>
                                <?php endforeach; ?>
                                <?php do_action( "woocommerce_after_edit_address_form_{$load_address}" ); ?>
                            </div>
                        </form>
                    </div></div><?php
                }
            }
        }
    }

    public function get_booking_page_select_option_popup(){
        $content = '';
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            $event_id = event_m_get_param('event_id');
            $product_id = event_m_get_param('product_id');
            if(!empty($event_id) && !empty($product_id)){
                $product = wc_get_product($product_id);
                if(!empty($product)){
                    $product_price = $product->get_price();
                    $available_variations = $product->get_available_variations();
                    $variations_json = wp_json_encode( $available_variations );
                    $variations_attr = function_exists( 'wc_esc_json' ) ? wc_esc_json( $variations_json ) : _wp_specialchars( $variations_json, ENT_QUOTES, 'UTF-8', true );
                    $currency_symbol = em_currency_symbol();
                    $min_price = $product->get_variation_price('min');
                    $max_price = $product->get_variation_price('max');
                    $price_range = $currency_symbol.$min_price.' - '.$currency_symbol.$max_price;
                    $available_filters = array();
                    $content .= '<div class="ep-woocommerce-product-option-popup" id="ep-woocommerce-product-option-popup-model" data-event_id="'.$event_id.'" data-currency_symbol="'.$currency_symbol.'" data-product_id="'.$product_id.'" data-final_price="'.$product_price.'" data-product_variations="'.$variations_attr.'">';
                         $content .= '<div class="ep-product-popup-overlay"> </div>';   
                    $content .= '<div class="ep-product-option-popup-content">';       
                            $content .= '<div class="ep-product-popup-header">';
                                $content .= '<span class="ep-product-popup-close">&times;</span>';
                            $content .= '</div>';
                            $content .= '<div class="ep-product-popup-body">';
                                $content .= '<div class="ep-product-popup-left">';
                                    $content .= '<div class="ep-product-image">';
                                        $content .= $product->get_image(array(300, 300));
                                    $content .= '</div>';
                                $content .= '</div>';
                                $content .= '<div class="ep-product-popup-right">';
                                    $content .= '<div class="ep-product-name">'.$product->get_name().'</div>';
                                    $content .= '<div class="ep-product-price-range">'.$price_range.'</div>';
                                    $content .= '<div class="ep-product-variation-block">';
                                        foreach( $product->get_attributes() as $attr_name => $attr ){
                                            $available_filters[$attr_name] = array();
                                            $attr_label = wc_attribute_label($attr_name);
                                            $content .= '<div class="ep-product-variation-block-left">'.wc_attribute_label($attr_name).'</div>';
                                            $content .= '<div class="ep-product-variation-block-right">';
                                                $content .= '<select class="ep-product-variation-select" id="'.$attr_name.'" data-attr="attribute_'.$attr_name.'" data-attr_label="'.$attr_label.'">';
                                                    $content .= '<option value="">'.__('Select', 'eventprime-event-woocommerce-integration') . ' ' . $attr_label . '</option>';
                                                    foreach( $attr->get_terms() as $term ){
                                                        $content .= '<option value="'.$term->slug.'">'.$term->name.'</option>';
                                                        $available_filters[$attr_name][$term->slug] = $term->name;
                                                    }
                                                $content .= '</select>';
                                            $content .= '</div>';
                                        }
                                        $content .= '<div class="ep-product-variation-error" data-error_msg="'.__('Please Select', 'eventprime-event-woocommerce-integration').'"></div>';
                                        $content .= '<button type="button" class="ep-product-variation-block-submit" variation_id="">'.__('Submit', 'eventprime-event-woocommerce-integration').'</button>';
                                        $available_filters = wp_json_encode( $available_filters );
                                        $available_filters = function_exists( 'wc_esc_json' ) ? wc_esc_json( $available_filters ) : _wp_specialchars( $available_filters, ENT_QUOTES, 'UTF-8', true );
                                        $content .= '<div class="ep-woocommerce-product-available-filters" data-available_filters="'.$available_filters.'">';
                                        $content .= '<div class="em_progress_screen ep-progress-loader" id="ep-woocommerce-product-loader-'.$event_id.'" style="display:none;"></div>';
                                    $content .= '</div>';
                                $content .= '</div>';
                            $content .= '</div>';
                        $content .= '</div>';
                    $content .= '</div>';
                    $content .= '<script type="text/javascript">
                                    $(".ep-product-popup-close").click(function(){
                                      var modal = $("#ep-woocommerce-option-popup-model");
                                      modal.hide();
                                      $("#ep-woocommerce-option-popup-model").remove();
                                    });
                                    $(".ep-product-variation-select").change(function(){
                                        var id = this.id;
                                        var select_attr = $(this).data("attr");
                                        var select_attr_val = $(this).val();
                                        var vardata = $("#ep-woocommerce-product-option-popup-model").data("product_variations");
                                        var vardatastr = JSON.parse(JSON.stringify(vardata));
                                        var currency_symbol = $("#ep-woocommerce-product-option-popup-model").data("currency_symbol");
                                        var attr_var = [];
                                        var available_filters = JSON.parse(JSON.stringify($(".ep-woocommerce-product-available-filters").data("available_filters")));
                                        var crossed = 0;
                                        var selected_data = [];
                                        var variation_index = -1;
                                        $(".ep-product-variation-select").each(function(){
                                            var data_attr = $(this).data("attr");
                                            var data_value = $(this).val();
                                            if(data_attr == select_attr){
                                                crossed = 1;
                                                selected_data[data_attr] = data_value;
                                                $.each(vardatastr, function(index, item){
                                                    $.each(item.attributes, function(idx, itemdata){
                                                        if(selected_data[idx] != "undefined"){
                                                            if(selected_data[idx] == itemdata){
                                                                variation_index = index;
                                                                return false;
                                                            }
                                                            else{
                                                                variation_index = -1;
                                                            }
                                                        }
                                                    });
                                                    if(variation_index > -1){
                                                        return false;
                                                    }
                                                });
                                                if(variation_index > -1){
                                                    if(vardatastr[variation_index]){
                                                        var final_data = vardatastr[variation_index];
                                                        $(".ep-product-price-range").html(currency_symbol+final_data.display_price);
                                                        $(".ep-product-image img").attr("src", final_data.image.thumb_src);
                                                        $(".ep-product-image img").attr("srcset", final_data.image.srcset);
                                                        $(".ep-product-variation-block-submit").attr("variation_id", final_data.variation_id);
                                                        $("#ep-woocommerce-product-option-popup-model").attr("data-final_price", final_data.display_price);
                                                    }
                                                }
                                            }
                                            else if(crossed == 0){
                                                selected_data[data_attr] = data_value;
                                            }
                                            else{
                                                var next_option = vardatastr[variation_index].attributes;
                                                var next_option_val = next_option[data_attr];
                                                var attrid = data_attr.replace("attribute_", "");
                                                $("#"+attrid).val("");
                                                if(next_option_val != ""){
                                                    $("#"+attrid + " option").each(function(){
                                                        var opval = $(this).val();
                                                        if(opval != "" && opval != next_option_val){
                                                            $(this).remove();
                                                        }
                                                    });
                                                }
                                                else{
                                                    $.each(available_filters[attrid], function(fid, fval){
                                                        if($("#"+attrid + " option[value="+fid+"]").length < 1){
                                                            $("#"+attrid).append(new Option(fval, fid))
                                                        }
                                                    });
                                                }
                                            }
                                        });
                                    });
                                    $(".ep-product-variation-block-submit").click(function(){
                                        var em_event_id = $("#ep-woocommerce-product-option-popup-model").data("event_id");
                                        var em_product_id = $("#ep-woocommerce-product-option-popup-model").data("product_id");
                                        $("#ep-woocommerce-product-loader-"+em_event_id).show();
                                        var currency_symbol = $("#ep-woocommerce-product-option-popup-model").data("currency_symbol");
                                        var all_attribute_data = {};
                                        var is_error = 0;
                                        $(".ep-product-variation-error").html("");
                                        var error_msg = $(".ep-product-variation-error").data("error_msg");
                                        $(".ep-product-variation-select").each(function(){
                                            var last_val = $(this).val();
                                            var last_label = $(this).data("attr_label");
                                            var last_attr = $(this).data("attr");
                                            if(last_val == ""){
                                                is_error = 1;
                                                error_msg = error_msg + " " + last_label;
                                                return false;  
                                            }
                                            else{
                                                all_attribute_data[last_attr] = {"label" : last_label, "value" : last_val};
                                            }
                                        });
                                        if(is_error == 1){
                                            $(".ep-product-variation-error").html(error_msg);
                                            return false;
                                        }
                                        else{
                                            var last_html = "";
                                            var variation_submit_id = $(".ep-product-variation-block-submit").attr("variation_id");
                                            var last_attr_data = [];
                                            var attr_arr = {};
                                            var att_id = 0;
                                            $.each(all_attribute_data, function(attrid, valueid){
                                                if(last_html != ""){
                                                    last_html += "<br>";
                                                }
                                                last_html += "<span>" + valueid.label + " : " + valueid.value + "</span>";
                                                attr_arr = {"id" : att_id, "variation_id" : variation_submit_id, "attribute" : attrid, "value" : valueid.value, "product_id" : em_product_id, "attr_label": valueid.label, "attr_value": valueid.value};
                                                last_attr_data.push(attr_arr);
                                                att_id++;
                                            });                                            
                                            $("#ep-woocommerce-option-popup-model").html(last_html);
                                            var final_product_price = $("#ep-woocommerce-product-option-popup-model").data("final_price");
                                            $("#ep-woo-product-price-"+em_product_id).html(currency_symbol+final_product_price);
                                            if(variation_submit_id){
                                                var var_input = $("#ep_product_variation_id");
                                                var_input.val(JSON.stringify(last_attr_data));
                                                var_input.trigger("input");
                                                // variation price
                                                var selected_variation_price = $("#ep_product_variation_price");
                                                selected_variation_price.val(JSON.stringify(final_product_price));
                                                selected_variation_price.trigger("input");
                                            }                                           
                                            $(".ep-choose-woo-btn").hide();
                                        }
                                        $("#ep-woocommerce-product-loader-"+em_event_id).hide();
                                        var modal = $("#ep-woocommerce-product-option-popup-model");
                                        modal.hide();
                                    });
                                    $(".ep-product-popup-close").on("click", function() {
                                        var modal = $("#ep-woocommerce-product-option-popup-model"); 
                                        modal.hide();
                                    });
                                </script>';
                }
            }
        }
        return $content; 
    }

    public function add_new_woocommerce_order($booking){
        if(isset($booking->order_info['woocommerce_products']) && !empty($booking->order_info['woocommerce_products'])){
            $order = wc_create_order();
            $price = $booking->order_info['item_price'] * $booking->order_info['quantity'];
            $woocommerce_products = $booking->order_info['woocommerce_products'];
            foreach ($woocommerce_products as $key => $value) {
                $prod_id = $value->id;
                if(isset($value->variation) && !empty($value->variation)){
                    $prod_variation = json_decode($value->variation);
                    if(!empty($prod_variation)){
                        $args = array();$variation_id = '';
                        foreach ($prod_variation as $pvars){                            
                            if($pvars->product_id == $prod_id){
                                $args[$pvars->attribute] = $pvars->value;
                                $variation_id = $pvars->id;
                            }
                        }
                        if(!empty($variation_id)){
                            $varProduct = new WC_Product_Variation($variation_id);
                            $order->add_product($varProduct, $value->qty, $args);
                        }                        
                    }
                }
                else{
                    $order->add_product(get_product($prod_id), $value->qty);
                }
                $price += $value->sub_total;
            }
            $billing_address = $shipping_address = array();
            if(isset($booking->order_info['billing_address']) && !empty($booking->order_info['billing_address'])){
                foreach ($booking->order_info['billing_address'] as $key => $value) {
                    // update user billing meta
                    update_user_meta( get_current_user_id(), $key, $value );
                    $keyname = str_replace("billing_", '', $key);
                    $billing_address[$keyname] = $value;
                }
            }
            if(isset($booking->order_info['shipping_address']) && !empty($booking->order_info['shipping_address'])){
                foreach ($booking->order_info['shipping_address'] as $key => $value) {
                    // update user billing meta
                    update_user_meta( get_current_user_id(), $key, $value );
                    $keyname = str_replace("shipping_", '', $key);
                    $shipping_address[$keyname] = $value;
                }
            }
            $order->set_address($billing_address,'billing');
            $order->set_address($shipping_address,'shipping');
            $order->set_payment_method($booking->order_info['payment_gateway']);
            $order->update_status('pending');
            $order->set_customer_ip_address(WC_Geolocation::get_ip_address()); 
            $order->set_customer_user_agent(wc_get_user_agent());
            //$order->calculate_totals();
            $order->set_total($price);
            // event prime booking id
            $order->update_meta_data( 'em_booking_id', $booking->id );
            $order->save();
            $order_id = $order->get_id();
            // save order id in ep booking order info
            $ep_order_info = $booking->order_info;
            $ep_order_info['woocommerce_order_id'] = $order_id;
            em_update_post_meta($booking->id, 'order_info', $ep_order_info);
        }
    }
    
    public function front_user_booking_item_details($booking) {
        if(!empty($booking) && !empty($booking->id) && !empty($booking->order_info['woocommerce_products'])){
            $woocommerce_products = $booking->order_info['woocommerce_products'];?>
            <tr> 
                <td colspan="4" class="ep-booking-items-w" style="padding: 40px 0px 0px 0px;">
                    <div class="ep-booking-items-title">
                        <?php _e('Product Details','eventprime-event-woocommerce-integration'); ?>
                    </div>
                    <table border="0" cellspacing="0" cellpadding="0" class="ep-booking-items-table" style="border-collapse: collapse;  table-layout: fixed;">
                        <thead>
                            <tr class="booking-details-border">
                                <th class="ep-booking-item" style="width: 55%;">
                                    <?php esc_html_e('Name', 'eventprime-event-calendar-management');?>
                                </th>
                                <th class="ep-booking-item" style="width: 15%;">
                                    <?php esc_html_e('Price', 'eventprime-event-calendar-management');?>
                                </th>
                                <th class="ep-booking-item" style="width: 15%;text-align:center;">
                                    <?php esc_html_e('Quantity', 'eventprime-event-calendar-management');?>
                                </th>
                                <th class="ep-booking-item" style="width: 20%;">
                                    <?php esc_html_e('Total', 'eventprime-event-calendar-management');?>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach($woocommerce_products as $woo){?>
                                <tr style="border-bottom: 1px solid #e7e8e9;">
                                    <td class="ep-booking-item" style="text-align: left"><?php echo $woo->name; ?></td>
                                    <td class="ep-booking-item">
                                        <?php echo em_price_with_position($woo->price, $booking->order_info['currency']); ?></td>
                                    <td class="ep-booking-item"><?php echo $woo->qty; ?></td>
                                    <td class="ep-booking-item">
                                        <?php 
                                        $subTotal = $woo->price * $woo->qty;
                                        echo em_price_with_position($subTotal, $booking->order_info['currency']); ?></td>
                                    </td>
                                </tr><?php
                            }?>
                        </tbody>
                    </table>
                </td>
            </tr><?php
        }
    }
    
    public function admin_booking_show_custom_data($booking_id) {
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration) && !empty($booking_id)){
            $booking_service = EventM_Factory::get_service('EventM_Booking_Service');
            $booking = $booking_service->load_model_from_db($booking_id);
            if(isset($booking->order_info['woocommerce_products']) && !empty($booking->order_info['woocommerce_products'])){
                $woocommerce_products = $booking->order_info['woocommerce_products'];?>
                <div class="ep-woocommerce-admin-booking-detail">
                    <h2><?php _e('Product Detail', 'eventprime-event-woocommerce-integration');?></h2>
                    <table class="ep-woocommerce-admin-booking-detail-table">
                        <thead>
                            <tr>
                                <th><?php _e('Image', 'eventprime-event-woocommerce-integration');?></th>
                                <th><?php _e('Name', 'eventprime-event-woocommerce-integration');?></th>
                                <th><?php _e('Quantity', 'eventprime-event-woocommerce-integration');?></th>
                                <th><?php _e('Price', 'eventprime-event-woocommerce-integration');?></th>
                            </tr>
                        </thead><?php
                        foreach($woocommerce_products as $woo){?>
                            <tr>
                                <td><?php echo $woo->image;?></td>
                                <td><?php echo $woo->name;?></td>
                                <td><?php echo $woo->qty;?></td>
                                <td><?php echo em_currency_symbol() . $woo->price;?></td>
                            </tr>
                            <?php
                        }?>
                    </table>
                </div><?php
            }
        }
    }

    public function reset_booking_page_product_block(){
        $content = '';
        $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
        if(!empty($allow_woocommerce_integration)){
            $event_id = event_m_get_param('event_id');
            if(!empty($event_id)){
                $products = $this->load_event_product($event_id);
                if(!empty($products)){
                    $currency_symbol = em_currency_symbol();
                    $content .= '<table class="ep-product-info-table">';
                        $content .= '<thead><tr>';
                            $content .= '<th>'.__('Image', 'eventprime-event-woocommerce-integration').'</th>';
                            $content .= '<th>'.__('Name', 'eventprime-event-woocommerce-integration').'</th>';
                            $content .= '<th>'.__('Quantity', 'eventprime-event-woocommerce-integration').'</th>';
                            $content .= '<th>'.__('Price', 'eventprime-event-woocommerce-integration').'</th>';
                            $content .= '<th class="pmth" style="display:none;"></th>';
                        $content .= '</tr></thead>';
                        $content .= '<tbody>';
                            foreach ($products as $productid => $value) {
                                $content .= '<tr class="ep-product-info-table-rows">';
                                    $content .= '<td>'.$value['image'].'</td>';
                                    $content .= '<td>'.$value['name'].'<br/>';
                                    if($value['type'] == 'variable'){
                                        $content .= '<a  class="ep-choose-woo-btn" data-pid="'.$productid.'" data-event-id="'.$event_id.'" onclick="ep_woo_select_option(this)">'.__('Select Options', 'eventprime-event-woocommerce-integration').'</a>';
                                        $content .= '<div id="ep-woocommerce-option-popup-model"></div>';
                                        $content .= '<input type="text" id="ep_product_variation_id" ng-model="ep_product_variation_id['.$productid.']" name="ep_product_variation_id['.$productid.']" style="display:none;" />';
                                        $content .= '<input type="text" id="ep_product_variation_price" ng-model="ep_product_variation_price['.$productid.']" name="ep_product_variation_price['.$productid.']" style="display:none;" />';
                                    }
                                    $content .= '</td>';
                                    $content .= '<td>';
                                        if(!empty($value['purchase_mendatory'])){
                                            $content .= '<input type="number" min="1" ng-init="ep_product_quantity['.$productid.']=1" name="ep_product_quantity['.$productid.']" ng-model="ep_product_quantity['.$productid.']" />';
                                        }
                                        else{
                                            $content .= '<input type="number" min="0" ng-init="ep_product_quantity['.$productid.']=1" name="ep_product_quantity['.$productid.']" ng-model="ep_product_quantity['.$productid.']" />';
                                        }
                                    $content .= '</td>';
                                    $content .= '<td id="ep-woo-product-price-'.$productid.'">'.$currency_symbol.$value['price'].'</td>';
                                    if(empty($value['purchase_mendatory'])){
                                        $content .= '<script type="text/javascript">
                                            jQuery(".pmth").show();
                                        </script>';
                                        $content .= '<td><a type="button" title="'.__('Remove', 'eventprime-event-woocommerce-integration').'" class="remove_product" data-pid="'.$productid.'" ng-click="removeBookingProduct('.$productid.')">X</a></td>';
                                    }else {$content .= '<td></td>';}
                                $content .= '</tr>';
                            }
                        $content .= '</tbody>';
                    $content .= '</table>';
                }
            }
        }
        return $content;
    }
}
EventM_Woocommerce_Integration_Service::get_instance();
