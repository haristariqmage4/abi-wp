<?php
/**
 * Plugin Name: EventPrime Woocommerce Integration
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that allows you to add optional and/ or mandatory products to your events. You can define quantity or let users chose it themselves. Fully integrates with EventPrime checkout experience and WooCommerce order management.
 * Version: 1.0.4
 * Author: EventPrime
 * Text Domain: eventprime-woocommerce-integration
 * Domain Path: /languages
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 6.1.1
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_Woocommerce_Integration')) {

    final class EM_Woocommerce_Integration {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.0.4';

        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;

        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }
        /**
         * Event_Magic Constructor.
         */
        private function __construct() {
            $this->define_constants();
            $this->load_textdomain();
            $this->includes(); 
            $this->define_hooks();
            $em = event_magic_instance();
            array_push($em->extensions,'woocommerce_integration');
        }
        
        public function define_constants(){
            $em= event_magic_instance();
            $em->define('EMWI_BASE_URL', plugin_dir_url(__FILE__));
            define('EMWI_VERSION', $this->version);
        }

        public function load_textdomain(){
            load_plugin_textdomain('eventprime-event-woocommerce-integration', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }
        
        public function includes(){
            include_once('includes/models/class-emwi-global-settings.php');
            include_once('includes/dao/class-emwi-global-settings.php');
            include_once('includes/services/class-woocommerce-integration.php');
            if(is_admin()){
                include('includes/admin/class-admin.php');
            }
        }
        
        public function define_hooks(){
            add_action('init', array($this,'event_woocommerce_integration_register_session'));
            add_action('wp_enqueue_scripts',array($this,'event_magic_enqueue_style_and_scripts'));
            // global settings
            add_action('event_magic_gs_settings',array($this,'event_woocommerce_integration_gs_settings'));
            add_action('event_magic_gs_popup',array($this,'event_woocommerce_integration_gs_settings_form'));
            add_action('em_after_gs_save',array($this,'event_woocommerce_integration_gs_settings_save'));
            add_filter('em_load_gs_ext_options',array($this,'event_woocommerce_integration_get_options'), 99, 1);
            add_filter('event_magic_gs_get_model',array($this,'event_woocommerce_integration_get_options'), 99, 1);
            // event deshboard
            add_filter('eventprime_load_post_response', array($this,'event_woocommerce_integration_load_into_post_response_model'),10,2);
            add_filter('eventprime_load_into_event_model', array($this,'load_event_woocommerce_integration_parameters'),10,2);
            // event front calendar popup
            //add_action('event_magic_popup_custom_data', array($this,'event_woocommerce_integration_popup_render'));
            // front calendar view
            //add_filter('event_magic_popup_custom_data_before_footer_filter', array( $this, 'event_woocommerce_integration_popup_render_filter'), 99, 2);
            add_action('event_magic_popup_custom_data_before_footer', array( $this, 'event_woocommerce_integration_popup_render'), 99, 1);
            add_action('em_event_popup_data_scripts', array($this, 'event_woocommerce_integration_popup_data_scripts'));
            // card, masonry, slider view
            //add_action('event_magic_front_views_before_description_end', array($this,'event_woocommerce_integration_popup_render'));
            
            add_action('wp_ajax_em_popup_view_woocommerce_products', array($this, 'event_woocommerce_integration_popup_request'));
            add_action('wp_ajax_nopriv_em_popup_view_woocommerce_products', array($this, 'event_woocommerce_integration_popup_request'));
            // single event page
            add_filter('event_magic_single_event_ticket_price',array($this,'event_woocommerce_integration_single_event_ticket_price'), 99, 2);
            add_action('event_magic_woocommerce_integration_event_detail', array($this, 'event_woocommerce_integration_event_product_detail'));
            // booking page
            add_action('event_magic_additional_fields',array($this,'event_woocommerce_integration_booking_page_product_block'));
            add_action('wp_ajax_em_woocommerce_select_option_popup',array($this,'event_woocommerce_integration_select_option_popup'));
            add_action('wp_ajax_nopriv_em_woocommerce_select_option_popup',array($this,'event_woocommerce_integration_select_option_popup'));
            add_filter('event_magic_update_order_info_data',array($this,'event_woocommerce_update_order_info_data'), 99, 2);
            // checkout page
            add_action('wp_ajax_em_get_woocommerce_event_cart_product', array($this, 'event_woocommerce_integration_get_event_cart_product'));
            add_action('wp_ajax_nopriv_em_get_woocommerce_event_cart_product', array($this, 'event_woocommerce_integration_get_event_cart_product'));
            
            add_action('wp_ajax_em_get_woocommerce_state_by_country_code', array($this, 'event_woocommerce_integration_get_woocommerce_state_by_country_code'));
            add_action('wp_ajax_nopriv_em_get_woocommerce_state_by_country_code', array($this, 'event_woocommerce_integration_get_woocommerce_state_by_country_code'));
            
            add_action('event_magic_front_checkout_data_view',array($this,'event_woocommerce_integration_front_checkout_data_view'));

            // remove product from cart on delete tmp booking
            add_action('event_magic_remove_booking_associated_data',array($this,'event_woocommerce_integration_remove_booking_associated_data'));

            // offline payment filter
            add_filter('event_magic_add_offline_payment_response', array($this, 'event_woocommerce_integration_add_offline_payment_response'), 99, 2);
            // without payment filter
            add_filter('event_magic_add_without_payment_response', array($this, 'event_woocommerce_integration_add_without_payment_response'), 99, 2);
            // stripe payment filter
            add_filter('event_magic_add_stripe_payment_response', array($this, 'event_woocommerce_integration_add_stripe_payment_response'), 99, 2);
            // action on paypal data verification
            add_filter('event_magic_paypal_data_verify_booking', array($this, 'event_woocommerce_integration_data_verify_booking'), 99, 2);
            // confirm booking order info
            add_filter('event_magic_add_booking_order_info', array($this, 'event_woocommerce_integration_add_booking_order_info'), 99, 2);
            // add new woocommerce order
            add_action('event_magic_automatic_recurrence_booking', array($this, 'event_woocommerce_integration_add_new_woocommerce_order'), 10, 1);
            // user profile
            add_action('event_magic_front_user_booking_before_total_price', array($this, 'event_woocommerce_integration_front_user_booking_item_details'), 10, 1);            
            add_filter('event_magic_booking_get_final_price', array($this, 'event_woocommerce_integration_booking_get_final_price'), 99, 2);
            // admin attendee section
            add_action('event_magic_admin_booking_show_custom_data', array($this, 'event_woocommerce_integration_admin_booking_show_custom_data'), 10, 1);
            // update booking amount received data for view attendee booking
            add_filter('event_magic_view_attendee_amount_received', array($this, 'event_woocommerce_integration_view_attendee_amount_received'), 99, 2);
            // update booking amount due data for view attendee booking
            add_filter('event_magic_view_attendee_amount_due', array($this, 'event_woocommerce_integration_view_attendee_amount_due'), 99, 2);

            //reset product on booking page
            add_action('wp_ajax_em_reset_woo_products_booking_page',array($this,'event_woocommerce_integration_reset_woo_products_booking_page'));
            add_action('wp_ajax_nopriv_em_reset_woo_products_booking_page', array($this, 'event_woocommerce_integration_reset_woo_products_booking_page'));
        }

        function event_woocommerce_integration_register_session(){
            if(!session_id())
                session_start();

            // check EventPrime and WooCommerce currency
            $this->check_woo_ep_currency();
        }

        public function check_woo_ep_currency() {
            $currency = em_global_settings('currency');
            $woo_currency = get_option('woocommerce_currency');
            if($currency !== $woo_currency){
                add_action('admin_notices',array($this, 'em_woocommerce_integration_currrency_diff_message'));
            }
        }

        public function em_woocommerce_integration_currrency_diff_message() {?>
            <div class="notice notice-success is-dismissible">
                <p><?php _e( 'Woocommerce Currency is not same with EventPrime Currency. This should be same .', 'eventprime-event-woocommerce-integration' ); ?></p>
            </div><?php
        }

        public function event_magic_enqueue_style_and_scripts() {
            wp_enqueue_script('em-woocommerce-integration-js', EMWI_BASE_URL . 'includes/public/js/em_woocommerce_integration.js', array('em-booking-controller'), EMWI_VERSION);
            wp_localize_script('em-woocommerce-integration-js', 'emwi_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
            wp_enqueue_style('em-woocommerce-integration-css', EMWI_BASE_URL . 'includes/public/css/em_woocommerce_integration.css', false, EMWI_VERSION);
        }

        public function event_woocommerce_integration_gs_settings(){ 
            $all_plugins = apply_filters('active_plugins', get_option('active_plugins'));
            if (stripos(implode($all_plugins), 'woocommerce.php')) {?>
                <a href="javascript:void(0)" class="ep-extension-with-gs" ng-click="enableGlobalService('showEventWoocommerce')"><?php
            }
            else{
                $msg = __('Woocommerce Plugin Not Installed or Activated.', 'eventprime-event-woocommerce-integration');?>
                <a href="javascript:void(0)" ng-click="show_alert_message('<?php echo $msg;?>')"><?php
            }?>
                <div class="em-settings-box">
                    <img class="em-settings-icon" ng-src="<?php echo EMWI_BASE_URL; ?>includes/admin/template/images/ep-woo-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('WooCommerce Integration', 'eventprime-event-woocommerce-integration'); ?></div>
                    <span><?php _e('Sell store products with your events!', 'eventprime-event-woocommerce-integration'); ?></span>
                </div>
            </a> 
            <?php
        }

        public function event_woocommerce_integration_gs_settings_form(){?>
            <div ng-show="showEventWoocommerce">
                <div class="emrow">
                    <div class="emfield"><?php _e('Allow Woocommerce Integration', 'eventprime-event-woocommerce-integration'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" ng-true-value="1" ng-fale-value="0" name="allow_woocommerce_integration"  ng-model="data.options.allow_woocommerce_integration">
                        <div class="emfield_error"></div>
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Allow EventPrime integration with Woocommerce.', 'eventprime-event-woocommerce-integration'); ?>
                    </div>
                </div>
            </div><?php
        }

        public function event_woocommerce_integration_gs_settings_save(){
            $request = EventM_Raw_Request::get_instance();
            $service =  EventM_Factory::get_service('EventM_Setting_Service');
            $model = $request->map_request_to_model('EventMWI_Global_Settings_Model');
            $template = $service->save($model);
        }

        public function event_woocommerce_integration_get_options($options){
            $emwidao = new EventMWI_Global_Settings_DAO();
            $emwimodel = $emwidao->get();
            $options->allow_woocommerce_integration = absint($emwimodel->allow_woocommerce_integration);
            if(isset($options->load_extension_services)){
                $options->load_extension_services[] = 'showEventWoocommerce';
            }
            return $options;
        }

        public function event_woocommerce_integration_load_into_post_response_model($response) {
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $response = $service->load_post_response_model($response);
            return $response;
        }

        public function load_event_woocommerce_integration_parameters($event,$post) {
            $event->selectd_products = metadata_exists('post',$post->ID,'em_selectd_products') ? em_get_post_meta($post->ID,'selectd_products',true) : '';
            $event->enable_product = metadata_exists('post',$post->ID,'em_enable_product') ? absint(em_get_post_meta($post->ID,'enable_product',true)) : 0;
            $event->allow_update_quantity = metadata_exists('post',$post->ID,'em_allow_update_quantity') ? absint(em_get_post_meta($post->ID,'allow_update_quantity',true)) : 0;
            $event->multiply_product_quantity = metadata_exists('post',$post->ID,'em_multiply_product_quantity') ? absint(em_get_post_meta($post->ID,'multiply_product_quantity',true)) : 0;
            $event->display_combined_cost = metadata_exists('post',$post->ID,'em_display_combined_cost') ? absint(em_get_post_meta($post->ID,'display_combined_cost',true)) : 0;
            return $event;
        }

        /*public function event_woocommerce_integration_popup_render_filter($html, $event_model){
            $content = '';
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            if(!empty($allow_woocommerce_integration)){
                $event_service = EventM_Factory::get_service('EventM_Service');
                $event = $event_service->load_model_from_db($event_model->id);
                if(!empty($event->selectd_products)){
                    $content .= '<div class="ep-view-woocommerce-product ep-event-detail-row" id="ep-view-woocommerce-product-'.$event_model->id.'" data-eventid="'.$event_model->id.'" title="'.__('View included product', 'eventprime-event-woocommerce-integration').'" onclick="ep_show_woo_products('.$event_model->id.')"><svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><g><rect fill="none" height="24" width="24"/><path d="M18,6h-2c0-2.21-1.79-4-4-4S8,3.79,8,6H6C4.9,6,4,6.9,4,8v12c0,1.1,0.9,2,2,2h12c1.1,0,2-0.9,2-2V8C20,6.9,19.1,6,18,6z M12,4c1.1,0,2,0.9,2,2h-4C10,4.9,10.9,4,12,4z M18,20H6V8h2v2c0,0.55,0.45,1,1,1s1-0.45,1-1V8h4v2c0,0.55,0.45,1,1,1s1-0.45,1-1V8 h2V20z"/></g></svg><span>'.__('View included product', 'eventprime-event-woocommerce-integration').'</span></div>';
                        
                    $content .= '<div class="em_progress_screen ep-progress-loader" id="ep-woocommerce-product-loader-'.$event_model->id.'" style="display:none;"></div>';
                    //$content .= '</div>';
                    if(isset($event_model->has_popup) && !empty($event_model->has_popup)){
                        $content .= '<script type="text/javascript">
                            jQuery("#ep-view-woocommerce-product-'.$event_model->id.'").click(function(e){
                                e.preventDefault();
                                e.stopPropagation();
                                var thisclicked = this;
                                em_woocommerce_integration_popup_view_products(thisclicked);
                            });
                        </script>';
                    }
                    else{
                        $content .= '<div id="ep-woocommerce-product-popup-viewer-'.$event_model->id.'"></div>';
                    }
                    $html .= $content;
                }
            }
            return $html;
        }*/

        public function event_woocommerce_integration_popup_render($event_model){
            $content = '';
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            if(!empty($allow_woocommerce_integration)){
                $event_service = EventM_Factory::get_service('EventM_Service');
                $event = $event_service->load_model_from_db($event_model->id);
                if(!empty($event->selectd_products)){
                    $content .= '<div class="ep-view-woocommerce-product ep-event-detail-row" id="ep-view-woocommerce-product-'.$event_model->id.'" data-eventid="'.$event_model->id.'" title="'.__('View included product', 'eventprime-event-woocommerce-integration').'" onclick="ep_show_woo_products('.$event_model->id.')"><svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><g><rect fill="none" height="24" width="24"/><path d="M18,6h-2c0-2.21-1.79-4-4-4S8,3.79,8,6H6C4.9,6,4,6.9,4,8v12c0,1.1,0.9,2,2,2h12c1.1,0,2-0.9,2-2V8C20,6.9,19.1,6,18,6z M12,4c1.1,0,2,0.9,2,2h-4C10,4.9,10.9,4,12,4z M18,20H6V8h2v2c0,0.55,0.45,1,1,1s1-0.45,1-1V8h4v2c0,0.55,0.45,1,1,1s1-0.45,1-1V8 h2V20z"/></g></svg><span>'.__('View included product', 'eventprime-event-woocommerce-integration').'</span></div>';
                        
                    $content .= '<div class="em_progress_screen ep-progress-loader" id="ep-woocommerce-product-loader-'.$event_model->id.'" style="display:none;"></div>';
                    //$content .= '</div>';
                    if(isset($event_model->has_popup) && !empty($event_model->has_popup)){
                        $content .= '<script type="text/javascript">
                            jQuery("#ep-view-woocommerce-product-'.$event_model->id.'").click(function(e){
                                e.preventDefault();
                                e.stopPropagation();
                                var thisclicked = this;
                                em_woocommerce_integration_popup_view_products(thisclicked);
                            });
                        </script>';
                    }
                    else{
                        $content .= '<div id="ep-woocommerce-product-popup-viewer-'.$event_model->id.'"></div>';
                    }
                }
            }
            echo $content;
        }

        public function event_woocommerce_integration_popup_data_scripts(){
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            if(!empty($allow_woocommerce_integration)){
                $content = '<script type="text/javascript">
                    function em_woocommerce_integration_popup_view_products(thisclicked){
                        var em_event_id = $(thisclicked).data("eventid");
                        $("#ep-woocommerce-product-loader-"+em_event_id).show();
                        var data = {
                            action: "em_popup_view_woocommerce_products",
                            event_id: em_event_id,
                        };
                        $.post(emwi_ajax_object.ajax_url, data, function(response) {
                            $("#em_calendar").append(response);
                            var modal = $("#ep-woocommerce-product-popup-model");
                            modal.show();
                            $(".ep-product-popup-close").click(function(){
                                modal.hide();
                                $("#ep-woocommerce-product-popup-model").remove();
                            });
                            $("#ep-woocommerce-product-loader-"+em_event_id).hide();
                        });
                    }
                </script>';
                echo $content;
            }
        }

        public function event_woocommerce_integration_popup_request() {
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $event_product = $service->get_event_product_popup_request();
            echo $event_product;die;
        }

        public function event_woocommerce_integration_single_event_ticket_price($ticket_price, $event_id){
            $event_service = EventM_Factory::get_service('EventM_Service');
            $event_model = $event_service->load_model_from_db($event_id);
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $ticket_price = $service->get_single_event_ticket_price($event_model, $ticket_price);
            return $ticket_price;
        }

        // view product button action on event detail page
        public function event_woocommerce_integration_event_product_detail($event_model){
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            if(!empty($allow_woocommerce_integration)){
                $event_service = EventM_Factory::get_service('EventM_Service');
                $event = $event_service->load_model_from_db($event_model->id);
                if(!empty($event->selectd_products)){
                    $content = '';
                    $content .= '<div class="ep-view-woocommerce-product" id="ep-view-woocommerce-product-detail-'.$event_model->id.'" data-eventid="'.$event_model->id.'" title="'.__('View included product', 'eventprime-event-woocommerce-integration').'"><svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><g><rect fill="none" height="24" width="24"/><path d="M18,6h-2c0-2.21-1.79-4-4-4S8,3.79,8,6H6C4.9,6,4,6.9,4,8v12c0,1.1,0.9,2,2,2h12c1.1,0,2-0.9,2-2V8C20,6.9,19.1,6,18,6z M12,4c1.1,0,2,0.9,2,2h-4C10,4.9,10.9,4,12,4z M18,20H6V8h2v2c0,0.55,0.45,1,1,1s1-0.45,1-1V8h4v2c0,0.55,0.45,1,1,1s1-0.45,1-1V8 h2V20z"/></g></svg>'.__('View included product', 'eventprime-event-woocommerce-integration');
                        $content .= '<div class="em_progress_screen ep-progress-loader" id="ep-woocommerce-product-loader-'.$event_model->id.'" style="display:none;"></div>';
                    $content .= '</div>';
                    $content .= '<div id="ep-woocommerce-product-popup-viewer-'.$event_model->id.'"></div>';
                    echo $content;
                }
            }
        }

        public function event_woocommerce_integration_booking_page_product_block(){
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $booking_block = $service->get_booking_page_product_block();
            echo $booking_block;
        }

        public function event_woocommerce_integration_get_event_cart_product(){
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $cart_products = $service->get_event_cart_product();
            echo json_encode($cart_products);
            wp_die();
        }
        
        public function event_woocommerce_integration_get_woocommerce_state_by_country_code(){
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $states = $service->get_woocommerce_state_by_country_code();
            echo json_encode($states);
            wp_die();
        }

        public function event_woocommerce_integration_front_checkout_data_view(){
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $product_block = $service->get_checkout_page_product_block();
            $billing_block = $service->get_checkout_page_billing_block();
            $shipping_block = $service->get_checkout_page_shipping_block();
        }

        public function event_woocommerce_integration_select_option_popup(){
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $option_block = $service->get_booking_page_select_option_popup();
            echo $option_block;
            wp_die();
        }

        public function event_woocommerce_update_order_info_data($order_info, $event_id){
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $order_info = $service->update_event_order_info($order_info, $event_id);
            return $order_info;
        }

        public function event_woocommerce_integration_remove_booking_associated_data($booking){
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $service->remove_tmp_booking_products_from_cart($booking);
        }

        public function event_woocommerce_integration_add_offline_payment_response($offline_response, $orders){
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            if(!empty($allow_woocommerce_integration) && isset($orders[0]->woocommerce_products) && !empty($orders[0]->woocommerce_products)){
                $offline_response['woocommerce_products'] = $orders[0]->woocommerce_products;
                $offline_response['billing_address'] = (isset($orders[0]->billing_address) ? $orders[0]->billing_address : []);
                $offline_response['shipping_address'] = (isset($orders[0]->shipping_address) ? $orders[0]->shipping_address : []);
            }
            /*echo "<pre>";
            print_r($offline_response);die;*/
            return $offline_response;
        }

        public function event_woocommerce_integration_add_without_payment_response($data, $orders){
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            if(!empty($allow_woocommerce_integration) && isset($orders[0]->woocommerce_products) && !empty($orders[0]->woocommerce_products)){
                $data['woocommerce_products'] = $orders[0]->woocommerce_products;
                $data['billing_address'] = (isset($orders[0]->billing_address) ? $orders[0]->billing_address : []);
                $data['shipping_address'] = (isset($orders[0]->shipping_address) ? $orders[0]->shipping_address : []);
            }
            return $data;
        }

        public function event_woocommerce_integration_add_stripe_payment_response($stripe_response, $orders){
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            if(!empty($allow_woocommerce_integration) && isset($orders[0]->woocommerce_products) && !empty($orders[0]->woocommerce_products)){
                $stripe_response['woocommerce_products'] = $orders[0]->woocommerce_products;
                $stripe_response['billing_address'] = (isset($orders[0]->billing_address) ? $orders[0]->billing_address : []);
                $stripe_response['shipping_address'] = (isset($orders[0]->shipping_address) ? $orders[0]->shipping_address : []);
            }
            return $stripe_response;
        }
        
        public function event_woocommerce_integration_data_verify_booking($booking, $all_order_data) {
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            if(!empty($allow_woocommerce_integration)){
                if(!empty($booking) && isset($all_order_data->woocommerce_products) && !empty($all_order_data->woocommerce_products)){
                    $booking->order_info['woocommerce_products'] = $all_order_data->woocommerce_products;
                    $booking->order_info['billing_address'] = (isset($all_order_data->billing_address) ? $all_order_data->billing_address : []);
                    $booking->order_info['shipping_address'] = (isset($all_order_data->shipping_address) ? $all_order_data->shipping_address : []);
                }
            }
            return $booking;
        }

        public function event_woocommerce_integration_add_booking_order_info($order_info, $data){
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            if(!empty($allow_woocommerce_integration) && isset($data['woocommerce_products']) && !empty($data['woocommerce_products'])){
                $order_info['woocommerce_products'] = $data['woocommerce_products'];
                $order_info['billing_address'] = (isset($data['billing_address']) ? $data['billing_address'] : []);
                $order_info['shipping_address'] = (isset($data['shipping_address']) ? $data['shipping_address'] : []);               
            }
            return $order_info;
        }

        public function event_woocommerce_integration_add_new_woocommerce_order($booking){
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $service->add_new_woocommerce_order($booking);
        }
        
        public function event_woocommerce_integration_front_user_booking_item_details($booking){
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $service->front_user_booking_item_details($booking);
        }
        
        public function event_woocommerce_integration_booking_get_final_price($after_discount_price, $order_info) {
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            if(!empty($allow_woocommerce_integration) && !empty($order_info) && isset($order_info['woocommerce_products'])){
                $woocommerce_products = $order_info['woocommerce_products'];
                foreach($woocommerce_products as $woo){
                    $after_discount_price+= $woo->sub_total;
                }
            }
            return $after_discount_price;
        }
        
        public function event_woocommerce_integration_admin_booking_show_custom_data($booking_id) {
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $service->admin_booking_show_custom_data($booking_id);            
        }
        
        public function event_woocommerce_integration_view_attendee_amount_received($amount_received, $booking) {
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            $order_info = $booking->order_info;
            if(!empty($allow_woocommerce_integration) && !empty($order_info) && isset($order_info['woocommerce_products'])){
                $woocommerce_products = $order_info['woocommerce_products'];
                foreach($woocommerce_products as $woo){
                    $amount_received += $woo->sub_total;
                }
            }
            return $amount_received;
        }
        
        public function event_woocommerce_integration_view_attendee_amount_due($amount_due, $booking) {
            $allow_woocommerce_integration = em_global_settings('allow_woocommerce_integration');
            $order_info = $booking->order_info;
            if(!empty($allow_woocommerce_integration) && !empty($order_info) && isset($order_info['woocommerce_products'])){
                $woocommerce_products = $order_info['woocommerce_products'];
                foreach($woocommerce_products as $woo){
                    $amount_due += $woo->sub_total;
                }
            }
            return $amount_due;
        }

        public function event_woocommerce_integration_reset_woo_products_booking_page(){
            $service = EventM_Factory::get_service('EventM_Woocommerce_Integration_Service');
            $booking_block = $service->reset_booking_page_product_block();
            wp_send_json_success($booking_block);
        }
    }
}

function em_woocommerce_integration() {
    return EM_Woocommerce_Integration::instance();
}
function em_woocommerce_integration_checks(){ ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e( 'EventPrime Woocommerce Integration Extension won\'t work as EventPrime plugin is not active/installed.', 'eventprime-event-calendar-management' ); ?></p>
    </div><?php 
}

function em_woocommerce_integration_checks_woocommerce_activation(){ ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e( 'EventPrime Woocommerce Integration Extension won\'t work as Woocommerce plugin is not active/installed.', 'eventprime-event-calendar-management' ); ?></p>
    </div><?php 
    deactivate_plugins( plugin_basename( __FILE__ ) );
}

add_action('plugins_loaded',function(){
    if(!class_exists('Event_Magic')){
        add_action('admin_notices','em_woocommerce_integration_checks');
    }
    $all_plugins = apply_filters('active_plugins', get_option('active_plugins'));
    if(!stripos(implode($all_plugins), 'woocommerce.php')){
        add_action('admin_notices','em_woocommerce_integration_checks_woocommerce_activation');
    }
});
add_action('event_magic_loaded', 'em_woocommerce_integration');
require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_woocommerce_metadata.json',
    __FILE__,
    'eventprime-woocommerce-integration'
);