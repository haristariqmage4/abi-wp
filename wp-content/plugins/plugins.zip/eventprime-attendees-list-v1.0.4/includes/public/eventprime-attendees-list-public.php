<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class EventM_Attendees_List_Public {
    
    private static $instance = null;
    
    private function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueues'));
    }
    
    public static function get_instance() {   
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }
    
    public function enqueues() {
        wp_register_script('em-attendees-list-public', plugin_dir_url(__DIR__) . 'public/js/eventprime-attendees-list-public.js', array('jquery'));
        wp_register_style('em-attendees-list-public', plugin_dir_url(__DIR__) . 'public/css/eventprime-attendees-list-public.css');
    }

}
EventM_Attendees_List_Public::get_instance();