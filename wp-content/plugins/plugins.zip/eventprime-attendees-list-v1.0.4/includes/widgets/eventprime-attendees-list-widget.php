<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EventM_Attendees_List_Widget')) {

    class EventM_Attendees_List_Widget extends WP_Widget {

        function __construct() {
            parent::__construct('eventm_attendees_list', __("EventPrime Attendees List","eventprime-attendees-list"), array('description' => __("Show list of attendees for the selected bookable & published event", 'eventprime-attendees-list')));
        }

        public function widget($args, $instance) {
            $title = apply_filters('widget_title', $instance['title']);
            echo $args['before_widget'];
            if (!empty($title))
                echo $args['before_title'] . $title . $args['after_title'];
            $booking_service = EventM_Factory::get_service('EventM_Booking_Service');
            if (empty($instance['event_id'])) {
                $content = __("No event selected","eventprime-attendees-list");
            } else {
                $booking_args = array(
                    'numberposts' => -1,
                    'post_status'=> 'completed',
                    'post_type'=> 'em_booking',
                    'meta_key' => 'em_event',
                    'meta_value' => $instance['event_id']
                );
                $booking_posts = get_posts($booking_args);
                if (!empty($booking_posts)) {
                    $content = '<ol>';
                    foreach ($booking_posts as $post) {
                        $attendee_names = get_post_meta($post->ID, 'em_attendee_names');
                        $order_info = get_post_meta($post->ID, 'em_order_info');
                        if(!isset($order_info[0]['is_custom_booking_field']) || $order_info[0]['is_custom_booking_field'] == 0){
                            if (!empty($attendee_names)) {
                                foreach($attendee_names[0] as $key => $val) {
                                    echo "<li>".$val."</li>";
                                }
                            }
                        }
                        else{
                            foreach($attendee_names as $attendee_data){
                                foreach ($attendee_data as $alabel => $avalue) {
                                    if(!empty($avalue)){
                                        $name = 0;
                                        foreach($avalue as $label => $value){
                                            if(strpos(strtolower($label), 'name') !== false){
                                                echo "<li>".$value."</li>";
                                                $name = 1;
                                            }
                                        }
                                        // if empty the name fields then show first field value
                                        if( empty( $name ) ) {
                                            $ni = 1;
                                            foreach($avalue as $label => $value){
                                                if( $ni == 1 ){
                                                    if( $value != 'N/A' ) {
                                                        echo "<li>".$value."</li>";
                                                    }
                                                }
                                                $ni++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    $content .= '</ol>';
                } else {
                    $content = __("No confirmed bookings exist for the selected event","eventprime-attendees-list");
                }
            }
            wp_enqueue_script('em-attendees-list-public');
            wp_enqueue_style('em-attendees-list-public');
            ?>
            <div class="em_widget_container">
                <?php echo $content; ?>
            </div>
            <div class="ep-loadMore-wrap dbfl">
                <a href="#" id="ep-load-More">
                    <?php _e("Show More",'eventprime-attendees-list'); ?>
                </a>
            </div>
            <?php
            echo $args['after_widget'];
        }

        /**
         * 
         * Widget Backend
         */
        public function form($instance) {
            if (isset($instance['title'])) {
                $title = $instance['title'];
            } else {
                $title = __("New Title","eventprime-attendees-list");
            }
            $posts = get_posts(array(
                'numberposts'=>-1,
                'post_status'=>'any',
                'post_type'=>'em_event',
                'meta_key'=>'em_enable_booking',
                'meta_value'=>1
            ));
?>
            <p>
                <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('event_id'); ?>"><?php _e('Event','eventprime-attendees-list'); ?>:</label>
                <select id="<?php echo $this->get_field_id('event_id'); ?>" name="<?php echo $this->get_field_name('event_id'); ?>">
                    <option value="0"><?php _e('None','eventprime-attendees-list'); ?></option>
                    <?php if (!empty($posts)) {
                        foreach($posts as $post) {
                            $post_title = $post->post_title.' - '.date_i18n(get_option('date_format'),get_post_meta($post->ID,'em_start_date',true)); ?>
                            <option value="<?php echo esc_attr($post->ID); ?>" <?php if($instance['event_id'] == $post->ID) echo "selected"; ?>><?php echo $post_title; ?></option>
                        <?php }
                    } ?>
                </select>
            </p>
        <?php }

        // Updating widget replacing old instances with new
        public function update($new_instance, $old_instance) {
            $instance = array();
            $instance['title'] = !empty($new_instance['title']) ? strip_tags($new_instance['title']) : '';
            $instance['event_id'] = absint($new_instance['event_id']);
            return $instance;
        }

    }

}

// Register and load the widget
function em_load_attendees_list_widget() {
    register_widget('EventM_Attendees_List_Widget');
}

add_action('widgets_init', 'em_load_attendees_list_widget');