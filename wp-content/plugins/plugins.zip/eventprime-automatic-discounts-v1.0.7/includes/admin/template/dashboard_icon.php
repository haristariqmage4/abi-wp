<div class="ep-grid-icon difl" id="ep-event-earlybird">
    <a href="<?php echo admin_url("/admin.php?page=em_dashboard&tab=earlybird_list&post_id=$post_id"); ?>" class="ep-dash-link">
        <div class="ep-grid-icon-area dbfl">
            <img class="ep-grid-icon dibfl" src="<?php echo EMEBD_BASE_URL.'includes/admin/template/images/event-early-bird-discount-icon.png'; ?>">
        </div>
        <div class="ep-grid-icon-label dbfl"><?php _e('Automatic Discounts', 'eventprime-event-automatic-discounts'); ?></div>
    </a>
</div>