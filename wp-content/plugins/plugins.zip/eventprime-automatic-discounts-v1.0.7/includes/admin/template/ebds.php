<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<div class="kikfyre" ng-app="eventMagicApp" ng-controller="earlyBirdDiscountCtrl" ng-init="initialize('list', '<?php echo $post_id?>')" ng-cloak="">
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>
    <div class="kf-hidden" style="{{requestInProgress ?'display:none':'display:block'}}">
        <!-- Operations bar Starts --> 
        <div class="kf-operationsbar dbfl">
            <div class="kf-titlebar_dark dbfl">
                <div class="kf-title kf-title-1 difl"><?php _e('Automatic Discounts Rules','eventprime-event-automatic-discounts'); ?></div>
            </div>
            <div class="kf-nav dbfl">
                <ul>
                    <li><a ng-href="<?php echo admin_url("/admin.php?page=em_dashboard&tab=earlybird_rule&post_id=$post_id"); ?>"><?php _e('Add New', 'eventprime-event-automatic-discounts'); ?></a></li>
                    <li><button class="em_action_bar_button" ng-click="deleteRules()" ng-disabled="selections.length == 0" ><?php _e('Delete', 'eventprime-event-automatic-discounts'); ?></button></li>
                </ul>
            </div>
        </div>
        <!--  Operations bar Ends -->
        <div class="emagic-table dbfl">
            <table class="kf-etypes-table ep-ebd-table ep-earlybird-table" id="ep-tblLocations"><!-- remove class for default 80% view -->
                <tr>
                    <th class="table-header"></th>
                    <th class="table-header"><input type="checkbox" id="em_bulk_selector" ng-click="checkAll()" ng-model="selectedAll"  ng-checked="selections.length == data.ebds.length"/></th>
                    <th class="table-header"><?php _e('Name', 'eventprime-event-automatic-discounts'); ?></th>
                    <th class="table-header"><?php _e('Rule Type', 'eventprime-event-automatic-discounts'); ?></th>
                    <th class="table-header"><?php _e('Start Date & Time', 'eventprime-event-automatic-discounts'); ?></th>
                    <th class="table-header"><?php _e('End Date & Time', 'eventprime-event-automatic-discounts'); ?></th>
                    <th class="table-header"><?php _e('Bookings', 'eventprime-event-automatic-discounts'); ?></th>
                    <th class="table-header"><?php _e('Seats', 'eventprime-event-automatic-discounts'); ?></th>
                    <th class="table-header"><?php _e('Discount', 'eventprime-event-automatic-discounts'); ?></th>
                    <th class="table-header"><?php _e('Status', 'eventprime-event-automatic-discounts'); ?></th>
                    <th class="table-header"><?php _e('Position', 'eventprime-event-automatic-discounts'); ?></th>
                    <th class="table-header"><?php _e('Action', 'eventprime-event-automatic-discounts'); ?></th>
                </tr>

                <tr ng-repeat="ebd in data.ebds" data-ruleid="{{ebd.id}}">
                    <td class="ep-dotts"><span class="material-icons" ng-if="data.ebds.length > 1">drag_indicator</span></td>
                    <td>
                        <input type="checkbox"  ng-model="ebd.Selected" ng-click="selectEbd(ebd.id)"  ng-true-value="{{ebd.id}}" ng-false-value="0">
                    </td>
                    <td>{{ebd.name}}</td>
                    <td>{{ebd.ebd_rule_type}}</td>
                    <td>{{ebd.ebd_start_date}}</td>
                    <td>{{ebd.ebd_end_date}}</td>
                    <td>{{ebd.no_of_booking}}</td>
                    <td>{{ebd.no_of_seat}}</td>
                    <td>{{ebd.discount}} {{ebd.discount_type}}</td>
                    <td>{{ebd.rule_status}}</td>
                    <td>{{ebd.priority}}</td>
                    <td>
                        <a ng-href="<?php echo admin_url('admin.php?page=em_dashboard&tab=earlybird_rule&post_id='.$post_id); ?>&rule_id={{ebd.id}}"><?php _e('View/Edit', 'eventprime-event-automatic-discounts'); ?></a>
                    </td>
                </tr>
            </table>

            <div class="em_empty_card ep-ebd-notice" ng-show="data.ebds.length == 0">
                <?php _e('The Automatic Discounts Rule you create will appear here in tabular Format. Presently, you do not have any rule created.', 'eventprime-event-automatic-discounts'); ?>
            </div>

        </div>

        <div class="kf-pagination dbfr" ng-show="data.ebds.length != 0"> 
            <ul>
                <li dir-paginate="ebd in data.total_count | itemsPerPage: data.pagination_limit"></li>
            </ul>
            <dir-pagination-controls on-page-change="pageChanged(newPageNumber)"></dir-pagination-controls>
        </div>
    </div>
    <div class="kf_progress_screen" style="display: none;" id="ep-loading-sorting"></div>
    <button type="button" id="ep-ebd-sort" ng-click="ebdSorting()" style="display: none;"></button>
</div>
<script type="text/javascript">
jQuery(function () {
    jQuery("#ep-tblLocations").sortable({
  	items: 'tr:not(tr:first-child)',
  	cursor: 'pointer',
  	axis: 'y',
  	dropOnEmpty: false,
  	start: function (e, ui) {
            ui.item.addClass("selected");
  	},
  	stop: function (e, ui) {
            ui.item.removeClass("selected");
            jQuery("#ep-ebd-sort").trigger('click');
  	}
    });
});
</script>
