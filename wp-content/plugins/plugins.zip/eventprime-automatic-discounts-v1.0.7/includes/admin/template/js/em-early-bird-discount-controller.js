eventMagicApp.controller('earlyBirdDiscountCtrl', function ($scope, $http, TermUtility, EMRequest, PostUtility) {
    $scope.requestInProgress = false;
    $scope.formErrors = [];
    $scope.selections = [];
    $scope.paged = 1;
    $ = jQuery;
    $scope.progressStart= function(){
        $scope.requestInProgress = true;
    }
    $scope.progressStop= function(){
        $scope.requestInProgress = false;
    }
    /*
     * Controller initialization for data load 
     */
    $scope.initialize = function (type, id) {
        if(type == 'list'){
            $scope.prepareListPage(id);
        }
        else if(type == 'edit'){
            $scope.preparePageData(id);
        }
    }

    /**
    * prepare list page
    */
    $scope.prepareListPage = function(id){
        $scope.data = {};
        $scope.data.post_id = id;
        $scope.data.paged = $scope.paged;
        $scope.data.em_request_context = 'admin_early_bird_list_templates';
        $scope.progressStart();
        EMRequest.send('em_load_strings',$scope.data).then(function(response){
            $scope.progressStop();
            var responseBody = response.data;
            if(responseBody.success){
                $scope.data = responseBody.data;
            }
        });
    };

    $scope.preparePageData = function(rule_id){
        $scope.data.paged = $scope.paged;
        $scope.data.rule_id = rule_id;
        $scope.data.em_request_context = 'admin_early_bird_data_templates';
        $scope.progressStart();
        EMRequest.send('em_load_strings',$scope.data).then(function(response){
            $scope.progressStop();
            var responseBody = response.data;
            if(responseBody.success){
                $scope.data = responseBody.data;
                var start_booking_date = responseBody.data.event.ebd_start_booking_date;
                var last_booking_date = responseBody.data.event.ebd_last_booking_date;
                var stDate = new Date(start_booking_date);
                var ltDate = new Date(last_booking_date);
                $("#ebd_start_date").datetimepicker({controlType: 'select',oneLine: true,changeYear: true, minDate: stDate, maxDate: ltDate});
                $("#ebd_end_date").datetimepicker({controlType: 'select',oneLine: true,changeYear: true, minDate: stDate, maxDate: ltDate});
            }
        });
    };

    $scope.saveEbd = function(isValid){
        if(!isValid){
            return;
        }
        $scope.formErrors= [];
        if( $('#description').is(':visible') ) 
            $scope.data.ebd.description = $('#description').val();
        else 
            $scope.data.ebd.description = tinymce.get('description').getContent();

        $scope.data.ebd.event_id = $scope.data.ebds.event_id;
        $scope.progressStart();
        EMRequest.send('em_save_event_ebd', $scope.data.ebd).then(function(response){
            $scope.progressStop();
            var responseBody = response.data;
            if(responseBody.success){
                if(responseBody.data.hasOwnProperty('redirect')){
                    location.href = responseBody.data.redirect;
                }
            }
            else{
                if(responseBody.data.hasOwnProperty('errors')){
                    $scope.formErrors = responseBody.data.errors;
                    jQuery('html, body').animate({ scrollTop: 0 }, 'slow');
                }
            }
        });
    }

    /*
     * Select item
    */
    $scope.selectEbd = function(ebd_id){
        if($scope.selections.indexOf(ebd_id) >= 0)
            $scope.selections = em_remove_from_array($scope.selections,ebd_id);
        else
            $scope.selections.push(ebd_id);
    }

    /*
     * Select all ebd lists
    */
    $scope.checkAll = function () {    
        angular.forEach($scope.data.ebds, function (ebd) {
            if ($scope.selectedAll) { 
                $scope.selections.push(ebd.id);
                ebd.Selected = $scope.selectedAll ? ebd.id : 0; 
            }
            else{
                $scope.selections = [];
                ebd.Selected = 0;
            }
        });
    };

    /*
     * Function to delete rule
    */
    $scope.deleteRules = function(){
        var confirmed = confirm("Do you want to delete this rule ?");
        if(confirmed){
            $scope.data.selections = $scope.selections;
            EMRequest.send('em_delete_event_ebd_rule', $scope.data).then(function(response){
                $scope.progressStop();
                var responseBody = response.data;
                if(responseBody.success){
                    if(responseBody.data.hasOwnProperty('redirect')){
                        location.href = responseBody.data.redirect;
                    }
                }
                else{
                    if(responseBody.data.hasOwnProperty('error')){
                        $scope.formErrors = responseBody.data.errors;
                    }
                }
            });
        } 
    }

    $scope.ebdSorting = function(){
        var ruleids = [];
        $("#ep-tblLocations").find("tr").each(function (index, item) {
            var rlid = $(this).data('ruleid');
            if(rlid){
                ruleids.push(rlid);
            }
        });
        if(ruleids.length > 0){
            $scope.data.rulespositions = ruleids;
            $scope.data.paged = $scope.paged;
            $scope.data.em_request_context = 'admin_early_bird_list_sorting';
            $scope.progressStart();
            EMRequest.send('em_load_strings',$scope.data).then(function(response){
                $scope.progressStop();
                var responseBody = response.data;
                if(responseBody.success){
                    $scope.data = responseBody.data;
                }
            });
        }
    }

    $scope.changeRuleType = function(){
        if($scope.data.ebd.rule_type == 'datetime'){
            $scope.data.ebd.ebd_discount_slogan = 'Hurry, Sale ends on {{end_date}}!';
        }
        if($scope.data.ebd.rule_type == 'booking'){
            $scope.data.ebd.ebd_discount_slogan = 'Hurry, on discount for next {{bookings_left}} bookings!';
        }
        if($scope.data.ebd.rule_type == 'user_role'){
            $scope.data.ebd.ebd_discount_slogan = 'Hurry, {{user_role}}! We’ve special discount for you!';
        }
        if($scope.data.ebd.rule_type == 'seat'){
            $scope.data.ebd.ebd_discount_slogan = '{{free_seats}} tickets free with every booking!';
        }
    }
})
.directive('stringToNumber', function() {
    return {
        require: 'ngModel',
        link: function(scope, element, attrs, ngModel) {
            ngModel.$parsers.push(function(value) {
                return '' + value;
            });
            ngModel.$formatters.push(function(value) {
                return parseFloat(value);
            });
        }
    };
});