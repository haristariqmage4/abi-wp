<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

class EventM_Early_Bird_Discount_DAO extends EventM_Post_Dao
{
    public function __construct() {
        $this->post_type = EM_EBD_POST_TYPE;
    }
    
    public function get($id)
    {
        $post = get_post($id);
        if(empty($post))
            return new EventM_Early_Bird_Discounts_Model(0);
        
        $ebd = new EventM_Early_Bird_Discounts_Model($id);
        $meta = $this->get_meta($id,'',true);
        foreach ($meta as $key => $val) {
            $key = str_replace('em_','',$key);
            if (property_exists($ebd, $key)) {
                $ebd->{$key} = maybe_unserialize($val[0]);
            }
        }
        $ebd->id = $post->ID;
        $ebd->name = $post->post_title;
        $ebd->description = $post->post_content;
        return $ebd;
    }

    public function save($model){
        if($model->discount_type == 'percentage'){
            if($model->discount > 100){
                return new WP_Error( 'broke', __( 'Percentage discount should not be greater then 100','eventprime-event-automatic-discounts' ) );
            }
        }
        if(!empty($model->ebd_start_date)){
            $sdt = strtotime($model->ebd_start_date);
            $model->ebd_start_date = $sdt;
        }
        if(!empty($model->ebd_end_date)){
            $edt = strtotime($model->ebd_end_date);
            $model->ebd_end_date = $edt;
        }
        if(!empty($edt) && !empty($sdt)){
            if($edt < $sdt){
                return new WP_Error( 'broke', __( 'End Date should be greater then Start Date','eventprime-event-automatic-discounts' ) );
            }
        }
        if($model->rule_type == 'datetime'){
            $model->no_of_booking = '';
            $model->rule_user_role = '';
            $model->no_of_seat = '';
        }
        if($model->rule_type == 'booking'){
            $model->ebd_start_date = '';
            $model->ebd_end_date = '';
            $model->rule_user_role = '';
            $model->no_of_seat = '';
        }
        if($model->rule_type == 'user_role'){
            $model->ebd_start_date = '';
            $model->ebd_end_date = '';
            $model->no_of_booking = '';
            $model->no_of_seat = '';
            if(empty($model->rule_user_limit))
                $model->rule_user_limit = 0;
        }
        if($model->rule_type == 'seat'){
            $model->ebd_start_date = '';
            $model->ebd_end_date = '';
            $model->no_of_booking = '';
            if(empty($model->rule_user_limit))
                $model->rule_user_limit = 0;
        }
        $model->is_active = absint($model->is_active);
        $model->priority = absint($model->priority);
        $model->show_on_front = absint($model->show_on_front);
        if(!empty($model->rule_user_limit)){
            $model->rule_user_limit = absint($model->rule_user_limit);
        }
        $model->disable_if_volume_discount = absint($model->disable_if_volume_discount);
        $model->disable_if_coupon_code_discount = absint($model->disable_if_coupon_code_discount);
        //$model->event_id = absint($model->event_id);
        $post_id = parent::save($model);
        /* automatic discount updates for child events */
        $child_events_data = array( 'model' => $model, 'post_id' => $post_id );
        do_action( 'save_child_events_ebd', $child_events_data );
        if ($post_id instanceof WP_Error) {
            return false;
        }
        return $this->get($post_id);
    }

    public function deleteRule($rules){
        $this->check_permission();
        if(!empty($rules) && is_array($rules)){
            foreach ($rules as $id) {
                $postData = get_posts(
                    array(
                        'ID' => $id,
                        'post_type' => $this->post_type,
                        'status' => 'any'
                    )
                );
                if(!empty($postData)) {
                    wp_delete_post($id, true);
                    /* automatic discount deletion for child events */
                    $child_events_data = array( 'rules' => $rules, 'post_id' => $id );
                    do_action( 'delete_child_events_ebd', $child_events_data );
                }
            }
            return 'success';
        }
        return null;
    }

    private function check_permission(){
        if(!em_is_user_admin()){
            $error_msg = __('User not allowed','eventprime-event-automatic-discounts');
            wp_send_json_error(array('errors'=>array($error_msg)));
        }
    }
  
    public function fetchEbdData($ebdData){
        $returnData = $ruleData = array();
        $event_id = absint($ebdData->event_id);
        if(empty($event_id)){
            $returnData['errors'] = __('Invalid Event Id','eventprime-event-automatic-discounts');
            return $returnData; 
        }
        $event_service = EventM_Factory::get_service('EventM_Service');
        $event = $event_service->load_model_from_db($event_id);
        
        $args = array(
            'post_type'      => $this->post_type,
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key'   => 'em_event_id',
                    'value' => $event_id,
                ),
                'em_priority_clause' => array(
                    'key' => 'em_priority',
                ),
            ),
            'orderby' => array(
                'em_priority_clause' => 'ASC',
            ),
            'order' => 'ASC',
        );
        $posts = get_posts($args);        
        if(empty($posts) || count($posts) == 0){
            // check for rules
            $returnData['errors'] = __('No Discount Rules Found','eventprime-event-automatic-discounts');
            return $returnData;
        }
        foreach($posts as $post){
            $is_available = 'false';
            $id = $post->ID;
            $single_rule = new EventM_Early_Bird_Discounts_Model($id);
            $meta = $this->get_meta($id,'',true);
            foreach ($meta as $key => $val) {
                $key = str_replace('em_','',$key);
                if (property_exists($single_rule, $key)) {
                    $single_rule->{$key} = maybe_unserialize($val[0]);
                }
            }
            // check for rule activation
            if(empty($single_rule->is_active)){
                continue;
            }
            // check volume discount condition
            $disable_if_volume_discount = $single_rule->disable_if_volume_discount;
            if(!empty($disable_if_volume_discount)){
                if(!empty($event->allow_discount) && !empty($event->discount_per)){
                    continue;
                }
            }
            if($single_rule->rule_type == 'booking'){
                $is_available = $this->check_booking_type_ebd_rule_uses($id, $single_rule);
            }
            else if($single_rule->rule_type == 'user_role'){
                $rule_user_roles = $single_rule->rule_user_role;
                if(!empty($rule_user_roles)){
                    $user = wp_get_current_user();
                    $curr_user_roles = (array) $user->roles;
                    if(!empty($curr_user_roles)){
                        foreach ($curr_user_roles as $value) {
                            if(in_array($value, $rule_user_roles)){
                                $is_available = 'true';
                                $single_rule->applied_user_role = $value;
                                if($single_rule->rule_user_limit > 0){
                                    $is_available = $this->check_ebd_rule_uses_user_limit($id, $single_rule);
                                }
                            }
                        }
                    }
                }
            }
            else if($single_rule->rule_type == 'seat'){
                $is_available = 'true';
                $rule_user_roles = $single_rule->rule_user_role;
                if(!empty($rule_user_roles)){
                    $is_available = 'false';
                    $user = wp_get_current_user();
                    $curr_user_roles = (array) $user->roles;
                    if(!empty($curr_user_roles)){
                        foreach ($curr_user_roles as $value) {
                            if(in_array($value, $rule_user_roles)){
                                $is_available = 'true';
                                $single_rule->applied_user_role = $value;
                            }
                        }
                    }
                }
            }
            else {
                $rule_start_date = $single_rule->ebd_start_date;
                $rule_end_date = $single_rule->ebd_end_date;
                if($rule_start_date < em_current_time_by_timezone() && $rule_end_date > em_current_time_by_timezone()){
                    $is_available = 'true';
                }
            }
            if($is_available !== 'false'){
                $ruleData['id'] = $id;
                $ruleData['name'] = $post->post_title;
                $ruleData['rule_type'] = $single_rule->rule_type;
                $ruleData['discount'] = $single_rule->discount;
                $ruleData['discount_type'] = $single_rule->discount_type;
                $ruleData['description'] = $post->post_content;
                $ruleData['ebd_discount_slogan'] = $single_rule->ebd_discount_slogan;
                $ruleData['show_on_front'] = $single_rule->show_on_front;
                if($ruleData['rule_type'] == 'booking'){
                    $ruleData['no_of_booking'] = $single_rule->no_of_booking;
                }
                else{
                    $ruleData['start_date'] = $single_rule->ebd_start_date;
                    $ruleData['end_date'] = $single_rule->ebd_end_date;
                }
                $ruleData['disable_if_coupon_code_discount'] = $single_rule->disable_if_coupon_code_discount;
                if(!empty($single_rule->disable_if_coupon_code_discount)){
                    $ruleData['code_message'] = __('An earlier discount was removed since it is not compatible with this coupon', 'eventprime-event-automatic-discounts');
                }
                if(!empty($single_rule->applied_user_role)){
                    $ruleData['applied_user_role'] = $single_rule->applied_user_role;
                }
                if($ruleData['rule_type'] == 'seat'){
                    $ruleData['no_of_seat'] = $single_rule->no_of_seat;
                    if(!empty($single_rule->applied_user_role)){
                        $ruleData['applied_user_role'] = $single_rule->applied_user_role;
                    }
                }
                break;
            }
        }
        $returnData = array("active_rule" => $ruleData);
        return $returnData;
    }
    
    public function check_booking_type_ebd_rule_uses($rule_id, $rule_data) {
        $bookings = array();
        $no_of_uses = 0;
        $args = array(
            'numberposts' => -1,
            'orderby' => 'date',
            'order' => 'DESC'
        );
        if(isset($rule_data->event_id)){
            $args = array(
                'meta_query' => array(
                    array(
                      'key' => em_append_meta_key('event'), 
                      'value' => $rule_data->event_id, 
                      'compare' => '=',
                    )
                ),
            );
        }
        $defaults = array('post_type' => 'em_booking', 'numberposts' => -1, 'orderby' => 'date', 'order' => 'ASC', 'post_status' => 'any');
        $args = wp_parse_args($args, $defaults);
        $posts = get_posts($args);
        if(empty($posts))
          return $no_of_uses;
        foreach($posts as $post){
            $id = $post->ID;
            $booking = new EventM_Booking_Model($id);
            $meta = $this->get_meta($id,'',true);
            if(!empty($meta)){
                foreach ($meta as $key => $val) {
                    $key = str_replace('em_','',$key);
                    if (property_exists($booking, $key)) {
                        $booking->{$key}= maybe_unserialize($val[0]);
                    }
                }
                // if temp booking then not count
                if($booking->booking_tmp_status == 1) {
                    continue;
                }
                if(isset($booking->order_info['applied_ebd']) && !empty($booking->order_info['applied_ebd']) && $booking->order_info['ebd_id'] == $rule_id){
                    ++$no_of_uses;
                }
            }
        }
        if($no_of_uses > 0){
            if($no_of_uses >= $rule_data->no_of_booking){
                return 'false';
            }
        }
        return $no_of_uses;
    }
    
    public function check_ebd_rule_uses_user_limit($rule_id, $rule_data) {
        $bookings = array();
        $no_of_uses = 0;
        $user = wp_get_current_user();
        $args = array(
            'numberposts' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => array(
                array(
                  'key' => em_append_meta_key('user'), 
                  'value' => $user->ID, 
                  'compare' => '=', 
                  'type' => 'NUMERIC,'
                ),
                array(
                  'key' => em_append_meta_key('event'), 
                  'value' => $rule_data->event_id, 
                  'compare' => '=',
                )
            ),
        );
        $defaults = array('post_type' => 'em_booking', 'numberposts' => -1, 'orderby' => 'date', 'order' => 'ASC', 'post_status' => 'any');
        $args = wp_parse_args($args, $defaults);
        $posts = get_posts($args);
        if(empty($posts))
          return $no_of_uses;
        
        foreach($posts as $post){
            $id = $post->ID;
            $booking = new EventM_Booking_Model($id);
            $meta = $this->get_meta($id,'',true);
            if(!empty($meta)){
                foreach ($meta as $key => $val) {
                    $key = str_replace('em_','',$key);
                    if (property_exists($booking, $key)) {
                        $booking->{$key}= maybe_unserialize($val[0]);
                    }
                }
                // if temp booking then not count
                if($booking->booking_tmp_status == 1) {
                    continue;
                }
                /*if($booking->payment_log['payment_gateway'] == 'offline'){
                    if($booking->payment_log['offline_status'] != 'Received'){
                        continue;
                    }
                }*/
                if(isset($booking->order_info['applied_ebd']) && !empty($booking->order_info['applied_ebd']) && $booking->order_info['ebd_id'] == $rule_id){
                    ++$no_of_uses;
                }
            }
        }
        if($no_of_uses > 0){
            if($no_of_uses >= $rule_data->rule_user_limit){
                return 'false';
            }
        }
        return $no_of_uses;
    }
}