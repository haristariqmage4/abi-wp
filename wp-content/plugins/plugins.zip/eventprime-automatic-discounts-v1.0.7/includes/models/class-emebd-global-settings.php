<?php

class EventMEBD_Global_Settings_Model extends EventM_Global_Settings_Model
{
  public $allow_early_bird_discount;
}