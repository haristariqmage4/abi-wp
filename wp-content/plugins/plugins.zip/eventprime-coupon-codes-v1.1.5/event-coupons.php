<?php
/**
 * Plugin Name: EventPrime Coupon Codes
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that allows creating coupon codes for event booking discounts.
 * Version: 1.1.5
 * Author: EventPrime
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 6.1.1
 * Text Domain: eventprime-event-coupons
 * Domain Path: /languages
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_Coupons')) {
    final class EM_Coupons {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.1.5';

        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;
        
        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        /**
         * Cloning is forbidden.
         */
        public function __clone() {
            _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'eventprime-event-calendar-management'), $this->version);
        }

        /**
         * Unserializing instances of this class is forbidden.
         */
        public function __wakeup() {
            _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'eventprime-event-calendar-management'), $this->version);
        }

        /**
         * Event_Magic Constructor.
         */
        public function __construct() { 
            $this->define_constants();
            $this->load_textdomain();
            $this->includes();
            $this->define_hooks();
            $em = event_magic_instance();
            array_push($em->extensions,'coupons');
        }

        public function register_post_type(){
            register_post_type(EM_COUPON_POST_TYPE,
                array(
                    'labels' => array(
                        'name'                  => __( 'Coupons','eventprime-event-coupons'),
                        'singular_name'         => __( 'Coupon','eventprime-event-coupons'),
                        'add_new'               => __( 'Add Coupon','eventprime-event-coupons'),
                        'add_new_item'          => __( 'Add New Coupon','eventprime-event-coupons'),
                        'edit'                  => __( 'Edit','eventprime-event-coupons'),
                        'edit_item'             => __( 'Edit Coupon','eventprime-event-coupons'),
                        'new_item'              => __( 'New Coupon','eventprime-event-coupons'),
                        'view'                  => __( 'View','eventprime-event-coupons'),
                        'view_item'             => __( 'View Coupon','eventprime-event-coupons'),
                        'not_found'             => __( 'No Coupons found','eventprime-event-coupons'),
                        'not_found_in_trash'    => __( 'No Coupons found in trash','eventprime-event-coupons'),
                    ),
                    'description'         => __( 'Here you can add new coupons.','eventprime-event-coupons'),
                    'public'              => true,
                    'show_ui'             => false,
                    'map_meta_cap'        => true,
                    'publicly_queryable'  => true,
                    'exclude_from_search' => false,
                    'hierarchical'        => false, // Restrict WP to loads all records!
                    'query_var'           => true,
                    'capability_type'     => 'event_magic', 
                    'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'page-attributes', 'publicize', 'wpcom-markdown' ),
                    'show_in_nav_menus'   => false
                )
            );
        }       

        public function define_constants(){
            event_magic_instance()->define('EMCP_BASE_URL', plugin_dir_url(__FILE__));
            event_magic_instance()->define('EM_COUPON_POST_TYPE','em_coupon');
        }        

        public function includes(){
            include_once('includes/models/class-coupons.php'); // Loading model
            include_once('includes/dao/class-coupons.php'); // Loading DAO
            include_once('includes/services/class-coupons.php'); // Loading service class
            if(is_admin()){
                include('includes/admin/class-admin.php');
            }
        }

        public function define_hooks(){
            add_action('init', array($this, 'register_post_type'));
            add_action('wp_ajax_em_save_event_coupon', array($this, 'save_coupon'));
            add_action('wp_ajax_em_apply_event_coupon', array($this, 'apply_coupon'));
            add_action('wp_ajax_nopriv_em_apply_event_coupon', array($this, 'apply_coupon'));
            add_action('event_magic_gs_settings',array($this,'event_coupons_gs_settings'));
        }       

        public function load_textdomain(){
            load_plugin_textdomain('eventprime-event-coupons', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        public function save_coupon(){
            $service = EventM_Factory::get_service('EventM_Coupons_Service');
            $request = EventM_Raw_Request::get_instance();
            $model = $request->map_request_to_model('EventM_Coupons_Model');
            $model->id = absint(event_m_get_param('id'));
            $template = $service->save($model);
            // In case of any errors
            if ($template instanceof WP_Error) {
                $error_msg= $template->get_error_message(); 
                wp_send_json_error(array('errors' => array($error_msg)));
            }
            
            $redirect = admin_url('/admin.php?page=em_coupons');
            wp_send_json_success(array('redirect' => $redirect));
        }

        public function apply_coupon(){
            /*if (!is_user_logged_in())
                wp_die("User not logged in");*/
            $service = EventM_Factory::get_service('EventM_Coupons_Service');
            $postdata = $service->getCouponData();
            // In case of any errors
            if(isset($postdata['errors'])){
                wp_send_json_error(array('errors' => $postdata['errors']));
            }           
            wp_send_json_success(array('postdata' => $postdata['coupons'], "success" => $postdata['success']));
        }

        public function event_coupons_gs_settings(){?>
            <a href='javascript:void(0)'>
                <div class="em-settings-box ep-active-extension ep-no-global-settings-model" data-popup="ep-coupon-codes-ext" onclick="CallEPExtensionModal(this)">
                    <img class="em-settings-icon" ng-src="<?php echo EM_BASE_URL; ?>includes/admin/template/images/coupon-code-extension-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Coupon Codes', 'eventprime-event-coupons'); ?></div>
                    <span><?php _e('Create custom coupon codes.', 'eventprime-event-coupons'); ?></span>
                </div>
            </a>
            <?php
        }
    }
}

function em_coupons() {
    return EM_Coupons::instance();
}

function em_coupons_checks(){ ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e( 'EventPrime Coupons won\'t work as EventPrime plugin is not active/installed', 'eventprime-event-calendar-management' ); ?></p>
    </div>
<?php }

add_action('plugins_loaded',function(){if(!class_exists('Event_Magic')){add_action('admin_notices','em_coupons_checks');}});
add_action('event_magic_loaded', 'em_coupons');

require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/coupon_code_metadata.json',
    __FILE__,
    'eventprime-event-coupon-codes'
);