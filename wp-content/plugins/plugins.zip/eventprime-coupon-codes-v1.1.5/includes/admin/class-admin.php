<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class EM_Coupons_Admin {
	
    public function __construct() { 
        add_action('event_magic_menus', array($this, 'menus'));
        add_action('admin_enqueue_scripts', array($this,'enqueue'));
        add_action('event_magic_load_strings',array($this,'load_screen_data'));
        add_action('wp_ajax_em_admin_coupon_load_template', array($this, 'load_event_coupon_data'));
        add_action('wp_ajax_em_save_event_coupon', array($this, 'save_event_coupon'));
        add_action('wp_ajax_em_delete_event_coupon', array($this, 'delete_event_coupon'));
        $this->current_page = isset($_GET['page']) ? $_GET['page'] : '';
    }
    
    public function menus(){
        add_submenu_page("event_magic", __('Coupons', 'eventprime-event-coupons'), __('Coupons', 'eventprime-event-coupons'), "manage_options", "em_coupons", array($this, 'coupons'));
        add_submenu_page("", __('New Coupon', 'eventprime-event-coupons'), __('New Coupon', 'eventprime-event-coupons'), "manage_options", "em_add_new_coupon", array($this, 'coupons'));
    }
    
    public function coupons() {
       wp_enqueue_style('em_admin_coupons', plugin_dir_url(__DIR__) . 'admin/template/css/em_admin_coupons.css', false, EVENTPRIME_VERSION);

        wp_enqueue_script('em-timepicker', array('jquery') );
        wp_enqueue_script('em-coupons-controller');
        if($this->current_page == 'em_coupons'){
            include_once('template/coupons.php' );
        }
        else if($this->current_page == 'em_add_new_coupon'){
            include_once('template/coupon_add.php' );
        }
    }
    
    public function enqueue(){
        wp_register_script('em-coupons-controller',EMCP_BASE_URL.'includes/admin/template/js/em-coupons-controller.js',array('em-angular-module','em-timepicker'));
    }

    public function load_screen_data($context){
        $service = EventM_Factory::get_service('EventM_Coupons_Service');
        if($context == 'admin_coupon_templates'){
            $response = $service->load_list_page();
            wp_send_json_success($response);
        }
        else if($context == 'admin_coupon_template'){
            $coupons = $service->load_edit_page();
            wp_send_json_success(array('coupon' => $coupons));
        }
    }

    public function save_event_coupon(){
        $service = EventM_Factory::get_service('EventM_Coupons_Service');
        $request = EventM_Raw_Request::get_instance();
        $model = $request->map_request_to_model('EventM_Coupons_Model');
        $model->id = absint(event_m_get_param('id'));
        $template = $service->save($model);
        // In case of any errors
        if ($template instanceof WP_Error) {
            $error_msg = $template->get_error_message(); 
            wp_send_json_error(array('errors' => array($error_msg)));
        }
        
        $redirect = admin_url('/admin.php?page=em_coupons');
        wp_send_json_success(array('redirect' => $redirect));
    }

    public function delete_event_coupon(){
        $service = EventM_Factory::get_service('EventM_Coupons_Service');
        $request = EventM_Raw_Request::get_instance();
        $template = $service->delete();
        // In case of any errors
        if ($template instanceof WP_Error) {
            $error_msg = $template->get_error_message(); 
            wp_send_json_error(array('errors' => array($error_msg)));
        }
        
        $redirect = admin_url('/admin.php?page=em_coupons');
        wp_send_json_success(array('redirect' => $redirect));
    }

}
new EM_Coupons_Admin;