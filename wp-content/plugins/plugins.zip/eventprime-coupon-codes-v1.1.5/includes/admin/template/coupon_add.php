<div class="kikfyre kf-container" ng-app="eventMagicApp" ng-controller="couponsCtrl" ng-init="initialize('edit')" ng-cloak="">
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>
    <div class="kf-hidden" style="{{requestInProgress ?'display:none':'display:block'}}">
        <div class="kf-db-title">
            <?php _e('Add/Edit Coupon','eventprime-event-coupons'); ?>
        </div>
        <div class="form_errors">
            <ul>
                <li class="emfield_error" ng-repeat="error in formErrors">
                    <span>{{error}}</span>
                </li>
            </ul>  
        </div>
        <form name="couponForm" ng-submit="saveCoupon(couponForm.$valid)" novalidate >
            <div class="emrow">
                <div class="emfield"><?php _e('Name','eventprime-event-coupons'); ?><sup>*</sup></div>
                <div class="eminput">
                    <input required type="text" name="name" ng-model="data.coupon.name">
                    <div class="emfield_error">
                        <span ng-show="couponForm.name.$error.required && !couponForm.name.$pristine"><?php _e('This is  required field.','eventprime-event-coupons'); ?></span>
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Name the Coupon.','eventprime-event-coupons'); ?>
                </div>
            </div>

            <div class="emrow">
                <div class="emfield"><?php _e('Code','eventprime-event-coupons'); ?><sup>*</sup></div>
                <div class="eminput">
                    <input required type="text" name="code" ng-model="data.coupon.code">
                    <div class="emfield_error">
                        <span ng-show="couponForm.code.$error.required && !couponForm.code.$pristine"><?php _e('This is  required field.','eventprime-event-coupons'); ?></span>
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Coupon Code.','eventprime-event-coupons'); ?>
                </div>
            </div>

            <div class="emrow">
                <div class="emfield"><?php _e('Discount','eventprime-event-coupons'); ?><sup>*</sup></div>
                <div class="eminput">
                    <span ng-show="data.coupon.discount_type == 'Fixed'"><?php echo em_currency_symbol();?></span>
                    <input required type="number" string-to-number name="discount" ng-model="data.coupon.discount" min="0">
                    <div class="emfield_error">
                        <span ng-show="couponForm.discount.$error.required && !couponForm.discount.$pristine"><?php _e('This is  required field.','eventprime-event-coupons'); ?></span>
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Discount amount of Coupon.','eventprime-event-coupons'); ?>
                </div>
            </div>

            <div class="emrow">
                <div class="emfield"><?php _e('Discount Type','eventprime-event-coupons'); ?><sup>*</sup></div>
                <div class="eminput">
                    <select required ng-model="data.coupon.discount_type" name="discount_type" ng-options="group.key as group.label for group in data.coupon.discount_types_list">
                    </select>
                    <div class="emfield_error">
                        <span ng-show="couponForm.discount_type.$error.required && !couponForm.discount_type.$pristine"><?php _e('This is  required field.','eventprime-event-coupons'); ?></span>
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Discount type of Coupon.','eventprime-event-coupons'); ?>
                </div>
            </div>
            <div class="emrow">
                <div class="emfield">
                    <?php _e('Expiration By Date','eventprime-event-coupons'); ?>
                </div>
                <div class="eminput">
                    <input type="checkbox" string-to-number ng-model="data.coupon.is_expiry" ng-true-value="1" ng-false-value="0">
                </div>
                <div class="emnote">
                    <i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Enable Start Date and End Date', 'eventprime-event-coupons'); ?>
                </div>
            </div>
            <div class="emrow" ng-show="data.coupon.is_expiry == 1">
                <div class="emfield"><?php _e('Start Date','eventprime-event-coupons'); ?></div>
                <div class="eminput">
                    <input id="event_coupon_start_date" type="text" name="start_date" ng-model="data.coupon.start_date" autocomplete="off">
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Start date of Coupon.','eventprime-event-coupons'); ?>
                </div>
            </div>

            <div class="emrow" ng-show="data.coupon.is_expiry == 1">
                <div class="emfield"><?php _e('End Date','eventprime-event-coupons'); ?></div>
                <div class="eminput">
                    <input id="event_coupon_end_date" type="text" name="end_date" ng-model="data.coupon.end_date" autocomplete="off">
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('End date of Coupon.','eventprime-event-coupons'); ?>
                </div>
            </div>

            <div class="emrow">
                <div class="emfield"><?php _e('Active','eventprime-event-coupons'); ?></div>
                <div class="eminput">
                    <input type="checkbox" name="is_active" string-to-number ng-model="data.coupon.is_active" ng-true-value="1" ng-false-value="0">
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Activate/Deactivate Coupon.','eventprime-event-coupons'); ?>
                </div>
            </div>

            <div class="emrow">
                <div class="emfield"><?php _e('Uses per Customer','eventprime-event-coupons'); ?></div>
                <div class="eminput">
                    <input required type="number" string-to-number name="uses_per_customer" ng-model="data.coupon.uses_per_customer" min="0">
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('To limit coupon total uses by user. 0 will mean no limit.','eventprime-event-coupons'); ?>
                </div>
            </div>

            <div class="emrow">
                <div class="emfield"><?php _e('Limit by Total Uses','eventprime-event-coupons'); ?></div>
                <div class="eminput">
                    <input required type="number" string-to-number name="total_uses_limit" ng-model="data.coupon.total_uses_limit" min="0">
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('To limit coupon uses by total number in addition to per user limit. 0 will mean no limit.','eventprime-event-coupons'); ?>
                </div>
            </div>
            <div class="emrow kf-bg-light">
                <div class="emfield emeditor"><?php _e('Description','eventprime-event-coupons'); ?></div>
                <div class="eminput emeditor">
                    <?php 
                    $coupon_id= event_m_get_param('coupon_id');
                    $content='';
                    if($coupon_id!==null && (int)$coupon_id>0){             
                        $post = get_post($coupon_id);
                        if(!empty($post))
                            $content = $post->post_content;
                    }
                    wp_editor($content,'description');
                    ?>
                    <div class="emfield_error"></div>
                </div>
                <div class="emnote emeditor">
                    <?php _e('Description','eventprime-event-coupons'); ?>
                </div>
            </div>

            <div class="dbfl kf-buttonarea">
                <div class="em_cancel"><a class="kf-cancel" href="<?php echo admin_url('admin.php?page=em_coupons'); ?>"><?php _e('Cancel','eventprime-event-coupons'); ?></a></div>
                <button type="submit" class="btn btn-primary" ng-disabled="couponForm.$invalid || requestInProgress"><?php _e('Save','eventprime-event-coupons'); ?></button>
                <span class="kf-error" ng-show="couponForm.$invalid && couponForm.$dirty "><?php _e('Please fill all required fields.','eventprime-event-coupons'); ?></span>
            </div>

            <div class="dbfl kf-required-errors" ng-show="couponForm.$invalid && couponForm.$dirty">
                <h3><?php _e("Looks like you missed out filling some required fields (*). You will not be able to save until all required fields are filled in. Here’s what's missing",'eventprime-event-coupons'); ?> - 
                    <span ng-show="couponForm.name.$error.required"><?php _e("Name",'eventprime-event-coupons'); ?></span>
                    <span ng-show="couponForm.code.$error.required"><?php _e('Code','eventprime-event-coupons'); ?></span>
                    <span ng-show="couponForm.discount.$error.required"><?php _e('Discount','eventprime-event-coupons'); ?></span>
                    <span ng-show="couponForm.discount_type.$error.required"><?php _e('Discount Type','eventprime-event-coupons'); ?></span>
                </h3>
            </div>
        </form>
    </div>
</div>