eventMagicApp.controller('couponsCtrl', function($scope, $http, EMRequest){
  $scope.data = {};
  $scope.requestInProgress = false;
  $scope.formErrors = [];
  $scope.selections = [];
  $scope.paged = 1;
  $ = jQuery;

  $scope.progressStart = function()
  {
    $scope.requestInProgress = true;
  }

  $scope.progressStop = function()
  {
    $scope.requestInProgress = false;
  }

  /**
   * initialize function
   */
  $scope.initialize = function(type)
  {
    if(type == 'list'){
      $scope.prepareListPage();
    }
    else{
      $scope.preparePageData();
    }
  }

  /**
   * prepare list page
   */
  $scope.prepareListPage = function(){
    $scope.data.paged = $scope.paged;
    $scope.data.em_request_context = 'admin_coupon_templates';
    $scope.progressStart();
    EMRequest.send('em_load_strings',$scope.data).then(function(response){
      $scope.progressStop();
      var responseBody = response.data;
      if(responseBody.success){
        $scope.data = responseBody.data;
      }
    });
  }
  /**
   * prepare add / edit page
   */
  $scope.preparePageData = function () {
    $scope.progressStart();
    
    $scope.data.em_request_context = 'admin_coupon_template';
    $scope.data.coupon = {};
    $scope.data.coupon.is_active = "1";
    $scope.data.coupon.uses_per_customer = 0;
    $scope.data.coupon.total_uses_limit = 0;
    var dt = [{'key' : 'Fixed', 'label' : 'Fixed'}, {'key' : 'Percentage', 'label' : 'Percentage'}];
    $scope.data.coupon.discount_types_list = dt;
    $scope.initializeDateTimePickers();
    $scope.data.coupon_id = em_get('coupon_id');
    if($scope.data.coupon_id){
      $scope.progressStart();
      EMRequest.send('em_load_strings', $scope.data).then(function(response){
        var responseBody = response.data;
        if(!responseBody.success)
          return;
        $scope.data = responseBody.data;
        var dt = [{'key' : 'Fixed', 'label' : 'Fixed'}, {'key' : 'Percentage', 'label' : 'Percentage'}];
        $scope.data.coupon.discount_types_list = dt;
      });
      $scope.progressStop();
    }
    $scope.progressStop();
  };
  /**
   * Initialize start date and end date fields
   */
  $scope.initializeDateTimePickers = function(){
    $("#event_coupon_start_date").datetimepicker({controlType: 'select',oneLine: true,timeFormat: 'HH:mm',changeYear: true});
    $("#event_coupon_end_date").datetimepicker({controlType: 'select',oneLine: true,timeFormat: 'HH:mm',changeYear: true});
  }

  /**
   * function to save coupon
   */
  $scope.saveCoupon = function(isValid){
    if(!isValid){
      return;
    }
    $scope.formErrors= [];
    if( $('#description').is(':visible') ) 
      $scope.data.coupon.description = $('#description').val();
    else 
      $scope.data.coupon.description = tinymce.get('description').getContent();
    // check for set expiry
    if(!$scope.data.coupon.is_expiry){
    	$scope.data.coupon.start_date = '';
    	$scope.data.coupon.end_date = '';
    }

    $scope.progressStart();
    EMRequest.send('em_save_event_coupon', $scope.data.coupon).then(function(response){
      $scope.progressStop();
      var responseBody = response.data;
      if(responseBody.success){
        if(responseBody.data.hasOwnProperty('redirect')){
          location.href = responseBody.data.redirect;
        }
      }
      else
      {
        if(responseBody.data.hasOwnProperty('errors')){
          $scope.formErrors = responseBody.data.errors;
          jQuery('html, body').animate({ scrollTop: 0 }, 'slow');
        }
      }
    });
  }

  /*
   * Select item
   */
  $scope.selectCoupon = function(coupon_id){
    if($scope.selections.indexOf(coupon_id) >= 0)
      $scope.selections = em_remove_from_array($scope.selections,coupon_id);
    else
      $scope.selections.push(coupon_id);
  }

  /*
   * Select all coupon code lists
   */
  $scope.checkAll = function () {    
    angular.forEach($scope.data.coupons, function (coupon) {
      if ($scope.selectedAll) { 
        $scope.selections.push(coupon.id);
        coupon.Selected = $scope.selectedAll ? coupon.id : 0; 
      }
      else{
        $scope.selections = [];
        coupon.Selected = 0;
      }
    });
  };

  /*
   * Function to delete coupon
   */
  $scope.deleteCoupons = function(){
    var confirmed = confirm("Do you want to delete this coupon ?");
    if(confirmed){
      EMRequest.send('em_delete_event_coupon', $scope.selections).then(function(response){
        $scope.progressStop();
        var responseBody = response.data;
        if(responseBody.success){
          if(responseBody.data.hasOwnProperty('redirect')){
            location.href = responseBody.data.redirect;
          }
        }
        else{
          if(responseBody.data.hasOwnProperty('error')){
            $scope.formErrors = responseBody.data.errors;
          }
        }
      });
    } 
  }

  $scope.pageChanged = function(newPage) {
    $scope.selectedAll = false;
    $scope.paged = newPage;
    $scope.prepareListPage();
  };
})
.directive('stringToNumber', function() {
  return {
    require: 'ngModel',
    link: function(scope, element, attrs, ngModel) {
      ngModel.$parsers.push(function(value) {
        return '' + value;
      });
      ngModel.$formatters.push(function(value) {
        return parseFloat(value);
      });
    }
  };
});