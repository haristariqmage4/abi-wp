<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/**
 * @summary Dao class for Event Coupons. 
 * 
 * Functions
 * 1. edit_event_coupons :  Responsible for adding and editing the record.
 */
class EventM_Coupons_DAO extends EventM_Post_Dao
{
  public function __construct() {
    $this->post_type = EM_COUPON_POST_TYPE;
  }
  public function get($id)
  {
    $post = get_post($id);
    if(empty($post))
      return new EventM_Coupons_Model(0);
    $coupons = new EventM_Coupons_Model($id);
    $meta = $this->get_meta($id,'',true);
    foreach ($meta as $key => $val) {
      $key = str_replace('em_','',$key);
      if (property_exists($coupons, $key)) {
        $coupons->{$key} = maybe_unserialize($val[0]);
      }
    }
    $coupons->id = $post->ID;
    $coupons->name = $post->post_title;
    return $coupons;
  }

  public function save($model){
    if(!empty($this->is_coupon_code_exist($model))){
      // coupon code already exist
      return new WP_Error( 'broke', __( 'Coupon Code Already Exist.','eventprime-event-coupons' ) );
    }

    if(!empty($model->is_expiry)){
      if(!empty($model->start_date)){
        $sdt = strtotime($model->start_date);
        $model->start_date = $sdt;
      }
      if(!empty($model->end_date)){
        $edt = strtotime($model->end_date);
        $model->end_date = $edt;
      }
      if(!empty($edt) && !empty($sdt)){
        if($edt < $sdt){
          return new WP_Error( 'broke', __( 'Expiration End Date should be greater then Expiration Start Date','eventprime-event-coupons' ) );
        }
      }
    }
    else{
      $model->start_date = $model->end_date = '';
    }
    if(!empty($model->total_uses_limit) && !empty($model->uses_per_customer)){
      if($model->total_uses_limit < $model->uses_per_customer){
        return new WP_Error( 'broke', __( 'Total uses limit should not be less then uses per customer','eventprime-event-coupons' ) );
      }
    }
    $post_id = parent::save($model);
    if ($post_id instanceof WP_Error) {
      return false;
    }
    return $this->get($post_id);
  }

  private function is_coupon_code_exist($coupon){
    $is_exist = 0;
    $code = $coupon->code;
    $id = '';
    if(isset($coupon->id)){
      $id = $coupon->id;
    }
    $args = array(
      'post_type'      => $this->post_type,
      'posts_per_page' => -1,
      'meta_query'     => array(
        array(
          'key'   => 'em_code',
          'value' => $code,
        )
      ),
    );
    $posts = get_posts($args);
    if(!empty($posts)){
      $is_exist = 1;
      if(!empty($id)){
        $postId = $posts[0]->ID;
        if($postId == $id){
          $is_exist = 0;
        }
      }
    }
    return $is_exist;
  }

  public function fetchCouponData($couponData){
    $returnData = array();
    $args = array(
      'post_type'      => $this->post_type,
      'posts_per_page' => -1,
      'meta_query'     => array(
        array(
          'key'   => 'em_code',
          'value' => $couponData->couponcode,
        )
      ),
    );
    $posts = get_posts($args);
    if(empty($posts)){
      // user entered wronge coupon code
      $returnData['errors'] = __('Invalid Coupon Code.','eventprime-event-coupons');
      return $returnData;
    }
    $id = $posts[0]->ID;
    $coupons = new EventM_Coupons_Model($id);
    $meta = $this->get_meta($id,'',true);
    foreach ($meta as $key => $val) {
      $key = str_replace('em_','',$key);
      if (property_exists($coupons, $key)) {
        $coupons->{$key} = maybe_unserialize($val[0]);
      }
    }
    // check for coupon code activation
    if(empty($coupons->is_active)){
      $returnData['errors'] = __('Invalid Coupon Code.','eventprime-event-coupons');
      return $returnData;
    }
    // check early bird condition
    $earlyBird = $this->chkEarlyBirdConditions($coupons);
    if(isset($earlyBird['error_msg'])){
      $returnData['errors'] = $earlyBird['error_msg'];
      return $returnData;
    }
    // check uses per customer condition
    if($coupons->uses_per_customer > 0){
      $usesCondition = $this->chkUsesPerUserConditions($coupons, $couponData);
      if(isset($usesCondition['error_msg'])){
        $returnData['errors'] = $usesCondition['error_msg'];
        return $returnData;
      }
    }
    // get total no. of uses of a coupon code
    if($coupons->total_uses_limit > 0){
      $totalUses = $this->getCouponUses($couponData->couponcode);
      if($totalUses >= $coupons->total_uses_limit){
        $returnData['errors'] = $return['error_msg'] = __('Coupon code uses reached at maximum limit.','eventprime-event-coupons');
        return $returnData;
      }
    }
    $coupons->id = $id;
    $coupons->name = $posts[0]->post_title;
    $success_msg = __('Coupon Applied Successfully.','eventprime-event-coupons');
    $returnData = array("success" => $success_msg, "coupons" => $coupons);
    return $returnData;
  }

  public function deleteCoupon($coupons){
    $this->check_permission();
    if(!empty($coupons) && is_array($coupons)){
      foreach ($coupons as $id) {
        $postData = get_posts(
          array(
            'ID' => $id,
            'post_type' => EM_COUPON_POST_TYPE,
            'status' => 'any'
          )
        );
        if(!empty($postData)) {
          wp_delete_post($id, true);
        }
      }
      return 'success';
    }
    return null;
  }

  private function check_permission(){
    if(!em_is_user_admin()){
      $error_msg = __('User not allowed','eventprime-event-coupons');
      wp_send_json_error(array('errors'=>array($error_msg)));
    }
  }
  /**
   * function to check early bird conditions
   */
  private function chkEarlyBirdConditions($data){
    $return = array();
    if(empty($data->is_expiry)){
      $return['success'] = 1;
      return $return;
    }
    $today = em_current_time_by_timezone();
    $start_date = $data->start_date;
    $end_date = $data->end_date;
    if(!empty($start_date)){
      if($today < $start_date){
        $return['error_msg'] = __('Invalid Coupon Code','eventprime-event-coupons');
        return $return;
      }
    }
    if(!empty($end_date)){
      if($today > $end_date){
        $return['error_msg'] = __('Coupon Code Expired','eventprime-event-coupons');
        return $return;
      }
    }
    $return['success'] = 1;
    return $return;
  }
  /**
   * function to check uses per customer condition
   */
  private function chkUsesPerUserConditions($data, $couponData){
    $noOfUses = 0;
    $user = wp_get_current_user();
    $return = array();
    if(!empty($user) && !empty($user->ID)){
      $args = array(
        'numberposts' => -1,
        'orderby' => 'date',
        'order' => 'DESC',
        'post_status'=> 'any',
        'meta_query' => array(
          array(
            'key' => em_append_meta_key('user'), 
            'value' => $user->ID, 
            'compare' => '=', 
            'type' => 'NUMERIC,'
          ),
          array(
            'key' => em_append_meta_key('event'), 
            'value' => $couponData->event_id, 
            'compare' => '=',
          )
        ),
      );
      $defaults = array('post_type' => 'em_booking', 'numberposts' => -1, 'orderby' => 'date', 'order' => 'ASC', 'post_status' => 'any');
      $args = wp_parse_args($args, $defaults);
      $posts = get_posts($args);
      if(empty($posts))
        return array();
      $bookings = array();
      foreach($posts as $post){
        $id = $post->ID;
        $booking = new EventM_Booking_Model($id);
        $meta = $this->get_meta($id,'',true);
        if(!empty($meta)){
          foreach ($meta as $key => $val) {
            $key= str_replace('em_','',$key);
            if (property_exists($booking, $key)) {
              $booking->{$key}= maybe_unserialize($val[0]);
            }
          }
          // if temp booking then not count
          if($booking->booking_tmp_status == 1) {
            continue;
          }
          if($booking->payment_log['payment_gateway'] == 'offline'){
            if($booking->payment_log['offline_status'] != 'Received'){
              continue;
            }
          }
          $usedCode = $booking->order_info['coupon_code'];
          if(!empty($usedCode) && $usedCode == $couponData->couponcode){
            $noOfUses++;
          }
        }
      }
      if($noOfUses >= $data->uses_per_customer){
        $return['error_msg'] = __('You used code at maximum times','eventprime-event-coupons');
        return $return;
      }
    }
    return $return;
  }
  /**
   * function to get no. of uses of a coupon code
   */
  public function getCouponUses($couponCode){
    $noOfUses = 0;
    $user = wp_get_current_user();
    $return = array();
    $args = array(
      'numberposts' => -1,
      'orderby' => 'date',
      'order' => 'DESC',
      'post_status'=> 'any',
    );
    $defaults = array('post_type' => 'em_booking', 'numberposts' => -1, 'orderby' => 'date', 'order' => 'ASC', 'post_status' => 'any');
    $args = wp_parse_args($args, $defaults);
    $posts = get_posts($args);
    if(empty($posts))
      return $noOfUses;
    $bookings = array();
    foreach($posts as $post){
      $id = $post->ID;
      $booking = new EventM_Booking_Model($id);
      $meta = $this->get_meta($id,'',true);
      if(!empty($meta)){
        foreach ($meta as $key => $val) {
          $key = str_replace('em_','',$key);
          if (property_exists($booking, $key)) {
            $booking->{$key}= maybe_unserialize($val[0]);
          }
        }
        if(isset($booking->order_info['parent_booking_id']) && !empty($booking->order_info['parent_booking_id'])){
          continue;
        }
        // if temp booking then not count
        if($booking->booking_tmp_status == 1) {
          continue;
        }
        if($booking->payment_log['payment_gateway'] == 'offline'){
          if($booking->payment_log['offline_status'] != 'Received'){
            continue;
          }
        }
        $usedCode = $booking->order_info['coupon_code'];
        if(!empty($usedCode) && $usedCode == $couponCode){
          $noOfUses++;
        }
      }
    }
    return $noOfUses;
  }
}