<?php

class EventM_Coupons_Model extends EventM_Array_Model
{
    public $id;
    public $name;
    public $code;
    public $discount;
    public $description = '';
    public $discount_type;
    public $is_expiry = 0;
    public $start_date = '';
    public $end_date = '';
    public $is_active = false;
    public $priority = 1;
    public $uses_per_customer = 0;
    public $total_uses_limit = 0;
    public $status = "publish";
}