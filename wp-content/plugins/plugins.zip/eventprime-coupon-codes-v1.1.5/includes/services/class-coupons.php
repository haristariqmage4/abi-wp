<?php
if (!defined( 'ABSPATH')){
    exit;
}

class EventM_Coupons_Service {
    
    private $dao;
    private static $instance = null;
    
    private function __construct() {
        $this->actions();
        $this->dao = new EventM_Coupons_DAO();
    }
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }
    
    public function actions(){
        add_action( 'event_magic_front_coupon_section', array($this, 'front_coupon_section'), 10, 1 );
    }

    public function front_coupon_section(){
        $extensions = event_magic_instance()->extensions;
        if(!in_array('coupons', $extensions)){
            return;
        }?>

        <div class="ep-coupon-code-wrap" ng-show="price &gt; 0">
            <div class="ep-coupon-code-input">
                <label><?php _e('Enter Coupon Code', 'eventprime-event-coupons'); ?></label>
                <input type="text" ng-model="couponCode" placeholder="<?php _e('Enter Coupon Code', 'eventprime-event-coupons'); ?>" class="ep-coupon-code">
            </div>
            
            <div class="ep-coupon-code-button">
                <button type="button" ng-disabled="couponCode == ''" ng-hide="couponCodeApplied == 1" ng-click="applyCoupon()" class="ep-coupon-code-button"><?php _e('Apply', 'eventprime-event-coupons'); ?></button>
                <button type="button" ng-show="couponCodeApplied == 1" ng-click="cancelCoupon()" class="ep-coupon-code-button"><?php _e('Cancel', 'eventprime-event-coupons'); ?></button>
            </div>
        </div>

        <div id="kf-reconfirm-popup" class="dbfl" ng-show="couponAppliedPopup" ng-cloak>
            <div class="dbfl em_block kf-reconfirm-popup-content">
                <p>{{ couponPopupMsg }}</p>
                <button type="button" ng-click="hideCouponPopup()" class="btn btn-warning btn-sm"><?php _e('OK', 'eventprime-event-coupons'); ?></button>
            </div>
        </div>
        <div id="kf-reconfirm-popup" class="dbfl" ng-show="couponCanceledPopup" ng-cloak>
            <div class="dbfl em_block kf-reconfirm-popup-content">
                <p><?php _e('Coupon Removed Successfully'); ?></p>
                <button type="button" ng-click="hideCouponPopup()" class="btn btn-warning btn-sm"><?php _e('OK', 'eventprime-event-coupons'); ?></button>
            </div>
        </div>
        <?php
    }

    public function load_edit_page()
    {
        $coupon_id = absint(event_m_get_param('coupon_id')); 
        $coupons = $this->load_model_from_db($coupon_id);
        if(!empty($coupons->start_date)){
            $start_date = date("F d, Y H:i", $coupons->start_date);
            $coupons->start_date = $start_date;
        }
        if(!empty($coupons->end_date)){
            $end_date = date("F d, Y H:i", $coupons->end_date);
            $coupons->end_date = $end_date;
        }
        return $coupons;
    }
    
    public function load_list_page(){
        $response = new stdClass();
        $response->coupons = array();
         
        $args = array(
            'posts_per_page' => EM_PAGINATION_LIMIT,
            'offset' => ((int) event_m_get_param('paged')-1) * EM_PAGINATION_LIMIT,
            'post_type' => EM_COUPON_POST_TYPE,
            'post_status' => 'publish');
        $templates = get_posts($args);
        
        foreach($templates as $tmp){
           $template = $this->load_model_from_db($tmp->ID);
           $data = $template->to_array();
           // get total no of uses
           $noOfUses = $this->getCouponUses($data['code']);
           $data['no_of_uses'] = $noOfUses;
           if(!empty($data['start_date'])){
                $start_date = date("F d, Y H:i", $data['start_date']);
                $data['start_date'] = $start_date;
            }
            if(!empty($data['end_date'])){
                $end_date = date("F d, Y H:i", $data['end_date']);
                $data['end_date'] = $end_date;
            }
           $response->coupons[] = $data;
        }
        
        $post_count_obj = wp_count_posts($this->dao->post_type);
        $post_count = $post_count_obj->publish;
        $response->total_posts = range(1, $post_count);
        $response->pagination_limit = EM_PAGINATION_LIMIT;
        return $response;
    }
    
    public function save($model){
        $template = $this->dao->save($model);
        return $template;
    }
    
    public function load_model_from_db($id){
        return $this->dao->get($id);
    }
    
    public function map_request_to_model($id, $model=null){  
        $coupons = new EventM_Coupons_Model($id);
        $data = (array) $model;
        if(!empty($data) && is_array($data)){
            foreach($data as $key=>$val){
                $method= "set_".$key;
                if(method_exists($coupons, $method)){
                    $coupons->$method($val);
                }
            }
        }
        return $coupons;
    }

    public function delete(){
        $input = file_get_contents("php://input");
        $coupons = json_decode($input);
        $template = $this->dao->deleteCoupon($coupons);
        return $template;
    }

    public function getCouponData(){
        $input = file_get_contents("php://input");
        $coupon = json_decode($input);
        $couponData = $this->dao->fetchCouponData($coupon);
        return $couponData;
    }

    public function getCouponUses($couponCode){
        return $this->dao->getCouponUses($couponCode);
    }
}
EventM_Coupons_Service::get_instance();
