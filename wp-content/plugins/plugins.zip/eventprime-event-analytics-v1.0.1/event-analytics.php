<?php
/**
 * Plugin Name: EventPrime Analytics
 * Plugin URI: http://eventprime.net
 * Description: An EventPrime extension that adds a complete event analytics dashboard for your events.
 * Version: 1.0.1
 * Author: EventPrime
 * Author URI: http://eventprime.net
 * Requires at least: 4.8
 * Tested up to: 5.7.1
 * Text Domain: eventprime-event-analytics
 * Domain Path: /languages
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('EM_Analytics')) {

    final class EM_Analytics {
        /**
         * Plugin version.
         *
         * @var string
         */
        public $version = '1.0.1';

        /**
         * The single instance of the class.
         *
         * @var Event_Magic
         */
        protected static $_instance = null;

        
        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        /**
         * Cloning is forbidden.
         */
        public function __clone() {
            _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'event_magic'), $this->version);
        }

        /**
         * Unserializing instances of this class is forbidden.
         */
        public function __wakeup() {
            _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'event_magic'), $this->version);
        }

        /**
         * Event_Magic Constructor.
         */
        public function __construct() { 
            $this->define_constants();
            $this->load_textdomain();
            $this->includes();
            $this->global_actions();
            $em= event_magic_instance();
            array_push($em->extensions,'analytics');
        }
        
        public function define_constants(){
            event_magic_instance()->define('EMA_BASE_URL', plugin_dir_url(__FILE__));
        }
        
        public function includes(){
            include_once('includes/services/class-analytics.php'); // Loading service class
            if(is_admin()){
                include('includes/admin/class-admin.php');
            }
        }
        
        public function load_textdomain(){
            load_plugin_textdomain('eventprime-event-analytics', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        public function global_actions() {
            add_action('event_magic_gs_settings',array($this,'event_analytics_gs_settings'));
        }

        public function event_analytics_gs_settings(){?>
            <a href='javascript:void(0)'>
                <div class="em-settings-box ep-active-extension ep-no-global-settings-model" data-popup="ep-events-analytics-ext" onclick="CallEPExtensionModal(this)">
                    <img class="em-settings-icon" ng-src="<?php echo EM_BASE_URL; ?>includes/admin/template/images/ep-analytics-icon.png">
                    <div class="em-settings-description"></div>
                    <div class="em-settings-subtitle"><?php _e('Analytics', 'eventprime-event-analytics'); ?></div>
                    <span><?php _e('Analyze bookings data.', 'eventprime-event-analytics'); ?></span>
                </div>
            </a>
            <?php
        }
        
    }

}

function em_analytics() {
    return EM_Analytics::instance();
}

function em_analytic_checks(){ ?>
    <div class="notice notice-success is-dismissible">
         <p><?php _e( 'EventPrime Analytics won\'t work as EventPrime plugin is not active/installed', 'event-magic' ); ?></p>
    </div>
<?php }

add_action('plugins_loaded',function(){if(!class_exists('Event_Magic')){add_action('admin_notices','em_analytic_checks');}});
add_action('event_magic_loaded', 'em_analytics');
require_once plugin_dir_path( __FILE__ ) .'extension-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://eventprime.net/event_analytics_metadata.json',
    __FILE__,
    'eventprime-event-analytics'
);