<?php
class EM_Analytics_Admin {
	
    public function __construct() { 
        add_action('event_magic_menus', array($this, 'menus'));
        add_action('event_magic_admin_enqueues',array($this,'enqueue'));
        add_action('wp_ajax_em_load_chart',array($this,'load_chart'));
        add_action('event_magic_load_strings',array($this,'load_screen_data'));
    }
    
    public function menus(){
        add_submenu_page("event_magic", __('Analytics', 'eventprime-event-analytics'), __('Analytics', 'eventprime-event-analytics'), "manage_options", "em_analytics", array($this, 'analytics'));
    }
    
    public function analytics() {
        wp_enqueue_script('jquery-ui-datepicker', array('jquery') );
        wp_enqueue_script('google_charts');
        wp_enqueue_script('em-analytic-controller');
        wp_enqueue_style('jquery-style', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/smoothness/jquery-ui.css');
        include_once('template/analytics.php' );
    }
    
    public function enqueue(){
        wp_register_script('em-analytic-controller',EMA_BASE_URL.'includes/admin/template/js/em-analytic-controller.js',array('em-angular-module'));
    }
    
    public function load_screen_data($context){
        $service = EventM_Analytics_Service::get_instance();
        if($context=='admin_analytics'){
            $service->load_options();
        }
    }
    
    public function load_chart(){
        $service = EventM_Analytics_Service::get_instance();
        $response = $service->get_chart_data();
        echo json_encode($response);
        die;
    }
}
new EM_Analytics_Admin;