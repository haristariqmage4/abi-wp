<div class="kikfyre" ng-app="eventMagicApp" ng-controller="analyticCtrl" ng-init="initialize()" ng-cloak="">
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>
    <div class="kf-titlebar_dark dbfl">
        <div class="kf-title kf-title-1 difl"><?php _e('Analytics','eventprime-event-analytics'); ?></div>
    </div>
    <form  class="em-filters-form dbfl" name="filterForm" novalidate >
        
        <div class="kf-filter-1 em-filter-bar dbfl">
            <div>
                <select class="kf-filter-bar kf-dropdown difl" name="report_by" ng-model="data.filter_type" ng-change="showFilters()">
                <option value=""><?php _e('Select Type','eventprime-event-analytics'); ?></option>
                <option value="revenue"><?php _e('Revenue','eventprime-event-analytics'); ?></option>
                <option value="booking"><?php _e('Booking','eventprime-event-analytics'); ?></option>
            </select>
        </div>
        </div>    
        <div class="filters em-filter-bar dbfl" ng-show="showFilterOptions">
            <div>
                <select class="kf-dropdown difl" name="report_by" ng-model="data.report_by" required>
                    <option value="today" selected><?php _e('Today','eventprime-event-analytics'); ?></option>
                    <option value="yesterday"><?php _e('Yesterday','eventprime-event-analytics'); ?></option>
                    <option value="this_week"><?php _e('This Week','eventprime-event-analytics'); ?></option>
                    <option value="last_week"><?php _e('Last Week','eventprime-event-analytics'); ?></option>
                    <option value="this_month"><?php _e('This Month','eventprime-event-analytics'); ?></option>
                    <option value="last_month"><?php _e('Last Month','eventprime-event-analytics'); ?></option>
                    <option value="this_year"><?php _e('This Year','eventprime-event-analytics'); ?></option>
                    <option value="last_year"><?php _e('Last Year','eventprime-event-analytics'); ?></option>
                    <option value="custom"><?php _e('Custom','eventprime-event-analytics'); ?></option>
                </select>
            </div>
        
            <div>
                <select class="kf-dropdown difl" name="venue" ng-model="data.venue" ng-options="venue.id as venue.name for venue in data.venues ">
                    
                </select>
            </div>
        
            <div>
                <select class="kf-dropdown difl" name="event" ng-model="data.event" ng-options="event.id as event.name for event in data.events ">
                    
                </select>
            </div>
                
           <div ng-show="data.report_by=='custom'" class="dbfl">
                <div class="difl kf-custom-date">
                    <span class="difl"><?php _e('Start Date','eventprime-event-analytics'); ?></span>
                    <div><input class="difl" type="text" ng-required="data.report_by=='custom'" id="start_date" name="start_date" ng-model="data.start_date" /></div>
                </div>
                <div class="difl kf-custom-date">
                    <span class="difl"><?php _e('End Date','eventprime-event-analytics'); ?></span>
                    <div><input class="difl" type="text" ng-required="data.report_by=='custom'" id="end_date" name="end_date" ng-model="data.end_date" /></div>
                </div>
            </div>
            
        <div class="kf-filter-button">		
            <input type="button" value="Reset" onclick="location.reload()" class="btn btn-primary kf-upload" />  		
 -      </div>
            
        <div class="kf-filter-button">
            <input type="button" class="btn btn-primary kf-upload" ng-disabled="filterForm.$invalid" value="Filter" ng-click="getData()" />
        </div>    
    </div>
   </form>
    
 
    <div id="revenue_chart" class="dbfl" style="width: 900px; height: 500px"></div>
    <div id="booking_chart" class="dbfl" style="width: 900px; height: 500px"></div>
</div>


