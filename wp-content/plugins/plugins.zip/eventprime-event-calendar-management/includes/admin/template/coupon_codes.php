<div class="kikfyre ep-banner-container">
    <div class="kf-titlebar dbfl">
        <div class="kf-db-title difl"><?php _e('Coupon Codes','eventprime-event-calendar-management'); ?></div>
    </div>
    <?php do_action('event_magic_admin_bottom_premium_banner'); ?>
</div>