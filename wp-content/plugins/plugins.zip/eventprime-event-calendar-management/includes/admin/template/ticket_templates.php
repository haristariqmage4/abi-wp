<div class="kikfyre ep-banner-container">
    <div class="kf-titlebar dbfl">
        <div class="kf-db-title dbfl"><?php _e('Ticket Manager', 'eventprime-event-calendar-management'); ?></div>
    </div>
    <?php do_action('event_magic_admin_bottom_premium_banner'); ?>
</div>